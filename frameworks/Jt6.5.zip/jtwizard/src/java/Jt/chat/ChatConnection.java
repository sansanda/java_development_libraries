package Jt.chat;

public class ChatConnection  {

    public static final String JtCLASS_NAME = ChatConnection.class.getName(); 
    private static final long serialVersionUID = 1L;
    private long sequence;   
 

    public long getSequence() {
        return sequence;
    }



    public void setSequence(long sequence) {
        this.sequence = sequence;
    }

}