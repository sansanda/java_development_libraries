package Jt.chat.form;
import org.apache.struts.validator.ValidatorForm;

public class ChatForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;

    private String messageArea;    
    private String message;
    private String chatId;
    
    

    public String getMessageArea() {
        return messageArea;
    }

    public void setMessageArea(String messageArea) {
        this.messageArea = messageArea;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getChatId() {
        return chatId;
    }

    public void setChatId(String chatId) {
        this.chatId = chatId;
    }



}
 