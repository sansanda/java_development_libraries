package Jt.chat;


import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.chat.form.ChatForm;




public class ChatActionHandler extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = ChatActionHandler.class.getName();  
    transient JtFactory factory = new JtFactory ();
    transient JtContext context;
      

    
    private ChatForm retrieveChatForm (String chatId) {
        ChatForm chatForm;
        
        if (chatId == null)
            return (null);
        
        chatForm = new ChatForm ();
        
        
        chatForm.setChatId(chatId);
        
        return (chatForm);
        
    }

    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;

        //String chatId;
        //Chat chat;
        ChatManager chatManager;
        ChatForm form;
        JtMessage msg;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        content = e.getMsgContent();
        context = (JtContext) e.getMsgContext();

        
        if (e.getMsgId().equals (JtObject.JtDELETE)) {
            
            return null;            
        }

        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context"); // fix
            return (null);
        }
        
        
        // Create the ChatManager (singleton)
        
        
        chatManager = (ChatManager) factory.createObject(ChatManager.JtCLASS_NAME);
        
        
        if (e.getMsgId().equals (Chat.JtSEND)) {
            form = (ChatForm) context.getActionForm();  
                        
            if (form == null)
                return (null);
            
            msg = new JtMessage (Chat.JtSEND);
            
            msg.setMsgContent(form.getMessage());
            msg.setMsgData(form.getChatId());
            msg.setMsgContext(context);
            
            return (factory.sendMessage(chatManager, msg));

        }
        
        if (e.getMsgId().equals (Chat.JtRECEIVE)) {
            form = (ChatForm) context.getActionForm();  
            
            if (form == null)
                return (null);
            
            msg = new JtMessage (Chat.JtRECEIVE);
            msg.setMsgData(form.getChatId());
            msg.setMsgContext(context);        
            return (factory.sendMessage(chatManager, msg)); 
        }
        
        if (e.getMsgId().equals (Chat.KEYBOARD_EVENT)) {
            
            if (e.getMsgData() == null) {
                handleError ("Invalid ChatID");
                return (null);
            }  
            msg = new JtMessage (Chat.KEYBOARD_EVENT);
            msg.setMsgData(e.getMsgData());
            msg.setMsgContext(context);        
            return (factory.sendMessage(chatManager, msg)); 
        }

        if (e.getMsgId().equals (JtObject.JtACTIVATE)) {
            
            if (content == null) {
                handleError ("Invalid ChatID");
                return (null);
            }    
            
            msg = new JtMessage (Chat.CONNECT);
            msg.setMsgData(content);
            msg.setMsgContext(context);        
            factory.sendMessage(chatManager, msg); 
            
            return (retrieveChatForm ((String) content));
            
        }

        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
 
}