package Jt.chat;

import java.util.Date;

public class ChatMessage  {



    public static final String JtCLASS_NAME = ChatMessage.class.getName(); 
    private static final long serialVersionUID = 1L;

    private String message;
    private String username;
    private long sequence;
    private Date timeStamp;
    private boolean keyboardEvent;

    public String getMessage() {
        return message;
    }



    public void setMessage(String message) {
        this.message = message;
    }

    public String getUsername() {
        return username;
    }



    public void setUsername(String username) {
        this.username = username;
    }



    public long getSequence() {
        return sequence;
    }



    public void setSequence(long sequence) {
        this.sequence = sequence;
    }



    public Date getTimeStamp() {
        return timeStamp;
    }



    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }



    public boolean isKeyboardEvent() {
        return keyboardEvent;
    }



    public void setKeyboardEvent(boolean keyboardEvent) {
        this.keyboardEvent = keyboardEvent;
    }


}