
package Jt.directory.form;
import org.apache.struts.validator.ValidatorForm;

public class EntryForm extends ValidatorForm {


	private static final long serialVersionUID = 1L;
	private long entryId;


	private String title;
	private String description;
	private String url;
	private String email;
	private int status;
	private String address;
	private String address1;
	private String state;
	private String city;
	private String zip;
	private String country;
	private String phone;
	private String name;
	private boolean emailFlag;


	public long getEntryId() {
		return (entryId);
	}

	public void setEntryId(long entryId) {
		this.entryId=entryId;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return (description);
	}

	public void setDescription(String description) {
		this.description=description;
	}

	public String getUrl() {
		return (url);
	}

	public void setUrl(String url) {
		this.url=url;
	}

	public String getEmail() {
		return (email);
	}

	public void setEmail(String email) {
		this.email=email;
	}

	public int getStatus() {
		return (status);
	}

	public void setStatus(int status) {
		this.status=status;
	}

	public String getAddress() {
		return (address);
	}

	public void setAddress(String address) {
		this.address=address;
	}

	public String getAddress1() {
		return (address1);
	}

	public void setAddress1(String address1) {
		this.address1=address1;
	}

	public String getState() {
		return (state);
	}

	public void setState(String state) {
		this.state=state;
	}

	public String getCity() {
		return (city);
	}

	public void setCity(String city) {
		this.city=city;
	}

	public String getZip() {
		return (zip);
	}

	public void setZip(String zip) {
		this.zip=zip;
	}

	public String getCountry() {
		return (country);
	}

	public void setCountry(String country) {
		this.country=country;
	}

	public String getPhone() {
		return (phone);
	}

	public void setPhone(String phone) {
		this.phone=phone;
	}

	public boolean isEmailFlag() {
		return (emailFlag);
	}

	public void setEmailFlag(boolean emailFlag) {
		this.emailFlag=emailFlag;
	}

}
