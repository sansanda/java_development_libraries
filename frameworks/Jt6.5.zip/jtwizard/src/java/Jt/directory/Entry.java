package Jt.directory;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;


import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
//import Jt.wizard.struts.CRUD;



public class Entry extends JtObject {

    //public static final String GET_MY_PRODUCTS = "GET_MY_PRODUCTS";
    //public static final String GET_ALL_PRODUCTS = "GET_ALL_PRODUCTS";
    //public static final String SEARCH_FOR_KEYWORDS = "SEARCH_FOR_KEYWORDS";
    public static final String USERNAME = "USERNAME";
    //public static final String JtCLASS_NAME = Entry.class.getName(); 
    //public static final String DEFAULT_PATH = "../jtRoot/defaultPhoto.gif";

    
    private static final long serialVersionUID = 1L;
    private long entryId;
	private String title;
    private String description;
    private String url;


	private String email;
    /*
    private String firstname;
    private String lastname;
    */

    private int status;
    private String address;
    private String address1;
    private String state;
    private String city;
    private String zip;
    private String country;
    private String phone;
    private String name;
    private boolean emailFlag;  
    private Date creationDate;
    private String notes;
    private boolean approved;

    
    // Display attributes (display tag)
    private boolean paging = true;
    
    private transient JtContext context = new JtContext ();
    private transient JtFactory factory = new JtFactory ();
    
   

    public long getEntryId() {
        return entryId;
    }

    public void setEntryId(long entryId) {
        this.entryId = entryId;
    }
    
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}


    public boolean isPaging() {
        return paging;
    }

    public void setPaging(boolean paging) {
        this.paging = paging;
    }


    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }



     
    /*
    private String  retrieveRequestParameter (HttpServletRequest request, int index) {
        Enumeration enu;
        int i = 1;
        String parameter = null;
        
        if (request == null || index <= 0)
            return (null);
        
        enu = request.getParameterNames();
        
        if (enu == null)
            return (null);
        
        while (enu.hasMoreElements()) {
            parameter = (String) enu.nextElement();
            if (i == index)
                return (parameter);
            i++;
        }
        
        return (null);
               
    }
    */
    
    public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}
	
    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getStatus() {
		return status;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress1() {
		return address1;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCountry() {
		return country;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPhone() {
		return phone;
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setEmailFlag(boolean emailFlag) {
		this.emailFlag = emailFlag;
	}

	public boolean isEmailFlag() {
		return emailFlag;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	private String  retrievePageParameter (HttpServletRequest request) {
        Enumeration enu;
        String parameter = null;
        
        if (request == null)
            return (null);
        
        enu = request.getParameterNames();
        
        if (enu == null)
            return (null);
        
        while (enu.hasMoreElements()) {
            parameter = (String) enu.nextElement();
            
            if (parameter != null && parameter.startsWith("d") &&
                    parameter.endsWith("p")) {
                handleTrace (parameter);    
                return (parameter);
            }
        }        
        return (null);
               
    }
    
    
    private void updateSession (String attributeName, List productList) {
        HttpSession session = null;
        HttpServletRequest request = null;
        
        if (context == null) {
            handleWarning ("Product.updateSession: Invalid Jt context: null");
            return; // check
        }
        if (attributeName == null || productList == null)
            return;
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return;
        
        session = request.getSession();
        
        if (session == null) {
            handleWarning ("Product.updateSession: Invalid HttpSession session: null");
            return;
        }
        
        session.setAttribute(attributeName, productList);        
        
    }
    
    private Object retrieveAttributeFromSession (String attributeName) {
        HttpSession session = null;
        HttpServletRequest request = null;
        if (attributeName == null)
            return (null);
        
        if (context == null) {
            handleWarning ("Product.retrieveAttributeFromSession: Invalid Jt context: null");
            return (null);
        }
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        if (session == null) {
            handleWarning ("Product.retrieveAttributeFromSession: Invalid HttpSession session: null");
            return (null);
        }
        
        return (session.getAttribute(attributeName));
        
        
    }
    

    
    private void sessionCleanup (HttpSession session) {
        Enumeration enu;
        String attrName;
        ArrayList list = new ArrayList ();
        Iterator iterator;
        
        
        if (session == null)
            return;
        
        enu = session.getAttributeNames();
        
        // Remove all the attributes name like (jtxxxxxList)
        // except listName
        
        while (enu.hasMoreElements()) {
            attrName = (String) enu.nextElement();
            
            if (attrName != null &&
                    attrName.startsWith("jt") &&
                    attrName.endsWith("List")) {
                //if (!attrName.equals(listName)) {
                handleTrace (".sessionCleanup:" + attrName, 0);
                //session.removeAttribute(attrName);
                list.add(attrName);
                //}
            }
            
            
        }
        
        iterator = list.iterator();
        
        while (iterator.hasNext())
            session.removeAttribute((String) iterator.next());
    }
    
    private Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }

    
    private List retrieveAllProducts () {
        
        JtMessage msg = new JtMessage ();
        List result;
        String query = "select * from product"; // check - configuration file
        JtDAOStrategy adapter; 
        //LinkedList list = new LinkedList ();
        

        
        if (paging) {
            if (context != null && (retrievePageParameter (context.getRequest()) != null)) {

                // Retrieve product list from session
                result = (List) retrieveAttributeFromSession ("jtAllProductList");
                if (result != null)
                    return (result);
            }
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 

        //msg.setMsgContent("select * from roster");
        msg.setMsgContent(query);
       
       
        msg.setMsgData(new Entry ());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);

        if (paging) {
            sessionCleanup (retrieveSession ());
            updateSession ("jtAllProductList", result);
        }
        
        //addPhotos (result);
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("Product.retrieveSession: Invalid Jt context: null");
            return (null); // check
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        return (session);    
    }
    
    private List retrieveMyProducts (String owner) {
        
        JtMessage msg = new JtMessage ();
        List result;
        String query = "select * from product where " + Entry.USERNAME + "='"; // check - configuration file
        JtDAOStrategy adapter; 
        LinkedList list = new LinkedList ();

        
        if (owner == null)
            return list;
        
        

        

        if (paging) {
            if (context != null && (retrievePageParameter (context.getRequest()) != null)) {

                // Retrieve product list from session
                result = (List) retrieveAttributeFromSession ("jtMyProductList");
                if (result != null) {                   
                    return (result);
                }    
            }
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(false);
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 
        
        //msg.setMsgContent("select * from roster");
        msg.setMsgContent(query + owner + "'");
             
        msg.setMsgData(new Entry ());
               
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);
        
        if (paging) {
            sessionCleanup (retrieveSession ());
            updateSession ("jtMyProductList", result);
        }
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }
    
    private boolean validateKeyword (String keyword) {
        int i;
        char c;
        if (keyword == null || keyword.equals(""))
            return (false);
        
        for (i = 0; i < keyword.length(); i++) {
            
            c = keyword.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                continue;               
            }
            
            if (c == '\'') 
                continue;
            
            if (c == '-') 
                continue;
            
            return (false);
        }
        
        return (true);
    }
    
    private boolean validateKeywords (String keywords) {
        String keywordArray[];
        int i;
        
        
        if (keywords == null)
            return (false);
        
        keywordArray = keywords.split(" ");
        
        for (i = 0; i < keywordArray.length; i++) {
            
            if (!validateKeyword (keywordArray[i])) 
                return (false);

        }  
        
        return (true);
    }
    
    private List searchForKeywords (ActionForm form) {
        JtMessage msg = new JtMessage ();
        Object obj;
        List list;
        String keywords = null;
        JtDAOStrategy adapter;
        
        if (form == null) {
            handleError ("Invalid form object:" + form);
            return (null); // check
        }    
        
        keywords = (String) factory.getValue (form, "description");
        
        if (!validateKeywords (keywords)) {
            
            handleError ("invalid keywords");
            return (null);
        }
                 
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(false); 
        
        msg.setMsgId (JtDAOAdapter.JtSEARCH_FOR_KEYWORDS);
        msg.setMsgContent(new Entry ());
        msg.setMsgContext(context);
        

        
        msg.setMsgData("description");
        msg.setMsgAttachment(keywords);
        
        
        
        list = (List) factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (adapter.getObjException() != null) {
            this.setObjException(adapter.getObjException());
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return (null);
        }
        
        //addPhotos (list);
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        

        return (list);        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        

       
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        
        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (new LinkedList ());
        }

        form = (ActionForm) context.getActionForm();  
        //if (context != null)
        //    form = (ActionForm) context.getActionForm();  

            
/*
        if (e.getMsgId().equals(Entry.GET_MY_PRODUCTS)) {
            
            return (retrieveMyProducts (context.getUserName()));
        }
        
        if (e.getMsgId().equals(Entry.GET_ALL_PRODUCTS)) {
            
            return (retrieveAllProducts ());
        }
        
        if (e.getMsgId().equals(Entry.SEARCH_FOR_KEYWORDS)) {
            
            return (searchForKeywords (form));
        }      
*/
        

        return (super.processMessage(message));

    }

}