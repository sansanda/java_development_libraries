
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.esb;

import Jt.JtBridge;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.JtProxy;
import Jt.JtRemoteProxy;
import Jt.axis.JtAxisProxy;
import Jt.ejb.JtEJBProxy;
import Jt.examples.HelloWorld;
import Jt.examples.HelloWorldMessage;
import Jt.jms.JtJMSQueueAdapter;
import Jt.rest.JtRestService;
import Jt.service.Echo;



/**
 * Enterprise Service Bus (ESB) component. It provides functionality to connect
 * to the framework enterprise service bus and send MDP messages
 * to remote applications and components.
 */

public class JtESBBridge extends JtBridge {


  public static final String JtCLASS_NAME = JtESBBridge.class.getName(); 
  private static final long serialVersionUID = 1L;
  private String implementorClassname = null;
  private boolean initialized = false;
  private String url;
  private String classname;
  private String remoteComponentId;
  private JtFactory factory = new JtFactory ();

  public JtESBBridge () {
  }


	/**
	 * Retrieve the service URL.
	 */

	public String getUrl() {
		return url;
	}
	/**
	 * Specifies the service URL.
	 */

	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Returns the classname of the remote component.
	 */
	
	public String getClassname() {
		return classname;
	}
	
	/**
	 * Specifies the classname.
	 */
	
	public void setClassname(String classname) {
		this.classname = classname;
	}
	
	/**
	  * Returns the component Id of the remote component
	  */	
	
	public String getRemoteComponentId() {
		return remoteComponentId;
	}

	
	/**
	  * Specifies the component Id
	  */
	
	public void setRemoteComponentId(String remoteComponentId) {
		this.remoteComponentId = remoteComponentId;
	}	

	
	/**
	  * Returns the implementor class name. Either implementorClassname or implementor (class instance)
	  * must be supplied.
	  */	

	public String getImplementorClassname() {
		return implementorClassname;
	}

	/**
	  * Specifies the implementor class name
	  */
	
	public void setImplementorClassname(String implementorClassname) {
		this.implementorClassname = implementorClassname;
	}


	
	  // Propagate Exceptions
private Exception propagateException (Object obj)
  {
      Exception ex;
      JtObject component;
      

      if (obj == null)
          return null;

      if (!(obj instanceof JtObject)) {
    	  return null;
      }
      
      component = (JtObject) obj;
      //x = (Exception) factory.getValue(obj, "objException");
      ex = (Exception) component.getObjException();

      if (ex != null)
          this.setObjException(ex);

      return (ex);
  }
  

/*
  private boolean initializeProxy (JtProxy proxy) {
	  Boolean Bool;
	  
	  if (proxy == null)
		  return false;

	  Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));

	  if (Bool.booleanValue())
		  return (true);

	  if (propagateException (proxy) != null)
		  return (false);
	  
	  handleError ("Unable to initialize proxy:" + proxy);
	  return (false);
	  
  }	  
*/
  
  
  private boolean initialize () {

	  //JtAxisProxy axisProxy;
	  //JtEJBProxy ejbProxy;
	  JtRemoteProxy remoteProxy;


      if (implementor == null) {

    	  // Create an instance of the class name
    	  
          if (implementorClassname == null) {
              handleError ("processMessage: implementorClassName attribute must be set");   
              return false;
          }
          
          // Use the instance as the implementor
          
          implementor = factory.createObject(implementorClassname);
          
          
      }    
      
      if (implementor instanceof JtRemoteProxy) {
    	  remoteProxy = (JtRemoteProxy) implementor;
    	  remoteProxy.setClassname(classname);   	  
    	  remoteProxy.setUrl(url);
    	  remoteProxy.setRemoteComponentId(remoteComponentId);  	  
    	 
      }
      
      /*
      if (concreteStrategy instanceof JtAxisProxy) {
    	  axisProxy = (JtAxisProxy) concreteStrategy;
    	  
    	  axisProxy.setUrl(url);
    	  axisProxy.setClassname(classname);
    	  axisProxy.setRemoteComponentId(remoteComponentId);

    	  //if (concreteStrategy instanceof JtProxy)
    	  //	  return (initializeProxy ((JtProxy) concreteStrategy));    	  

      }
      */
      /*
      if (implementor instanceof JtEJBProxy) {
    	  ejbProxy = (JtEJBProxy) implementor;
    	  
    	  //ejbProxy.setUrl(url);
    	  ejbProxy.setClassname(classname);
    	  ejbProxy.setRemoteComponentId(remoteComponentId);

    	  if (implementor instanceof JtProxy)
    		  return (initializeProxy ((JtProxy) implementor));    	  

      }
      */
      return (true);
  }

  /**
   * Process object messages.
   * <ul>
   * </ul>
   */

  public Object processMessage (Object message) {
	  Object reply;

      if (!initialized) {
   
          initialized = initialize ();
          
          if (!initialized)
        	  return (null);
      }

      // Let the concrete strategy component handle the message

      if (implementor == null) {
          handleError ("processMessage: implementor attribute must be set");
          return (null);
      }

	  // Reset exceptions
	  this.setObjException(null);
 
      reply = factory.sendMessage (implementor, message);
      
      if (propagateException (implementor) != null)
    	  return (null);
    	  
      //return (((JtInterface) concreteStrategy).processMessage (message));
      return (reply);

  }

 
  /**
   * Demonstrates the functionality provided by the ESB Adapter.
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtESBBridge bridge;
	String url = "http://localhost:8080/JtPortal/JtRestService";
	String axisUrl = "http://localhost:8080/axis/services/JtAxisService";
	String sReply;

	
    // Create an instance of JtESBBridge (Rest Strategy)

    bridge = (JtESBBridge) factory.createObject (JtESBBridge.JtCLASS_NAME);

    // Specify the implementor to be used by the ESB bridge.
    // Use the Restful web service.

	bridge.setImplementorClassname (JtRestService.JtCLASS_NAME);
	bridge.setUrl(url);
	
	// Specify the remote component 
	
	bridge.setClassname (HelloWorldMessage.JtCLASS_NAME);       

    sReply = (String) factory.sendMessage (bridge, "hi");
    
    System.out.println("Reply:" + sReply);
    	
	
    // Create an instance of JtESBBridge

    bridge = (JtESBBridge) factory.createObject (JtESBBridge.JtCLASS_NAME);

    // Specify the implementor to be used by the ESB bridge.
    // Use the Axis web service.

    bridge.setImplementor (new JtAxisProxy ());
	bridge.setUrl(axisUrl);

	bridge.setClassname (HelloWorldMessage.JtCLASS_NAME);   // Remote component
    
    sReply = (String) factory.sendMessage (bridge, "hi");
    
    System.out.println("Reply(axis):" + sReply);
    
    // Create an instance of JtESBBridge (EJB strategy)
    
    bridge = (JtESBBridge) factory.createObject (JtESBBridge.JtCLASS_NAME);
    
    // Specify the implementor to be used by the ESB bridge.
    // Use the EJB strategy this time.
    
    bridge.setImplementor (new JtEJBProxy ());
	bridge.setClassname (HelloWorld.JtCLASS_NAME); // Remote component
    
    sReply = (String) factory.sendMessage (bridge, new JtMessage (HelloWorld.JtHELLO));
    
    System.out.println("Reply:" + sReply);
    
    // Create an instance of JtESBBridge (EJB Strategy)
    
    bridge = (JtESBBridge) factory.createObject (JtESBBridge.JtCLASS_NAME);
    
    // Specify the implementor to be used by the ESB bridge.
    
    bridge.setImplementor (new JtEJBProxy ());
	bridge.setClassname (Echo.JtCLASS_NAME); // Remote Echo component
    
    System.out.println("Reply:" + "Welcome to Jt messaging ...");
    
    // Create an instance of JtESBBridge (JMS strategy)
    	
    bridge = (JtESBBridge) factory.createObject(JtESBBridge.JtCLASS_NAME);		
	
    JtJMSQueueAdapter jmsAdapter = (JtJMSQueueAdapter) factory.createObject (JtJMSQueueAdapter.JtCLASS_NAME);
		
	// Specify the implementor (JMS strategy)

	bridge.setImplementor(jmsAdapter);
	
	factory.sendMessage (bridge, "Hi there");


  }

}


