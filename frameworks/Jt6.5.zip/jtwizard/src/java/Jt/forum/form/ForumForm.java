package Jt.forum.form;
import org.apache.struts.validator.ValidatorForm;

public class ForumForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private long forumId;
    private String description;
    private int posts;
    private int sequence;
    private String moderatorId;




    public long getForumId() {
        return forumId;
    }

    public void setForumId(long forumId) {
        this.forumId = forumId;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public int getPosts() {
        return (posts);
    }

    public void setPosts(int posts) {
        this.posts=posts;
    }

    public int getSequence() {
        return (sequence);
    }

    public void setSequence(int sequence) {
        this.sequence=sequence;
    }

    public String getModeratorId() {
        return (moderatorId);
    }

    public void setModeratorId(String moderatorId) {
        this.moderatorId=moderatorId;
    }

}
 