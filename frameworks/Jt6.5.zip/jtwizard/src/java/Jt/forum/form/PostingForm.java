package Jt.forum.form;
import org.apache.struts.validator.ValidatorForm;

public class PostingForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private long postingId;
    private String userId;
    private String subject;
    private String message;
    private String date;
    private long topicId;
    private boolean approved;
    
    private String formattedMessage;




    public long getPostingId() {
        return postingId;
    }

    public void setPostingId(long postingId) {
        this.postingId = postingId;
    }

    public String getUserId() {
        return (userId);
    }

    public void setUserId(String userId) {
        this.userId=userId;
    }

    public String getSubject() {
        return (subject);
    }

    public void setSubject(String subject) {
        this.subject=subject;
    }

    public String getMessage() {
        return (message);
    }

    public void setMessage(String message) {
        this.message=message;
    }

    public String getDate() {
        return (date);
    }

    public void setDate(String date) {
        this.date=date;
    }

    public long getTopicId() {
        return topicId;
    }

    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public String getFormattedMessage() {
        return formattedMessage;
    }

    public void setFormattedMessage(String formattedMessage) {
        this.formattedMessage = formattedMessage;
    }

}