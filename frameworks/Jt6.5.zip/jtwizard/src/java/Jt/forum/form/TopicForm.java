package Jt.forum.form;
import org.apache.struts.validator.ValidatorForm;

public class TopicForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private long topicId;
    private String subject;
    private String message;
    private int replies;
    private String userId;
    private long lastPostingId;
    private long forumId;
    private boolean approved;


    public long getTopicId() {
        return (topicId);
    }

    public void setTopicId(long topicId) {
        this.topicId=topicId;
    }

    public String getSubject() {
        return (subject);
    }

    public void setSubject(String description) {
        this.subject=description;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public int getReplies() {
        return (replies);
    }

    public void setReplies(int replies) {
        this.replies=replies;
    }

    public String getUserId() {
        return (userId);
    }

    public void setUserId(String userId) {
        this.userId=userId;
    }

    public long getLastPostingId() {
        return (lastPostingId);
    }

    public void setLastPostingId(long lastPostingId) {
        this.lastPostingId=lastPostingId;
    }

    public long getForumId() {
        return forumId;
    }

    public void setForumId(long forumId) {
        this.forumId = forumId;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

}