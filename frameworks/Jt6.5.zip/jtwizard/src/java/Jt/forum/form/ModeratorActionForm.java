package Jt.forum.form;
import java.util.List;

import org.apache.struts.action.ActionForm;

public class ModeratorActionForm extends ActionForm {

    private static final long serialVersionUID = 1L;

    private String message;
    private List rejected;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    

    public List getRejected() {
        return rejected;
    }

    public void setRejected(List rejected) {
        this.rejected = rejected;
    }


}
 