package Jt.forum.form;
import org.apache.struts.validator.ValidatorForm;

public class PostingInTopicForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private long topicId;
    private long postingId;
    private int sequence;

    public long getTopicId() {
        return topicId;
    }
    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }
    public long getPostingId() {
        return postingId;
    }
    public void setPostingId(long postingId) {
        this.postingId = postingId;
    }

    public int getSequence() {
        return (sequence);
    }

    public void setSequence(int sequence) {
        this.sequence=sequence;
    }


}

 