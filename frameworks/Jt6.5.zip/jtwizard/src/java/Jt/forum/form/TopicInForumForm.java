package Jt.forum.form;
import org.apache.struts.validator.ValidatorForm;

public class TopicInForumForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private long forumId;
    private long topicId;
    private int sequence;



    public long getForumId() {
        return forumId;
    }

    public void setForumId(long forumId) {
        this.forumId = forumId;
    }

    public long getTopicId() {
        return topicId;
    }

    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }

    public int getSequence() {
        return (sequence);
    }

    public void setSequence(int sequence) {
        this.sequence=sequence;
    }

}
 