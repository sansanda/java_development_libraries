package Jt.forum.form;


public class NewTopicForm extends TopicForm {


    private static final long serialVersionUID = 1L;
    private long forumId;
    public long getForumId() {
        return forumId;
    }
    public void setForumId(long forumId) {
        this.forumId = forumId;
    }




}