package Jt.forum;
import Jt.JtContext;
import Jt.JtMessage;
import Jt.JtObject;




public class NavigationLink extends JtObject {



    public static final String JtCLASS_NAME = NavigationLink.class.getName(); 
    
    public static final String NAVIGATION_LINK_ID = "jtNavigationLink"; 
    public static final int MAX_LENTGH = 25; 
    
    private static final long serialVersionUID = 1L;


    private long forumId = 0L;
    private String forumName = null;
    private long topicId = 0L;
    private String topicName = null;
    
    private String link = "";
    
    
    private transient JtContext context;
    
    NavigationLink () {
        
        calculateLink ();
    }
    
    public long getForumId() {
        return forumId;
    }



    public void setForumId(long forumId) {

        this.forumId = forumId;
        link = calculateLink ();
    }



    public String getForumName() {        
        return forumName;
    }



    public void setForumName(String forumName) {

        this.forumName = forumName;
        link = calculateLink ();
    }



    public long getTopicId() {
        return topicId;
    }



    public void setTopicId(long topicId) {

        this.topicId = topicId;
        link = calculateLink ();
    }




    public String getTopicName() {
        return topicName;
    }



    public void setTopicName(String topicName) {

        this.topicName = topicName;
        link = calculateLink ();
    }



    public String getLink() {
        return link;
    }



    public void setLink(String link) {
        this.link = link;
    }


    private String restrictLength (String str) {
        if (str == null)
            return (null);
        
        if (str.length() > NavigationLink.MAX_LENTGH) {
            return (str.substring(0, NavigationLink.MAX_LENTGH) + " ..");           
        }
        
        return (str);
        
    }

    private String calculateLink () {
        
        StringBuffer sb = new StringBuffer ();
        
        sb.append
        ("<a href=\"../RetrieveForums.do?msgId=" + JtObject.JtACTIVATE +
                
                "\">Forums</a> ");
        
        if (this.getForumId() == 0L)
            return (sb.toString());
        
        sb.append("&raquo; ");
        
        sb.append
        ("<a href=\"../RetrieveForumTopics.do?msgId=" + Forum.RETRIEVE_TOPICS +
                "&msgContent=" + this.getForumId() +
                
                "\">" + restrictLength (this.getForumName()) +  "</a>");

        if (this.getTopicId() == 0L)
            return (sb.toString());       
        
        sb.append("&raquo; ");
        
        sb.append
        ("<a href=\"../Posting.do?msgId=" + Topic.RETRIEVE_POSTINGS +
                "&msgContent=" + this.getTopicId() +
                
                "\">" + restrictLength (this.getTopicName()) +  "</a>");
        
        return (sb.toString());
        
        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //ActionForm form = null;



        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        content = e.getMsgContent();
        context = (JtContext) e.getMsgContext();

        /*
        if (msgid.equals (JtObject.JtACTIVATE)) {

            link = calculateLink ();
            return (this);
            
        }    
        */

        
        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
 

}