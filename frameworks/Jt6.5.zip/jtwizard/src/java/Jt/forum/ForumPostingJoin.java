package Jt.forum;

import java.util.Date;



public class ForumPostingJoin {


    
    private static final long serialVersionUID = 1L;

    private long forumId;
    private String description;
    private int posts; 
    //private int sequence;
    //private long lastPost;
    private String moderatorId;
    
    // Last topic
    private long topicId;
    private String subject;
    
    // Last posting
    private String userId;
    private long postingId;
    private Date date;    
    
    private transient String lastPosting; // calculated
    
    

    public long getForumId() {
        return forumId;
    }

    public void setForumId(long forumId) {
        this.forumId = forumId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
 

/*
    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }
*/

    public int getPosts() {
        return posts;
    }

    public void setPosts(int posts) {
        this.posts = posts;
    }
    
    /*
    public long getLastPost() {
        return lastPost;
    }

    public void setLastPost(long lastPost) {
        this.lastPost = lastPost;
    }
*/
    
    public String getModeratorId() {
        return moderatorId;
    }

    public void setModeratorId(String moderatorId) {
        this.moderatorId = moderatorId;
    }

    public long getTopicId() {
        return topicId;
    }

    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public long getPostingId() {
        return postingId;
    }

    public void setPostingId(long postingId) {
        this.postingId = postingId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLastPosting() {
        return lastPosting;
    }

    public void setLastPosting(String lastPosting) {
        this.lastPosting = lastPosting;
    } 

}