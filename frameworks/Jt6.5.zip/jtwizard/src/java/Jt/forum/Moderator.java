package Jt.forum;


import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMail;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.JtAccount;
import Jt.wizard.util.ResourceFile;



public class Moderator  extends JtObject   {


    public static final String JtCLASS_NAME = Moderator.class.getName();  
    public static final String NOTIFY_MODERATOR = "NOTIFY_MODERATOR"; 

    
    transient JtFactory factory = new JtFactory ();
    transient JtContext context;
    transient JtDAOStrategy adapter;

    
    private static final long serialVersionUID = 1L;


    private String userId;
    private String moderatorLink;
    private String messageSubject = "JtPortal: moderator action is needed.";
    private String rejectionMessageSubject = "JtPortal";    
    
    


    public String getUserId() {
        return userId;
    }


    public void setUserId(String userId) {
        this.userId = userId;
    }



    public String getModeratorLink() {
        return moderatorLink;
    }


    public String getMessageSubject() {
        return messageSubject;
    }


    public void setMessageSubject(String messageSubject) {
        this.messageSubject = messageSubject;
    }


    public void setModeratorLink(String moderatorLink) {
        this.moderatorLink = moderatorLink;
    }


    public String getRejectionMessageSubject() {
        return rejectionMessageSubject;
    }


    public void setRejectionMessageSubject(String rejectionMessageSubject) {
        this.rejectionMessageSubject = rejectionMessageSubject;
    }


    protected Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    private String buildLink (String username) {
        String result;
                
        if (username == null) {
            return (null);
        }   
        

             
        if (getModeratorLink() == null) {
            handleError ("Invalid moderator link. Please add it to the Jt resource file.");
            return (null);
        }
        
        result = getModeratorLink() + "?msgContent=" + 
             username;

        
        return (result);
        
    }
    
    private String buildEmailMessage (String username) {
        
        String result;
        String emailLink;
        
        ResourceFile resFile = new ResourceFile ();
        
        
        if (username == null)
            return (null);
        
        resFile.setPath("EmailTemplates/ModeratorEmail.txt");
        
        
        result = (String) factory.sendMessage(resFile, new JtMessage (JtObject.JtREAD));
        
        if (propagateException (resFile) != null)
            return (null);
        
        if (result == null)
            return (null);
            
        emailLink = buildLink (username);
        
        if (emailLink == null) {
            return (null);
        }
            
        
        result = result.replaceAll ("#link", emailLink);
        
        //handleTrace ("buildEmailMessage:" + result);
        return (result);
    }
    
    
   // Email the moderator link
    
    private boolean sendEmail (String email, 
            String message, String subject) {

        JtMail mailAdapter;
        //String message;

        
        if (email == null || message == null ||
                subject == null) {
            handleError ("Invalid parameters.");
            return false;
        }    
        
        

        mailAdapter = (JtMail) factory.createObject (JtMail.JtCLASS_NAME, "portalMailAdapter");
        
        mailAdapter.setTo(email);
        
   
        mailAdapter.setMessage(message);        
        mailAdapter.setSubject(subject);
        
        factory.sendMessage (mailAdapter, new JtMessage (JtObject.JtACTIVATE));
        
        if (propagateException (mailAdapter) != null) {
            factory.removeObject (mailAdapter);
            return false;
        }
        
        // Remove mailAdapter
        
        factory.removeObject (mailAdapter);

        return true;
    }
    
    
    private JtAccount retrieveAccount (String userId) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        msg.setMsgContent(new JtAccount ());
        JtAccount account;
        JtDAOStrategy daoAdapter;
        
        
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        
        msg.setMsgData (userId);
        
        account = (JtAccount) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null) {
            factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
            return (null);
        }
    
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (account);
    }
    

    
    private void notifyModerator (String username) {
        
        String message;
        String email;
        JtAccount account;
    
        
        if (username == null)
            return;
        
        account = retrieveAccount (username);

        
        if (account == null)
            return;
        
        email = account.getEmail();
        
        if (email == null) {
            handleError ("Invalid email (null) for moderator " + username);
            return;            
        }
        
        if ((message = buildEmailMessage (username)) == null)
            return;
        

        sendEmail (email, message, 
                this.getMessageSubject());
        
    }
    
    void sendRejectionMessage (String username, String message) {
        JtAccount account;
        String email;
        
        if (username == null || message == null) {
            handleWarning ("Moderator.sendRejectionMessage: invalid parameters (null).");
            return;
        }
        
        account = retrieveAccount (username);

        
        if (account == null)
            return;
        
        email = account.getEmail();
        
        if (email == null) {
            handleError ("Invalid email (null) for " + username);
            return;            
        }
        
        sendEmail (email, message, 
                this.getRejectionMessageSubject());
        
    }
    
        
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        //TopicForm form = null;
        //PostingForm form;
        //DAOCategory category;
        //List list;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //content = e.getMsgContent();

        /*
        context = (JtContext) e.getMsgContext();
               

        
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        */
        
        if (msgid.equals (Moderator.NOTIFY_MODERATOR)) {
            
            if (userId == null) {
                handleError ("Attribute userId needs to be set.");
                return (null);
            }
            
            notifyModerator (userId);            
                      
            return (null);
            
        }  
        

        


        
        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
}