package Jt.forum;

import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.form.PostingForm;
//import Jt.forum.form.TopicForm;




public class Posting  extends JtObject implements Comparable  {


    public static final String JtCLASS_NAME = Posting.class.getName();  
    public static final String RETRIEVE_POSTINGS = "RETRIEVE_POSTINGS"; 
    public static final String PREVIEW = "PREVIEW"; 
    public static final String SEARCH_FOR_KEYWORDS = "SEARCH_FOR_KEYWORDS";
    public static final String RETRIEVE_TOPIC = "RETRIEVE_TOPIC";
    public static final String MASSAGE_MESSAGE = "MASSAGE_MESSAGE";
    
    JtFactory factory = new JtFactory ();
    JtContext context;
    transient JtDAOStrategy adapter;
    static final int MAX_LENGTH = 0;

    
    private static final long serialVersionUID = 1L;


    private long postingId;
    private String userId;
    private String message;
    //private String subject;
    private Date date;
    
    private boolean approved = false;

    private String formattedMessage;

    public long getPostingId() {
        return postingId;
    }


    public void setPostingId(long postingId) {
        this.postingId = postingId;
    }


    public String getUserId() {
        return userId;
    }


    public void setUserId(String userId) {
        this.userId = userId;
    }

/*
    public String getSubject() {
        return subject;
    }


    public void setSubject(String subject) {
        this.subject = subject;
    }
*/

    public String getMessage() {
        return message;
    }


    public void setMessage(String message) {
        this.message = message;
    }


    public Date getDate() {
        return date;
    }


    public void setDate(Date date) {
        this.date = date;
    } 


    public boolean isApproved() {
        return approved;
    }


    public void setApproved(boolean approved) {
        this.approved = approved;
    }


    public String getFormattedMessage() {
        return formattedMessage;
    }


    public void setFormattedMessage(String formattedMessage) {
        this.formattedMessage = formattedMessage;
    }


    protected Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    
    private String getToken (String str, int index) {
        //StringBuffer token = new StringBuffer ();
        int lastIndex;
        
        if (str == null || index < 0)
            return (null);
        
        
        lastIndex = index;
        
        while (lastIndex < str.length()) {

            if (Character.isWhitespace(str.charAt(lastIndex)))
                break;
   
            lastIndex++;
        }
        
        return (str.substring(index, lastIndex));
    }
    
        
    private String formatText (String str) {
        //String tmp;
        StringBuffer sBuffer = new StringBuffer ();
        int i = 0;
        int cnt = 0;
        String token;
        char c;

        if (str == null)
            return (null);
        
        while (i < str.length()) {
            
            c = str.charAt(i);
            
            if (Character.isWhitespace(c)) {
                if (c == '\n') { // check
                    sBuffer.append("<br />");   
                    cnt = 0;
                    i++;
                    continue;
                }
                
                if ((Posting.MAX_LENGTH <= 0)
                        || (cnt + 1 < Posting.MAX_LENGTH)) {
                    sBuffer.append(c);
                    i++;
                    cnt++;
                    continue;
                }
                sBuffer.append("<br />");   
                cnt = 0;
                i++;
                continue;
                
            }
            
            token = getToken (str, i);
            
            if ((Posting.MAX_LENGTH <= 0) || 
                    (cnt + token.length() < Posting.MAX_LENGTH)) {
                sBuffer.append(token);
                cnt += token.length();
                i += token.length();
                continue;
            }
            
            sBuffer.append("<br />"); 
            sBuffer.append(token);
            cnt = token.length();
            
            i += token.length();
            //cnt = 0;
            
            
        }
        
        //tmp = str.replaceAll("\n", "<br />");
        
        return (sBuffer.toString());
    }
    
    
  
    private void massageList (List list) {
        Iterator iterator;
        Posting posting;
        //String tmp;
        LinkedList tmp = new LinkedList ();
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        


        while (iterator.hasNext()) {
            

            posting = (Posting) iterator.next();
            
            if (!posting.isApproved()) {
                tmp.add(posting);
            }
            
            posting.setMessage(formatText (posting.getMessage ()));
            

      
        }
        
        iterator = tmp.iterator();
        
        while (iterator.hasNext()) {
            posting = (Posting) iterator.next();
            list.remove (posting);
        }
        
    }    
    
    
    // Being moved to Topic
/*
    List retrievePostingsInTopic (String topicId) {
        CRUD crud = new CRUD ();
        JtMessage msg = new JtMessage (CRUD.EXECUTE_QUERY);
        List list;
        
        
        if (topicId == null) {
            handleError ("Invalid parameter topicId:" + topicId);
            return (null);
        }
        crud.setQuery
        ("Select * from posting_in_topic t, posting p WHERE p.postingId=t.postingId and t.topicId=" +
                topicId + " and p.approved=1 order by p.date desc");
        crud.setClassname(Posting.JtCLASS_NAME);
        msg.setMsgContext(context);
        
        list = (List) factory.sendMessage(crud, msg);
    
        if (propagateException (crud) != null)
            return (null);
        
        massageList (list);
        return (list);
    }
*/


    
    private void deletePosting () {
        JtMessage msg = new JtMessage ();

        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtDELETE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }  
    
    private void updatePosting () {
        JtMessage msg = new JtMessage ();

        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtUPDATE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }
    
    private Posting readPosting () {
        JtMessage msg = new JtMessage ();
        //Topic topic;
        Posting posting;
        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtREAD);
        //msg.setMsgContext(context); 

        msg.setMsgContent(new Posting ());
       
       
        msg.setMsgData (new Long (postingId));
                
        
        posting = (Posting) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (posting);
    }
    
    
    String previewPosting (PostingForm form) {
        PostingForm newForm = new PostingForm ();
        String message;
        
        if (form == null) {
            handleError ("Invalid Form: null");
            return (null);
        }    
        
        newForm.setTopicId(form.getTopicId());
        //newForm.setSubject(form.getSubject());
        message = form.getMessage();
        
        newForm.setFormattedMessage (formatText (message));
        
        handleTrace (newForm.getFormattedMessage());
        
        //context.getResponse();
        
        return (newForm.getFormattedMessage());
        
    }
    

    private boolean validateKeyword (String keyword) {
        int i;
        char c;
        if (keyword == null || keyword.equals(""))
            return (false);
        
        for (i = 0; i < keyword.length(); i++) {
            
            c = keyword.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                continue;               
            }
            
            if (c == '\'') 
                continue;
            
            if (c == '-') 
                continue;
            
            return (false);
        }
        
        return (true);
    }
    
    private boolean validateKeywords (String keywords) {
        String keywordArray[];
        int i;
        
        
        if (keywords == null)
            return (false);
        
        keywordArray = keywords.split(" ");
        
        for (i = 0; i < keywordArray.length; i++) {
            
            if (!validateKeyword (keywordArray[i])) 
                return (false);

        }  
        
        return (true);
    }   
    
    
    private Topic retrieveTopic () {
        String query = "select * from topic t, posting_in_topic p where t.topicId=p.topicId and p.postingId=";
        JtMessage msg = new JtMessage ();
        List result;
        //Forum oForum;
        Topic topic;
        
        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        //msg.setMsgContext(context); 

        msg.setMsgContent(query + postingId);
       
       
        msg.setMsgData (new Topic());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
       
        if (result == null || result.isEmpty()) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        if (result.size() > 1) {
            handleError ("Multiple entries for postingId " + postingId);
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        topic = (Topic) result.get(0);        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (topic);
    }
    
    List searchForKeywords (ActionForm form) {
        JtMessage msg = new JtMessage ();
        //Object obj;
        List list;
        String keywords = null;
        JtDAOStrategy adapter;
        
        if (form == null) {
            handleError ("Invalid form object:" + form);
            return (null); // check
        }    
        
        keywords = (String) factory.getValue (form, "message");
        
        if (!validateKeywords (keywords)) {
            
            handleError ("invalid keywords");
            return (null);
        }
                 
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(false); 
        
        msg.setMsgId (JtDAOAdapter.JtSEARCH_FOR_KEYWORDS);
        msg.setMsgContent(new Posting ());
        msg.setMsgContext(context);
        

        
        msg.setMsgData("message");
        msg.setMsgAttachment(keywords);
        
        
        
        list = (List) factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (adapter.getObjException() != null) {
            this.setObjException(adapter.getObjException());
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return (null);
        }
        
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        massageList (list);
        Collections.sort (list);
        return (list);        
    }
    
    public int compareTo (Object obj) {
        Date date, odate;
        
        if (obj == null)
            return (-1);
        
        date = this.getDate();
        odate = ((Posting) obj).getDate();
        
        if (odate == null && date == null)
            return (0);
        
        if (date == null)
            return (-1);
        
        return (date.compareTo(odate));
        
        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //TopicForm form = null;
        PostingForm form;
        //DAOCategory category;
        //List list;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();
        
 
        
        if (e.getMsgId().equals (JtDAOAdapter.JtREAD)) {
           
            return (readPosting ()); 
        }
        
        if (e.getMsgId().equals (JtDAOAdapter.JtUPDATE)) {
            
            updatePosting ();
            return (null); 
        }
        
        if (e.getMsgId().equals (JtDAOAdapter.JtDELETE)) {
            
            deletePosting ();
            return (null); 
        }
 
        if (e.getMsgId().equals (Posting.RETRIEVE_TOPIC)) {
            

            return (retrieveTopic ()); 
        }
        
        if (e.getMsgId().equals (Posting.MASSAGE_MESSAGE)) {
            
            this.setMessage(formatText (this.getMessage ()));
            return (null); 
        }

        return (super.processMessage (message));
        //handleError ("Invalid msg Id:" + msgid);
        //return (null);


    }
}