package Jt.forum;
import java.util.List;

import Jt.JtContext;
import Jt.JtFactory;

import Jt.JtMessage;
import Jt.DAO.JtDAOAdapter;
import Jt.forum.form.TopicForm;
import Jt.portal.DAOCategory;




public class TopicActionHandler extends Topic {

    public static final String RETRIEVE_SIBLING_POSTINGS = "RETRIEVE_SIBLING_POSTINGS";
    public static final String EDIT_MODERATED_POSTING = "EDIT_MODERATED_POSTING";
    public static final String NEW = "NEW";
    
    private static final long serialVersionUID = 1L;
    
    private String moderatedMessage = "Thank you for your posting. It has been sent to the forum moderator.";
    private String postedMessage =  "Thank you for your message. It has been posted to the forum."; 
 
    public String getModeratedMessage() {
        return moderatedMessage;
    }

    public void setModeratedMessage(String moderatedMessage) {
        this.moderatedMessage = moderatedMessage;
    }

    public String getPostedMessage() {
        return postedMessage;
    }

    public void setPostedMessage(String postedMessage) {
        this.postedMessage = postedMessage;
    }
    
    
    private TopicForm newTopic (String forumId) {
        TopicForm form = new TopicForm ();
        Long id;
        long lforumId;
        
        if (forumId == null || forumId.equals("")) {
            handleError ("Invalid parameter (forumId):null or empty" );
            return (null);
        }    
        
        try {
            lforumId = Long.parseLong(forumId);
        } catch (Exception e) {
            handleException (e);
            return (null);
        }
        
        form.setForumId(lforumId);
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return (null);
        }
        
        form.setTopicId(id.longValue());
        form.setUserId(context.getUserName());
        
        return (form);
        
    }

    

    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        TopicForm form = null;
        DAOCategory category;
        List list;
        String moderatorId;
        NavigationLink navigationLink;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();
                

        
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        

        form = (TopicForm) context.getActionForm();  
        
        if (e.getMsgId().equals (JtDAOAdapter.JtCREATE)) {
            addTopic (form);
            
            if (this.getObjException() != null) {
                return (null);                
            }
            
            if (parentForum == null)  // check
                return (null);
            
            moderatorId = parentForum.getModeratorId();
            
            if (moderatorId == null || moderatorId.equals(""))
                return (this.getPostedMessage());
            else
                return (this.getModeratedMessage());               
                
        }
        
        if (e.getMsgId().equals (TopicActionHandler.RETRIEVE_SIBLING_POSTINGS)) {
            category = new DAOCategory ();
            
            category.setCategoryId((String) e.getMsgContent());
            
            list = (List) retrieveSiblingPostings ((String) e.getMsgContent());
            
            if (list == null)
                return (null);
            category.setCategoryList(list);           
            return (category);
        }
        
        // Careful - Topic handles a message with the same ID
        
        if (e.getMsgId().equals (Topic.RETRIEVE_POSTINGS)) {
            category = new DAOCategory ();
            
            category.setCategoryId((String) e.getMsgContent());
            
            list = (List) retrievePostingsInTopic ((String) e.getMsgContent());
            
            if (list == null)
                return (null);
            category.setCategoryList(list);  
            updateNavigationLink ((String) e.getMsgContent());
            return (category);
        }
        
        if (msgid.equals (TopicActionHandler.NEW)) {

            navigationLink = retrieveNavigationLink ();
            
            if (navigationLink == null || (navigationLink.getForumId () <= 0L))
                return (null);
            
            return (newTopic (navigationLink.getForumId () + ""));
            
        }    
        
        handleError ("Invalid msg Id:" + msgid);
        return (null);



    }
}