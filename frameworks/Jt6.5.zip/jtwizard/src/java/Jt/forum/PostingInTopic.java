package Jt.forum;


import java.util.List;
import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.form.PostingForm;




public class PostingInTopic extends JtObject {


    public static final String JtCLASS_NAME = PostingInTopic.class.getName(); 
    private JtFactory factory = new JtFactory ();
    private JtContext context;
    
    private transient JtDAOStrategy adapter;
    //private boolean init = false;
    
    //public static final String NEW = "NEW";
    public static final String RETRIEVE_TOPIC = "RETRIEVE_TOPIC";
    
    private static final long serialVersionUID = 1L;
    
    private long topicId;
    private long postingId;
    private int sequence;
    
    public long getTopicId() {
        return topicId;
    }
    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }
    public long getPostingId() {
        return postingId;
    }
    public void setPostingId(long postingId) {
        this.postingId = postingId;
    }
    
    public int getSequence() {
        return sequence;
    }
    public void setSequence(int sequence) {
        this.sequence = sequence;
    }
    
    protected Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    /*
    private PostingForm newPosting (String topicId) {
        PostingForm form = new PostingForm ();
        Long id;
        long ltopicId;
        
        if (topicId == null || topicId.equals("")) {
            handleError ("Invalid parameter (forumId):null or empty" );
            return (null);
        }    
        
        try {
            ltopicId = Long.parseLong(topicId);
        } catch (Exception e) {
            handleException (e);
            return (null);
        }
        
        form.setTopicId(ltopicId);
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return (null);
        }
        
        form.setPostingId(id.longValue());
        
        return (form);
        
    }
    */

    
    
    private JtHashTable retrieveAttributes (Object obj) {
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtFactory fact = new JtFactory ();
        
        if (obj == null)
            return (null);
        msg.setMsgContent(obj);
        fact.setStopClass(obj.getClass().getSuperclass());
        
        return ((JtHashTable) fact.processMessage(msg));
        
    }
    
  
 
    private Forum retrieveParentForum (long topicId) {
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
        TopicInForum topicInForum = new TopicInForum ();
        Forum forum;
        
        if (topicId == 0L) {
            return (null);
        }    
        
        topicInForum.setTopicId(topicId);
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        if (propagateException (topicInForum) != null)
            return (null);
        
        return (forum);
    }
    

    private void deleteEntry () {
        JtMessage msg = new JtMessage ();

        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return;
        }
        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtDELETE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    } 
    
    private Topic retrieveParentTopic () {
        String query = "select * from topic t, posting_in_topic p where t.topicId=p.topicId and p.postingId=";
        JtMessage msg = new JtMessage ();
        List result;
        Topic oTopic;
        
        if (postingId == 0L) {
            handleError ("Attribute postingId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(false);
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 

        msg.setMsgContent(query + postingId);
       
       
        msg.setMsgData (new Topic ());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
       
        if (result == null || result.isEmpty()) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        if (result.size() > 1) {
            handleError ("Multiple entries for topicId " + topicId);
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        oTopic = (Topic) result.get(0);        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (oTopic);
    }
    
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //TopicForm form = null;
        PostingForm form;
        Forum forum;
        String moderatorId;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

/*
        if (!init) {
            initialize ();
            init = true;
        }
*/
        content = e.getMsgContent();
        
/*
        if (msgid.equals (PostingInTopic.NEW)) {

            return (newPosting ((String) content));
            
        }    
*/
        
        if (e.getMsgId().equals (JtDAOAdapter.JtDELETE)) {
            deleteEntry ();
            return (null); 
        }
        
        if (msgid.equals (PostingInTopic.RETRIEVE_TOPIC)) {

            return (retrieveParentTopic ());
            
        }  
        
       
        handleError ("Invalid msg Id:" + msgid);
        return (null);
        //return (super.processMessage (message));


    }


}