package Jt.forum;



//import org.apache.struts.action.ActionForm;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import Jt.JtContext;
import Jt.JtFactory;
//import Jt.JtHashTable;
//import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.form.TopicForm;
import Jt.portal.DAOCategory;


public class TopicInForum extends JtObject {

    public static final String JtCLASS_NAME = TopicInForum.class.getName(); 
    //public static final String JtADD_CHILD = "JtADD_CHILD";
    public static final String NEW = "NEW";
    public static final String RETRIEVE_FORUM = "RETRIEVE_FORUM";
    public static final String RETRIEVE_TOPICS = "RETRIEVE_TOPICS";   
    
    private JtFactory factory = new JtFactory ();
    private JtContext context = null;
    private transient JtDAOStrategy adapter;
    //private boolean init = false;
    
    private static final long serialVersionUID = 1L;
    
    private long forumId = 0L;
    private long topicId = 0L;
    private int sequence;
    

    
    public long getForumId() {
        return forumId;
    }
    public void setForumId(long forumId) {
        this.forumId = forumId;
    }
    public long getTopicId() {
        return topicId;
    }
    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }
    public int getSequence() {
        return sequence;
    }
    public void setSequence(int sequence) {
        this.sequence = sequence;
    }
   
    // Propagate Exception 

    private Exception propagateException (JtObject obj)
    {
        Exception ex;

        if (obj == null)
            return null;

        ex = (Exception) obj.getObjException();

        if (ex != null)
            this.setObjException(ex);

        return (ex);
    }
    

    /*
    private TopicForm newTopic (String forumId) {
        TopicForm form = new TopicForm ();
        Long id;
        long lforumId;
        
        if (forumId == null || forumId.equals("")) {
            handleError ("Invalid parameter (forumId):null or empty" );
            return (null);
        }    
        
        try {
            lforumId = Long.parseLong(forumId);
        } catch (Exception e) {
            handleException (e);
            return (null);
        }
        
        form.setForumId(lforumId);
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return (null);
        }
        
        form.setTopicId(id.longValue());
        form.setUserId(context.getUserName());
        
        return (form);
        
    }
    */
    
    private Forum retrieveForum () {
        String query = "select * from forum f, topic_in_forum t where f.forumId=t.forumId and t.topicId=";
        JtMessage msg = new JtMessage ();
        List result;
        Forum oForum;
        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 

        msg.setMsgContent(query + topicId);
       
       
        msg.setMsgData (new Forum ());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
       
        if (result == null || result.isEmpty()) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        if (result.size() > 1) {
            handleError ("Multiple entries for topicId " + topicId);
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }
        
        oForum = (Forum) result.get(0);        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (oForum);
    }
    
    
    private Posting retrievePosting (long postingId) {
        Posting posting = new Posting (); 
        JtMessage msg = new JtMessage (JtDAOAdapter.JtREAD);
        
        
        if (postingId == 0L)
            return (null);
        
        posting.setPostingId(postingId);
        
        return ((Posting) factory.sendMessage(posting, msg));
        
    }
    

    

    

    
    private HttpSession retrieveSession (JtContext context) {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        return (session);    
    } 
    

    
    private void deleteEntry () {
        JtMessage msg = new JtMessage ();

        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return;
        }
        
        if (forumId == 0L) {
            handleError ("Attribute forumId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtDELETE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    } 
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //TopicForm form = null;
        DAOCategory category;
        List list;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();

        //if (context != null)
        //    form = (TopicForm) context.getActionForm();  

        /*
        if (msgid.equals (TopicInForum.NEW)) {

            return (newTopic ((String) content));
            
        }    
        */
        
        if (msgid.equals (TopicInForum.RETRIEVE_FORUM)) {

            return (retrieveForum ());
            
        }  
        
        if (e.getMsgId().equals (JtDAOAdapter.JtDELETE)) {
            deleteEntry ();
            return (null); 
        }
        
        /*
        if (msgid.equals (JtObject.JtACTIVATE)) {

            category = new DAOCategory ();
            
            category.setCategoryId((String) e.getMsgContent());
            
            list = (List) retrieveTopicsInForum ((String) e.getMsgContent());
            
            if (list == null)
                return (null);
            category.setCategoryList(list);  
            updateNavigationLink ((String) e.getMsgContent());
            return (category);
            
        }  
        */
        
        handleError ("Invalid msg Id:" + msgid);
        return (null);
        //return (super.processMessage (message));


    }
}