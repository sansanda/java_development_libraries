package Jt.forum;


import java.util.List;
import Jt.JtContext;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.portal.DAOCategory;




public class ForumActionHandler extends Forum {

   

    private static final long serialVersionUID = 1L;

    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        //ActionForm form = null;

        DAOCategory category;
        List list;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //content = e.getMsgContent();
        context = (JtContext) e.getMsgContext();

        if (msgid.equals (JtObject.JtACTIVATE)) {
            updateNavigationLink ();
            return (retrieveForums ());
            
        }    
        
        /*
        if (e.getMsgId().equals (JtDAOAdapter.JtREAD)) {
            
            return (readForum ()); 
        }
        */
        
        if (msgid.equals (ForumActionHandler.RETRIEVE_CURRENT_FORUM)) {

            return (retrieveCurrentForum ());
            
        } 
        
        if (msgid.equals (Forum.RETRIEVE_TOPICS)) {

            category = new DAOCategory ();
            
            category.setCategoryId((String) e.getMsgContent());
            
            list = (List) retrieveTopicsInForum ((String) e.getMsgContent());
            
            if (list == null)
                return (null);
            category.setCategoryList(list);  
            updateNavigationLink ((String) e.getMsgContent());
            return (category);
            
        }  
        
        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
 

}