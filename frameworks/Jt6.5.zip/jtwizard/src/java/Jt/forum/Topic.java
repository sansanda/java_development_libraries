package Jt.forum;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.form.TopicForm;
import Jt.wizard.struts.CRUD;





public class Topic extends JtObject {

    public static final String RETRIEVE_POSTINGS = "RETRIEVE_POSTINGS";

    public static final String JtCLASS_NAME = Topic.class.getName();     
    JtFactory factory = new JtFactory ();
    JtContext context = null;
    transient JtDAOStrategy adapter;

    
    private static final long serialVersionUID = 1L;


    private long topicId; 
    private String subject;
    //private String message;
    private int replies;
    private String userId;
    private long lastPostingId;
    private boolean approved = false;



    private String lastPosting;
    

    Forum parentForum;

    public long getTopicId() {
        return topicId;
    }



    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }



    public String getSubject() {
        return subject;
    }



    public void setSubject(String description) {
        this.subject = description;
    }
 
/*
    public String getMessage() {
        return message;
    }



    public void setMessage(String message) {
        this.message = message;
    }
*/

    public int getReplies() {
        return replies;
    }

    public void setReplies(int replies) {
        this.replies = replies;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }



    public long getLastPostingId() {
        return lastPostingId;
    }



    public void setLastPostingId(long lastPostingId) {
        this.lastPostingId = lastPostingId;
    }

    
    // Display 
    
    public String getLastPosting() {
        return lastPosting;
    }



    public void setLastPosting(String lastPosting) {
        this.lastPosting = lastPosting;
    }



    public boolean isApproved() {
        return approved;
    }



    public void setApproved(boolean approved) {
        this.approved = approved;
    }



    protected Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    private JtHashTable retrieveAttributes (Object obj) {
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtFactory fact = new JtFactory ();
        
        if (obj == null)
            return (null);
        msg.setMsgContent(obj);
        fact.setStopClass(obj.getClass().getSuperclass());
        
        return ((JtHashTable) fact.processMessage(msg));
        
    }
    
    private void copyFormAttributes (ActionForm form, Object obj) {
        JtHashTable attributes;
        JtIterator iterator;
        String attribute;
        Object value;
        
        if (obj == null || form == null)
            return;
        //attributes = getAttributes (obj);
        attributes = retrieveAttributes (form);
        
        if (attributes == null)
            return;
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        if (iterator == null)
            return;
        
        for (;;) {
            attribute = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (attribute == null)
                break;
            
            if (attribute.equals("forumId")) {
                continue;
            }
            
            value = factory.getValue(form,attribute);
            factory.setValue (obj, attribute, value);
                
        }
        
    }
    
    private Topic readTopic () {
        JtMessage msg = new JtMessage ();
        //List result;
        Topic topic;
        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtREAD);
        //msg.setMsgContext(context); 

        msg.setMsgContent(new Topic ());
       
       
        msg.setMsgData (new Long (topicId));
                
        
        topic = (Topic) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (topic);
    }
    
    private void updateForum (long topicId) {
        String moderatorId;
        Forum forum;
        TopicInForum topicInForum = new TopicInForum ();
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
        
        if (topicId == 0L) {
            handleError ("Invalid form data");
            return;
        }    
        
        topicInForum.setTopicId(topicId);
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        if (forum == null) {
            handleWarning ("Unable to update forum for topic" + topicId);
            return; // check
        }
        
        moderatorId = forum.getModeratorId();
        
        if (moderatorId != null &&
                !moderatorId.equals(""))
            return;
        
        // Update Forum instance
        
        forum.setLastPost(topicId);
        forum.setPosts(forum.getPosts() + 1);
        
        //adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        
        msg.setMsgId (JtDAOAdapter.JtUPDATE); 
        
        msg.setMsgContent(forum);
        
        factory.sendMessage(adapter, msg);
        
        // Propagate the exception
       
        propagateException (adapter);
        
        
        //factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));   
 
    }
    
    private List retrievePostings () {
        String query = "Select * from posting_in_topic t, posting p WHERE p.postingId=t.postingId and t.topicId=" +
            topicId + " order by p.date desc";
        JtMessage msg = new JtMessage ();
        List result;
        //Forum oForum;
        
        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return null;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        //msg.setMsgContext(context); 

        msg.setMsgContent(query);
       
       
        msg.setMsgData (new Posting());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
       
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (result);
    }
   
    
     
    
    public void addTopic (TopicForm form) {
        JtMessage msg = new JtMessage ();
        Topic topic = new Topic ();
        Posting posting = new Posting ();
        TopicInForum topicInForum = new TopicInForum ();
        PostingInTopic postingInTopic = new PostingInTopic ();
        Long id;
        Forum forum = new Forum ();
        String moderatorId;
        
        if (form == null) {
            handleError ("Invalid parameter (form): null");
            return;
        }
        
        if (form.getForumId()  == 0L ||
                form.getTopicId()  == 0L) { //remove TopicId
            handleError ("Invalid form data");
            return;
        }       
        
        
        
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(true);
        
        copyFormAttributes (form, topic);
        
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return;
        }
        
        
        forum.setForumId(form.getForumId());
        parentForum = (Forum) factory.sendMessage(forum, new JtMessage (JtObject.JtREAD));

        
        if (propagateException (adapter) != null)
            return;
        
        if (parentForum == null) {
            handleError ("Unable to retrieve forum:" + form.getForumId());
            return;
        }
        moderatorId = parentForum.getModeratorId();
        
        topic.setLastPostingId(id.longValue());
        topic.setReplies(0);
        
        if (moderatorId != null && !moderatorId.equals("")) {
            topic.setApproved(false);
        } else
            topic.setApproved(true);
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(topic);
        msg.setMsgContext(context); // pass the JtContext
        
        // check - already exists 
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null)
            return;
        
        
        topicInForum.setForumId(form.getForumId());
        topicInForum.setTopicId(form.getTopicId());
        
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(topicInForum);
        msg.setMsgContext(context); // pass the JtContext        
        
        factory.sendMessage (adapter, msg);        
        
        
        if (propagateException (adapter) != null) { 
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
        

        
        posting.setDate(new Date ());
        posting.setUserId(context.getUserName());
        posting.setPostingId(id.longValue());
        posting.setMessage(form.getMessage());
        
        if (moderatorId != null && !moderatorId.equals("")) {
            posting.setApproved(false);
        } else
            posting.setApproved(true);
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(posting);
        msg.setMsgContext(context); // pass the JtContext
        
         
        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        
        if (propagateException (adapter) != null) { 
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }  
        
        
        postingInTopic.setPostingId (id.longValue());
        postingInTopic.setTopicId(form.getTopicId());
        
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(postingInTopic);
        msg.setMsgContext(context); // pass the JtContext        
        
        factory.sendMessage (adapter, msg);        
        
        if (propagateException (adapter) != null) { 
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }  

        updateForum (form.getTopicId());
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }

    private void deleteTopic () {
        JtMessage msg = new JtMessage ();

        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtDELETE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }  
    
    
    private void updateTopic () {
        JtMessage msg = new JtMessage ();

        
        if (topicId == 0L) {
            handleError ("Attribute topicId needs to be set.");
            return;
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtUPDATE);


        msg.setMsgContent(this);
                
        
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    } 
    
    long StringtoLong (String postingId) {
        long lpostingId;
        
        try {
            lpostingId = Long.parseLong(postingId);
        } catch (Exception e) {
            handleException (e);
            return (-1L);
        }
        return (lpostingId);
    }

    List retrieveSiblingPostings (String sPostingId) {
        PostingInTopic postingInTopic = new PostingInTopic ();
        Topic topic;
        long postingId;
        
        if (sPostingId == null)
            return (null);
        
        postingId = StringtoLong (sPostingId);
        
        if (postingId <= 0L)
            return (null);
            
        
        postingInTopic.setPostingId(postingId);
        
        topic = (Topic) factory.sendMessage(postingInTopic, new JtMessage (PostingInTopic.RETRIEVE_TOPIC));
        
       
        if (topic == null)
            return null;
        
        updateNavigationLink (sPostingId);
        
        //this.setTopicId(topic.getTopicId());
        
        
        return (retrievePostingsInTopic (topic.getTopicId() + ""));
    }
    
    private String getToken (String str, int index) {
        //StringBuffer token = new StringBuffer ();
        int lastIndex;
        
        if (str == null || index < 0)
            return (null);
        
        
        lastIndex = index;
        
        while (lastIndex < str.length()) {

            if (Character.isWhitespace(str.charAt(lastIndex)))
                break;
   
            lastIndex++;
        }
        
        return (str.substring(index, lastIndex));
    }
    

    private String formatText (String str) {
        //String tmp;
        StringBuffer sBuffer = new StringBuffer ();
        int i = 0;
        int cnt = 0;
        String token;
        char c;

        if (str == null)
            return (null);
        
        while (i < str.length()) {
            
            c = str.charAt(i);
            
            if (Character.isWhitespace(c)) {
                if (c == '\n') { // check
                    sBuffer.append("<br />");   
                    cnt = 0;
                    i++;
                    continue;
                }
                
                if ((Posting.MAX_LENGTH <= 0)
                        || (cnt + 1 < Posting.MAX_LENGTH)) {
                    sBuffer.append(c);
                    i++;
                    cnt++;
                    continue;
                }
                sBuffer.append("<br />");   
                cnt = 0;
                i++;
                continue;
                
            }
            
            token = getToken (str, i);
            
            if ((Posting.MAX_LENGTH <= 0) || 
                    (cnt + token.length() < Posting.MAX_LENGTH)) {
                sBuffer.append(token);
                cnt += token.length();
                i += token.length();
                continue;
            }
            
            sBuffer.append("<br />"); 
            sBuffer.append(token);
            cnt = token.length();
            
            i += token.length();
            //cnt = 0;
            
            
        }
        
        //tmp = str.replaceAll("\n", "<br />");
        
        return (sBuffer.toString());
    }
    
    // Being moved to Topic
    
    
    private void massageList (List list) {
        Iterator iterator;
        Posting posting;
        //String tmp;
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        


        while (iterator.hasNext()) {
            
            

            posting = (Posting) iterator.next();
            
            posting.setMessage(formatText (posting.getMessage ()));
            

      
        }
        
        
    }
    
    
    List retrievePostingsInTopic (String topicId) {
        String query = "Select * from posting_in_topic t, posting p WHERE p.postingId=t.postingId and t.topicId=" +
        topicId + " and p.approved=1 order by p.date desc";
        //CRUD crud = new CRUD ();
        JtMessage msg = new JtMessage (CRUD.EXECUTE_QUERY);
        List list;
        
        
        if (topicId == null) {
            handleError ("Invalid parameter topicId:" + topicId);
            return (null);
        }
        
        /*
        crud.setQuery
        ("Select * from posting_in_topic t, posting p WHERE p.postingId=t.postingId and t.topicId=" +
                topicId + " and p.approved=1 order by p.date desc");
        crud.setClassname(Posting.JtCLASS_NAME);
        msg.setMsgContext(context);
        */
        
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        //msg.setMsgContext(context); 

        msg.setMsgContent(query);
       
       
        msg.setMsgData (new Posting());
        
        
        
        list = (List) factory.sendMessage(adapter, msg);
    
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
        
        massageList (list);
                    
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (list);
    }
    
    
    private Forum retrieveParentForum (String topicId) {
        TopicInForum topicInForum = new TopicInForum ();
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
        long ltopicId;
        Forum forum;
        
        if (topicId == null)
            return (null);
       
        
        ltopicId = StringtoLong (topicId);
        
        if (ltopicId <= 0L)
            return (null);
        
        topicInForum.setTopicId(ltopicId);
        
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        return (forum);
    }
    
    private HttpSession retrieveSession (JtContext context) {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        return (session);    
    }  
    
    void updateNavigationLink (String sTopic) {
        HttpSession session;
        Forum forum;
        long lforumId, ltopicId;
        JtMessage msg;
        NavigationLink navigationLink = new NavigationLink ();
        Topic topic;
        
        if (context == null) {
            return;
        }
        
        session = retrieveSession (context);
        
        if (session == null)
            return;
        forum = new Forum ();

        
        try {
            ltopicId = Long.parseLong(sTopic);
        } catch (Exception e) {
            //handleException (e);
            handleWarning (e.getMessage());
            return;
        }
        
        topicId = ltopicId;
        
        topic = readTopic ();
        
        if (topic == null)
            return;
        
        forum = retrieveParentForum (topic.getTopicId() + "");
        
        /*
        forum.setForumId(lforumId);
        
        msg = new JtMessage (JtDAOAdapter.JtREAD);
        
        forum = (Forum) factory.sendMessage(forum, msg);
        */
        
        if (forum == null) {
            session.removeAttribute(NavigationLink.NAVIGATION_LINK_ID);
            return;
        }
        
        navigationLink.setForumId(forum.getForumId());
        navigationLink.setForumName(forum.getDescription());
        navigationLink.setTopicId(topic.getTopicId());
        navigationLink.setTopicName(topic.getSubject());
        
        session.setAttribute(NavigationLink.NAVIGATION_LINK_ID, navigationLink);
        /*       
        if (forum != null)
            session.setAttribute(Forum.CURRENT_FORUM_ID, forum);
        */
        
        
    }
    
    NavigationLink retrieveNavigationLink () {
        HttpSession session;
        
        if (context == null) {
            return (null);
        }
        
        session = retrieveSession (context);
        
        if (session == null)
            return (null);       
        
        return ((NavigationLink) session.getAttribute(NavigationLink.NAVIGATION_LINK_ID));
        
    }

    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        //TopicForm form = null;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();
                
        if (e.getMsgId().equals (JtDAOAdapter.JtREAD)) {
           
            return (readTopic ()); 
        }
 
        if (e.getMsgId().equals (JtDAOAdapter.JtDELETE)) {
            deleteTopic ();
            return (null); 
        }
        
        if (e.getMsgId().equals (JtDAOAdapter.JtUPDATE)) {
            updateTopic ();
            return (null); 
        }
        
        if (e.getMsgId().equals (Topic.RETRIEVE_POSTINGS)) {

            return (retrievePostings ()); 
        }
        
        
        
        
        /*
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        

        form = (TopicForm) context.getActionForm();  
        
        if (e.getMsgId().equals (JtDAOAdapter.JtCREATE)) {
            addTopic (form);
            return (null); 
        }
        */
        
        //handleError ("Invalid msg Id:" + msgid);
        //return (null);
        return (super.processMessage (message));


    }
}