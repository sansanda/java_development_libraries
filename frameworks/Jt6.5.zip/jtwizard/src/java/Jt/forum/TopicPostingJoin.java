package Jt.forum;

import java.util.Date;







public class TopicPostingJoin  {


    
    private static final long serialVersionUID = 1L;


    private long topicId; 
    private String subject;
    //private String message;
    private int replies;
    private String creatorId;
    private long lastPostingId;
    
    // Posting
    
    private String userId;
    private Date date;




    private String lastPosting;
    


    public long getTopicId() {
        return topicId;
    }



    public void setTopicId(long topicId) {
        this.topicId = topicId;
    }



    public String getSubject() {
        return subject;
    }



    public void setSubject(String description) {
        this.subject = description;
    }
 

    public int getReplies() {
        return replies;
    }

    public void setReplies(int replies) {
        this.replies = replies;
    }

    public String getCreatorId() {
        return creatorId;
    }



    public void setCreatorId(String creatorId) {
        this.creatorId = creatorId;
    }



    public long getLastPostingId() {
        return lastPostingId;
    }



    public void setLastPostingId(long lastPostingId) {
        this.lastPostingId = lastPostingId;
    }



    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }




    

    
    public Date getDate() {
        return date;
    }



    public void setDate(Date date) {
        this.date = date;
    }



    public String getLastPosting() {
        return lastPosting;
    }

    // Display 

    public void setLastPosting(String lastPosting) {
        this.lastPosting = lastPosting;
    }





}