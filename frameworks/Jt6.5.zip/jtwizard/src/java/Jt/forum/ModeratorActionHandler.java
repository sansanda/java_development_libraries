package Jt.forum;


import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


import Jt.JtContext;

import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.forum.form.ModeratorActionForm;
//import Jt.forum.form.TopicForm;
import Jt.wizard.struts.CRUD;



public class ModeratorActionHandler  extends Moderator   {


    public static final String JtCLASS_NAME = ModeratorActionHandler.class.getName();  
    public static final String APPROVE = "APPROVE"; 
    public static final String RETRIEVE_MODERATED_POSTINGS = "RETRIEVE_MODERATED_POSTINGS";
    public static final String DELETE_REJECTED_POSTINGS = "DELETE_REJECTED_POSTINGS";

    private String selectOneItemMessage = "Please select at least one topic to approve/reject.";
    
    
    private static final long serialVersionUID = 1L;

    public String getSelectOneItemMessage() {
        return selectOneItemMessage;
    }



    public void setSelectOneItemMessage(String selectOneItemMessage) {
        this.selectOneItemMessage = selectOneItemMessage;
    }



    private Posting retrievePosting (long postingId) {
        Posting posting = new Posting ();
        Posting tmp;
        
        if (postingId == 0L)
            return (null);
        
        posting.setPostingId(postingId);
        
        tmp = (Posting) factory.sendMessage(posting, new JtMessage (JtDAOAdapter.JtREAD));
        
        return (tmp);        
        
    }
    
    
       
    private boolean approvePosting (long postingId) {
        Posting posting = new Posting ();
        Posting tmp;
        
        if (postingId == 0L)
            return (false);
        
        posting.setPostingId(postingId);
        
        tmp = (Posting) factory.sendMessage(posting, new JtMessage (JtDAOAdapter.JtREAD));
        
        if (tmp == null)
            return (false);
      
        tmp.setApproved(true);
        factory.sendMessage(tmp, new JtMessage (JtDAOAdapter.JtUPDATE));        
        
        if (tmp.getObjException() != null)
            return (false);
        
        return (true);
    }
    
    private void massageList (List list) {
        Iterator iterator;
        Posting posting;
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        

        while (iterator.hasNext()) {
            
            
            posting = (Posting) iterator.next();
            factory.sendMessage(posting, new JtMessage (Posting.MASSAGE_MESSAGE));
                  
        }
        
        
    }   
    
    private List retrieveModeratedPostings (String moderatorId) {
        
        CRUD crud = new CRUD ();
        JtMessage msg = new JtMessage (CRUD.EXECUTE_QUERY);
        List list;        
        
        
        if (moderatorId == null) {
            handleError ("Invalid parameter (moderator Id)");
            return null;
        }
        
        crud.setQuery
        ("Select * from forum f, topic_in_forum tf ,posting_in_topic t, posting p " +
                "WHERE f.forumId=tf.forumId and tf.topicId=t.topicId" +
                " and p.postingId=t.postingId" + " and f.moderatorId=\'" + moderatorId +  
                "\' and p.approved=0 order by p.date desc");
        crud.setClassname(Posting.JtCLASS_NAME);
        crud.setCheckAccess(true);
        msg.setMsgContext(context);
        
        list = (List) factory.sendMessage(crud, msg);
    
        if (propagateException (crud) != null)
            return (null);
        
        massageList (list);
        return (list);        
        
    }
    
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    
    private long StringtoLong (String postingId) {
        long lpostingId;
        
        try {
            lpostingId = Long.parseLong(postingId);
        } catch (Exception e) {
            handleException (e);
            return (-1L);
        }
        return (lpostingId);
    }
    
    
    private void updateParentForum (long topicId) {
        Forum forum;
        TopicInForum topicInForum = new TopicInForum ();
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
        
        if (topicId == 0L)
            return;
        
        topicInForum.setTopicId(topicId);
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        if (forum == null) {
            handleWarning ("Unable to retrieve forum for topic" + topicId);
            return; 
        }
        
        forum.setLastPost(topicId);
        forum.setPosts(forum.getPosts() + 1);
        
        factory.sendMessage(forum, new JtMessage (JtDAOAdapter.JtUPDATE));
        
    }
    
    private Object moderatePostings (HttpServletRequest request) {
        Enumeration parameters;
        String param;
        LinkedList rejected = new LinkedList ();
        long lpostingId;
        Posting posting;
        ModeratorActionForm moderatorForm = new ModeratorActionForm ();
        Topic topic;
        boolean todo = false;
        
        if (request == null)
            return (null);
        
        parameters = request.getParameterNames();
        
        while (parameters.hasMoreElements()) {
            param = (String) parameters.nextElement();
            if ("Approve".equals(request.getParameter(param))) {
                //selected.add (param);
                lpostingId = StringtoLong (param);
                
                if (lpostingId  <= 0L)
                   continue;
                
                
                topic = retrieveParentTopic (lpostingId);
                
                if (topic == null)
                    continue;
                
                if (!updateParentTopic (topic, lpostingId))
                    continue;
                
                if (!approvePosting (lpostingId))
                    continue;
                
                todo = true;
                updateParentForum (topic.getTopicId());
  
            }
            
            if ("Reject".equals(request.getParameter(param))) {
                //selected.add (param);
                lpostingId = StringtoLong (param);
                

                if (lpostingId < 0L)
                    continue;
                
                posting = retrievePosting (lpostingId);
                todo = true;
                if (posting != null)
                    rejected.add(posting);
            }           
            //handleTrace ("FormBean.select:" + request.getParameter(param), 0);    
            //form.setSelected(selected);
        }
        
        if (!rejected.isEmpty())
            moderatorForm.setRejected(rejected);
        
        if (!todo) {
            handleUIError (this.getSelectOneItemMessage());
            return (null);
        }
        return (moderatorForm);
        //if (selected.isEmpty())
        //    handleUIError ("Please select one or more items from the list.");

    }
 
    
   
    
    private void rejectPosting (long postingId, String rejectionMessage) {
        Posting posting = new Posting ();
        Posting tmp;
        Topic topic;
        List postingList;
        //PostingInTopic postInTopic = new PostingInTopic ();
        //TopicInForum topicInForum = new TopicInForum ();
        //Forum forum;
        
        
        if (postingId == 0L)
            return;
        

        
        posting.setPostingId(postingId);
        
        tmp = (Posting) factory.sendMessage(posting, new JtMessage (JtDAOAdapter.JtREAD));
        

        
        if (propagateException (tmp) != null) {
            return;
        }
        
        if (tmp == null)
            return; // check
      
        
        factory.sendMessage(tmp, new JtMessage (JtDAOAdapter.JtDELETE)); 
        
        if (rejectionMessage != null && !rejectionMessage.equals(""))
            sendRejectionMessage (tmp.getUserId(), rejectionMessage);
        
        if (propagateException (tmp) != null) {
            return;
        }
        
        topic = (Topic) factory.sendMessage(posting, new JtMessage (Posting.RETRIEVE_TOPIC));
        
        if (propagateException (posting) != null) {
            return;
        }
        
        if (topic == null)
            return;
        
        /*
        postInTopic.setPostingId(postingId);
        postInTopic.setTopicId (topic.getTopicId());
        
        factory.sendMessage(postInTopic, new JtMessage (JtDAOAdapter.JtDELETE)); 
        */
        
        // Retrieve postings that belong to the topic
        
        postingList = (List) factory.sendMessage(topic, new JtMessage (Topic.RETRIEVE_POSTINGS));
        
        if (propagateException (topic) != null) {
            return;
        }
        
        if (postingList != null && postingList.size() == 0) {

            //topicInForum.setTopicId(topic.getTopicId());
            
            factory.sendMessage(topic, new JtMessage (JtDAOAdapter.JtDELETE));
        }
        
        
    }
    
    private void confirmRejectedPostings (ModeratorActionForm form) {
        List rejected;
        Iterator iterator;
        Posting posting;
        
        if (form == null)
            return;
        
        
        rejected = form.getRejected();
        
        if (rejected == null || rejected.isEmpty())
            return;
        
        iterator = rejected.iterator();
        
        while (iterator.hasNext()) {
            
            posting = (Posting) iterator.next();
            rejectPosting (posting.getPostingId(), form.getMessage());
        }
        
    }
    
    private Topic retrieveParentTopic (long postingId) {
        PostingInTopic postingInTopic = new PostingInTopic ();
        Topic tmp;
        
        postingInTopic.setPostingId(postingId);

        tmp = (Topic) 
        factory.sendMessage(postingInTopic, new JtMessage (PostingInTopic.RETRIEVE_TOPIC));
        
        return (tmp);
    }
    
    private boolean updateParentTopic (Topic topic, long postingId) {
        PostingInTopic postingInTopic = new PostingInTopic ();
        Topic tmp;
        
        if (topic == null || postingId == 0L)
            return (false);
        
        postingInTopic.setPostingId(postingId);
        
        tmp = (Topic) 
           factory.sendMessage(postingInTopic, new JtMessage (PostingInTopic.RETRIEVE_TOPIC));
        
        if (tmp == null)
            return (false);

        tmp.setLastPostingId(postingId);
        if (!tmp.isApproved ()) {
            tmp.setApproved(true);
            tmp.setReplies(0);
        } else {
            tmp.setReplies(tmp.getReplies() + 1);
        }
        factory.sendMessage(tmp, new JtMessage (JtDAOAdapter.JtUPDATE));        
        
        if (tmp.getObjException() != null)
            return (false);
        
        return (true);
    }
    
        
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        //DAOCategory category;
        //List list;
        ModeratorActionForm form;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();
               

        
        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        
        if (msgid.equals (ModeratorActionHandler.RETRIEVE_MODERATED_POSTINGS)) {
            
                        
            return (retrieveModeratedPostings (context.getUserName()));
            
        }       
        
        if (msgid.equals (JtObject.JtACTIVATE)) {
            
            
            return (moderatePostings (context.getRequest()));
            
        }  
        
        if (msgid.equals (ModeratorActionHandler.DELETE_REJECTED_POSTINGS)) {
            form = (ModeratorActionForm) context.getActionForm();  
            
            
            confirmRejectedPostings (form);
            return (null);
        }


        
        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
}