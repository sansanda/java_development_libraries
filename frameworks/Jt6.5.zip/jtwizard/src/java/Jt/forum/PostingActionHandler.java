package Jt.forum;


import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;


import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.form.PostingForm;




public class PostingActionHandler  extends Posting implements Comparable  {

    private static final long serialVersionUID = 1L;
    public static final String EDIT_MODERATED_POSTING = "EDIT_MODERATED_POSTING";
    public static final String UPDATE_MODERATED_POSTING = "UPDATE_MODERATED_POSTING";
    public static final String ADD_POSTING = "ADD_POSTING";
    public static final String NEW = "NEW";

    
    private String moderatedMessage = "Thank you for your posting. It has been sent to the forum moderator.";
    private String postedMessage =  "Thank you for your message. It has been posted to the forum."; 
 
    public String getModeratedMessage() {
        return moderatedMessage;
    }

    public void setModeratedMessage(String moderatedMessage) {
        this.moderatedMessage = moderatedMessage;
    }

    public String getPostedMessage() {
        return postedMessage;
    }

    public void setPostedMessage(String postedMessage) {
        this.postedMessage = postedMessage;
    }
 
    


    long StringtoLong (String postingId) {
        long lpostingId;
        
        try {
            lpostingId = Long.parseLong(postingId);
        } catch (Exception e) {
            handleException (e);
            return (-1L);
        }
        return (lpostingId);
    }
    
    private PostingForm editModeratedPosting (String postingId) {
        long lpostingId;
        Posting posting = new Posting (), tmp;
        PostingForm postingForm = new PostingForm ();
        PostingInTopic postingInTopic = new PostingInTopic ();
        Topic topic;
        
        if (postingId == null)
            return (null);
        
        lpostingId = StringtoLong (postingId);
        
        if (lpostingId <= 0L)
            return (null);
        
        posting.setPostingId(lpostingId);
        
        // check security
        tmp = (Posting) factory.sendMessage(posting, new JtMessage (JtDAOAdapter.JtREAD));
 
        if (propagateException (posting) != null) {
           return (null); 
        }
        
        if (tmp == null) {
            handleError ("Unable to read posting:" + postingId);
            return (null);
        }

        postingForm.setMessage(tmp.getMessage());
        postingForm.setPostingId(tmp.getPostingId());
        
        postingInTopic.setPostingId(lpostingId);
        
        topic = (Topic) factory.sendMessage(postingInTopic, new JtMessage (PostingInTopic.RETRIEVE_TOPIC));
        
        if (propagateException (posting) != null) {
            return (null); 
        }
        
        if (topic == null) {
            handleError ("Unable to retrieve parent topic:" + postingId);
            return (null);
        }
        
        //postingForm.setTopicId(topic.getTopicId());
        postingForm.setSubject(topic.getSubject());
        
        
        return (postingForm);
        
        
    }
    
    private void updateModeratedPosting (PostingForm form) {
        Posting posting = new Posting (), tmp;
        String message, subject;
        PostingInTopic postingInTopic = new PostingInTopic ();
        Topic topic;
        
        
        if (form == null) {
            handleError ("Invalid parameter (form): null");
            return;
        }
        
        if (form.getPostingId() == 0L) { 
            handleError ("Invalid form data");
            return;
        }
        
        posting.setPostingId(form.getPostingId());
        
        // check security
        tmp = (Posting) factory.sendMessage(posting, new JtMessage (JtDAOAdapter.JtREAD));
 
        if (propagateException (posting) != null) {
           return; 
        }
        
        if (tmp == null) {
            handleError ("Unable to read posting:" + form.getPostingId());
            return;
        }
        
        message = form.getMessage();
        
        if (message == null || message.equals("")) {
            return; // this should not happen
        }
        
        if (!message.equals(tmp.getMessage())) {
            tmp.setMessage(message);
            
            factory.sendMessage(tmp, new JtMessage (JtDAOAdapter.JtUPDATE));
        }
        
        postingInTopic.setPostingId(posting.getPostingId());
        
        topic = (Topic) factory.sendMessage(postingInTopic, new JtMessage (PostingInTopic.RETRIEVE_TOPIC));
               
        if (topic == null) {
            return;
        }
        
        subject = form.getSubject();
        if (subject == null || subject.equals("")) {
            return; 
        }
        
        if (!subject.equals(topic.getSubject())) {
            topic.setSubject(subject);
            
            factory.sendMessage(topic, new JtMessage (JtDAOAdapter.JtUPDATE));
        }
    }
    
    private JtHashTable retrieveAttributes (Object obj) {
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtFactory fact = new JtFactory ();
        
        if (obj == null)
            return (null);
        msg.setMsgContent(obj);
        fact.setStopClass(obj.getClass().getSuperclass());
        
        return ((JtHashTable) fact.processMessage(msg));
        
    }
    
    private void copyFormAttributes (ActionForm form, Object obj) {
        JtHashTable attributes;
        JtIterator iterator;
        String attribute;
        Object value;
        
        if (obj == null || form == null)
            return;
        //attributes = getAttributes (obj);
        attributes = retrieveAttributes (form);
        
        if (attributes == null)
            return;
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        if (iterator == null)
            return;
        
        for (;;) {
            attribute = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (attribute == null)
                break;
            
            if (attribute.equals("topicId")) {
                continue;
            }
            
            if (attribute.equals("subject")) {
                continue;
            }
            
            value = factory.getValue(form,attribute);
            factory.setValue (obj, attribute, value);
                
        }
        
    }
    
    private boolean addPostingToTopic (PostingForm form, Forum forum) {
        JtMessage msg = new JtMessage ();
        Posting posting = new Posting ();
        PostingInTopic postingInTopic = new PostingInTopic ();
        Long id;
        long postingId;

      
        if (form == null) {
            handleError ("Invalid parameter (form): null");
            return false; 
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(true);
        
        copyFormAttributes (form, posting);
        
        //System.out.println(form.getMessage());
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return false;
        }
        postingId = id.longValue();
        
        posting.setDate(new Date ());
        posting.setUserId(context.getUserName());
        posting.setPostingId(postingId);
        
        if (forum.getModeratorId() != null &&
                !forum.getModeratorId().equals("")) {
            posting.setApproved(false);
        } else
            posting.setApproved(true);           
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(posting);
        msg.setMsgContext(context); // pass the JtContext
        
        // check - already exists 
        
        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return false;
        }


        
        //postingInTopic.setPostingId(form.getPostingId());
        postingInTopic.setPostingId(postingId);
        postingInTopic.setTopicId(form.getTopicId());       

                      
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(postingInTopic);
        msg.setMsgContext(context); // pass the JtContext
        
         
        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        

        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return false;
        }
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (true);
                
    } 
    
    private void notifyModerator (String userId) {
        Moderator moderator;
        
        
        if (userId == null)
            return;
        
        moderator = (Moderator) factory.createObject(Moderator.JtCLASS_NAME);
        
        moderator.setUserId(userId);
        
        factory.sendMessage(moderator, new JtMessage (Moderator.NOTIFY_MODERATOR));
       
        
    }
    
    private void updateTopic (long topicId, long postingId) {
        //long forumId;
        //Forum forum;
        Topic topic = new Topic ();
        JtMessage msg = new JtMessage (JtDAOAdapter.JtREAD);

        if (topicId == 0L || postingId == 0L) {
            handleError ("Invalid form data");
            return;
        }
            
        topic.setTopicId(topicId);
        topic = (Topic) factory.sendMessage(topic, msg);

        if (propagateException (topic) != null)
            return;


        if (topic == null)
            return; // check

        // Update Topic instance

        topic.setLastPostingId(postingId);
        topic.setReplies(topic.getReplies() + 1);

        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 

        msg.setMsgId (JtDAOAdapter.JtUPDATE); 

        msg.setMsgContent(topic);

        factory.sendMessage(adapter, msg);

        // Propagate the exception

        propagateException (adapter);


        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));   

    } 
    
    private void updateForum (Forum forum, long postingId, long topicId) {
        //long forumId;
        //TopicInForum topicInForum = new TopicInForum ();
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
      
        if (forum == null)
            return;
        
        
        if (postingId <= 0L || topicId <= 0L) {
            handleError ("Invalid form data");
            return;
        }    

        /*
        topicInForum.setTopicId(topicId);
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        if (forum == null)
            return; // check
        */

        
        // Update Forum instance
        
        forum.setLastPost(topicId);
        forum.setPosts(forum.getPosts() + 1);
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        
        msg.setMsgId (JtDAOAdapter.JtUPDATE); 
        
        msg.setMsgContent(forum);
        
        factory.sendMessage(adapter, msg);
        
        // Propagate the exception
       
        propagateException (adapter);
        
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));   
 
    }
    
    private Forum retrieveParentForum (long topicId) {
        JtMessage msg = new JtMessage (TopicInForum.RETRIEVE_FORUM);
        TopicInForum topicInForum = new TopicInForum ();
        Forum forum;
        
        if (topicId == 0L) {
            return (null);
        }    
        
        topicInForum.setTopicId(topicId);
        forum = (Forum) factory.sendMessage(topicInForum, msg);
        
        if (propagateException (topicInForum) != null)
            return (null);
        
        return (forum);
    }
    
    private PostingForm newPosting (String topicId) {
        PostingForm form = new PostingForm ();
        Long id;
        long ltopicId;
        
        if (topicId == null || topicId.equals("")) {
            handleError ("Invalid parameter (forumId):null or empty" );
            return (null);
        }    
        
        try {
            ltopicId = Long.parseLong(topicId);
        } catch (Exception e) {
            handleException (e);
            return (null);
        }
        
        form.setTopicId(ltopicId);
        
        id =  (Long) factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID));
        
        if (id == null) {
            handleError ("Invalid framework Id:null" );
            return (null);
        }
        
        form.setPostingId(id.longValue());
        
        return (form);
        
    }
    
    private HttpSession retrieveSession (JtContext context) {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        return (session);    
    }  
    
    NavigationLink retrieveNavigationLink () {
        HttpSession session;
        
        if (context == null) {
            return (null);
        }
        
        session = retrieveSession (context);
        
        if (session == null)
            return (null);       
        
        return ((NavigationLink) session.getAttribute(NavigationLink.NAVIGATION_LINK_ID));
        
    }

    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //TopicForm form = null;
        PostingForm form;
        //DAOCategory category;
        List list;
        Forum forum;
        String moderatorId;
        NavigationLink navigationLink;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        content = e.getMsgContent();
        
        context = (JtContext) e.getMsgContext();
        
 
        
        
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
 /*       
        if (msgid.equals (Posting.RETRIEVE_POSTINGS)) {

            category = new DAOCategory ();
            
            category.setCategoryId((String) e.getMsgContent());
            
            list = (List) retrievePostingsInTopic ((String) e.getMsgContent());
            
            if (list == null)
                return (null);
            category.setCategoryList(list);           
            return (category);
            
        }  
*/        
        if (msgid.equals (Posting.PREVIEW)) {

            form = (PostingForm) context.getActionForm();  
            
            
            return (previewPosting (form));
            
        }  
        
        if (msgid.equals (PostingActionHandler.NEW)) {

            navigationLink = retrieveNavigationLink ();
            
            if (navigationLink == null || (navigationLink.getTopicId () <= 0L))
                return (null);
            
            return (newPosting (navigationLink.getTopicId () + ""));
            
        }    
        
        if (e.getMsgId().equals(Posting.SEARCH_FOR_KEYWORDS)) {
            
            form = (PostingForm) context.getActionForm();  
            
            return (searchForKeywords (form));
        }    
        
        if (e.getMsgId().equals (PostingActionHandler.EDIT_MODERATED_POSTING)) {
            return (editModeratedPosting ((String) e.getMsgContent()));
        }
        
        if (e.getMsgId().equals (PostingActionHandler.UPDATE_MODERATED_POSTING)) {
            
            form = (PostingForm) context.getActionForm(); 
            
            updateModeratedPosting (form);
            return (null);
        }
        
        if (e.getMsgId().equals (PostingActionHandler.ADD_POSTING)) {
            //super.processMessage (e);
            
            //if (this.getObjException() != null)
            //    return (null);
            
            context = (JtContext) e.getMsgContext(); // Redundant
            
            if (context == null || context.getUserName() == null) {
                handleError ("Invalid context. You session may have expired. Please log in.");
                return (null);
            }
            
            form = (PostingForm) context.getActionForm();
                        
            
            if (form == null || form.getTopicId() <= 0L ||
                    form.getPostingId() <= 0L) {
                handleError ("Invalid form data");
                return (null);
            }
            
            forum = retrieveParentForum (form.getTopicId());
            
            if (forum == null)
                return (null);
            
            if (!addPostingToTopic (form, forum))
                return (null);
        
            moderatorId = forum.getModeratorId();
            
            if (moderatorId != null && !moderatorId.equals("")) {
                notifyModerator (forum.getModeratorId()); 
                return (this.getModeratedMessage());
            }
            
            updateForum (forum, form.getPostingId(), form.getTopicId());
            
            updateTopic (form.getTopicId(), form.getPostingId());
            
              

            
            return (this.getPostedMessage()); // check
        }
        
        handleError ("Invalid msg Id:" + msgid);
        return (null);


    }
}