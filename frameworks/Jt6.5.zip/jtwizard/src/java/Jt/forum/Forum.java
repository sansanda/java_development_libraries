package Jt.forum;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.wizard.struts.CRUD;



public class Forum extends JtObject {



    public static final String JtCLASS_NAME = Forum.class.getName(); 
    public static final int MAX_DESCRIPTION_SIZE = 15; 
    
    public static final String RETRIEVE_CURRENT_FORUM = "RETRIEVE_CURRENT_FORUM"; 
    public static final String CURRENT_FORUM_ID = "jtCurrentForum"; 
    public static final String RETRIEVE_TOPICS = "RETRIEVE_TOPICS";
    
    private static final long serialVersionUID = 1L;

    private long forumId;
    private String description;
    private int posts; 
    private int sequence;
    private long lastPost;
    private String moderatorId;
    
    private transient String lastPosting; // calculated
    
    transient JtFactory factory = new JtFactory ();
    transient JtContext context;
    transient JtDAOStrategy adapter = null;
   
    

    public long getForumId() {
        return forumId;
    }

    public void setForumId(long forumId) {
        this.forumId = forumId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
 


    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }


    public int getPosts() {
        return posts;
    }

    public void setPosts(int posts) {
        this.posts = posts;
    }
    
    public long getLastPost() {
        return lastPost;
    }

    public void setLastPost(long lastPost) {
        this.lastPost = lastPost;
    }

    public String getModeratorId() {
        return moderatorId;
    }

    public void setModeratorId(String moderatorId) {
        this.moderatorId = moderatorId;
    }

    public String getLastPosting() {
        return lastPosting;
    }

    public void setLastPosting(String lastPosting) {
        this.lastPosting = lastPosting;
    }

    private Exception propagateException (JtObject obj)
    {
        Exception ex;

        if (obj == null)
            return null;

        ex = (Exception) obj.getObjException();

        if (ex != null)
            this.setObjException(ex);

        return (ex);
    }
    
    
    private Posting retrievePosting (long postingId) {
        Posting posting = new Posting (); 
        JtMessage msg = new JtMessage (JtDAOAdapter.JtREAD);
        
        
        if (postingId == 0L)
            return (null);
        
        posting.setPostingId(postingId);
        
        return ((Posting) factory.sendMessage(posting, msg));
        
    }
    
    
    private Topic retrieveTopic (long topicId) {
        Topic topic = new Topic (); 
        JtMessage msg = new JtMessage (JtDAOAdapter.JtREAD);
        
        
        if (topicId == 0L)
            return (null);
        
        topic.setTopicId(topicId);
        
        return ((Topic) factory.sendMessage(topic, msg));
        
    }
 
    
    private String buildField (ForumPostingJoin forum) {
        StringBuffer sb = new StringBuffer ();
        //Topic topic;
        //Posting posting;
        String desc;
        
        
        
        if (forum == null)
            return (null);
                
        
        desc = forum.getSubject();
        
        if (desc == null || desc.equals("")) {
            return (null);
        }
        
        if (desc.length() > MAX_DESCRIPTION_SIZE) {
            desc = desc.substring(0, MAX_DESCRIPTION_SIZE) + "..";
        }
        
        sb.append
        ("<a href=\"../Posting.do?msgId=RETRIEVE_POSTINGS&msgContent=" + forum.getTopicId() +
                
                "\">" + desc + "</a>");
        

        //posting = retrievePosting (topic.getLastPostingId());
        
        //if (posting == null)
        //    return (sb.toString());
        
        
        if (forum.getUserId() != null) {
            sb.append(" by ");

            sb.append
            ("<a href=\"../ReadForumProfile.do?msgId=RETRIEVE_PROFILE_FORM&msgContent=" + forum.getUserId() +

                    "\">" + forum.getUserId()+ "</a>");
            
            if (forum.getDate() != null) {
                sb.append(" - " + forum.getDate());
            }
        }
        //sb.append(str);
        
        return (sb.toString());
        
        
    }  
    private void massageList (List list) {
        Iterator iterator;
        ForumPostingJoin forum;
        //StringBuffer sb = new StringBuffer ();
        //Posting posting;
        String tmp;
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        

        /*
        sb.append
        ("<a href=\"../RetrieveForumTopics.do?msgId=JtACTIVATE&msgContent=" +
                
                "\">view</a>");
        */
        
        while (iterator.hasNext()) {
            
            

            forum = (ForumPostingJoin) iterator.next();
            
            tmp = buildField (forum);
            
            if (tmp != null)
                forum.setLastPosting(tmp);
/*
            posting = retrievePosting (forum.getLastPost());
            
            if (posting == null)
                return;
*/
            
        }
        
        
    }


    
    List retrieveForums () {
        String query = "Select f.forumId, f.description, f.posts, f.moderatorId, t.topicId, t.subject, p.postingId, p.userId, p.date from  "
            + "(forum f left join topic t  on t.topicId=f.lastPost) left join posting p on t.lastPostingId=p.postingId";

        List list;
        JtMessage msg = new JtMessage ();
        List classList = new LinkedList ();
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_JOIN);
        //msg.setMsgContext(context); 

        msg.setMsgContent(query);
       
       
        msg.setMsgData (new ForumPostingJoin ());
                
        classList.add(Forum.JtCLASS_NAME);
        classList.add(Topic.JtCLASS_NAME);
        classList.add(Posting.JtCLASS_NAME);
        
        msg.setMsgAttachment(classList);
        
        list = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        massageList (list);
        
        return (list);
    }
    
    
    private HttpSession retrieveSession (JtContext context) {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        return (session);    
    }   
    
    Forum retrieveCurrentForum () {
        HttpSession session = null;       
        
        if (context == null) {
            return (null);
        }
        
        session = retrieveSession (context);
        
        if (session == null) {
            return (null);
        }
        
        return ((Forum) session.getAttribute(Forum.CURRENT_FORUM_ID));
    }
    
    private Forum readForum () {
        
        JtMessage msg = new JtMessage ();
        //List result;
        Forum forum;
        
        
        if (forumId == 0L) {
            handleError ("Attribute forumId needs to be set.");
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtREAD);


        msg.setMsgContent(new Forum ());
       
       
        msg.setMsgData (new Long (forumId));
                
        
        forum = (Forum) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }  
        
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (forum);
    }
    
    
    private void updateForum () {
        
        JtMessage msg = new JtMessage ();
        Forum forum;
               
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtUPDATE);


        msg.setMsgContent(this);
                                     
        factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }  
        
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return;
    }
    
    void updateNavigationLink () {
        NavigationLink navigationLink = new NavigationLink ();
        HttpSession session;
        
        //navigationLink.setForumId(forum.getForumId());
        //navigationLink.setForumName(forum.getDescription());
        
        session = retrieveSession (context);
        
        if (session == null)
            return;
        
        session.setAttribute(NavigationLink.NAVIGATION_LINK_ID, navigationLink);
                
        
    }
    
    void updateNavigationLink (String sForum) {
        HttpSession session;
        Forum forum;
        long lforumId;
        JtMessage msg;
        NavigationLink navigationLink = new NavigationLink ();
        
        if (context == null) {
            return;
        }
        
        session = retrieveSession (context);
        
        if (session == null)
            return;
        forum = new Forum ();
        
        try {
            lforumId = Long.parseLong(sForum);
        } catch (Exception e) {
            //handleException (e);
            handleWarning (e.getMessage());
            return;
        }
        
        forum.setForumId(lforumId);
        
        msg = new JtMessage (JtDAOAdapter.JtREAD);
        
        forum = (Forum) factory.sendMessage(forum, msg);
        
        if (forum == null) {
            session.removeAttribute(NavigationLink.NAVIGATION_LINK_ID);
            return;
        }
        
        navigationLink.setForumId(forum.getForumId());
        navigationLink.setForumName(forum.getDescription());
        
        session.setAttribute(NavigationLink.NAVIGATION_LINK_ID, navigationLink);
        /*       
        if (forum != null)
            session.setAttribute(Forum.CURRENT_FORUM_ID, forum);
        */
        
        
    }
    
    private String buildDField (TopicPostingJoin topic) {
        StringBuffer sb = new StringBuffer ();
        //Posting posting;
        
        
        if (topic == null)
            return (null);
               
        
        //posting = retrievePosting (lastPosting);
        
        //if (posting == null)
            //return (null);
        
        
        sb.append
        ("<a href=\"../Posting.do?msgId=RETRIEVE_POSTINGS&msgContent=" + topic.getTopicId() +

                "\">" + topic.getDate()+ "</a>");
        
        if (topic.getUserId() != null) {
            
           
            sb.append(" by ");

            sb.append
            ("<a href=\"../ReadForumProfile.do?msgId=RETRIEVE_PROFILE_FORM&msgContent=" + topic.getUserId() +

                    "\">" + topic.getUserId()+ "</a>");
            

        }
        //sb.append(str);
        
        return (sb.toString());
        
        
    }
    
    
    
    private void massageTopicList (List list) {
        Iterator iterator;
        TopicPostingJoin topic;
        String tmp;
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        


        while (iterator.hasNext()) {
            
            

            topic = (TopicPostingJoin) iterator.next();
            
            tmp = buildDField (topic);
            
            if (tmp != null)
                topic.setLastPosting(tmp);
      
        }
        
        
    }
    
    List retrieveTopicsInForum (String forumId) {
        CRUD crud = new CRUD ();
        List list;
        List classList = new LinkedList ();
        JtMessage msg = new JtMessage ();
        
        String query = "Select t.topicId, t.subject, t.replies, t.userId as creatorId, t.lastPostingId, p.userId, p.date from topic_in_forum c, topic t, posting p WHERE c.topicId=t.topicId and c.forumId=" +
                forumId + " and t.lastPostingId=p.postingId and t.approved=1 order by p.date desc";
        
        if (forumId == null) {
            handleError ("Invalid forumId:" + forumId);
            return (null);
        }
        
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_JOIN);
        
        msg.setMsgContent (query);
        msg.setMsgData (new TopicPostingJoin ());
        
        //classList.add(Forum.JtCLASS_NAME);
        classList.add(Topic.JtCLASS_NAME);
        classList.add(Posting.JtCLASS_NAME);
        
        msg.setMsgAttachment(classList);
        
        list = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return null;
        }    
             
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        massageTopicList (list);
        
        return (list);
        
    }
    
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        ActionForm form = null;
        //TopicForm form = null;
        //PostingForm form;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        content = e.getMsgContent();
        context = (JtContext) e.getMsgContext();

        /*
        if (msgid.equals (JtObject.JtACTIVATE)) {
            updateNavigationLink ();
            return (retrieveForums ());
            
        }    
        */
        
        if (e.getMsgId().equals (JtDAOAdapter.JtREAD)) {
            
            return (readForum ()); 
        }
        
        if (e.getMsgId().equals (JtDAOAdapter.JtUPDATE)) {
            updateForum ();
            return (null); 
        }

        /*
        if (msgid.equals (Forum.RETRIEVE_CURRENT_FORUM)) {

            return (retrieveCurrentForum ());
            
        } 
        */
        return (super.processMessage (message));
        //handleError ("Invalid msg Id:" + msgid);
        //return (null);


    }
 

}