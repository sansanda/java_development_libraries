
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

/*
 * Work in progress (see BPEL Engine)
 */
package Jt.parallel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import Jt.JtComponent;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.esb.JtESBBridge;
import Jt.examples.HelloWorld;
import Jt.rest.JtRestService;
import Jt.util.JtExpression;


/**
 * Master Worker design pattern.
 */


public class MasterWorker extends JtObject {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = MasterWorker.class.getName(); 
  public static final String ADD_WORKER = "ADD_WORKER"; 

  private List urlList = new ArrayList ();


  private String workerClassname;


  public MasterWorker() {
  }
  public String getWorkerClassname() {
	  return workerClassname;
  }



  public void setWorkerClassname(String workerClassname) {
	  this.workerClassname = workerClassname;
  }






  private void activate () {
	  Iterator iterator;
	  Object member;
	  String url;
	  JtFactory factory = new JtFactory ();
	  JtESBBridge adapter;
	  
	  
	  if (urlList == null)
		  return;
	
	  iterator = urlList.iterator();
	  
	  while (iterator.hasNext()) {
		  url = (String) iterator.next();
		  
		  adapter = new JtESBBridge ();
		  adapter.setUrl(url);
	      adapter.setImplementorClassname (JtRestService.JtCLASS_NAME);
		  adapter.setClassname(workerClassname);
		  
		  //factory.sendMessage(adapter, new JtMessage (JtComponent.JtACTIVATE));
		  factory.sendMessage(adapter, new JtMessage (HelloWorld.JtHELLO));
	  }
	  
  }
  
  public void addWorker (String url) {

	  if (url == null)
		  return;
	  urlList.add(url);


  }
  
  public Object processMessage(Object msg) {
      JtMessage e = (JtMessage) msg;
      Object obj;
      String msgid;

      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;

      if (msgid.equals(MasterWorker.ADD_WORKER)) {
    	  addWorker ((String) e.getMsgContent());
    	  return (null);    	
      }
      
      if (msgid.equals(JtComponent.JtACTIVATE)) {
    	  activate ();
    	  return (null);    	
      }
      
      
      return (super.processMessage(msg));
  }


  /**
    * Demonstrates the messages processed by JtAdapter.   
    */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    MasterWorker masterWorker;
    JtMessage msg = new JtMessage (MasterWorker.ADD_WORKER);
	String url = "http://localhost:8080/JtPortal/JtRestService";

    // Create an instance of MasterWorker

    masterWorker = (MasterWorker)
    factory.createObject (MasterWorker.JtCLASS_NAME);
    
    msg.setMsgContent(url);
    factory.sendMessage(masterWorker, msg);
    factory.sendMessage(masterWorker, msg);
    factory.sendMessage(masterWorker, msg);
    
    //masterWorker.setWorkerClassname("Jt.examples.HelloWorld");
    masterWorker.setWorkerClassname("Jt.examples.patterns.Alarm");
    
    factory.sendMessage(masterWorker, new JtMessage (JtComponent.JtACTIVATE));
    

  }

}
