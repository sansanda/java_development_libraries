package Jt.portal;

import java.util.Collection;
import java.util.LinkedList;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMemento;
//import Jt.JtMemento;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.form.PasswordForm;
import Jt.security.JtMessageDigest;
import Jt.xml.JtXMLMemento;

public class Password extends JtObject {

    public static final String JtCLASS_NAME = Password.class.getName(); 
    private static final long serialVersionUID = 1L;
    public static final String LOST_PASSWORD = "LOST_PASSWORD";
    public static final String SAVE_PASSWORD = "SAVE_PASSWORD";
    public static final String CREATE_SERIAL = "CREATE_SERIAL";
    private JtFactory factory = new JtFactory ();
    //private JtAccount account;
    private transient JtContext context = null;
    //private JtDAOStrategy daoAdapter = new JtDAOStrategy ();
    private JtDAOStrategy daoAdapter;
    private String serial; 
    private String username;
    private boolean init = false;
    private String changePasswordLink = null;
    private String changePasswordSubject = null;



    public String getSerial() {
        return serial;
    }


    public void setSerial(String serial) {
        this.serial = serial;
    }   
    


    public String getUsername() {
        return username;
    }


    public void setUsername(String username) {
        this.username = username;
    }


    public String getChangePasswordLink() {
        return changePasswordLink;
    }


    public void setChangePasswordLink(String changePasswordLink) {
        this.changePasswordLink = changePasswordLink;
    }

    

    public String getChangePasswordSubject() {
        return changePasswordSubject;
    }


    public void setChangePasswordSubject(String changePasswordSubject) {
        this.changePasswordSubject = changePasswordSubject;
    }


    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    
    private PasswordForm lostPassword (String username, String serial) {
      PasswordForm form;        

      if (username == null || serial == null) {
          handleError ("Invalid parameters (null).");
      }
        
      form = new PasswordForm ();
      form.setUsername(username);
      form.setSerial(serial);
      
      return (form);
        
    }
    
    private JtAccount retrieveAccount (String userId) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        msg.setMsgContent(new JtAccount ());
        JtAccount account;
        
        msg.setMsgData (userId);
        
        account = (JtAccount) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null) {
            return (null);
        }
        
        factory.sendMessage(daoAdapter, new JtMessage (JtObject.JtREMOVE));
        return (account);
    }
    
    private boolean updateAccount (JtAccount account) {
        JtMessage msg = new JtMessage (JtObject.JtUPDATE);
        boolean result = true;
        
        if (account == null)
            return false;
        
        msg.setMsgContent(account);
        //msg.setMsgContext(context); check
        
        
        factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            result = false;
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (result);
        
    }
    
    private String encryptPassword (String password) {
        JtMessageDigest messageDigest = new JtMessageDigest ();
        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
        String digest;
        
        
        if (password == null)
            return (null);
        
        msg.setMsgContent(password);
        
        digest = (String) factory.sendMessage(messageDigest, msg);
        
        //handleTrace ("JtAccount.encryptPassword:" + digest);
        if (propagateException (messageDigest) != null)
            return (null);
        
        return (digest);
        
    }
    
    private boolean verifySerial (String username, String serial) {
        JtXMLMemento memento;
        Password password;
        JtMessage msg = new JtMessage (JtMemento.JtRESTORE);
        if (username == null || serial == null)
            return (false);
        if ((memento = readMemento (username, true)) == null)
            return (false); // check exceptions
        
        password = (Password) factory.sendMessage(memento, msg);
        
        if (password == null)
            return (false);
        
        if (serial.equals(password.getSerial()) && 
                username.equals(password.getUsername())) {
            return (true);
        }
        
        return (false);
        
    }
    
    private void newPassword (PasswordForm form) {
        JtAccount account;
        String epass;
        String username;
        String serial;
        
        if (form == null) {
            handleError ("Invalid parameters (form object).");
            return;
        }    
       

        
        username = form.getUsername();
        
        //username = context.getUserName();
        
        if (username == null) {
            handleError ("Invalid username (form object).");
            return;
        }  
        
        serial = form.getSerial();
        if (serial == null) {
            handleError ("Invalid serial (form object)."); // check
            return;
        } 
        
        if (!verifySerial (username, serial)) {
            handleError ("Unable to change password."); // check
            return;            
        }
        
        account = retrieveAccount (username);
        
        if (account == null) {
            if (this.getObjException() == null)
                handleUIError ("Unable to change your password.");
            return;
        }
        
        epass = encryptPassword (form.getNewPassword());
        
        if (epass == null) {
            if (this.getObjException() == null)
                handleError ("Unable to change your password.");
            return;
        }
        
        account.setPassword(epass);
        updateAccount (account);
        epass = null;
        
        removeMemento (username);
         
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    
    private JtXMLMemento readMemento (String username, boolean remove) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        //boolean result = true;
        JtXMLMemento reply;
        
        
        if (username == null) {
            return null;
        }

        msg.setMsgContent(new JtXMLMemento ());
        msg.setMsgData(Password.JtCLASS_NAME + username);        
        
        
        reply = (JtXMLMemento) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return (null);
        if (remove)
            factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (reply);      
        
    }
    
    private void removeMemento (String username) {
        JtMessage msg = new JtMessage (JtObject.JtDELETE);
        //boolean result = true;
        //JtXMLMemento reply;
        JtXMLMemento memento;
        
        
        if (username == null) {
            return;
        }

        memento = new JtXMLMemento ();
        memento.setName(Password.JtCLASS_NAME + username);        
        msg.setMsgContent(memento);       
        
        factory.sendMessage(daoAdapter, msg);
        
        //if (propagateException (daoAdapter) != null)
        //    return (null);

        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        //return (reply);      
        
    }
    
   
    private void saveMemento (JtXMLMemento memento, String username) {
        JtMessage msg = new JtMessage (JtObject.JtCREATE);
        //boolean result = true;
        
        
        if (memento == null) {
            return;
        }

        msg.setMsgContent(memento);
        
        // Already exists
        if (readMemento (username, false) != null) {
            msg.setMsgId(JtObject.JtUPDATE);
        }
        
        factory.sendMessage(daoAdapter, msg);
        
        propagateException (daoAdapter);
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return;      
        
    }
    
    
    private JtXMLMemento buildMemento (Object obj) {
        JtXMLMemento memento = new JtXMLMemento ();
        JtMessage msg = new JtMessage (JtMemento.JtSAVE);
        
        if (obj == null)
            return (null);
        
        msg.setMsgContent(obj);
        
        factory.sendMessage(memento, msg);
        
        if (propagateException (memento) != null)
            return (null);
        
        return (memento);        
    }
    
    
    
    private void saveSerial (String username, String serial) {
      JtXMLMemento memento;
      Password password = new Password ();
      
      if (username == null || serial == null) {
          handleError ("Invalid parameters." );
          return;
      }
      
      
      password.serial = serial;
      password.username = username;
      
      memento = buildMemento (password);
      memento.setName(password.getClass().getName() + username);
      
      
      if (memento != null)
          saveMemento (memento, username);
        
    }
    
    private void initialize () {
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        /*
        if (checkAccess)
            adapter.setCheckAccess(true);
        else
            adapter.setCheckAccess(false);           
        */
    }
     
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        String data;
        String content;
        //String attachment;
        ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
       
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        if (context != null)
            form = (ActionForm) context.getActionForm();  

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            
            content = (String) e.getMsgContent ();
            data = (String) e.getMsgData ();
            
            if (content == null ||  data == null) {
                handleError ("Invalid change password link. Please check the link and try again.");
                return (null);
            }
                        
            return (lostPassword ((String) e.getMsgContent(), 
                    (String) e.getMsgData()));

        }
        
        if (e.getMsgId().equals(Password.SAVE_PASSWORD)) {
            
            if (!init) {
                initialize ();
                init = true;
            }
            
            newPassword ((PasswordForm) form);
            return (null);
        }
        
        if (e.getMsgId().equals(Password.CREATE_SERIAL)) {
            
            if (!init) {
                initialize ();
                init = true;
            }
            content = (String) e.getMsgContent ();
            data = (String) e.getMsgData ();
            saveSerial (content, data);
            return (null);
        }
        
        
        return (super.processMessage(message));

    }





}
