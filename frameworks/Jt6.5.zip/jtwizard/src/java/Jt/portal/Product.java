package Jt.portal;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;


import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.wizard.struts.CRUD;



public class Product extends JtObject {

    public static final String GET_MY_PRODUCTS = "GET_MY_PRODUCTS";
    public static final String GET_ALL_PRODUCTS = "GET_ALL_PRODUCTS";
    public static final String SEARCH_FOR_KEYWORDS = "SEARCH_FOR_KEYWORDS";
    public static final String USERNAME = "USERNAME";
    public static final String JtCLASS_NAME = Product.class.getName(); 
    public static final String DEFAULT_PATH = "../jtRoot/defaultPhoto.gif";

    
    private static final long serialVersionUID = 1L;
    private String productId;
    private String description;
    private float size;
    private String color;
    private float price;
    private int quantityInStock;
    private String username;    
    private String photoPath;
    private int quantity = 1; // The shopping cart uses this attribute
    
    // Display attributes (display tag)
    private boolean paging = true;
    
    private transient JtContext context = new JtContext ();
    private transient JtFactory factory = new JtFactory ();
    
   

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isPaging() {
        return paging;
    }

    public void setPaging(boolean paging) {
        this.paging = paging;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public float getSize() {
        return (size);
    }

    public void setSize(float size) {
        this.size=size;
    }

    public String getColor() {
        return (color);
    }

    public void setColor(String color) {
        this.color=color;
    }

    public float getPrice() {
        return (price);
    }

    public void setPrice(float price) {
        this.price=price;
    }

    public int getQuantityInStock() {
        return (quantityInStock);
    }

    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock=quantityInStock;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    private void addPhotos (List list) {
        Iterator iterator;
        Product product;
        Photo photo = new Photo ();
        //UploadForm form;
        
        JtMessage msg = new JtMessage (Photo.RETRIEVE_PHOTO);
        
        if (list == null) {
            return;
        }
        
        iterator = list.iterator();
        
        
        msg.setMsgContext(context);
        
        while (iterator.hasNext()) {
            product = (Product) iterator.next ();
            msg.setMsgContent(product.getProductId());
            msg.setMsgData(product.getUsername());           
        
            photo = (Photo) factory.sendMessage(photo, msg);
            
            if (photo != null) {
                if (photo.isExists())
                    product.setPhotoPath(photo.getTargetPath());
                else
                    product.setPhotoPath(Product.DEFAULT_PATH);                   
            }
        }
        
        
        
    }
    
    /*
    private String  retrieveRequestParameter (HttpServletRequest request, int index) {
        Enumeration enu;
        int i = 1;
        String parameter = null;
        
        if (request == null || index <= 0)
            return (null);
        
        enu = request.getParameterNames();
        
        if (enu == null)
            return (null);
        
        while (enu.hasMoreElements()) {
            parameter = (String) enu.nextElement();
            if (i == index)
                return (parameter);
            i++;
        }
        
        return (null);
               
    }
    */
    
    private String  retrievePageParameter (HttpServletRequest request) {
        Enumeration enu;
        String parameter = null;
        
        if (request == null)
            return (null);
        
        enu = request.getParameterNames();
        
        if (enu == null)
            return (null);
        
        while (enu.hasMoreElements()) {
            parameter = (String) enu.nextElement();
            
            if (parameter != null && parameter.startsWith("d") &&
                    parameter.endsWith("p")) {
                handleTrace (parameter);    
                return (parameter);
            }
        }        
        return (null);
               
    }
    
    
    private void updateSession (String attributeName, List productList) {
        HttpSession session = null;
        HttpServletRequest request = null;
        
        if (context == null) {
            handleWarning ("Product.updateSession: Invalid Jt context: null");
            return; // check
        }
        if (attributeName == null || productList == null)
            return;
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return;
        
        session = request.getSession();
        
        if (session == null) {
            handleWarning ("Product.updateSession: Invalid HttpSession session: null");
            return;
        }
        
        session.setAttribute(attributeName, productList);        
        
    }
    
    private Object retrieveAttributeFromSession (String attributeName) {
        HttpSession session = null;
        HttpServletRequest request = null;
        if (attributeName == null)
            return (null);
        
        if (context == null) {
            handleWarning ("Product.retrieveAttributeFromSession: Invalid Jt context: null");
            return (null);
        }
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        if (session == null) {
            handleWarning ("Product.retrieveAttributeFromSession: Invalid HttpSession session: null");
            return (null);
        }
        
        return (session.getAttribute(attributeName));
        
        
    }
    

    
    private void sessionCleanup (HttpSession session) {
        Enumeration enu;
        String attrName;
        ArrayList list = new ArrayList ();
        Iterator iterator;
        
        
        if (session == null)
            return;
        
        enu = session.getAttributeNames();
        
        // Remove all the attributes name like (jtxxxxxList)
        // except listName
        
        while (enu.hasMoreElements()) {
            attrName = (String) enu.nextElement();
            
            if (attrName != null &&
                    attrName.startsWith("jt") &&
                    attrName.endsWith("List")) {
                //if (!attrName.equals(listName)) {
                handleTrace (".sessionCleanup:" + attrName, 0);
                //session.removeAttribute(attrName);
                list.add(attrName);
                //}
            }
            
            
        }
        
        iterator = list.iterator();
        
        while (iterator.hasNext())
            session.removeAttribute((String) iterator.next());
    }
    
    private Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }

    
    private List retrieveAllProducts () {
        
        JtMessage msg = new JtMessage ();
        List result;
        String query = "select * from product"; // check - configuration file
        JtDAOStrategy adapter; 
        //LinkedList list = new LinkedList ();
        

        
        if (paging) {
            if (context != null && (retrievePageParameter (context.getRequest()) != null)) {

                // Retrieve product list from session
                result = (List) retrieveAttributeFromSession ("jtAllProductList");
                if (result != null)
                    return (result);
            }
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 

        //msg.setMsgContent("select * from roster");
        msg.setMsgContent(query);
       
       
        msg.setMsgData(new Product ());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);

        if (paging) {
            sessionCleanup (retrieveSession ());
            updateSession ("jtAllProductList", result);
        }
        
        addPhotos (result);
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("Product.retrieveSession: Invalid Jt context: null");
            return (null); // check
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        return (session);    
    }
    
    private List retrieveMyProducts (String owner) {
        
        JtMessage msg = new JtMessage ();
        List result;
        String query = "select * from product where " + Product.USERNAME + "='"; // check - configuration file
        JtDAOStrategy adapter; 
        LinkedList list = new LinkedList ();

        
        if (owner == null)
            return list;
        
        

        

        if (paging) {
            if (context != null && (retrievePageParameter (context.getRequest()) != null)) {

                // Retrieve product list from session
                result = (List) retrieveAttributeFromSession ("jtMyProductList");
                if (result != null) {                   
                    return (result);
                }    
            }
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(false);
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 
        
        //msg.setMsgContent("select * from roster");
        msg.setMsgContent(query + owner + "'");
             
        msg.setMsgData(new Product ());
               
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);
        
        if (paging) {
            sessionCleanup (retrieveSession ());
            updateSession ("jtMyProductList", result);
        }
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }
    
    private boolean validateKeyword (String keyword) {
        int i;
        char c;
        if (keyword == null || keyword.equals(""))
            return (false);
        
        for (i = 0; i < keyword.length(); i++) {
            
            c = keyword.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                continue;               
            }
            
            if (c == '\'') 
                continue;
            
            if (c == '-') 
                continue;
            
            return (false);
        }
        
        return (true);
    }
    
    private boolean validateKeywords (String keywords) {
        String keywordArray[];
        int i;
        
        
        if (keywords == null)
            return (false);
        
        keywordArray = keywords.split(" ");
        
        for (i = 0; i < keywordArray.length; i++) {
            
            if (!validateKeyword (keywordArray[i])) 
                return (false);

        }  
        
        return (true);
    }
    
    private List searchForKeywords (ActionForm form) {
        JtMessage msg = new JtMessage ();
        Object obj;
        List list;
        String keywords = null;
        JtDAOStrategy adapter;
        
        if (form == null) {
            handleError ("Invalid form object:" + form);
            return (null); // check
        }    
        
        keywords = (String) factory.getValue (form, "description");
        
        if (!validateKeywords (keywords)) {
            
            handleError ("invalid keywords");
            return (null);
        }
                 
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(false); 
        
        msg.setMsgId (JtDAOAdapter.JtSEARCH_FOR_KEYWORDS);
        msg.setMsgContent(new Product ());
        msg.setMsgContext(context);
        

        
        msg.setMsgData("description");
        msg.setMsgAttachment(keywords);
        
        
        
        list = (List) factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (adapter.getObjException() != null) {
            this.setObjException(adapter.getObjException());
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return (null);
        }
        
        addPhotos (list);
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        

        return (list);        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        

       
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        
        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (new LinkedList ());
        }

        form = (ActionForm) context.getActionForm();  
        //if (context != null)
        //    form = (ActionForm) context.getActionForm();  

            

        if (e.getMsgId().equals(Product.GET_MY_PRODUCTS)) {
            
            return (retrieveMyProducts (context.getUserName()));
        }
        
        if (e.getMsgId().equals(Product.GET_ALL_PRODUCTS)) {
            
            return (retrieveAllProducts ());
        }
        
        if (e.getMsgId().equals(Product.SEARCH_FOR_KEYWORDS)) {
            
            return (searchForKeywords (form));
        }      
        

        return (super.processMessage(message));

    }

}