package Jt.portal;


import Jt.JtObject;



public class OrderItem extends JtObject {


    
    private static final long serialVersionUID = 1L;
    private String orderId;
    private int sequence;
    private String productId;
    private String description;
    private int size;
    private String color;
    private float price;
    private int quantity;
    
    
    
   

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }


    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public int getSize() {
        return (size);
    }

    public void setSize(int size) {
        this.size=size;
    }

    public String getColor() {
        return (color);
    }

    public void setColor(String color) {
        this.color=color;
    }

    public float getPrice() {
        return (price);
    }

    public void setPrice(float price) {
        this.price=price;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    
 
}