package Jt.portal;



import java.util.Iterator;
import java.util.List;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;




public class DAOProductCategory extends DAOCategory {


    private static final long serialVersionUID = 1L;
    public static final String RETRIEVE_OBJECTS = "RETRIEVE_OBJECTS";
    public static final String JtCLASS_NAME = DAOProductCategory.class.getName(); 
    private transient JtContext context = new JtContext ();
    private transient JtFactory factory = new JtFactory ();


    private void addPhotos (List list) {
        Iterator iterator;
        Product product;
        Photo photo = new Photo ();
        //UploadForm form;
        
        JtMessage msg = new JtMessage (Photo.RETRIEVE_PHOTO);
        
        if (list == null) {
            return;
        }
        
        iterator = list.iterator();
        
        
        msg.setMsgContext(context);
        
        while (iterator.hasNext()) {
            product = (Product) iterator.next ();
            msg.setMsgContent(product.getProductId());
            msg.setMsgData(product.getUsername());           
        
            photo = (Photo) factory.sendMessage(photo, msg);
            
            if (photo != null) {
                if (photo.isExists())
                    product.setPhotoPath(photo.getTargetPath());
                else
                    product.setPhotoPath(Product.DEFAULT_PATH);                   
            }
        }
        
        
        
    } 
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {

        Object reply;

        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);               

      
        
        reply = super.processMessage(message);
       
        
        context = (JtContext) e.getMsgContext();
       
        // Bug fix
        if (e.getMsgId().equals(DAOCategory.RETRIEVE_OBJECTS)) {
            if (reply != null) {
                addPhotos ((List) reply);
            }           
        }

        return (reply);


    }

}