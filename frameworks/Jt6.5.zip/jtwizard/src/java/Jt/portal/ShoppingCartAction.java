package Jt.portal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import Jt.JtContext;
import Jt.JtComposite;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;


/**
 * Shopping Cart Action.
 */


public class ShoppingCartAction extends JtComposite {
    

    private static final long serialVersionUID = 1L;
    //private boolean init = false;
    private transient JtContext context;
    public static final String JtCLASS_NAME = ShoppingCartAction.class.getName(); 
    //public static final String ADD_CHILD = "ADD_CHILD"; 
    //public static final String REMOVE_CHILD = "REMOVE_CHILD"; 
    //public static final String CALCULATE_TOTAL = "CALCULATE_TOTAL"; 
    
    public static final String SHOPPING_CART_ID = "jtShoppingCart"; 
    
    private transient JtFactory factory = new JtFactory ();
    //private transient String itemClassName = Product.JtCLASS_NAME; 
    //private double total;
    private transient HttpSession session;
    
    
    public ShoppingCartAction () {
        
    }
    /*  
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    */
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("ShoppingCart.retrieveSession: Invalid Jt context: null");
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        return (session);    
    }
    

    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    

    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //JtMessage msg;
        ShoppingCart cart = null;

        //ActionForm form;
        
        //Object obj;
        //Boolean Bool;
        //JtContext jtContext;
        //String userName;
        

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //if (!init) {
            //initialize ();     
            //init = true;
        //}
        
        context = (JtContext) e.getMsgContext();
        
        
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        

        session = retrieveSession ();
        
        if (session == null) {
            handleError ("Invalid session. You session may have expired. Please log in.");
            return (null);
        }       
        
        cart = (ShoppingCart) session.getAttribute(ShoppingCartAction.SHOPPING_CART_ID);

        
        if (cart == null) {           
            cart = (ShoppingCart) factory.createObject(ShoppingCart.JtCLASS_NAME);
            session.setAttribute(ShoppingCartAction.SHOPPING_CART_ID, cart);
        }        
        
        
        // Add an item to the shopping cart
                
        
        if (e.getMsgId().equals(ShoppingCart.ADD_CHILD)) {
            
            factory.sendMessage(cart, e);
            propagateException (cart);

            return (null);
        }
       
        // Remove an item from the shopping cart
        
        if (e.getMsgId().equals(ShoppingCart.REMOVE_CHILD)) {

            factory.sendMessage(cart, e);
            propagateException (cart);

            return (null);
        }
        
        
        return (super.processMessage (message));

    }
    



}
