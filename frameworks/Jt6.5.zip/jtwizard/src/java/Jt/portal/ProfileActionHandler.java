package Jt.portal;


import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.form.ProfileForm;



public class ProfileActionHandler extends JtProfile {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = ProfileActionHandler.class.getName(); 
  public static final String RETRIEVE_PROFILE_FORM = "RETRIEVE_PROFILE_FORM";
  //private String userId;

  //private transient JtContext context = null;
  //private transient JtFactory factory = new JtFactory ();
  //private transient JtDAOStrategy daoAdapter = null;
  //private transient CRUD crudObj;
  //private boolean initted = false;


  private Exception propagateException (JtObject obj) {
      
      if (obj == null)
          return (null);
      
      if (obj.getObjException() != null) {
          this.setObjException(obj.getObjException());
      }  
      return ((Exception) obj.getObjException());
  }
  
  
  

 
  private ProfileForm retrieveProfileForm (String userId) { // Check security
      JtProfile tmp;
      ProfileForm profile = new ProfileForm ();
      JtMessage msg = new JtMessage (JtObject.JtREAD);
      
      if (userId == null) {
          handleError ("Invalid userId parameter");
          return (null);
      }
      
      daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
      msg.setMsgContent(new JtProfile ());
      
      msg.setMsgData (userId);
      msg.setMsgContext(context);
      
      tmp = (JtProfile) factory.sendMessage(daoAdapter, msg);
      
      if (propagateException (daoAdapter) != null) {
          factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
          return null;
      }
      
      profile.setUsername(tmp.getUsername());
      profile.setFirstname(tmp.getFirstname ());
      profile.setLastname(tmp.getLastname ());
      
      factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
      
      return (profile);
  }

  
  
  /*
  private ProfileForm retrieveProfile (String userId) { // Check security
      ProfileForm form;
      JtMessage msg = new JtMessage (JtObject.JtREAD);
      
      if (userId == null)
          return (null);
      
      crudObj = (CRUD) factory.createObject(CRUD.JtCLASS_NAME);
      
      crudObj.setClassname(ProfileActionHandler.JtCLASS_NAME);
      msg.setMsgId(JtObject.JtREAD);
      context.setActionForm(new ProfileForm ());
      msg.setMsgContext(context); // Pass the contex
      msg.setMsgContent(userId);
      crudObj.setKey("username");
      
      
      form = (ProfileForm) factory.sendMessage(crudObj, msg);
      
      if (propagateException (crudObj) != null)
          return (null);

      // Remove Object
      
      
      return (form);
  }
  */

  
  
 
  /*
  private void initialize () {
      daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
      daoAdapter.setCheckAccess(false);     
  }
  */
  
  // Process object messages

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage msg = (JtMessage) message;
      ActionForm form = null;


      if (msg == null)
          return null;

      msgid = (String) msg.getMsgId ();

      if (msgid == null)
          return null;
      
      //if (!initted) {
      //    initialize ();
      //    initted = true;
      //}

      context = (JtContext) msg.getMsgContext();
      
      //if (context != null)
      //    form = (ActionForm) context.getActionForm();  

      
      if (msgid.equals (ProfileActionHandler.RETRIEVE_PROFILE_FORM)) {

          return (retrieveProfileForm ((String) msg.getMsgContent()));
      }
      handleError ("Invalid msg Id:" + msgid);
      return (null);
  }
}
