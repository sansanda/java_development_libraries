package Jt.portal;

import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.AckCodeType;
import com.paypal.soap.api.AddressType;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CountryCodeType;
import com.paypal.soap.api.CreditCardDetailsType;
import com.paypal.soap.api.CreditCardTypeType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.DoDirectPaymentRequestDetailsType;
import com.paypal.soap.api.DoDirectPaymentRequestType;
import com.paypal.soap.api.DoDirectPaymentResponseType;
import com.paypal.soap.api.PayerInfoType;
import com.paypal.soap.api.PaymentActionCodeType;
import com.paypal.soap.api.PaymentDetailsType;
import com.paypal.soap.api.PersonNameType;
import Jt.JtContext;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.portal.form.PaymentForm;


/**
 * Paypal payment adapter.
 */

public class PaypalAdapter extends JtObject {
    

    private static final long serialVersionUID = 1L;
    //private String implementorClassName;
    private boolean init = false;
    private transient JtContext context;
    public static final String JtCLASS_NAME = PaypalAdapter.class.getName(); 
    
    private String apiUsername;
    private String apiPassword;
    private String certificateFile;
    private String privateKeyPassword;
    private String environment;
    
    private String actionType = (String) "Sale";
/*    
    private String firstName;
    private String lastName;
    private String city;
    private String stateOrProvince;
    private String postalCode;
    private String country;

    
    private String cardNumber;
    private String cardType;
    private int expirationMonth;
    private int expirationYear;   
    private String cvv2;
    private double total;
*/    
    
    
    
    
    public PaypalAdapter () {
        
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    
/*    
    public String getImplementorClassName() {
        return implementorClassName;
    }

    public void setImplementorClassName(String implementorClassName) {
        this.implementorClassName = implementorClassName;
    }
*/
    
    public String getApiUsername() {
        return apiUsername;
    }

    public void setApiUsername(String apiUsername) {
        this.apiUsername = apiUsername;
    }

    public String getApiPassword() {
        return apiPassword;
    }

    public void setApiPassword(String apiPassword) {
        this.apiPassword = apiPassword;
    }

    public String getCertificateFile() {
        return certificateFile;
    }

    public void setCertificateFile(String certificateFile) {
        this.certificateFile = certificateFile;
    }

    public String getPrivateKeyPassword() {
        return privateKeyPassword;
    }

    public void setPrivateKeyPassword(String privateKeyPassword) {
        this.privateKeyPassword = privateKeyPassword;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    /*
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateOrProvince() {
        return stateOrProvince;
    }

    public void setStateOrProvince(String stateOrProvince) {
        this.stateOrProvince = stateOrProvince;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getExpirationMonth() {
        return expirationMonth;
    }

    public void setExpirationMonth(int expirationMonth) {
        this.expirationMonth = expirationMonth;
    }

    public int getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(int expirationYear) {
        this.expirationYear = expirationYear;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
*/    
    private String maskDigits (String creditCardNumber) {
        
        if (creditCardNumber == null)
            return (null);
        
        if (creditCardNumber.length() <= 12)
            return ("");
        
        return ("xxxx-xxxx-xxxx-" + creditCardNumber.substring(12));
    }
    
    private PaymentReceipt directPayment (PaymentForm form) {
        CallerServices caller;
        HttpServletRequest request;
        APIProfile profile = null;
        ServletContext servletContext;
        PaymentReceipt paymentReceipt = new PaymentReceipt ();

        
        if (form == null) {
            handleError ("Invalid parameter (form)");
            return (null);
        }    
        
        request = context.getRequest();
        
        
        if (request == null) {
            handleError ("Invalid parameter (request)");
            return (null);
        }        
        
        servletContext = (ServletContext) context.getServletContext(); 
        
        if (servletContext == null) {
            handleError ("Invalid Servlet Context");
            return (null);
        }     
        
        caller = new CallerServices();
        
        if (this.getApiUsername() == null
                || this.getApiPassword() == null
                || this.getCertificateFile() == null
                || this.getPrivateKeyPassword() == null
                || this.getEnvironment() == null) {
            handleError ("Profile attributes need to be set.");
            return (null);
        }
        
        try {
            profile = ProfileFactory.createSSLAPIProfile();
            profile.setAPIUsername (this.getApiUsername());
            profile.setAPIPassword(this.getApiPassword());
            profile.setCertificateFile(servletContext.getRealPath("WEB-INF/cert/" + this.getCertificateFile()));
            profile.setPrivateKeyPassword(this.getPrivateKeyPassword());
            profile.setEnvironment(this.getEnvironment());
            //profile.setAPIUsername("sdk-seller_api1.sdk.com");
            //profile.setAPIPassword("12345678");
            //profile.setCertificateFile(servletContext.getRealPath("WEB-INF/cert/sdk-seller.p12"));
            //profile.setPrivateKeyPassword("password");
            //profile.setEnvironment("beta-sandbox");
            caller.setAPIProfile(profile);
        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }
        

        
        DoDirectPaymentRequestType pprequest = new DoDirectPaymentRequestType();
        DoDirectPaymentRequestDetailsType details = new DoDirectPaymentRequestDetailsType();
        PaymentDetailsType paymentDetails = new PaymentDetailsType();
        paymentDetails.setButtonSource("Java_SDK_JSP");
        
        BasicAmountType amount = new BasicAmountType();
        ///amount.set_value(form.);
        amount.setCurrencyID(CurrencyCodeType.USD);
        paymentDetails.setOrderTotal(amount);
        
        AddressType shipTo = new AddressType();
        shipTo.setName(form.getFirstName() + " " + form.getLastName());
        shipTo.setStreet1(form.getBillingAddress1());
        shipTo.setStreet2(form.getBillingAddress2());
        shipTo.setCityName(form.getCity());
        shipTo.setStateOrProvince(form.getState());
        shipTo.setCountry(CountryCodeType.US);
        shipTo.setPostalCode(form.getZip());
        paymentDetails.setShipToAddress(shipTo);
        
        details.setPaymentDetails(paymentDetails);

        CreditCardDetailsType cardDetails = new CreditCardDetailsType();
        cardDetails.setCreditCardType(CreditCardTypeType.fromString(form.getCardType()));
        cardDetails.setCreditCardNumber(form.getCardNumber());
        
        
        cardDetails.setExpMonth(new Integer(Integer.parseInt(form.getExpirationMonth())));
        cardDetails.setExpYear(new Integer(Integer.parseInt(form.getExpirationYear())));
        cardDetails.setCVV2(form.getCvv2());
        
        PayerInfoType payer = new PayerInfoType();
        PersonNameType name = new PersonNameType();
        name.setFirstName(form.getFirstName());
        name.setLastName(form.getLastName());
        payer.setPayerName(name);
        payer.setPayerCountry(CountryCodeType.US);
        payer.setAddress(shipTo);
       
        cardDetails.setCardOwner(payer);
                    
        details.setCreditCard(cardDetails);
                
        details.setIPAddress(request.getRemoteAddr());
        details.setPaymentAction(PaymentActionCodeType.fromString(actionType));
        //details.setPaymentAction(PaymentActionCodeType.Sale);
        
        pprequest.setDoDirectPaymentRequestDetails(details);
        
        PaymentDetailsType payment = new PaymentDetailsType();

        BasicAmountType orderTotal = new BasicAmountType();
        orderTotal.setCurrencyID(CurrencyCodeType.USD);
        orderTotal.set_value(form.getAmount());
        payment.setOrderTotal(orderTotal);
        
        details.setPaymentDetails(payment);
        pprequest.setDoDirectPaymentRequestDetails(details);
        try {
            DoDirectPaymentResponseType ppresponse = 
                (DoDirectPaymentResponseType)caller.call("DoDirectPayment", pprequest);
            
            if (!ppresponse.getAck().equals(AckCodeType.Success) && 
                !ppresponse.getAck().equals(AckCodeType.SuccessWithWarning)) {
                //session.setAttribute("response", ppresponse);
                //response.sendRedirect("APIError.jsp");
                handleTrace ("Ack:" + ppresponse.getAck());
                
                handleTrace ("Correlation ID:" + ppresponse.getCorrelationID());
                
                handleTrace ("Version:" + ppresponse.getVersion());
                
                for (int i = 0; i < ppresponse.getErrors().length; i++) {
                    handleTrace ("Error Number:" + ppresponse.getErrors(i).getErrorCode());                   

                    handleTrace ("Short Message:" + ppresponse.getErrors(i).getShortMessage());                   
                    handleUIError ("Long Message:" + ppresponse.getErrors(i).getLongMessage());                   

                }
                
                //handleError ("failed");

                return (null);
            }
            
            paymentReceipt.setFirstName (form.getFirstName());
            paymentReceipt.setLastName (form.getLastName());
            paymentReceipt.setCardNumber(maskDigits (form.getCardNumber()));
            paymentReceipt.setAmount(form.getAmount());
            paymentReceipt.setTransactionId(ppresponse.getTransactionID());
            
            return (paymentReceipt);
        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }

    }
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("PaypalAdapter.retrieveSession: Invalid Jt context: null");
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        return (session);    
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        ShoppingCart cart;
        HttpSession session;
        PaymentReceipt paymentReceipt = null; 

        Object reply;
        //JtMessage msg;

        ActionForm form;
        
        //Object obj;
        //Boolean Bool;
        //JtContext jtContext;
        //String userName;
        

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (!init) {
            //initialize ();     
            init = true;
        }
        
        context = (JtContext) e.getMsgContext();
        
        if (context == null) {
            handleError ("Invalid context.");
            return null;
        }
        

        form = (ActionForm) context.getActionForm();  
        

        if (e.getMsgId().equals(PaymentBridge.DIRECT_PAYMENT)) {
            
            if (e.getMsgData() != null)
                actionType = (String) e.getMsgData();
            
            paymentReceipt = directPayment ((PaymentForm) form);
            
            session = retrieveSession ();
            
            if (paymentReceipt != null && session != null) {
                cart = (ShoppingCart) session.getAttribute(Checkout.SHOPPING_CART_ID);
                handleTrace ("PaypalAdapter(cart):" + cart);
                if (cart != null) {
                    paymentReceipt.setItems(cart.getList());
                    handleTrace ("PaypalAdapter(items):" + cart.getList());
                }    
            }       
            

            return (paymentReceipt);
        }
        // Let the implementor process the message
        
        reply = super.processMessage (message);
        
        //if (concreteStrategy != null) {
        //    propagateException (concreteStrategy);  
        //}
        
        return (reply);

    }



}
