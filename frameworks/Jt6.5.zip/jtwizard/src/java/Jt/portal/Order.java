package Jt.portal;


import java.util.Iterator;
import java.util.List;
//import org.apache.struts.action.ActionForm;
import Jt.JtComposite;
import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;



public class Order extends JtComposite {

    public static final String JtCLASS_NAME = Order.class.getName(); 
    public static final String COMPLETED = "COMPLETED"; 
    //public static final String READ_CHILDREN = "READ_CHILDREN";     
    private static final long serialVersionUID = 1L;
    private String orderId;
    private String description;
    private float amount;
    private String username; 
    private String status;
    private String notes;
    private boolean init = false;
    private String query = "Select * from order_item where orderId=";
    
    private transient JtDAOStrategy adapter;
    
    // Display attributes (display tag)
    
    private transient JtContext context = new JtContext ();
    private transient JtFactory factory = new JtFactory ();
    
   

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    
    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    
    private Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }

    
    private boolean createItems (List list) {
        Iterator iterator;
        Object temp;
        JtMessage msg;
        
        if (list == null)
            return (true);
        
        msg = new JtMessage (JtObject.JtCREATE);   
        iterator = list.iterator();
        
        
        while (iterator.hasNext()) {
            temp = iterator.next();
            msg.setMsgContent(temp);
            factory.sendMessage (adapter, msg);
            
            if (adapter.getObjException() != null)
                return (false);
        }
        
        return (true);
    }
    
    private boolean deleteItems (List list) {
        Iterator iterator;
        Object temp;
        JtMessage msg;
        
        if (list == null)
            return (true);
        
        msg = new JtMessage (JtObject.JtDELETE);   
        iterator = list.iterator();
        
        
        while (iterator.hasNext()) {
            temp = iterator.next();
            msg.setMsgContent(temp);
            factory.sendMessage (adapter, msg);
            
            if (adapter.getObjException() != null)
                return (false);
        }
        
        return (true);
    }
    
    
    private void deleteObject () {
        
        JtMessage msg;
        
        
        factory.sendMessage (adapter, 
                new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));
        
        
        if (deleteItems (this.getList()) != true) {
            
            propagateException(adapter);

            factory.sendMessage (adapter, 
                    new JtMessage (JtDAOAdapter.JtROLLBACK));  
            
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        }
        
        
        msg = new JtMessage (JtObject.JtREMOVE);   
        msg.setMsgContent(this);
        msg.setMsgContext(context); // pass the JtContext

        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (propagateException(adapter) != null) {

            factory.sendMessage (adapter, 
                    new JtMessage (JtDAOAdapter.JtROLLBACK));  
            //factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            
            //return;
        }     
        
                 
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }
    
    
    private void createObject () {
        
        JtMessage msg;
        
        
        factory.sendMessage (adapter, 
                new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));
        
        msg = new JtMessage (JtObject.JtCREATE);   
        msg.setMsgContent(this);
        msg.setMsgContext(context); // pass the JtContext

        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (propagateException(adapter) != null) {

            factory.sendMessage (adapter, 
                    new JtMessage (JtDAOAdapter.JtROLLBACK));  
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            
            return;
        }  
        factory.sendMessage (adapter, 
                new JtMessage (JtDAOAdapter.JtCOMMIT));
        
        factory.sendMessage (adapter, 
                new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));
        
        if (createItems (this.getList()) == true)
            factory.sendMessage (adapter, 
                    new JtMessage (JtDAOAdapter.JtCOMMIT));
        else
            factory.sendMessage (adapter, 
                    new JtMessage (JtDAOAdapter.JtROLLBACK));                    
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
    }
    
    
    private void initialize () {
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        /*
        if (checkAccess)
            adapter.setCheckAccess(true); //check
        else
            adapter.setCheckAccess(false);           
        */
    }
    
    
    private String buildQuery (String orderId) {
        if (orderId == null)
            return (null);
        
        return (query + "'" + orderId + "';");
    }
    
    private List readChildren () {
        JtMessage msg;
        List list = null;
        
        if (orderId == null || orderId.equals("")) {
            handleError ("Invalid orderId");
            return (null);
        }
        
        query = buildQuery (orderId);
        
        msg = new JtMessage (JtDAOAdapter.JtEXECUTE_QUERY);   
        msg.setMsgContent(query);
        msg.setMsgData(new OrderItem ());
        msg.setMsgContext(context); // pass the JtContext

        list = (List) factory.sendMessage (adapter, msg);
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return (null);
        }
        
        this.setList(list);
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (list);
    }

    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        //ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        
        if (!init) {
            initialize ();
            init = true;
        }
       
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        
        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }

        //if (context != null)
        //    form = (ActionForm) context.getActionForm();  

        if (e.getMsgId().equals(JtObject.JtCREATE)) {
            
            createObject ();
            return (null); 
        }
        
        if (e.getMsgId().equals(JtObject.JtDELETE)) {
            
            deleteObject ();
            return (null); 
        }    
        
        if (e.getMsgId().equals(JtDAOAdapter.JtREAD_CHILDREN)) {
            
            readChildren ();
            return (null); 
        } 
   

        return (super.processMessage(message));

    }

}