package Jt.portal;



public class InProductCategory  {



    public static final String JtCLASS_NAME = InProductCategory.class.getName(); 


    
    private static final long serialVersionUID = 1L;
    private String productId;
    private String categoryId;
   

   
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }
    
    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }
 
    
 
    


}