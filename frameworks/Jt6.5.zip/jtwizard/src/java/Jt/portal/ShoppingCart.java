package Jt.portal;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;
//import Jt.JtContext;
import Jt.JtComposite;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;

/**
 * Shopping Cart.
 */


public class ShoppingCart extends JtComposite {
    

    private static final long serialVersionUID = 1L;
    //private boolean init = false;
    //private transient JtContext context;
    public static final String JtCLASS_NAME = ShoppingCart.class.getName(); 
    public static final String ADD_CHILD = "ADD_CHILD"; 
    public static final String REMOVE_CHILD = "REMOVE_CHILD"; 
    public static final String CALCULATE_TOTAL = "CALCULATE_TOTAL"; 
    
    public static final String SHOPPING_CART_ID = "jtShoppingCart"; 
    
    private transient JtFactory factory = new JtFactory ();
    private transient String itemClassName = Product.JtCLASS_NAME; 
    private float total;
    HttpSession session;
    
    
    public ShoppingCart () {
        
    }
    /*  
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    */
    
    public String getItemClassName() {
        return itemClassName;
    }

    public float getTotal() {
        total = calculateTotal ();
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public void setItemClassName(String itemClassName) {
        this.itemClassName = itemClassName;
    }

    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    

    
    private Object retrieveItem (String id) {
        JtDAOStrategy adapter;
        JtMessage msg;
        JtObject item, item1 = null;
        
        if (id == null)
            return (null);
        
        
        if (itemClassName == null) {
            handleError ("Invalid class name:null");
            return (null);
        }      
        
        item = (JtObject) factory.createObject(itemClassName);
        
        if (item == null) {
            handleError ("unable to create class instance:" + itemClassName);
            return (null);
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(true); // che
        msg = new JtMessage (JtObject.JtREAD);
        msg.setMsgContent(item);
        msg.setMsgData(id);
        
        item1 = (JtObject) factory.sendMessage(adapter, msg);
        
        if (propagateException (adapter) != null)
            return (null);
        
        if (item1 != null)
            item1.setComponentId(id);
        factory.sendMessage(adapter, new JtMessage (JtObject.JtREMOVE));
        return (item1);
    }

    private void addItem (String id) {
        
        Object item = null;
        JtMessage msg = new JtMessage (JtComposite.JtADD_CHILD);
        
        if (id == null) {
            handleError ("Invalid item id:null");
            return;
        }
        
        item = retrieveItem (id);
        
        if (this.getObjException() != null)
            return;
        
        if (item == null) {
            handleError ("Invalid item:" + id);
            return;
        }
        
        msg.setMsgContent(item);
        super.processMessage(msg);
                

    }
    
    
    private float calculateTotal () {
        
        Iterator iterator;
        List list = this.getList();
        Object item;
        Float tmp;
        float total = (float) 0.0;
        Integer iTmp;
        int quantity;
        
        if (list == null)
        	return (total);
        
        iterator = (Iterator) list.iterator();
        while (iterator.hasNext()) {
            item = iterator.next();
            
            tmp = (Float) factory.getValue(item, "price");
            iTmp = (Integer) factory.getValue(item, "quantity");
            
            quantity = iTmp.intValue();
            total += (tmp.floatValue() * quantity);

            
        }
        
        return (total);
        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        JtMessage msg;
        ShoppingCart cart = null;

        //ActionForm form;
        
        //Object obj;
        //Boolean Bool;
        //JtContext jtContext;
        //String userName;
        

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //if (!init) {
            //initialize ();     
            //init = true;
        //}
        
        /*
        context = (JtContext) e.getMsgContext();
        
        
        if (context == null) {
            handleError ("Invalid context. You session may have expired. Please log in.");
            return (null);
        }
        

        session = retrieveSession ();
        
        if (session == null) {
            handleError ("Invalid session. You session may have expired. Please log in.");
            return (null);
        }       
        //form = (ActionForm) context.getActionForm();  
        
        cart = (ShoppingCart) session.getAttribute(ShoppingCart.SHOPPING_CART_ID);

        
        if (cart == null)
            session.setAttribute(ShoppingCart.SHOPPING_CART_ID, this);
        */
        // Add an item to the shopping cart
                
        
        if (e.getMsgId().equals(ShoppingCart.ADD_CHILD)) {
            addItem ((String) e.getMsgContent());
            calculateTotal ();
            return (null);
        }
       
        // Remove an item from the shopping cart
        
        if (e.getMsgId().equals(ShoppingCart.REMOVE_CHILD)) {
            msg = new JtMessage (JtComposite.JtREMOVE_CHILD);

            msg.setMsgContent(e.getMsgContent());
            super.processMessage (msg);
            calculateTotal ();
            return (null);
        }
        
        
        return (super.processMessage (message));

    }
    
    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        ShoppingCart cart;        
        JtMessage msg;
      
        
        // Create an instance of ShoppingCart

        cart = (ShoppingCart) factory.createObject (ShoppingCart.JtCLASS_NAME);
        
        

        
        System.out.println ("Total=" + cart.getTotal()); 
        
        // Add objects to the cart
        
        msg = new JtMessage (ShoppingCart.ADD_CHILD);
        msg.setMsgContent("SKU100"); 

        factory.sendMessage(cart, msg);
        
        System.out.println ("Total=" + cart.getTotal());         
        
    }    


}
