package Jt.portal.form;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.validator.ValidatorForm;

public class AccountForm extends ValidatorForm {

    private boolean active;
    private String password;
    private boolean disabled;
    private String username;
    private String email;


    public boolean isActive() {
        return (active);
    }

    public void setActive(boolean active) {
        this.active=active;
    }

    public String getPassword() {
        return (password);
    }

    public void setPassword(String password) {
        this.password=password;
    }

    public boolean isDisabled() {
        return (disabled);
    }

    public void setDisabled(boolean disabled) {
        this.disabled=disabled;
    }

    public String getUsername() {
        return (username);
    }

    public void setUsername(String username) {
        this.username=username;
    }

    public String getEmail() {
        return (email);
    }

    public void setEmail(String email) {
        this.email=email;
    }

}

