package Jt.portal.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.ValidatorForm;

public class ChangePasswordForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private String password;
    private String newPassword;
    private String retypeNewPassword;


    public String getPassword() {
        return (password);
    }

    public void setPassword(String password) {
        this.password=password;
    }

    public String getNewPassword() {
        return (newPassword);
    }

    public void setNewPassword(String newPassword) {
        this.newPassword=newPassword;
    }

    public String getRetypeNewPassword() {
        return (retypeNewPassword);
    }

    public void setRetypeNewPassword(String retypeNewPassword) {
        this.retypeNewPassword=retypeNewPassword;
    }
    
    public ActionErrors validate (ActionMapping mapping, HttpServletRequest request) {
        
        ActionErrors errors = super.validate(mapping, request);
        
        
        if (newPassword != null && !newPassword.equals (retypeNewPassword)) 
            errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.errors.nomatch", "Passwords"));

       
        return errors;
        
    }

}
