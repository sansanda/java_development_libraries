package Jt.portal.form;
import java.util.List;

import org.apache.struts.action.*;

public class OrderForm extends ActionForm {


    private static final long serialVersionUID = 1L;
    private String orderId;
    private String description;
    private float amount;
    private String status;
    private String username;
    private String notes;
    private List list;


    public String getOrderId() {
        return (orderId);
    }

    public void setOrderId(String orderId) {
        this.orderId=orderId;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public float getAmount() {
        return (amount);
    }

    public void setAmount(float amount) {
        this.amount=amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return (username);
    }

    public void setUsername(String username) {
        this.username=username;
    }

    public String getNotes() {
        return (notes);
    }

    public void setNotes(String notes) {
        this.notes=notes;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

}