package Jt.portal.form;
import org.apache.struts.validator.ValidatorForm;

public class InProductCategoryForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private String productId;
    private String categoryId;


    public String getProductId() {
        return (productId);
    }

    public void setProductId(String productId) {
        this.productId=productId;
    }

    public String getCategoryId() {
        return (categoryId);
    }

    public void setCategoryId(String categoryId) {
        this.categoryId=categoryId;
    }

}
