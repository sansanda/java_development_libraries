package Jt.portal.form;

import org.apache.struts.action.ActionForm;

public class CheckoutForm extends ActionForm {


    private static final long serialVersionUID = 1L;

}
