package Jt.portal.form;
import org.apache.struts.validator.ValidatorForm;

public class ProductForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private String productId;
    private String username;
    private String description;
    private float size;
    private String color;
    private float price;
    private int quantityInStock;


    public String getProductId() {
        return (productId);
    }

    public void setProductId(String productId) {
        this.productId=productId;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public float getSize() {
        return (size);
    }

    public void setSize(float size) {
        this.size=size;
    }

    public String getColor() {
        return (color);
    }

    public void setColor(String color) {
        this.color=color;
    }

    public float getPrice() {
        return (price);
    }

    public void setPrice(float price) {
        this.price=price;
    }

    public int getQuantityInStock() {
        return (quantityInStock);
    }

    public void setQuantityInStock(int quantityInStock) {
        this.quantityInStock=quantityInStock;
    }

} 