package Jt.portal.form;

import org.apache.struts.validator.ValidatorForm;

public class ProductCategoryForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private String categoryId;
    private String description;


    public String getCategoryId() {
        return (categoryId);
    }

    public void setCategoryId(String categoryId) {
        this.categoryId=categoryId;
    }

    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

}