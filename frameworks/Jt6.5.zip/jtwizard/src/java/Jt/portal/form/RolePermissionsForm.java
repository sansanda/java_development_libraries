package Jt.portal.form;
import org.apache.struts.validator.ValidatorForm;

public class RolePermissionsForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private String roleId;
    private String classname;
    private boolean createPermission;
    private boolean readPermission;
    private boolean updatePermission;
    private boolean deletePermission;
    private boolean executePermission;


    public String getRoleId() {
        return (roleId);
    }

    public void setRoleId(String roleId) {
        this.roleId=roleId;
    }

    public String getClassname() {
        return (classname);
    }

    public void setClassname(String classname) {
        this.classname=classname;
    }

    public boolean isCreatePermission() {
        return (createPermission);
    }

    public void setCreatePermission(boolean createPermission) {
        this.createPermission=createPermission;
    }

    public boolean isReadPermission() {
        return (readPermission);
    }

    public void setReadPermission(boolean readPermission) {
        this.readPermission=readPermission;
    }

    public boolean isUpdatePermission() {
        return (updatePermission);
    }

    public void setUpdatePermission(boolean updatePermission) {
        this.updatePermission=updatePermission;
    }

    public boolean isDeletePermission() {
        return (deletePermission);
    }

    public void setDeletePermission(boolean deletePermission) {
        this.deletePermission=deletePermission;
    }

    public boolean isExecutePermission() {
        return (executePermission);
    }

    public void setExecutePermission(boolean executePermission) {
        this.executePermission=executePermission;
    }

}
 