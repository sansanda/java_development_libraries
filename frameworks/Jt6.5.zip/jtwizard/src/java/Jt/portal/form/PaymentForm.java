package Jt.portal.form;
import org.apache.struts.validator.ValidatorForm;

public class PaymentForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private String firstName;
    private String lastName;
    private String cardType;
    private String cardNumber;
    private String expirationMonth;
    private String expirationYear;
    private String cvv2;
    private String billingAddress1;
    private String billingAddress2;
    private String city;
    private String state;
    private String country;
    private String zip;
    private String phone;
    private String username;
    private String email;
    private String amount;


    public String getFirstName() {
        return (firstName);
    }

    public void setFirstName(String firstName) {
        this.firstName=firstName;
    }

    public String getLastName() {
        return (lastName);
    }

    public void setLastName(String lastName) {
        this.lastName=lastName;
    }

    public String getCardType() {
        return (cardType);
    }

    public void setCardType(String cardType) {
        this.cardType=cardType;
    }

    public String getCardNumber() {
        return (cardNumber);
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber=cardNumber;
    }

    public String getExpirationMonth() {
        return (expirationMonth);
    }

    public void setExpirationMonth(String expirationMonth) {
        this.expirationMonth=expirationMonth;
    }

    public String getExpirationYear() {
        return expirationYear;
    }

    public void setExpirationYear(String expirationYear) {
        this.expirationYear = expirationYear;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }

    public String getBillingAddress1() {
        return (billingAddress1);
    }

    public void setBillingAddress1(String billingAddress1) {
        this.billingAddress1=billingAddress1;
    }

    public String getBillingAddress2() {
        return (billingAddress2);
    }

    public void setBillingAddress2(String billingAddress2) {
        this.billingAddress2=billingAddress2;
    }

    public String getCity() {
        return (city);
    }

    public void setCity(String city) {
        this.city=city;
    }

    public String getState() {
        return (state);
    }

    public void setState(String state) {
        this.state=state;
    }

    public String getCountry() {
        return (country);
    }

    public void setCountry(String country) {
        this.country=country;
    }

    public String getZip() {
        return (zip);
    }

    public void setZip(String zip) {
        this.zip=zip;
    }

    public String getPhone() {
        return (phone);
    }

    public void setPhone(String phone) {
        this.phone=phone;
    }

    public String getUsername() {
        return (username);
    }

    public void setUsername(String username) {
        this.username=username;
    }

    public String getEmail() {
        return (email);
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

}
