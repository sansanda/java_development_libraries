package Jt.portal.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.ValidatorForm;

import Jt.JtFactory;

public class RegistrationForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;

    private String username;
    private String password;
    private String retypePassword;
    private String email;
    private String retypeEmail;
    private transient JtFactory factory = new JtFactory ();
    //private boolean active;
    //private boolean disabled;
    
    

/*
    public String getUserId() {
        return (userId);
    }

    public void setUserId(String userId) {
        this.userId=userId;
    }
*/
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return (password);
    }

    public void setPassword(String password) {
        this.password=password;
    }

    public String getRetypePassword() {
        return retypePassword;
    }

    public void setRetypePassword(String retypePassword) {
        this.retypePassword = retypePassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRetypeEmail() {
        return retypeEmail;
    }

    public void setRetypeEmail(String retypeEmail) {
        this.retypeEmail = retypeEmail;
    }
    
    public ActionErrors validate (ActionMapping mapping, HttpServletRequest request) {
        
        ActionErrors errors = super.validate(mapping, request);
        
        //factory.handleTrace("validate: " + password);
        
        //factory.handleTrace("validate: " + email);
        //factory.handleTrace("validate: " + retypePassword);
        
        //factory.handleTrace("validate: " + retypeEmail);
        
        if (password != null && !password.equals (retypePassword)) 
            errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.errors.nomatch", "Passwords"));

        if (email != null && !email.equals (retypeEmail)) 
            errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.errors.nomatch", "Emails"));
       
        return errors;
        
    }
    
/*
    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getDisabled() {
        return disabled;
    }

    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }
*/

}
 
