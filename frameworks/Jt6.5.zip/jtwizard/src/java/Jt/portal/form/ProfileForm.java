package Jt.portal.form;
//import javax.servlet.http.HttpServletRequest;
import org.apache.struts.validator.ValidatorForm;

public class ProfileForm extends ValidatorForm {

    //private String userId;
    private String username;
    private String firstname;
    private String lastname;
    private int status;
    private String address;
    private String address1;
    private String state;
    private String city;
    private String country;
    private String zip;
    private String phone;
    private boolean emailFlag;

/*
    public String getUserId() {
        return (userId);
    }

    public void setUserId(String userId) {
        this.userId=userId;
    }
*/
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFirstname() {
        return (firstname);
    }

    public void setFirstname(String firstname) {
        this.firstname=firstname;
    }



    public String getLastname() {
        return (lastname);
    }

    public void setLastname(String lastname) {
        this.lastname=lastname;
    }

    public int getStatus() {
        return (status);
    }

    public void setStatus(int status) {
        this.status=status;
    }

    public String getAddress() {
        return (address);
    }

    public void setAddress(String address) {
        this.address=address;
    }

    public String getAddress1() {
        return (address1);
    }

    public void setAddress1(String address1) {
        this.address1=address1;
    }

    public String getState() {
        return (state);
    }

    public void setState(String state) {
        this.state=state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return (country);
    }

    public void setCountry(String country) {
        this.country=country;
    }

    public String getZip() {
        return (zip);
    }

    public void setZip(String zip) {
        this.zip=zip;
    }

    public String getPhone() {
        return (phone);
    }

    public void setPhone(String phone) {
        this.phone=phone;
    }

    public boolean isEmailFlag() {
        return (emailFlag);
    }

    public void setEmailFlag(boolean emailFlag) {
        this.emailFlag=emailFlag;
    }

} 