package Jt.portal.form;

import org.apache.struts.validator.ValidatorForm;

public class RoleForm extends ValidatorForm {


    private static final long serialVersionUID = 1L;
    private String description;
    private String roleId;


    public String getDescription() {
        return (description);
    }

    public void setDescription(String description) {
        this.description=description;
    }

    public String getRoleId() {
        return (roleId);
    }

    public void setRoleId(String roleId) {
        this.roleId=roleId;
    }

}
 