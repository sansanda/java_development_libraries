package Jt.portal.form;

import org.apache.struts.validator.ValidatorForm;

public class MailingMemberForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    private String email;
    private String name;
    private boolean emailFlag;
    private boolean sent;


    public String getEmail() {
        return (email);
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public String getName() {
        return (name);
    }

    public void setName(String name) {
        this.name=name;
    }

    public boolean isEmailFlag() {
        return (emailFlag);
    }

    public void setEmailFlag(boolean emailFlag) {
        this.emailFlag=emailFlag;
    }

    public boolean isSent() {
        return (sent);
    }

    public void setSent(boolean sent) {
        this.sent=sent;
    }

}
