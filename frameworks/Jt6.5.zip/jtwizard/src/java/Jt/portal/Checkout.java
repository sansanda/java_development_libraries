package Jt.portal;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;

import Jt.JtComposite;
import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.portal.form.PaymentForm;
import Jt.wizard.struts.ActionMappingForm;


/**
 * Check out process.
 */


public class Checkout extends JtObject {
    

    private static final long serialVersionUID = 1L;
    private transient JtContext context;
    public static final String JtCLASS_NAME = Checkout.class.getName();     
    public static final String SHOPPING_CART_ID = "jtShoppingCart";    
    public static final String CREATE_ORDER = "CREATE_ORDER";  
    public static final String DO_PAYMENT = "DO_PAYMENT"; 
    private transient JtFactory factory = new JtFactory ();
    private transient HttpSession session;
    private ShoppingCart cart = null;
    
    
    public Checkout () {
        
    }
    /*  
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    */
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("ShoppingCart.retrieveSession: Invalid Jt context: null");
            return (null); 
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession();
        
        return (session);    
    }
    

    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    // Propagate UI errors. obj needs to be an instance
    // of JtObject
    
    private Object propagateUiErrors (JtObject obj) {
        if (obj == null)
            return null;
        
        if (obj.getObjErrors() != null)
            this.setObjErrors(obj.getObjErrors ());
        
        return (this.getObjErrors());
    }
    

    
    private Object retrieveItem (ShoppingCart cart, String item) {
        JtMessage msg;
        
        if (cart == null || item == null)
            return (null);
        
        msg = new JtMessage (JtComposite.JtGET_CHILD);
        msg.setMsgContent(item);
        return ((Object) factory.sendMessage(cart, msg));
        
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    
    private int stringToInteger (String str) {
        int value;
        
        if (str == null)
            return (-1);

        try {
            value = Integer.parseInt(str);
        }
        catch (Exception ex) {
            return (-1);

        }
        
        return (value);

    }
 
    
    private void updateQuantities (ShoppingCart cart,
            HttpServletRequest request) {
        Enumeration parameters;
        String param;
        Object item;
        String sQuantity;
        
        handleTrace ("Checkout.updateQuantities: ");
        
        if (cart == null || request == null)
            return;
        
        parameters = request.getParameterNames();
        
        while (parameters.hasMoreElements()) {
            
            
            param = (String) parameters.nextElement();
            handleTrace ("Checkout.updateQuantities: " + param);            
            

            item = retrieveItem (cart, param);
            
            if (item == null) {
                handleWarning ("Checkout.updateQuantities: item not found:" + item);
                continue;
            }            
            
            sQuantity = request.getParameter(param);
            if (stringToInteger (sQuantity) <= 0) {
                handleUIError ("Invalid quantity:" + sQuantity);
                continue;
            }
            
            factory.setValue(item, "quantity", sQuantity);
               
        }
        
    }
    
    // Update/return the payment form
    
    private PaymentForm doCheckout(HttpServletRequest request) {
        PaymentForm paymentForm = new PaymentForm ();
        
        if (request == null) {
            handleError ("Invalid Http request: null");
            return (null);
        }
        
        if (cart == null)
            return (null);
        
        
        updateQuantities (cart, request);
        paymentForm.setAmount("" + cart.getTotal()); 
        return (paymentForm);
        
    }
    
    
    private Order buildOrder (ShoppingCart cart, String orderId) {
        Iterator iterator;
        Order order;
        Product product;
        OrderItem item;
        JtMessage msg;
        int i = 1;
        List list;
        
        
        if (cart == null || orderId == null)
            return (null);
        
        
        order = (Order) factory.createObject(Order.JtCLASS_NAME);
        
        order.setAmount(cart.getTotal());
        order.setOrderId(orderId);
        
        list = cart.getList();
        
        if (list == null)
        	return (order); // check 
        
        iterator = list.iterator();
        
        msg = new JtMessage (JtComposite.JtADD_CHILD);
        while (iterator.hasNext()) {
            product = (Product) iterator.next();
            
            item = new OrderItem ();
            item.setOrderId(orderId);
            item.setSequence(i++);
            item.setDescription(product.getDescription());
            item.setProductId(product.getProductId());
            item.setPrice (product.getPrice());
            item.setQuantity(product.getQuantity());
            msg.setMsgContent(item);
            msg.setMsgContext(context);
            factory.sendMessage(order, msg);
        }
        
        return (order);
    }
    
    private Object doPayment (PaymentForm form) {
        JtMessage msg = new JtMessage (PaymentBridge.DIRECT_PAYMENT);
        PaymentReceipt receipt;
        Order order;
        
        PaymentBridge paymentBridge = (PaymentBridge) factory.createObject(PaymentBridge.JtCLASS_NAME);
        
        msg.setMsgContext(context);
        receipt = (PaymentReceipt) factory.sendMessage(paymentBridge, msg);
        
        if (propagateException (paymentBridge) != null) {
            return (null);
        }
        
        if (propagateUiErrors (paymentBridge) != null) {
            return (null);
        }
        
        if (receipt == null)
            return (null); // check
        
        order = buildOrder (cart, receipt.getTransactionId());

        msg = new JtMessage (JtObject.JtCREATE);
        msg.setMsgContext(context);
        order.setUsername(context.getUserName());
        order.setStatus(Order.COMPLETED);
        factory.sendMessage (order, msg);
        
        
        return (receipt);
            
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        ActionForm form;
        HttpServletRequest request;
        //JtMessage msg;
        //ShoppingCart cart = null;
        
        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        //if (!init) {
            //initialize ();     
            //init = true;
        //}
        
        context = (JtContext) e.getMsgContext();
        request = context.getRequest();
        
        if (context == null) {
            handleError ("You session may have expired. Please log in.");
            return (null);
        }
        

        session = retrieveSession ();
        form = (ActionForm) context.getActionForm();  
        
        if (session == null) {
            handleError ("Invalid session. You session may have expired. Please log in.");
            return (null);
        }       
        
        cart = (ShoppingCart) session.getAttribute(Checkout.SHOPPING_CART_ID);

        
        if (cart == null) {           
            handleError ("You session may have expired. Please log in.");
            return (null);
        }        
        
                      
        
        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            
            return (doCheckout (request));
        }
        
/*        
        if (e.getMsgId().equals("CREATE_ORDER")) {
            
            return (createOrder (cart));
        }
*/
        
        if (e.getMsgId().equals(Checkout.DO_PAYMENT)) {
            
            return (doPayment ((PaymentForm) form));
        }
        
        return (super.processMessage (message));

    }
    



}
