package Jt.portal;

import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.JtAccount;
import Jt.security.JtMessageDigest;


public class Login extends JtObject {

    
    private static final long serialVersionUID = 1L;
    //private String userId;
    //private String password;
    private JtDAOStrategy daoAdapter = null;
    private JtFactory factory = new JtFactory ();
    //private JtAccount account;
    public static final String JtCLASS_NAME = Login.class.getName(); 
    public static final String GET_USERNAME = "GET_USERNAME";
    private boolean initted = false;
    
    /*
    public String getUserID() {
        return userId;
    }
    public void setUserID(String userId) {
        this.userId = userId;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    */
    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    private String encryptPassword (String password) {
        JtMessageDigest messageDigest = new JtMessageDigest ();
        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
        String digest;
        
        
        if (password == null)
            return (null);
        
        msg.setMsgContent(password);
        
        // Check Exceptions
        
        //digest = (String) factory.sendMessage(messageDigest, msg);
        
        // security
        digest = (String) messageDigest.processMessage(msg);
        
        if (propagateException (messageDigest) != null)
            return (null);
        
        //handleTrace ("Login.encryptPassword:" + digest);
        return (digest);
        
    }

    private JtAccount retrieveAccount (String username) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        JtAccount account;
        
        msg.setMsgContent(new JtAccount ());
        
        msg.setMsgData (username);
        
        account = (JtAccount) factory.sendMessage(daoAdapter, msg);
        
        propagateException (daoAdapter);
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        return (account);
        
        
    }
    
    private void initialize () {
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(true);        
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    private JtAccount login (ActionForm form) {
        JtAccount account;
        //String userId;
        String password;
        String ePass;
        String username;
        
        if (form == null) {
            handleError ("invalid parameter value (null): form");
            return (null);
        }
        
        //userId = (String) factory.getValue(form, "userId"); // check log
        username = (String) factory.getValue(form, "username");
        
        // Just in case. useId and password should be required fields
        if (username == null || username.equals("")) {
            handleError ("Invalid username");
            return (null);
        }
        
        password = (String) factory.getValue(form, "password");
        if (password == null || password.equals("")) {
            handleError ("Invalid userId");
            return (null);
        }
        
/*        
        if (userId == null) {
            handleError ("attribute userId needs to be set.");
            return;
        }
            
        if (password == null) {
            handleError ("attribute password needs to be set.");
            return;
        }
*/        

        
        // Create Account
        
        account = retrieveAccount (username);
        
        if (this.getObjException() != null)
            return (null);
        
        if (account == null) {//
            handleUIError ("Invalid username or password. Please try again.");
            return (null);
        }
        
        ePass = encryptPassword (password);
        password = null;
        
        if (ePass == null) {
            return (null); // check propagate Exception
            
        }
            
        if (!ePass.equals(account.getPassword())) {
            handleUIError ("Invalid username or password. Please try again.");
            return (null);
        }
        
        if (!account.isActive()) {
            handleUIError 
            ("This account needs to be activated. Please check your email. An activation link has been sent.");   
            return (null);
        }
        if (account.isDisabled()) {
            handleUIError 
            ("This account is not active.");   
            return (null);
        }
        
        return (account);
        
        
    }
    
    
    
    
    private  String retrieveUsername (HttpSession session) {
        JtContext context;
        
        
        if (session == null)
            return (null);
        
        
        //factory.handleTrace("updateSession (session):" + session);
        
        if (session == null)
            return (null); 
        
        context = (JtContext) session.getAttribute("jtContext");
        
        if (context == null)
            return (null);
        
        return (context.getUserName());
        
        
    }
    
    
    private void updateSession (JtContext context, JtAccount account) {
        HttpServletRequest request;
        HttpSession session;
        
        
        factory.handleTrace("updateSession");
        
        if (context == null || account == null)
            return;
        
        request = context.getRequest();
        
        if (request == null)
            return;
        
        session = request.getSession();
        
        //factory.handleTrace("updateSession (session):" + session);
        
        if (session == null)
            return;
        
        //factory.handleTrace("updateSession (username):" + account.getUsername());
        context.setUserName(account.getUsername());
        
        session.setAttribute("jtContext", context);                
        
        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        ActionForm form = null;
        JtContext context;
        JtAccount account;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        if (!initted) {
            initialize ();
            initted = true;
        }

/*
        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {

            // pass the form information   
            data = e.getMsgData ();
            return ( getActionMappings ());
        }
*/        
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        if (context != null)
            form = (ActionForm) context.getActionForm();  

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            
            
            account = login (form);
            if (account != null)
                updateSession (context, account);
            
            return (null);
        }
        
        if (e.getMsgId().equals(Login.GET_USERNAME)) {
                                 
            return (retrieveUsername ((HttpSession) e.getMsgContent()));
        }
        
        return (super.processMessage(message));

    }

    
    
}
