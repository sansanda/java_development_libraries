package Jt.portal;


import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.forum.Topic;
import Jt.forum.TopicInForum;
import Jt.forum.form.TopicForm;



public class DAOCategory extends JtObject {

    public static final String RETRIEVE_OBJECTS = "RETRIEVE_OBJECTS";

    public static final String JtCLASS_NAME = DAOCategory.class.getName(); 
    public static final String JtADD_CHILD = "JtADD_CHILD";
    public static final String CATEGORY_ID = "categoryId";

    private transient JtDAOStrategy adapter;
    private boolean init = false;
    
    private static final long serialVersionUID = 1L;
    private String categoryId;
    private String classname;
    private String categoryClassname;
    private String keyAttribute;
    private String orderByAttribute = null;
    private boolean ascendent = true;
    
    private transient List categoryList;
    private String categoryAttribute = CATEGORY_ID;
    
    private String query;
    private String sessionVariable = "jtDAOCategoryList";

    
    // Display attributes (display tag)
    private boolean paging = true;
    
    protected transient JtContext context = new JtContext ();
    private transient JtFactory factory = new JtFactory ();
    
   

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }
 
    
  
    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getCategoryClassname() {
        return categoryClassname;
    }

    public void setCategoryClassname(String categoryClassname) {
        this.categoryClassname = categoryClassname;
    }

    public String getKeyAttribute() {
        return keyAttribute;
    }

    public void setKeyAttribute(String keyAttribute) {
        this.keyAttribute = keyAttribute;
    }

    public String getCategoryAttribute() {
        return categoryAttribute;
    }

    public void setCategoryAttribute(String categoryAttribute) {
        this.categoryAttribute = categoryAttribute;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getSessionVariable() {
        return sessionVariable;
    }

    public void setSessionVariable(String sessionVariable) {
        this.sessionVariable = sessionVariable;
    }

    public List getCategoryList() {
        return categoryList;
    }

    public void setCategoryList(List categoryList) {
        this.categoryList = categoryList;
    }

    public String getOrderByAttribute() {
        return orderByAttribute;
    }

    public void setOrderByAttribute(String orderByAttribute) {
        this.orderByAttribute = orderByAttribute;
    }

    public boolean isAscendent() {
        return ascendent;
    }

    public void setAscendent(boolean ascendent) {
        this.ascendent = ascendent;
    }

    protected Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    
    private Object retrieveAttributeFromSession (String attributeName) {
        HttpSession session = null;
        HttpServletRequest request = null;
        if (attributeName == null)
            return (null);
        
        if (context == null) {
            handleWarning ("DAOCategory.retrieveAttributeFromSession: Invalid Jt context: null");
            return (null);
        }
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        if (session == null) {
            handleWarning ("DAOCategory.retrieveAttributeFromSession: Invalid HttpSession session: null");
            return (null);
        }
        
        return (session.getAttribute(attributeName));
        
        
    }
    
    private void sessionCleanup (HttpSession session) {
        Enumeration enu;
        String attrName;
        ArrayList list = new ArrayList ();
        Iterator iterator;
        
        
        if (session == null)
            return;
        
        enu = session.getAttributeNames();
        
        // Remove all the attributes name like (jtxxxxxList)
        // except listName
        
        while (enu.hasMoreElements()) {
            attrName = (String) enu.nextElement();
            
            if (attrName != null &&
                    attrName.startsWith("jt") &&
                    attrName.endsWith("List")) {
                //if (!attrName.equals(listName)) {
                handleTrace ("DAOCategory.sessionCleanup:" + attrName, 0);
                //session.removeAttribute(attrName);
                list.add(attrName);
                //}
            }
            
            
        }
        
        iterator = list.iterator();
        
        while (iterator.hasNext())
            session.removeAttribute((String) iterator.next());
    }
    
    private void updateSession (String attributeName, List productList) {
        HttpSession session = null;
        HttpServletRequest request = null;
        
        if (context == null) {
            handleWarning ("DAOCategory.updateSession: Invalid Jt context: null");
            return; // check
        }
        if (attributeName == null || productList == null)
            return;
        
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return;
        
        session = request.getSession(false);
        
        if (session == null) {
            handleWarning ("DAOCategory.updateSession: Invalid HttpSession session: null");
            return;
        }
        
        session.setAttribute(attributeName, productList);        
        
    }
    
    private String  retrievePageParameter (HttpServletRequest request) {
        Enumeration enu;
        String parameter = null;
        
        if (request == null)
            return (null);
        
        enu = request.getParameterNames();
        
        if (enu == null)
            return (null);
        
        while (enu.hasMoreElements()) {
            parameter = (String) enu.nextElement();
            
            if (parameter != null && parameter.startsWith("d") &&
                    parameter.endsWith("p")) {
                handleTrace (parameter);    
                return (parameter);
            }
        }        
        return (null);
               
    }

    private List retrieveObjectsInCategory (String categoryId) {
        
        JtMessage msg = new JtMessage ();
        List result;
        //String query = "select * from  in_product_category c, product p WHERE i.productId = p.productId"; // check - configuration file
        JtDAOStrategy adapter; 
        Object classInstance;
        String tquery;
        
        //LinkedList list = new LinkedList ();
        

       
        if (paging) {
            if (context != null && (retrievePageParameter (context.getRequest()) != null)) {

                // Retrieve product list from session
                result = (List) retrieveAttributeFromSession (sessionVariable);
                if (result != null)
                    return (result);
            }
        }

        
        if (categoryId == null) {
            handleError ("Invalid parameter Category Id:" + null );
            return (null); // check

        }    
        
        if (classname == null) {
            handleError ("Attribute classname needs to be set.");
            return (null);
        }
        
        if (query == null) {
            handleError ("Attribute query needs to be set.");
            return (null);
        }
        
        classInstance = factory.createObject (classname);
        if (classInstance == null) {
            handleError ("unable to create an object of class: " + classname);
            return (null);
        }    
        
        tquery = query + "'" + categoryId + "'";
        
        if (orderByAttribute != null && !orderByAttribute.equals("")) {
            if (ascendent)
                tquery += " Order by " +  orderByAttribute + " asc";
            else
                tquery += " Order by " +  orderByAttribute + " desc";
                
        }
        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        //adapter.setCheckAccess(false); // check
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check
        msg.setMsgContext(context); 

        msg.setMsgContent(tquery);
       
       
        msg.setMsgData(classInstance);
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);


        if (paging) {
            sessionCleanup (retrieveSession ());
            updateSession (sessionVariable, result);
        }

        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }   
    
    private HttpSession retrieveSession () {
        HttpSession session = null;
        HttpServletRequest request = null;       
        
        if (context == null) {
            handleWarning ("DAOCategory.retrieveSession: Invalid Jt context: null");
            return (null); // check
        }
        request = (HttpServletRequest) context.getRequest();
        
        if (request == null)
            return (null);
        
        session = request.getSession(false);
        
        return (session);    
    }
    
    
    private JtHashTable retrieveAttributes (Object obj) {
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtFactory fact = new JtFactory ();
        
        if (obj == null)
            return (null);
        msg.setMsgContent(obj);
        fact.setStopClass(obj.getClass().getSuperclass());
        
        return ((JtHashTable) fact.processMessage(msg));
        
    }
    
    private void copyFormAttributes (ActionForm form, Object obj) {
        JtHashTable attributes;
        JtIterator iterator;
        String attribute;
        Object value;
        
        if (obj == null || form == null)
            return;
        //attributes = getAttributes (obj);
        attributes = retrieveAttributes (form);
        
        if (attributes == null)
            return;
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        if (iterator == null)
            return;
        
        for (;;) {
            attribute = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (attribute == null)
                break;
            value = factory.getValue(form,attribute);
            factory.setValue (obj, attribute, value);
                
        }
        
    }
    
    
    private void addObjectToCategory (ActionForm form) {
        JtMessage msg = new JtMessage ();
        //String username;
        //TopicInForum topicInForum = new TopicInForum ();
        Object classInstance;
        Object keyValue;
        Object categoryAttrValue;

      
        if (form == null) {
            handleError ("Invalid parameter (form): null");
            return; 
        }
        
        if (classname == null) {
            handleError ("classname attributes needs to set.");
            return;
        }   
        
        if (categoryClassname == null) {
            handleError ("categoryClassname attributes needs to set.");
            return;
        }  
        
        if (keyAttribute == null) {
            handleError ("keyAttribute needs to set.");
            return;
        } 
        
        if (categoryAttribute == null) {
            handleError ("categoryAttribute needs to set.");
            return;
        } 
        
        categoryAttrValue = factory.getValue(form, categoryAttribute);
        
        if (categoryAttrValue == null) {
            handleError ("Category ID is null");
            return;
        }  

        classInstance = factory.createObject (classname);
        if (classInstance == null) {
            handleError ("unable to create an object of class: " + classname);
            return;
        }    


        
        copyFormAttributes (form, classInstance);
        
        keyValue = factory.getValue(classInstance, keyAttribute);
        
        if (keyValue == null) {
            handleError (keyAttribute + " is null");
            return;
        }    
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(classInstance);
        msg.setMsgContext(context); // pass the JtContext
        
        // check - already exists 
        
        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        
        if (propagateException (adapter) != null) {
            factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
            return;
        }

        
        classInstance = factory.createObject (categoryClassname);
        if (classInstance == null) {
            handleError ("unable to create an object of class: " + classname);
            return;
        }    
        
        //topicInForum.setTopicId(form.getTopicId());
        //topicInForum.setForumId(form.getForumId());       

        
        factory.setValue(classInstance, keyAttribute, keyValue);
        factory.setValue(classInstance, categoryAttribute, categoryAttrValue);
              
        msg = new JtMessage (JtDAOAdapter.JtCREATE);   
        msg.setMsgContent(classInstance);
        msg.setMsgContext(context); // pass the JtContext
        
         
        factory.sendMessage (adapter, msg);
        
        // Propagate the exception
        

        propagateException (adapter);
        
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
                
    } 
    
    private void initialize () {
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);                  
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        String content;
        //String attachment;
        ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);               

        if (!init) {
            initialize ();
            init = true;
        }
        
        content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        


        //form = (ActionForm) context.getActionForm();  
        if (context != null)
            form = (ActionForm) context.getActionForm();  

            

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            
            if (context == null || context.getUserName() == null) {
                handleError ("Invalid context. You session may have expired. Please log in.");
                return (null);
            }
            
            categoryList = retrieveObjectsInCategory (content);
            categoryId = (String) content; 
            return (this);
        }
        
        if (e.getMsgId().equals(DAOCategory.RETRIEVE_OBJECTS)) {
            
            if (context == null || context.getUserName() == null) {
                handleError ("Invalid context. You session may have expired. Please log in.");
                return (new LinkedList ());
            }
            
            return (retrieveObjectsInCategory (content));
        }
        
        if (e.getMsgId().equals (DAOCategory.JtADD_CHILD)) {
            addObjectToCategory (form);
            return (null); // check
        }
        
        handleError ("Invalid message Id:" + e.getMsgId());
        
        return (null);

        //return (super.processMessage(message)); //security bug

    }

}