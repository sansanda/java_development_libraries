package Jt.portal;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMail;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.form.AccountForm;
import Jt.portal.form.ChangePasswordForm;
import Jt.portal.form.ProfileForm;
import Jt.portal.form.RegistrationForm;
import Jt.portal.form.RequestNewPasswordForm;
import Jt.security.JtMessageDigest;
import Jt.wizard.struts.CRUD;
import Jt.wizard.util.ResourceFile;

public class JtAccount extends JtObject {

    public static final String JtCLASS_NAME = JtAccount.class.getName(); 
    private static final long serialVersionUID = 1L;
    public static final String ACTIVATE_ACCOUNT = "ACTIVATE_ACCOUNT";
    public static final String READ_MY_ACCOUNT = "READ_MY_ACCOUNT";
    public static final String UPDATE_MY_ACCOUNT = "UPDATE_MY_ACCOUNT";
    public static final String CHANGE_PASSWORD = "CHANGE_PASSWORD";
    public static final String REQUEST_PASSWORD_CHANGE = "REQUEST_PASSWORD_CHANGE";
    //private long id;
    //String userId;
    private String username;
    private String password;
    private String email;
    private boolean active;
    private boolean disabled;
    private boolean regEmail;
    private JtFactory factory = new JtFactory ();
    //private JtAccount account;
    //private JtDAOAdapter daoAdapter = new JtDAOAdapter ();
    private transient JtContext context = null;
    private transient CRUD crudObj;
    //private String changePasswordLink = null;
    private transient String serial;
    private transient JtDAOStrategy daoAdapter;
    private transient Password passwordObj;
    private transient boolean init = false;
    
    /*
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    */
    
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    
    public boolean isRegEmail() {
        return regEmail;
    }
    public void setRegEmail(boolean regEmail) {
        this.regEmail = regEmail;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    /*
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    */
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isDisabled() {
        return disabled;
    }
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    /*
    public String getChangePasswordLink() {
        return changePasswordLink;
    }
    public void setChangePasswordLink(String changePasswordLink) {
        this.changePasswordLink = changePasswordLink;
    }
    */
    
    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    private String encryptPassword (String password) {
        JtMessageDigest messageDigest = new JtMessageDigest ();
        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
        String digest;
        
        
        if (password == null)
            return (null);
        
        msg.setMsgContent(password);
        
        // Check Exceptions
        //digest = (String) factory.sendMessage(messageDigest, msg);
        
        // security
        digest = (String) messageDigest.processMessage(msg);
        
        //handleTrace ("JtAccount.encryptPassword:" + digest);
        if (propagateException (messageDigest) != null)
            return (null);
        
        return (digest);
        
    }

    private JtAccount retrieveAccount (String userId) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        msg.setMsgContent(new JtAccount ());
        JtAccount account;
        
        msg.setMsgData (userId);
        
        account = (JtAccount) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return (null);
        
        //factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (account);
    }
    
    private void updateMyAccount (ActionForm form) {
        JtAccount account = new JtAccount ();
        String username;
        String password;
        String ePass;
        
        if (form == null) {
            handleError ("invalid parameter value (null): form");
            return;
        }
        
        //userId = (String) factory.getValue(form, "userId"); // check log
        username = (String) factory.getValue(form, "username");
        
        // Just in case. useId and password should be required fields
        if (username == null || username.equals("")) {
            handleError ("Invalid username");
            return;
        }
        
        password = (String) factory.getValue(form, "password");
        if (password == null || password.equals("")) {
            handleError ("Invalid password");
            return;
        }
             

        ePass = encryptPassword (password);
        
        
        if (ePass == null) {
            return;      
        }
        
        account.setUsername(username);
        account.setPassword(ePass);
        account.setEmail((String) factory.getValue(form, "email"));
        

       updateAccount (account);
         
        
    }
    
    private void activateAccount (String username) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        JtAccount account;
        
        if (username == null)
            return;
        
        msg.setMsgContent(new JtAccount ());
        
        msg.setMsgData (username);
        
        account = (JtAccount) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return;
        
        if (account == null) {
            if (getObjException () != null)
                handleError ("unable to retrieve account:" + account); // check
            return;
        }

        account.setActive(true);
        updateAccount (account);
    }
    
/*    
    private JtAccount createAccount (String userId) {
        JtMessage msg = new JtMessage (JtObject.JtCREATE);
        msg.setMsgContent(new JtAccount ());
        
        msg.setMsgData (userId);
        
        return ((JtAccount) factory.sendMessage(daoAdapter, msg));
    }
*/    

    private boolean verifyPassword (JtAccount account, String password) {
        String epass;
        /*
        if (password == null) {
            handleError ("Attribute password needs to be set.");
            return (false);
        }
        */
        
        epass = encryptPassword (password);
        
        if (epass == null) {// check. 2 exception            
            return (false);
        }
        
        if (epass.equals(account.getPassword())) {
            return true;
        }
        
        return false;
        
        
    }
    
    private RegistrationForm myAccount () {
        String username;
        
        if (context == null) {
            handleUIError ("Invalid Jt Context. Please Log in");
            return (null);
        }
        
        username = context.getUserName();
        
        if (username == null) {
            handleUIError ("Invalid Jt Context. Please Log in");
            return (null);
        }  
        
        return (retrieveMyAccount (username));
        
    }
    
    private void changePassword (ChangePasswordForm form) {
        JtAccount account;
        String epass;
        
        if (form == null)
            return;
        
        if (context == null) {
            handleUIError ("Invalid Jt Context. Please Log in");
            return;
        }
        
        username = context.getUserName();
        
        if (username == null) {
            handleUIError ("Invalid Jt Context. Please Log in");
            return;
        }  
        
        // Check exception
        
        account = retrieveAccount (username);
        
        if (account == null) // check
            return;
        
        if (!verifyPassword (account, form.getPassword())) {
            handleUIError ("The current password is invalid. Please try again.");
            return;
        }
        
        epass = encryptPassword (form.getNewPassword());
        
        if (epass == null) {
            if (this.getObjException() == null)
                handleError ("Unable to change your password.");// check (double)
            return;
        }
        
        account.setPassword(epass);
        updateAccount (account);
         
    }
    
    private RegistrationForm retrieveMyAccount (String userId) { // Check security
        AccountForm form;
        RegistrationForm oform = new RegistrationForm ();
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        
        if (userId == null)
            return (null);
        
        crudObj = (CRUD) factory.createObject(CRUD.JtCLASS_NAME);
        
        crudObj.setClassname(JtAccount.JtCLASS_NAME);
        msg.setMsgId(JtObject.JtREAD);
        context.setActionForm(new AccountForm ());
        msg.setMsgContext(context); // Pass the context
        msg.setMsgContent(userId);
        crudObj.setKey("username");
        
        
        form = (AccountForm) factory.sendMessage(crudObj, msg);
        
        if (propagateException (crudObj) != null)
            return (null);

        // Remove Object
        
        oform.setUsername(form.getUsername());       
        oform.setEmail(form.getEmail());
        oform.setPassword(form.getPassword());
        
        factory.sendMessage(crudObj, new JtMessage (JtObject.JtREMOVE));
        
        return (oform);
    }
    
/*    
    void register (ActionForm form) {
        String userId;
        JtAccount account;
        String password;
        
        if (form == null) {
            handleError ("invalid parameter value (null): form");
            return;
        }
        
        userId = (String) factory.getValue(form, "userId"); // check log
        
        // Just in case. useId and password should be required fields
        if (userId == null || userId.equals("")) {
            handleError ("Invalid userId");
            return;
        }
        
        account = retrieveAccount (userId);
        
        if (account != null) {
            
            handleError ("Please choose a different user ID");
            return;
        }
        
        password = (String) factory.getValue(form, "password");
        if (password == null || password.equals("")) {
            handleError ("Invalid userId");
            return;
        }
        
        // encrypt password
        

        
        // Send email
        
    }
*/
    
    private boolean updateAccount (JtAccount account) {
        JtMessage msg = new JtMessage (JtObject.JtUPDATE);
        boolean result = true;
        
        if (account == null)
            return false;
        
        msg.setMsgContent(account);
        msg.setMsgContext(context);
        
        
        factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            result = false;
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (result);
        
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    
    private String generateSerial () {
        Date date = new Date ();
        String tmp;
        
        tmp = "" + date.getTime();
        
        return (tmp);
    }
    
    private String buildLink (String username) {
        String result;
        //Date date = new Date ();
        //Password password;
                
        if (username == null) {
            return (null);
        }   
        
        //password = (Password) factory.createObject(Password.JtCLASS_NAME);
        
        //serial = generateSerial ();
        
        
        if (passwordObj.getChangePasswordLink() == null) {
            handleError ("Invalid change password link. Add it to the Jt resource file.");
            return (null);
        }
        
        result = passwordObj.getChangePasswordLink() + "?msgContent=" + 
             username + "&msgData=" + serial; // check
        
        return (result);
        
    }
    
    private String buildEmailMessage (String username) {
        
        String result;
        String emailLink;
        
        ResourceFile resFile = new ResourceFile ();
        
        
        if (username == null)
            return (null);
        
        resFile.setPath("EmailTemplates/ChangePasswordEmail.txt");
        
        
        result = (String) factory.sendMessage(resFile, new JtMessage (JtObject.JtREAD));
        
        if (propagateException (resFile) != null)
            return (null);
        
        if (result == null)
            return (null);
            
        emailLink = buildLink (username);
        
        if (emailLink == null) {
            return (null);
        }
            
        
        result = result.replaceAll ("#link", emailLink);
        
        //handleTrace ("buildEmailMessage:" + result);
        return (result);
    }
    
    
    // Send the registration email
    
    private boolean sendEmail (String email, 
            String message, String subject) {

        JtMail mailAdapter;
        //String message;

        
        if (email == null || message == null ||
                subject == null) {
            handleError ("Invalid parameters.");
            return false;
        }    
        
        /*
        if (link == null) {
            handleError ("Attribute Link needs to be set. Update the Jt Resource File.");
            return false;
        }
        */
        

        mailAdapter = (JtMail) factory.createObject (JtMail.JtCLASS_NAME, "portalMailAdapter");
        
        mailAdapter.setTo(email);
        
        //message = buildEmailMessage (account.getUsername());
        
        /*
        if (message == null) {
            handleError ("Invalid registration message");
            return false;
        }
        */
        
        mailAdapter.setMessage(message);        
        mailAdapter.setSubject(subject);
        
        factory.sendMessage (mailAdapter, new JtMessage (JtObject.JtACTIVATE));
        
        if (propagateException (mailAdapter) != null) {
            factory.removeObject (mailAdapter);
            return false;
        }
        
        // Remove mailAdapter
        
        factory.removeObject (mailAdapter);

        return true;
    }
    
    
    private JtAccount retrieveAccountByEmail (String email) {
        JtAccount account = new JtAccount ();
        //JtDAOAdapter adapter = new JtDAOAdapter (); // check new adapter
        JtDAOAdapter adapter; 
        JtMessage msg = new JtMessage (JtDAOAdapter.JtSEARCH_BY_ATTRIBUTES); // Hibernate does not implement this
        LinkedList attributeNames = new LinkedList ();
        Collection col;
        Iterator iterator;
        
        
        if (email == null)
            return (null);
        
        adapter = (JtDAOAdapter) factory.createObject(JtDAOAdapter.JtCLASS_NAME); // use the native DAO implementation
        
        attributeNames.add("email");
        account.setEmail(email);
        msg.setMsgContent(account);
        msg.setMsgData (attributeNames);
        
        //factory.sendMessage (account, new JtMessage (JtObject.JtPRINT));
        col = (Collection) factory.sendMessage(adapter, msg); 
        
        propagateException (adapter);
        
        factory.sendMessage(adapter, new JtMessage (JtObject.JtREMOVE));
        
        if (this.getObjException() != null)
            return (null);
               
        if (col.size() == 0) {
            return (null);
        }
        
        if (col.size () > 1) {
            handleWarning 
            ("retrieveAccountByEmail: multiple accounts for the same email: " + email);
        }
        
        iterator = col.iterator();
        
        return ((JtAccount) iterator.next());
    }
    
    private boolean sendChangePasswordLink (String email) {
        
        String message;
        
        if (email == null)
            return (false);
        
/*        
        if (changePasswordLink == null) {
            handleError ("Attribute changePasswordLink needs to be set. Please update the Jt Resource File.");
            return false;
        }
*/        
        
        passwordObj = (Password) factory.createObject(Password.JtCLASS_NAME);
        
        if ((message = buildEmailMessage (username)) == null)
            return false;
        
        //return (sendEmail (email, message, 
        //        "JtPortal: change password"));
        return (sendEmail (email, message, 
                passwordObj.getChangePasswordSubject()));
        
    }
    
    private boolean createSerial () {
        JtMessage msg = new JtMessage (Password.CREATE_SERIAL);
        Password password;
        
        if (serial == null || serial.equals(""))
            return (false);
        
        if (username == null)
            return (false);
        
        // check - object name, serial
        password = new Password ();
        //password.setSerial(serial);
        
        msg.setMsgContent(username);
        msg.setMsgData(serial);
        factory.sendMessage(password, msg);
        
        if (propagateException (password) != null)
            return (false);
        
        return (true);
    }
    
    private void requestPasswordChange (RequestNewPasswordForm form) {
        String email;
        JtAccount account;
        
        if (form == null || form.getEmail() == null) {
            handleError ("Invalid form error.");
            return;
        }    
        email = form.getEmail();
        
        // Retrieve account
        account = retrieveAccountByEmail (email);
        
        if (account == null) {
            handleUIError ("Email doesn't exist. Please try again.");
            return;
        }    
    
        this.username = account.username;
        
        if (username == null || username.equals ("")) {
            handleError ("Invalid username:" + username);
            return;           
        }
        
        serial = generateSerial ();
        if (!createSerial ()) {
            if (getObjException () == null)
                handleError ("Unable to send change password email.");
            
            return;
        }
        
        // Send link (change Password)
        
        if (sendChangePasswordLink (email))
            return;
        
        if (this.getObjException() != null)
            return;
        
        handleError ("Unable to send change password email.");
     
    }
    
    private void initialize () {
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(true);        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        ActionForm form = null;
        //JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
       
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        if (context != null)
            form = (ActionForm) context.getActionForm();  
/*
        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
                        
            register (form);
            return (null);
        }
        
        
*/
        if (!init) {
            initialize ();
            init = true;
        }
        

        
        if (e.getMsgId().equals(JtAccount.ACTIVATE_ACCOUNT)) {
                        
            activateAccount ((String) e.getMsgContent());
            return (null);
        }
        
        if (e.getMsgId().equals (JtAccount.READ_MY_ACCOUNT)) {

            return (myAccount ());
        }
        
        if (e.getMsgId().equals (JtAccount.UPDATE_MY_ACCOUNT)) {
            updateMyAccount (form);
            return (null);
        }
        
        if (e.getMsgId().equals (JtAccount.CHANGE_PASSWORD)) {
            changePassword ((ChangePasswordForm) form);
            return (null);
        }
        
        if (e.getMsgId().equals (JtAccount.REQUEST_PASSWORD_CHANGE)) {
            requestPasswordChange ((RequestNewPasswordForm) form);
            return (null);
        }
        
        return (super.processMessage(message));

    }


}
