package Jt.portal;



import java.util.Collection;
import java.util.LinkedList;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMail;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.JtAccount;
import Jt.security.JtMessageDigest;
import Jt.wizard.util.ResourceFile;


public class Register extends JtObject {


    private static final long serialVersionUID = 1L;
    private JtFactory factory = new JtFactory ();
    //private JtAccount account;
    private transient JtDAOStrategy adapter;
    private boolean initted = false;
    private transient JtContext context = null;
    private String link;
    JtMail mailAdapter = null;
    
    
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    
    private String encryptPassword (String password) {
        JtMessageDigest messageDigest = new JtMessageDigest ();
        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
        String digest;
        
        
        if (password == null)
            return (null);
        
        msg.setMsgContent(password);
        
        // Check Exceptions
        //digest = (String) factory.sendMessage(messageDigest, msg);
        // security
        digest = (String) messageDigest.processMessage(msg);
        
        handleTrace ("Login.encryptPassword:" + digest);
        if (propagateException (messageDigest) != null)
            return (null);
        
        return (digest);
        
    }

    // Create an Account
    
    private boolean createAccount (JtAccount account) {
        JtMessage msg = new JtMessage (JtObject.JtCREATE);
        boolean result = true;
        
        if (account == null)
            return false;
        
        msg.setMsgContent(account);
        msg.setMsgContext(context);
        
        
        factory.sendMessage(adapter, msg);
        
        if (propagateException (adapter) != null)
            result = false;
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (result);
        
    }
    
    // Read an Account
    
    private JtAccount readAccount (String username) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        JtAccount account = null;
        
        if (username == null)
            return null;
        
        msg.setMsgContent(new JtAccount ());

        msg.setMsgData(username);
        
        account = (JtAccount) factory.sendMessage(adapter, msg);
        
        propagateException (adapter);
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (account);
        
    }
    
    private boolean updateAccount (JtAccount account) {
        JtMessage msg = new JtMessage (JtObject.JtUPDATE);
        boolean result = true;
        
        if (account == null)
            return false;
        
        msg.setMsgContent(account);
        msg.setMsgContext(context);
        
        
        factory.sendMessage(adapter, msg);
        
        if (propagateException (adapter) != null)
            result = false;
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        return (result);
        
    }
    
    
    private void initialize () {
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(true);        
    }
    
    private Exception propagateException (JtObject obj) {
        
        if (obj == null)
            return (null);
        
        if (obj.getObjException() != null) {
            this.setObjException(obj.getObjException());
        }  
        return ((Exception) obj.getObjException());
    }
    
    
    private String buildLink (String username) {
        String result;
        
        if (link == null)
            return (null);
        
        result = link + "?jtMsgId=NEW&jtMsgContent=" + username; // check
        
        return (result);
        
    }
    
    private String buildEmailMessage (String username) {
        
        String result;
        String emailLink;
        
        ResourceFile resFile = new ResourceFile ();
        
        
        if (username == null)
            return (null);
        
        resFile.setPath("EmailTemplates/RegistrationEmail.txt");
        
        
        result = (String) factory.sendMessage(resFile, new JtMessage (JtObject.JtREAD));
        
        if (propagateException (resFile) != null)
            return (null);
        
        if (result == null)
            return (null);
            
        emailLink = buildLink (username);
        
        if (emailLink == null) {
            return (null);
        }
            
        
        result = result.replaceAll ("#link", emailLink);
        
        //handleTrace ("buildEmailMessage:" + result);
        return (result);
    }
    
    
    // Send the registration email
    
    private boolean sendEmail (JtAccount account) {

        //JtMail mailAdapter;
        String message;

        
        if (account == null)
            return false;
        
        if (link == null) {
            handleError ("Attribute Link needs to be set. Update the Jt Resource File.");
            return false;
        }
        
        if (mailAdapter == null)
            mailAdapter = (JtMail) factory.createObject (JtMail.JtCLASS_NAME, "portalMailAdapter");
        
        if (mailAdapter == null)
            return (false);

        mailAdapter.setTo(account.getEmail());
        
        message = buildEmailMessage (account.getUsername());
        
        if (message == null) {
            handleError ("Invalid registration message");
            return false;
        }
        
        mailAdapter.setMessage(message);
        
        if (mailAdapter.getSubject() == null)
            mailAdapter.setSubject("Welcome to the Jt Portal");
        
        factory.sendMessage (mailAdapter, new JtMessage (JtObject.JtACTIVATE));
        
        if (propagateException (mailAdapter) != null) {
            return false;
        }
        
        // Remove mailAdapter
        
        factory.removeObject (mailAdapter);

        return true;
    }
    
    private boolean verifyName (String name) {
        int i;
        
        if (name == null)
            return (false);
        
        for (i = 0; i < name.length(); i++ ) {
            if (!Character.isLetterOrDigit(name.charAt(i)))
                return (false);
        }
        
        return true;
    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
    
    private void register (ActionForm form) {
        JtAccount account = new JtAccount ();
        String username;
        String password;
        String ePass;
        
        if (form == null) {
            handleError ("Invalid parameter value (null): form");
            return;
        }
        
        //userId = (String) factory.getValue(form, "userId"); // check log
        username = (String) factory.getValue(form, "username");
        
        // Just in case. useId and password should be required fields
        if (username == null || username.equals("")) {
            handleError ("Invalid username");
            return;
        }
    
        if (!verifyName (username)) {
            handleUIError ("Username can only contain letters and digits.");
            return;
        }
        
        password = (String) factory.getValue(form, "password");
        if (password == null || password.equals("")) {
            handleError ("Invalid password");
            return;
        }
             

        ePass = encryptPassword (password);
        
        
        if (ePass == null) {
            return;      
        }
        
        account.setUsername(username);
        account.setPassword(ePass);
        account.setEmail((String) factory.getValue(form, "email"));
        
        
        if (readAccount (username) != null) {
            handleUIError ("This username is already taken. Please try again.");
            return;
        }
            
        
        // Create Account
        
        if (!createAccount (account))
            return;

        
        account.setRegEmail(true);
        if (sendEmail (account)) {
            updateAccount (account);
            return;
        }    
        
        // Retry to send the email
        if (sendEmail (account)) {
            updateAccount (account);
            return;
        } 
        
    }
    

    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String data;
        //String content;
        //String attachment;
        ActionForm form = null;
        JtContext ctx;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
      
        
        if (!initted) {
            initialize ();
            initted = true;
        }
     
        //content = (String) e.getMsgContent ();

        ctx = (JtContext) e.getMsgContext();
        context = ctx;
        if (ctx != null)
            form = (ActionForm) ctx.getActionForm();  

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
                      
            register (form);            
            return (null);
        }
        
        return (super.processMessage(message));

    }



    
    
}
