package Jt.portal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;



public class Logout extends JtObject {

    
    private static final long serialVersionUID = 1L;
    private JtFactory factory = new JtFactory ();
    
         
    void logout (JtContext context) {
        HttpServletRequest request;
        HttpSession session;
        
        
        factory.handleTrace("logout");
        
        if (context == null) {
            handleError ("logout: invalid Jt context");
            return;
        }    
        
        request = context.getRequest();
        
        if (request == null)
            return;
        
        session = request.getSession();
        
        factory.handleTrace("logout (session):" + session);
        
        if (session == null)
            return;
 
        factory.handleTrace("logout: invalidate session: " + session.getId());
        session.invalidate();
               
        
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {

        JtContext context;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
      
        //content = (String) e.getMsgContent ();
        //data = (String) e.getMsgData ();
        //attachment  = (String) e.getMsgAttachment ();
        context = (JtContext) e.getMsgContext();
        //if (context != null)
        //    form = (ActionForm) context.getActionForm();  

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
                       
            logout (context);
            
            return (null);
        }
        
        return (super.processMessage(message));

    }

    
    
}
