 package Jt.portal;


import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
import Jt.*;
//import Jt.DAO.FileForm;
import Jt.wizard.Upload;
import Jt.wizard.struts.form.UploadForm;

//import Jt.wizard.struts.DAODefinitionForm;
//import Jt.wizard.struts.FileForm;



/**
 * Photo (JtWizard internal class).
 */

public class Photo extends JtObject {
    public static final String JtCLASS_NAME = Photo.class.getName(); 
    public static final String JtUPLOAD = "JtUPLOAD";
    //public static final String NEW = "NEW";
    //public static final String GET_IMAGE_TAG = "GET_IMAGE_TAG";
    public static final String PHOTO_FILENAME = "profilePhoto";
    public static final String RETRIEVE_PHOTO = "RETRIEVE_PHOTO";
    public static final String DEFAULT_PATH = "../jtRoot/defaultPhoto.gif";
    
    private static final long serialVersionUID = 1L;
    private JtFactory factory = new JtFactory ();
    private String targetPath;
    private String absoluteTargetPath;
    private String username = null;
    private String rootPath = "../jtRoot";
    private boolean exists;
    //private boolean jpeg = false;
    private String webPath = "";
    private String imageTag; // being deprecated
    private String extension = null;
    private int width = 100;
    private int height = 125;
    private String photoFilename;
    private boolean implicitUsername;
    private transient JtContext context;
    
    

    public Photo() {
    }

    // Attributes


    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    
    public boolean isImplicitUsername() {
        return implicitUsername;
    }

    public void setImplicitUsername(boolean implicitUsername) {
        this.implicitUsername = implicitUsername;
    }

    public boolean isExists() {
        return exists;
    }

    public void setExists(boolean exists) {
        this.exists = exists;
    }

    public String getRootPath() {
        return rootPath;
    }

    public void setRootPath(String rootPath) {
        this.rootPath = rootPath;
    }

    public String getPhotoFilename() {
        return photoFilename;
    }

    public void setPhotoFilename(String photoFilename) {
        this.photoFilename = photoFilename;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getImageTag() {
        return imageTag;
    }

    public void setImageTag(String imageTag) {
        this.imageTag = imageTag;
    }

    /*
    public boolean isJpeg() {
        return jpeg;
    }

    public void setJpeg(boolean jpeg) {
        this.jpeg = jpeg;
    }
    */

    /*
    public boolean isExists() {
        return exists;
    }

    public void setExists(boolean exists) {
        this.exists = exists;
    }
    */

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }


    private Exception propagateException (JtObject obj) {
        if (obj == null)
            return (null);

        if (obj.getObjException() != null)
            this.setObjException(obj.getObjException());

        return ((Exception) obj.getObjException ());

    }
    
    private String concatenatePath (String path, String subpath) {
        char separator = File.separatorChar;


        if (path == null)
            return null;
        if (subpath == null)
            return path;


        return (path + separator + subpath);

    }
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);


    }
 /*   
    private String determineFileExtension (String name) 
    {
        if (name == null)
            return null;
        

        if (name.toLowerCase().endsWith(".jpg"))
            return ("jpg");
        
        if (name.toLowerCase().endsWith(".gif"))
            return ("gif");
        
        return (null);
       
    }
*/    
    private String determineTargetPath (String filename) {
        
        if (filename == null) {
            return (null);
        }
        
        if (username == null || username.equals("")) {
            handleError ("Username attribute needs to be set.");
            return (null);           
        }
        
        return (concatenatePath (rootPath, "home" +  File.separatorChar + username + 
                File.separatorChar + filename));
                
        
    }
    
    private String determineHttpTargetPath (String filename) {
        
        if (filename == null) {
            return (null);
        }
        
        if (username == null || username.equals("")) {
            handleError ("Username attribute needs to be set.");
            return (null);           
        }
        
        return (rootPath + '/' + "home" +  '/' + username + 
                '/' + filename);
                
        
    }
    
    private String determineAbsoluteTargetPath (String filename) {
        String dirName;
       
        if (filename == null || rootPath == null) {
            return (null);
        }
        
        if (username == null || username.equals("")) {
            handleError ("Username attribute needs to be set.");
            return (null);           
        }
       
        if (rootPath.startsWith ("../"))
            dirName = rootPath.substring(3);
        else
            dirName = rootPath;
            
        return (concatenatePath (webPath + File.separatorChar + dirName, "home" +  File.separatorChar + username + 
                File.separatorChar + filename));
            
                
        
    }  
    
    private String retrieveExtension (String filename) {
        String lfilename;
        
        if (filename == null)
            return (null);
        
        lfilename = filename.toLowerCase();
        
        if (lfilename.endsWith(".jpg"))
            return (".jpg");
        
        if (lfilename.endsWith(".jpeg"))
            return (".jpeg");
        
        if (lfilename.endsWith(".gif"))
            return (".gif");   
        
        if (lfilename.endsWith(".png"))
            return (".png");  
        
        return (null);
    }

    
    private boolean removeOldPhoto (String oldExt) {
        String path;
        JtFile file = new JtFile ();

        if (oldExt == null)
            return (false);
        
        if (photoFilename == null)
            return (false);
                    
        path = determineAbsoluteTargetPath (photoFilename + oldExt);
        
        file.setPath(path);
        
        factory.sendMessage(file, new JtMessage (JtFile.JtDELETE));
        
        if (propagateException (file) != null)
            return (false);
        
        return (true);

    }
    
    
    private boolean checkPermissions (String username) {
        String currentUser;
        
        if (username == null || username.equals (""))
            return (false);
        
        currentUser = context.getUserName();
        if (currentUser == null) {
            return (false);
        }
        
        if (currentUser.equals("admin")) {
            return (true);
        }
        
        if (username.equals(currentUser))
            return (true);
        
        return (false);                
        
    }
    
    private UploadForm upload (UploadForm dform) {

        FormFile theFile;
        InputStream inputStream = null;
        Upload upload = new Upload ();
        String ext, oldExt;
        UploadForm form = new UploadForm ();

/*
        if (dform == null) {
            return (null);            
        }
*/
        
        if (dform == null || dform.getUsername() == null) {
            handleUIError ("invalid form object"); // this should not happen
            return (null);            
        }
        
        username = dform.getUsername();

        theFile = dform.getTheFile();

        handleTrace ("upload:" + theFile.getFileName());

        if (theFile == null || (ext = retrieveExtension (theFile.getFileName())) == null) {
            handleUIError ("File must be an image file (Jpeg, Gif or Png).");
            return (null);
        }
        
        if (dform.getFilename() == null) {
            handleUIError ("invalid form object."); // this should not happen
            return (null);
        }
        
        if (!checkPermissions (username)) {
            handleUIError ("Access denied."); 
            return (null);            
        }
        
        photoFilename = dform.getFilename();
        
        oldExt = checkExistence ();
        
        absoluteTargetPath = determineAbsoluteTargetPath (photoFilename + ext );
       
        if (absoluteTargetPath == null) {
            handleError ("Invalid target path: null.");
            return (null);
        }

        try {
            inputStream = theFile.getInputStream();
        } catch (Exception e) {
            handleException (e);
        }

        if (inputStream == null) {
            handleError ("inputStream is null.");
            return (null);
        }    

        
        upload.setInputStream(inputStream);
        upload.setTargetPath(absoluteTargetPath);
        
        factory.sendMessage(upload, new JtMessage (JtObject.JtACTIVATE));
        
        if (propagateException (upload) != null)
            return (null);
        
        targetPath = determineTargetPath (photoFilename + ext);  
        
        imageTag = calculateImageTag (targetPath);
        
        
        form.setImageTag(imageTag);
        form.setFilename (photoFilename);
        form.setTargetPath(targetPath);
        form.setUsername(username);
        
        if (oldExt == null || ext.equals(oldExt))
            return (form);

        if (!removeOldPhoto (oldExt))
            return (null); // check
        
        return (form);
        
    }

/*
    public UploadForm newForm () {
        UploadForm form = new UploadForm ();
        
        //form.setTargetPath("/temp/kk.gif");
        
        return (form);
        
        
    }
*/
    
    private String checkExistence () {
        String path;
        File file;

        if (photoFilename == null)
            return (null);
        
        path = determineAbsoluteTargetPath (photoFilename + ".jpg");
        file = new File (path);
        if (file.exists ()) {
            return (".jpg");
        }  
        
        path = determineAbsoluteTargetPath (photoFilename+ ".jpeg");
        file = new File (path);
        if (file.exists ()) {
            return (".jpeg");
        }  
        
        path = determineAbsoluteTargetPath (photoFilename + ".gif");
        file = new File (path);
        if (file.exists ()) {
            return (".gif");
        }     
        
        path = determineAbsoluteTargetPath (photoFilename+ ".png");
        file = new File (path);
        if (file.exists ()) {
            return (".png");
        }          
        
        return (null);

    }
    
    private String calculateImageTag (String targetPath) {

        if (targetPath == null) 
            return (null);
        
        
        
        if (width <= 0 || height <= 0)
            return (imageTag = "<img src=\"" + targetPath + "\" />");
        else
            return (imageTag = "<img src=\"" + targetPath + "\" width=\"" + width + "\" height=\"" +
                    height + 
                    "\" />");           
    }
    
    private UploadForm readObject () {
        
        UploadForm form = new UploadForm ();
        
        if (username == null || photoFilename == null)
            return (null);
        
        extension = checkExistence ();
        
        if (extension == null) {
            
            exists = false;
            extension = ".jpg";
            targetPath = determineHttpTargetPath (photoFilename + extension);  
            
            imageTag = ""; // Change to Photo frame
            
            form.setImageTag(imageTag);
            form.setFilename (photoFilename);  
            form.setUsername(username);
            form.setTargetPath(null);
            
            return (form);
        } else
            exists = true;
        
        targetPath = determineHttpTargetPath (photoFilename + extension);  
        
        imageTag = calculateImageTag (targetPath);
        
        form.setImageTag(imageTag);
        form.setFilename (photoFilename);
        form.setUsername(username);
        form.setTargetPath(targetPath);
        //handleTrace ("readObject returns ..." + this);
        return (form);
    }
    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        //Object data;
        HttpServletRequest request;
        //JtContext context;
        ActionForm form = null;
        ServletContext sContext;
        Object reply;



        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;



        context = (JtContext) msg.getMsgContext();
        if (context != null) {
            form = (ActionForm) context.getActionForm();
            //username = context.getUserName(); //check
            sContext = (ServletContext) context.getServletContext();
            if (sContext == null) {
                handleError ("Invalid ServletContext. You may need to log in.");
                return (null);
            }
            webPath = sContext.getRealPath("/"); //check
            handleTrace ("webPath:" + webPath); 
        }
        
        if (context == null || context.getUserName() == null) {
            handleError ("Invalid context. Please log in.");
            return (null);
        }
        
        //photoFilename = PHOTO_FILENAME;


       
        // Upload file
        
        if (msgid.equals(JtObject.JtUPDATE)) {

            // pass the form information   
            //data = msg.getMsgData ();           

            reply = upload ((UploadForm) form);
            
            //if (reply != null)
            //    return (reply);

            // An error has been dectected. The universal action
            // won't add the jtReply to the request. We need
            // to add it manually.

            /*
            request = context.getRequest();
            
            if (request == null) {
                handleError ("Invalid context. You may need to log in.");
                return (null);
            }
            request.setAttribute("jtReply", readObject ());
            */
            
            return (reply);
        }

        if (msgid.equals(JtObject.JtREAD)) {
          
            photoFilename = (String) msg.getMsgContent();
            
            if (isImplicitUsername ())
                username = context.getUserName();
            else                
                username = (String) msg.getMsgData();
            
            if (photoFilename == null || photoFilename.equals("")) {
                handleError ("Invalid Photo filename.");
                return (null);
            }    
            
            return (readObject ());
        }

        
        if (msgid.equals(Photo.RETRIEVE_PHOTO)) {
            
            
            //photoFilename = (String) msg.getMsgContent();
            
            photoFilename = (String) msg.getMsgContent();

            username = (String) msg.getMsgData(); // check
            
            if (photoFilename == null || photoFilename.equals("")) {
                handleError ("Invalid Photo filename.");
                return (null);
            }    
            
            readObject ();
            return (this);
        }
        

        // Let the superclass handle all other messages
        return (super.processMessage (message));


    }




    /**
     * Demonstrates the messages processed by this class.
     */

    /*
    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        //String reply;
        Upload upload;

        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
        InputStream istream = null;


        try {
            istream = 
                new FileInputStream ("");
        } catch (Exception e) {
            e.printStackTrace ();
            System.exit (1);
        }

        msg.setMsgData(istream);

        upload = (Upload) factory.createObject (Upload.JtCLASS_NAME);
        factory.sendMessage (upload, msg);


    }
     */

}



