package Jt.portal;

import Jt.JtBridge;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;

public class PaymentBridge extends JtBridge {
    

    private static final long serialVersionUID = 1L;
    private String implementorClassName = PaypalAdapter.JtCLASS_NAME;
    private boolean init = false;
    public static final String JtCLASS_NAME = PaymentBridge.class.getName(); 
    public static final String DIRECT_PAYMENT = "DIRECT_PAYMENT"; 
    
    
    
    public PaymentBridge () {
        
    }
    
    public String getImplementorClassName() {
        return implementorClassName;
    }

    public void setImplementorClassName(String implementorClassName) {
        this.implementorClassName = implementorClassName;
    }

    
    private void initialize () {

        JtFactory factory = new JtFactory ();

        if (implementor == null) {

            if (implementorClassName == null) {
                handleError ("implementorClassName attribute must be set");   
                return;
            }
            implementor = factory.createObject(implementorClassName);
        }     
        
    }
    
    // Propagate UI errors. obj needs to be an instance
    // of JtObject
    
    private void propagateUiErrors (JtObject obj) {
        if (obj == null)
            return;
        
        if (obj.getObjErrors() != null)
            this.setObjErrors(obj.getObjErrors ());
        
    }
    
    private Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }

    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;

        Object reply;
        JtMessage msg;
        //Object obj;
        //Boolean Bool;
        //JtContext jtContext;
        //String userName;
        

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (!init) {
            initialize ();     
            init = true;
        }
        


        // Let the implementor process the message
        
        reply = super.processMessage (message);
        
        if (implementor != null) {
            propagateException (implementor);  
            propagateUiErrors ((JtObject) implementor); // check
        }
        
        return (reply);

    }

}
