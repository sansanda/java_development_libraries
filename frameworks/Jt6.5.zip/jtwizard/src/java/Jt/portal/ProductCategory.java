package Jt.portal;



public class ProductCategory  {



    public static final String JtCLASS_NAME = ProductCategory.class.getName(); 

    
    private static final long serialVersionUID = 1L;

    private String categoryId;
    private String description;
   
    
    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
 
    
 
    


}