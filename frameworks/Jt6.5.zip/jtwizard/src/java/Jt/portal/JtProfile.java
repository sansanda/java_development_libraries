package Jt.portal;

import java.util.Date;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.portal.form.ProfileForm;
import Jt.wizard.struts.CRUD;
import Jt.wizard.struts.view.JspGenerator;


public class JtProfile extends JtObject {
  public static final String JtCLASS_NAME = JtProfile.class.getName(); 
  public static final String NEW = "NEW";
  public static final String READ_MY_PROFILE = "READ_MY_PROFILE";
  //private String userId;
  private String username;  
  private String firstname;
  private String lastname;
  private int status;
  private String address;
  private String address1;
  private String state;
  private String city;
  private String zip;
  private String country;
  private String phone;
  private boolean emailFlag;
  
  transient JtContext context = null;
  transient JtFactory factory = new JtFactory ();
  //private transient JtDAOStrategy daoAdapter = new JtDAOStrategy ();
  transient JtDAOStrategy daoAdapter = null;
  private transient CRUD crudObj;
  private boolean initted = false;

/*
  public String getUserId() {
      return userId;
  }

  public void setUserId(String userId) {
      this.userId = userId;
  }
*/
  
  public String getUsername() {
      return username;
  }

  public void setUsername(String username) {
      this.username = username;
  }

  public String getFirstname() {
      return (firstname);
  }

  public void setFirstname(String firstname) {
      this.firstname=firstname;
  }

  public String getLastname() {
      return (lastname);
  }

  public void setLastname(String lastname) {
      this.lastname=lastname;
  }

  public int getStatus() {
      return (status);
  }

  public void setStatus(int status) {
      this.status=status;
  }

  public String getAddress1() {
      return (address1);
  }

  public void setAddress1(String address1) {
      this.address1=address1;
  }

  public String getAddress() {
      return (address);
  }

  public void setAddress(String address) {
      this.address=address;
  }

  public String getState() {
      return (state);
  }

  public void setState(String state) {
      this.state=state;
  }

  public String getCity() {
    return city;
}

public void setCity(String city) {
    this.city = city;
}

public String getZip() {
      return (zip);
  }

  public void setZip(String zip) {
      this.zip=zip;
  }

  public String getCountry() {
      return country;
  }

  public void setCountry(String country) {
      this.country = country;
  }
  
  public String getPhone() {
      return phone;
  }

  public void setPhone(String phone) {
      this.phone = phone;
  }

  public boolean isEmailFlag() {
      return emailFlag;
  }

  public void setEmailFlag(boolean emailFlag) {
      this.emailFlag = emailFlag;
  }

  private Exception propagateException (JtObject obj) {
      
      if (obj == null)
          return (null);
      
      if (obj.getObjException() != null) {
          this.setObjException(obj.getObjException());
      }  
      return ((Exception) obj.getObjException());
  }
  
  private ProfileForm myProfile () {
      String username;
      
      if (context == null) {
          handleError ("Invalid Jt Context. Please Log in");
          return (null);
      }
      
      username = context.getUserName();
      
      if (username == null) {
          handleError ("Invalid Jt Context. Please Log in");
          return (null);
      }  
      
      return (retrieveProfile (username));
      
  }
  
  

 /*
  private JtProfile retrieveProfile (String userId) { // Check security
      JtProfile profile;
      JtMessage msg = new JtMessage (JtObject.JtREAD);
      
      if (userId == null)
          return (null);
      
      daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
      msg.setMsgContent(new JtProfile ());
      
      msg.setMsgData (userId);
      msg.setMsgContext(context);
      
      profile = (JtProfile) factory.sendMessage(daoAdapter, msg);
      
      propagateException (daoAdapter);
      
      factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
      
      return (profile);
  }
*/
  
  private ProfileForm retrieveProfile (String userId) { // Check security
      ProfileForm form;
      JtMessage msg = new JtMessage (JtObject.JtREAD);
      
      if (userId == null)
          return (null);
      
      crudObj = (CRUD) factory.createObject(CRUD.JtCLASS_NAME);
      
      crudObj.setClassname(JtProfile.JtCLASS_NAME);
      msg.setMsgId(JtObject.JtREAD);
      context.setActionForm(new ProfileForm ());
      msg.setMsgContext(context); // Pass the contex
      msg.setMsgContent(userId);
      crudObj.setKey("username");
      
      
      form = (ProfileForm) factory.sendMessage(crudObj, msg);
      
      if (propagateException (crudObj) != null)
          return (null);

      // Remove Object
      
      
      return (form);
  }
  
  private ProfileForm newProfile (String username) {
      ProfileForm form = new ProfileForm ();
      

      
      if (username == null) {
          handleError ("Invalid link");
          return (null);
      }
      form.setUsername(username);
      
      return (form);
      
  }
  
  
  
  
  private void createProfile (ProfileForm form) {
      
      JtMessage msg = new JtMessage (JtObject.JtCREATE);
      CRUD crudObject;
      JtAccount account = new JtAccount ();
      String username;
      
      if (form == null) {
          handleError ("Invalid form:" + form);
          return;
      }
      
      username = form.getUsername();
      
      // Create the Profile DAO (Let CRUD accomplish this task)
      
      crudObject = (CRUD) factory.createObject(CRUD.JtCLASS_NAME);
            
      crudObject.setClassname(JtProfile.JtCLASS_NAME);
      msg.setMsgId(JtObject.JtCREATE);
      msg.setMsgContext(context); // Pass the context
      
      factory.sendMessage(crudObject, msg);
      
      if (propagateException (crudObject) != null)
          return;
      
      msg = new JtMessage (JtAccount.ACTIVATE_ACCOUNT);
      msg.setMsgContent(username);
      factory.sendMessage(account, msg);
      
      propagateException (account);
      
  }
  
  private void initialize () {
      daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
      //adapter.setCheckAccess(true);     
  }
  
  // Process object messages

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage msg = (JtMessage) message;
      ActionForm form = null;


      if (msg == null)
          return null;

      msgid = (String) msg.getMsgId ();

      if (msgid == null)
          return null;
      
      if (!initted) {
          initialize ();
          initted = true;
      }

      context = (JtContext) msg.getMsgContext();
      
      if (context != null)
          form = (ActionForm) context.getActionForm();  

      // Store the Profile and Activate the user account
      
      if (msgid.equals (JtObject.JtCREATE)) {

          createProfile ((ProfileForm) form);
          return (null);
      }
      
      // New Profile
      
      if (msgid.equals (JtProfile.NEW)) {

          return (newProfile ((String) msg.getMsgContent()));
      }
      
      if (msgid.equals (JtProfile.READ_MY_PROFILE)) {

          return (myProfile ());
      }

      // Let the superclass handle all other messages
      return (super.processMessage (message));

  }
}
