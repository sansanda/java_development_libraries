// Implementation of the Jt Messaging Design Pattern
// JavaScript Core Jt Objects
// Copyright Jt Framework



// JtMessage

function JtMessage (msgId) {

   // Attributes
   this.msgId = msgId;  
   this.msgContent = null;
   this.msgData = null; 
   this.msgAttachment = null;

}

// JtFactory

function JtFactory () {


   // Send a Jt Message

   this.sendMessage = function (obj, msg) {
      return (obj.processMessage (msg));
   }

}



// Jt Ajax Adapter. Submits the AJAX request.

function JtAjaxAdapter () {

   // Attributes

   this.url = null;         // url that should serve the AJAX request
   this.formName = null;    // a HTML form may be passed as part of the AJAX request
   this.callback = null;    // callback provided by the user to process the reply
   this.operation = "POST"; // POST or GET request
   this.className = null; // delegate class

   // Request object
 
   if (window.XMLHttpRequest) {
     this.request = new XMLHttpRequest ();

   }
   else if (window.ActiveXObject) {
     this.request = new ActiveXObject ("Microsoft.XMLHTTP");
   }

  // Convert a form to its String representation

  function convertFormToString(formName){
        
    //Setup the return String
    returnString ="";
    var cnt = 0;
        
    //Get the form values
    formElements=document.forms[formName].elements;
        
    //loop through the array
 
    for (var i=0; i < formElements.length; i++) {

        
    //for(var i=formElements.length-1;i>=0; --i ){
        //we escape (encode) each value

        if (formElements[i].type == "button"
            || formElements[i].type == "reset" 
            || formElements[i].type == "submit")
          continue;

        if (cnt != 0)
          returnString+="&"; 
        
        returnString += (escape(formElements[i].name)+"=" 
        +escape(formElements[i].value));
        cnt++;
   }
        
   //return the values
   return returnString; 
  }


   // Invoke Ajax request

   this.invokeAjaxRequest = function (msg) {

   var params;
   var getUrl;

   params = 'msgId=' + msg.msgId;


   // Messaging information

   if (msg.msgContent != null) {
      params += '&' + 'msgContent=' + msg.msgContent;
   } 

   if (msg.msgData != null) {
      params += '&' + 'msgData=' + msg.msgData;
   } 

   if (msg.msgAttachment != null) {
      params += '&' + 'msgAttachment=' + msg.msgAttachment;
   } 

   if (this.className != null) {
      params += '&' + 'jtClassName=' + this.className;
   } 

   if (this.formName != null) {
      params += '&' + convertFormToString (this.formName);
   } 

   // Get

   if (this.operation == 'GET') {
      getUrl = this.url + '?' + params;
      this.request.open ("GET", getUrl, true);
      this.request.onreadystatechange = this.callback;
      //window.alert (getUrl);

      this.request.send (null);
      return (false);
   }

   // Post

   this.request.open ("POST", this.url, true);
   this.request.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");

   this.request.setRequestHeader("Content-length", params.length);
   //lreq.setRequestHeader("Connection", "close");   
   this.request.onreadystatechange = this.callback;

     
   this.request.send (params);

   //return (lreq);
   return (false);

   }

   // Process Jt Messages

   this.processMessage = function (msg) {

        return (this.invokeAjaxRequest (msg));


   }

}




 
  // Add a row to the table

  function jtAddTableRow (arrayName, maxRows) {


     //var maxRows = 50;
     //var table = document.getElementById ('table');
     var tblBody = document.getElementById ("jtTBodyId");
     var lastRow = tblBody.getElementsByTagName("tr").length;
     var tdElem;
     var field = null;
     //var attrs;
     var str;
     var str1;
     var children;


     //window.alert (lastRow);
     //window.alert (tblBody);


     if (lastRow < 1)
         return;

     //var newNode = table.rows[0].cloneNode(true);
     var newNode = tblBody.rows[0].cloneNode(true);
     var fields = newNode.getElementsByTagName ("td");

     //field.setAttribute ("name", "mappings[" + lastRow + "].name" );

     if (lastRow >= maxRows) {
         window.alert ("The maximun number of attributes has been exceeded."); 
         return;
     }

     //window.alert (fields.length); 


     //var cnt = fields.length;

     for (var i = 0; i < fields.length; i++) {

       //window.alert (i); 
       tdElem = fields.item (i);


       //var strx =  tdElem.innerHTML.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");


       //field = tdElem.firstChild;
       children = tdElem.childNodes;

       for (var j=0; j < children.length; j++) {
          field = children[j];


          if (field.nodeType == 1)
             break;          
       }
       

       if (field == null)
         continue;

       if (field.nodeType != 1) 
          continue;

       //attrs = field.attributes;
       //window.alert (strx); 

       //if (field.hasAttribute ("name"))

       str = field.getAttribute ('name');

       str1 =  str.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");
       field.setAttribute ("name", str1);

       //window.alert (newNode.innerHTML); 
       //window.alert (str1); 
       //window.alert (field.getAttribute ('name')); 
       //window.alert (i + ":" + cnt); 
       
     }
     
             tblBody.appendChild(newNode);
  }


 function jtAddTableRowOld (arrayName) {


     var maxRows = 50;
     var table = document.getElementById ('table');
     var lastRow = document.getElementById('table').getElementsByTagName('tr').length;


     //window.alert (arrayName);


     if (lastRow < 1)
         return;

     var newNode = table.rows[0].cloneNode(true);


     if (lastRow >= maxRows) {
         window.alert ("The maximun number of attributes has been exceeded."); 
         return;
     }


     var str =  newNode.innerHTML.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");
     
     
     window.alert (str); 

     table.appendChild (newNode);  

     //table.innerHTML += str;


     //var newItem = oldItem.cloneNode (true);
     //var str =  newNode.innerHTML.replace ("/\[0\]/", "[" + lastRow + "]");

     //var lastRow = table.rows.length;

     //var oldItem = table.firstChild;
     //var newNode = oldItem.cloneNode (true);

     //var iteration = lastRow;
     // creates a new row
     //var row = table.insertRow(lastRow);
     //var row = document.createElement ("tr");
     //var td = document.createElement ("td");
     //var inp = document.createElement ("input");

     //inp.setAttribute ("type", "text" );
     //inp.setAttribute ("name", "dbmappings[" + lastRow + "].attribute" );
     //inp.setAttribute ("value", "new" );

     //td.appendChild (inp);
     //row.appendChild (td); 
     //table.appendChild (row);
     //table.appendChild (newNode);

     //var newItem = document.createElement ("tr");
     //var newItem1 = document.createElement ("td");
     //newItem.appendChild (newItem1);

     //table.appendChild (newItem);
     //table.innerHTML += "<tr><td><input type=\"checkbox\" name=\"dbmappings[10].keyAttribute\" value=\"on\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].attribute\" value=\"location1\" readonly=\"readonly\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].column\" value=\"location1\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].sql_type\" value=\"\"></td>"
     //+  "<td><input type=\"checkbox\" name=\"dbmappings[10].notNull\" value=\"on\"></td>"
     //+  "<td><input type=\"checkbox\" name=\"dbmappings[10].unique\" value=\"on\"></td>"
     //+ "<td><input type=\"checkbox\" name=\"dbmappings[10].enabled\" value=\"on\" checked=\"checked\"></td>";
  }









