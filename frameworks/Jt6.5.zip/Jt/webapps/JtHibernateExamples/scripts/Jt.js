
 

  function jtAddTableRow (arrayName, maxRows) {


     //var maxRows = 50;
     var table = document.getElementById ('table');
     var tblBody = document.getElementById ('table');
     var lastRow = document.getElementById('table').getElementsByTagName('tr').length;
     //var tr = document.createElement ("tr");
     var tdElem;
     var field = null;
     //var attrs;
     var str;
     var str1;
     var childdren;

     //window.alert (arrayName);


     if (lastRow < 1)
         return;

     //var newNode = table.rows[0].cloneNode(true);
     var newNode = tblBody.rows[0].cloneNode(true);
     var fields = newNode.getElementsByTagName ("td");

     //field.setAttribute ("name", "mappings[" + lastRow + "].name" );

     if (lastRow >= maxRows) {
         window.alert ("The maximun number of attributes has been exceeded."); 
         return;
     }

     //window.alert (fields.length); 


     //var cnt = fields.length;

     for (var i = 0; i < fields.length; i++) {

       //window.alert (i); 
       tdElem = fields.item (i);


       //var strx =  tdElem.innerHTML.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");


       //field = tdElem.firstChild;
       children = tdElem.childNodes;

       for (var j=0; j < children.length; j++) {
          field = children[j];


          if (field.nodeType == 1)
             break;          
       }
       

       if (field == null)
         continue;

       if (field.nodeType != 1) 
          continue;

       //attrs = field.attributes;
       //window.alert (strx); 

       //if (field.hasAttribute ("name"))

       str = field.getAttribute ('name');

       str1 =  str.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");
       field.setAttribute ("name", str1);

       //window.alert (newNode.innerHTML); 
       //window.alert (field.getAttribute ('name')); 
       //window.alert (i + ":" + cnt); 
       
     }
      
 


     //var str =  newNode.innerHTML.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");
     
     
     //window.alert (str); 

     //tr.appendChild (newNode);

     //table.appendChild (newNode);  
     tblBody.appendChild(newNode);
     //tblBody.appendChild(tr);


     //window.alert (tblBody.innerHTML); 

     //table.innerHTML += str;
     //table.innerHTML += "";


     //var row = document.createElement ("tr");
     //var td = document.createElement ("td");
     //var inp = document.createElement ("input");

     //inp.setAttribute ("type", "text" );
     //inp.setAttribute ("name", "mappings[" + lastRow + "].name" );
     //inp.setAttribute ("value", "new" );

     //td.appendChild (inp);
     //row.appendChild (td); 
     //tblBody.appendChild (row);

     //window.alert (newNode.innerHTML); 


  }


 function jtAddTableRowOld (arrayName) {


     var maxRows = 50;
     var table = document.getElementById ('table');
     var lastRow = document.getElementById('table').getElementsByTagName('tr').length;


     //window.alert (arrayName);


     if (lastRow < 1)
         return;

     var newNode = table.rows[0].cloneNode(true);


     if (lastRow >= maxRows) {
         window.alert ("The maximun number of attributes has been exceeded."); 
         return;
     }


     var str =  newNode.innerHTML.replace (arrayName + "\[0\]", arrayName + "[" + lastRow + "]", "g");
     
     
     window.alert (str); 

     table.appendChild (newNode);  

     //table.innerHTML += str;


     //var newItem = oldItem.cloneNode (true);
     //var str =  newNode.innerHTML.replace ("/\[0\]/", "[" + lastRow + "]");

     //var lastRow = table.rows.length;

     //var oldItem = table.firstChild;
     //var newNode = oldItem.cloneNode (true);

     //var iteration = lastRow;
     // creates a new row
     //var row = table.insertRow(lastRow);
     //var row = document.createElement ("tr");
     //var td = document.createElement ("td");
     //var inp = document.createElement ("input");

     //inp.setAttribute ("type", "text" );
     //inp.setAttribute ("name", "dbmappings[" + lastRow + "].attribute" );
     //inp.setAttribute ("value", "new" );

     //td.appendChild (inp);
     //row.appendChild (td); 
     //table.appendChild (row);
     //table.appendChild (newNode);

     //var newItem = document.createElement ("tr");
     //var newItem1 = document.createElement ("td");
     //newItem.appendChild (newItem1);

     //table.appendChild (newItem);
     //table.innerHTML += "<tr><td><input type=\"checkbox\" name=\"dbmappings[10].keyAttribute\" value=\"on\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].attribute\" value=\"location1\" readonly=\"readonly\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].column\" value=\"location1\"></td>"
     //+ "<td><input type=\"text\" name=\"dbmappings[10].sql_type\" value=\"\"></td>"
     //+  "<td><input type=\"checkbox\" name=\"dbmappings[10].notNull\" value=\"on\"></td>"
     //+  "<td><input type=\"checkbox\" name=\"dbmappings[10].unique\" value=\"on\"></td>"
     //+ "<td><input type=\"checkbox\" name=\"dbmappings[10].enabled\" value=\"on\" checked=\"checked\"></td>";
  }
