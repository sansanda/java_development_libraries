/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.JAAS;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

public class JtCallbackHandler implements CallbackHandler {

	private String username;
	private char password[];
	//private Object loginStrategy; 


	public JtCallbackHandler (String username, char password[]) {
		this.username = username;
		this.password = password;
		
	}
	
	/*
	public Object getLoginStrategy() {
		return loginStrategy;
	}

	public void setLoginStrategy(Object loginStrategy) {
		this.loginStrategy = loginStrategy;
	}
    */
	
	public void handle(Callback[] callbacks)
	throws UnsupportedCallbackException {
		
		

		for (int i = 0; i < callbacks.length; i++) {
			if (callbacks[i] instanceof NameCallback) {

				NameCallback nc = (NameCallback)callbacks[i];

				nc.setName(username);

			} else if (callbacks[i] instanceof PasswordCallback) {

				PasswordCallback pc = (PasswordCallback)callbacks[i];

				pc.setPassword(password);

			} else {
				throw new UnsupportedCallbackException
				(callbacks[i], "Unrecognized Callback");
			}
		}
	}






}
