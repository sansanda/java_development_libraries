
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.JAAS;

//import javax.security.auth.Subject;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;


/**
 * JAAS Adapter.
 */


public class JtJAASAdapter extends JtObject {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtJAASAdapter.class.getName(); 
  public static final String JtLOGIN = "JtLOGIN";
  public static final String JtLOGOUT = "JtLOGOUT";
  JtFactory factory = new JtFactory ();
  private String name = "Jt";
  private String username;
  private String password;
  private LoginContext loginContext = null;
  //private Object loginStrategy;
  
  
  //private JtLoginModule loginModule;
  
  public JtJAASAdapter() {
  }
  
  public String getName() {
	  return name;
  }


  public void setName(String name) {
	  this.name = name;
  }



  public String getUsername() {
	  return username;
  }


  public void setUsername(String username) {
	  this.username = username;
  }



  public String getPassword() {
	  return password;
  }


  public void setPassword(String password) {
	  this.password = password;
  }




  /*
  private boolean initialize () {

	  
	  loginModule = (JtLoginModule) factory.createObject (JtLoginModule.JtCLASS_NAME);
	  
	  return (true);
  }
  */
  

  
  public LoginContext getLoginContext() {
	  return loginContext;
  }

  public void setLoginContext(LoginContext loginContext) {
	  this.loginContext = loginContext;
  }

private boolean login () {
	  //JtMessage msg = new JtMessage (JtJAASAdapter.JtLOGIN);
	  //LoginContext loginContext;
	  //Subject subject;
	  JtCallbackHandler callbackHandler;
	  
	  if (name == null) {
		  handleError ("Invalid name attribute (null).");
		  return (false);
	  }
	  
	  if (username == null) {
		  handleError ("Invalid username attribute  (null).");
		  return (false);
	  }
	  
	  if (password == null) {
		  handleError ("Invalid password attribute  (null).");
		  return (false);
	  }
	  
	  callbackHandler = new JtCallbackHandler (username, password.toCharArray());
	  //callbackHandler.setLoginStrategy(loginStrategy);
	  
	  try {
		  loginContext = new LoginContext (name, callbackHandler);
		  
		  loginContext.login();
		  
		  //TODO 
		  //subject = loginContext.getSubject ();
		  //System.out.println(subject);
	  } catch (FailedLoginException ex) {

		  return (false);
	  }		  
		  
	  catch (Exception ex) {

		  handleException (ex);
		  return (false);
	  }
	  
	  
	  return (true);
  }
  
  
  private boolean logout () {
	  
	  if (loginContext == null) {
		  handleError ("Invalid login context (null).");
		  return (false);
	  }
	
	  try {
		  loginContext.logout();
	  } catch (LoginException e) {

		  return (false);
	  }
	  
	  return (true);
  }
  
  /**
   * Process object messages.
   * <ul>
   * </ul>
   */

  public Object processMessage (Object message) {
      JtMessage e = (JtMessage) message;
      
      String msgid;

      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;

      
      if (msgid.equals (JtJAASAdapter.JtLOGIN))    	  
    	  return new Boolean (login ());
      
      if (msgid.equals (JtJAASAdapter.JtLOGOUT))    	  
    	  return new Boolean (logout ());
      
      
      handleError ("Invalid message Id:" + msgid);

      return (null);

  }



  /**
    * Demonstrates the messages processed by JtAASAdapter.   
    */

  public static void main(String[] args) {
	JtMessage msg = new JtMessage (JtJAASAdapter.JtLOGIN);
    JtFactory factory = new JtFactory ();
    JtJAASAdapter adapter;
    Boolean Bool;
    LoginContext context;


    // Create an instance of JtJAASAdapter

    adapter = (JtJAASAdapter)
    factory.createObject (JtJAASAdapter.JtCLASS_NAME);
    
    //adapter.setName("Sample");
    
    // Set username & password
    
    adapter.setUsername("jt");
    adapter.setPassword("messaging");
    
    // Try to log in
    
    Bool = (Boolean) factory.sendMessage(adapter, msg);
    
    if (Bool == null || !Bool.booleanValue())
    	System.out.println("JtLOGIN: fail");
    else {
    	System.out.println("JtLOGIN: pass");
    	
    	context = adapter.getLoginContext();

		if (context != null)
			System.out.println(context.getSubject ());
    }	
    
	msg = new JtMessage (JtJAASAdapter.JtLOGOUT);
    Bool = (Boolean) factory.sendMessage(adapter, msg);
    
    if (Bool == null || !Bool.booleanValue())
    	System.out.println("JtLOGOUT: fail");
    else
    	System.out.println("JtLOGOUT: pass");   
    
  }

}
