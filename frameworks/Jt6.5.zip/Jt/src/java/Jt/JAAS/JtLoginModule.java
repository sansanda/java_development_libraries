
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.JAAS;

import java.security.Principal;
import java.util.Map;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;
import Jt.security.JtPrincipal;



public class JtLoginModule implements LoginModule {


	private static final long serialVersionUID = 1L;
	private Subject lSubject;
	private CallbackHandler lCallbackHandler;
	private String lUsername;
	private char lPassword[]; 
	private boolean loginSuccess = false;
	private boolean commitSuccess = false;	
	private Principal lPrincipal;
    public static final String JtCLASS_NAME = JtLoginModule.class.getName();	
    private String loginVerificationClassname;



	public void initialize(Subject subject, CallbackHandler callbackHandler, Map sharedState,
			Map options) {
		
		lSubject = subject;
		lCallbackHandler = callbackHandler;
		lUsername = null;
		loginVerificationClassname = (String) options.get ("loginVerificationClassname");
		
	}

	private void clearPassword () {
		int i;
		
		if (lPassword == null)
			return;
		for (i = 0; i < lPassword.length; i++) {
			
			lPassword[i] = ' ';
		}
		
		lPassword = null;
	}
	public boolean login() throws LoginException {
		
		char tempPassword[];
		Boolean Bool; 
		
		Callback[] callbacks = new Callback[2];
		JtFactory factory = new JtFactory ();
		Object loginStrategy;
		
		if (lCallbackHandler == null) {
			throw new LoginException ("CallbackHandler is missing");
		}
		
		
		callbacks[0] = new NameCallback("Username");
		callbacks[1] = new PasswordCallback("Password", false);		
		
		try {
			lCallbackHandler.handle(callbacks);
			lUsername = ((NameCallback)callbacks[0]).getName();
			tempPassword = ((PasswordCallback) callbacks[1]).getPassword();
			
			lPassword = new char [tempPassword.length];
			
			System.arraycopy(tempPassword, 0, lPassword, 0, tempPassword.length);
			
			((PasswordCallback) callbacks[1]).clearPassword();
			
			if (lPassword == null)
				throw new LoginException ("Invalid password");
			
		} catch (Exception ex) {
			throw new LoginException (ex.toString());
		}
		
		//System.out.println("name:" + lCallbackHandler.getClass().getName());
		//loginStrategy = ((JtCallbackHandler) lCallbackHandler).getLoginStrategy();
		
		if (loginVerificationClassname == null) {
			
			loginSuccess = false;
			lUsername = null;
			clearPassword ();
			factory.handleError ("Invalid Login Classname (null)");
			throw new FailedLoginException ("Invalid Login Classname (null)");
		}
		
		loginStrategy = factory.createObject(loginVerificationClassname);
		
		if (loginStrategy == null) {
			
			loginSuccess = false;
			lUsername = null;
			clearPassword ();
			factory.handleError ("Invalid Login Component: " + loginVerificationClassname);
			throw new FailedLoginException ("Invalid Login component: " + loginVerificationClassname);
		}

        factory.setValue(loginStrategy, "username", lUsername);
        factory.setValue(loginStrategy, "password", new String (lPassword));    
        
        Bool = (Boolean) factory.sendMessage(loginStrategy, new JtMessage (JtObject.JtACTIVATE));
        
        factory.setValue(loginStrategy, "username", null);
        factory.setValue(loginStrategy, "password", null); 
		
        if (Bool != null && Bool.booleanValue()) {
			
			loginSuccess = true;
			return true;
		} else {
			loginSuccess = false;
			lUsername = null;
			clearPassword ();
			
			throw new FailedLoginException ("Incorrect Password");
		}
		
	}

	public boolean commit() throws LoginException {

		
		if (loginSuccess == false) {
		    return false;
		} else {
		    // add a Principal (authenticated identity)
		    // to the Subject

		    lPrincipal = new JtPrincipal(lUsername);
		    if (!lSubject.getPrincipals().contains(lPrincipal))
			lSubject.getPrincipals().add(lPrincipal);

		    // in any case, clean out state
		    lUsername = null;

		    clearPassword ();
		    lPassword = null;

		    commitSuccess = true;
		    return true;
		}


	}
	
	public boolean abort() throws LoginException {
		
		if (loginSuccess == false) {
			return false;
		} else if (loginSuccess && !commitSuccess) {
			loginSuccess = false;
			lUsername = null;
			clearPassword ();
			lPrincipal = null;
		} else 
			logout ();
		
		
		return true;
		
	}
	public boolean logout() throws LoginException {
		
		lSubject.getPrincipals().remove(lPrincipal);
		commitSuccess = false;
		loginSuccess = false;
		lUsername = null;
        clearPassword ();
		lPrincipal = null;
		return true;

	}
	


}
