

package Jt;
import java.util.*;



/**
 * Handles hash tables. This class is useful when a hashtable component 
 * needs to be added to UML/BPM diagrams or accessed via a remote API.
 */

public class JtHashTable extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtHashTable.class.getName(); 
    public static final String JtGET = "JtGET";
    public static final String JtPUT = "JtPUT";
    public static final String JtCLEAR = "JtCLEAR";
    public static final String JtGET_KEYS = "JtGET_KEYS";
    public static final String JtREMOVE_OBJECT = "JtREMOVE_OBJECT";
    
    protected HashMap hashmap = null;



    public JtHashTable() {
    }


    /**
     * Void operation.
     */

    public void setSize (int size) {

    }

    /**
     * Returns the number of elements in the hash table.
     */ 

    public int getSize () {
        return (hashmap != null ? hashmap.size (): 0);
    }


    /**
     * Specifies the HashMap object used to represent this object
     */

    public void setHashmap (HashMap hashmap) {
        this.hashmap = hashmap; // void operation
    }

    /**
     * Returns the HashMap.
     */ 

    public HashMap getHashmap () {
        return (hashmap);
    }

    private Object getKeys () {
        JtIterator jit = new JtIterator ();
        Collection col;
        HashMap tmp;

        tmp = getHashmap ();
        if (tmp == null)
          return (null);    

        col = tmp.keySet ();
        if (col == null)
        //if (col == null || (col.size () == 0))
          return (null);

        jit.setIterator (col.iterator ());
        return jit;     

    }
    
    /**
     * Returns a JtIterator.
     */

    public Object getIterator () {
        JtIterator jit;
        Collection values;

        jit = new JtIterator ();

        if (hashmap == null)
            return (null);

        values = hashmap.values ();

        if (values == null)
            return (null);
        jit.setIterator(values.iterator ());

        return (jit);
    }

    /**
     * void operation. 
     */
    public void setIterator (Object iterator) {

    }

    // Broadcast a message

    private void broadcastMessage (JtMessage msg)
    {
        Collection values;
        Iterator it;
        JtFactory factory = new JtFactory ();

        if (msg == null || hashmap == null)
            return;

        values = hashmap.values ();
        if (values == null)
            return;
        it = values.iterator ();

        while (it.hasNext()) {
            factory.sendMessage (it.next (), msg);
        }

    }

    /**
     * Process object messages.
     * <ul>
     * <li> JtPUT - Adds the component (msgContent) to this hash table using
     * the specified key (msgData)
     * <li> JtREMOVE_OBJECT - Removes the component specified by msgData.
     * <li> JtCLEAR - Removes all the entries from this hash table
     * <li> JtGET - Returns the component to which the specified key (msgData) is mapped to 
     * <li> JtBROADCAST - Broadcast a message (msgContent) to all the components
     * in this hash table
     * <li> JtGET_KEYS - Returns a JtIterator over the keys found in the hash table
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        Object data;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();
        data = e.getMsgData ();

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            if (hashmap != null)
                hashmap.clear();
            return (null);     
        }

        if (msgid.equals (JtHashTable.JtPUT)) {
            // Add an object to the hash table

            if (content == null) {
                handleWarning 
                ("JtHashTable.processMessage(JtPUT):adding null value");
                //return (this);

            }
            if (hashmap == null)
                hashmap = new HashMap ();
//          col = new Hashtable ();

            hashmap.put (data, content);        
            return (null);
        }     


        if (msgid.equals (JtHashTable.JtGET)) {


            if (data == null) {
                handleWarning 
                ("JtHashTable.processMessage(JtGET):invalid value (null)");
                return (null);

            }
            if (hashmap == null)
                return (null);


            return (hashmap.get (data));        

        }  


        if (msgid.equals (JtHashTable.JtCLEAR)) {

            if (hashmap != null) {
                hashmap.clear ();
            }

            return (null);
        }

        if (msgid.equals (JtHashTable.JtREMOVE_OBJECT)) {
            // Remove an object from the collection

            if (data == null) {
                handleWarning 
                ("JtHashTable.processMessage(JtREMOVE_OBJECT):invalid key (null).");
                return (null);

            }
            if (hashmap.get(data) == null) {
                handleError ("element not found " + content);
                return (null);
            }    
            
            hashmap.remove (data);        
            return (null);
        }   
        
        
        // Broadcast a message to all the members
        // of the hash table

        if (msgid.equals (JtObject.JtBROADCAST)) {

            if (hashmap == null) {
                return (null);
            }

            broadcastMessage ((JtMessage) content);

            return (null);
        }
        
        if (msgid.equals (JtHashTable.JtGET_KEYS)) {
            return (getKeys ());     
        }

        return (super.processMessage (message));

    }



    /**
     * Demonstrates the messages processed by this class.
     * 
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtMessage msg = new JtMessage (JtHashTable.JtPUT);
        JtMessage msg1 = new JtMessage (JtHashTable.JtGET);
        JtPrinter printer = new JtPrinter ();
        
        JtHashTable table;

        // Create an instance of JtHashTable
        
        table = (JtHashTable) factory.createObject (JtHashTable.JtCLASS_NAME);
        
        msg.setMsgContent(new Integer (1));
        msg.setMsgData("one");
        
        // Add an object to hashtable
        
        factory.sendMessage (table, msg);   
        
        
        msg1.setMsgData("one");       
        System.err.println ("JtHashTable(JtGET):" + factory.sendMessage (table, msg1));
        
        //msg.setMsgContent(new Integer (2));
        //msg.setMsgData("two");
        
        // Add an object to the hashtable
        
        //factory.sendMessage (table, msg);    
        
        System.out.println ("count:" + table.getSize());
             
        printer.processMessage (table);
        
        
        if (table.getSize() == 1)
            System.err.println ("JtHashTable(JtPUT):GO");
        else
            System.err.println ("JtHashTable:FAILED");
        
        factory.sendMessage (table, new JtMessage (JtHashTable.JtCLEAR));
        
        if (table.getSize() == 0)
            System.err.println ("JtHashTable (JtCLEAR):GO");
        else
            System.err.println ("JtHashTable:FAILED");



    }


}

    

