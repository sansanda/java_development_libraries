

package Jt;


/**
 * Jt Implementation of the Singleton pattern.
 */

public class JtSingleton extends JtObject {
    
  public static final String JtCLASS_NAME = JtSingleton.class.getName(); 
  private static final long serialVersionUID = 1L;
  //private Object instance = null; This attribute is being deprecated



  public JtSingleton () {
  }

/**
  * Returns the unique class instance.
  */

  /*
  public synchronized Object getInstance()
  {
    return instance;
  }
  */

/**
  * Specifies the unique class instance.
  */

  /*
  public synchronized void setInstance(Object newInstance)
  {
    if (instance == null)
      instance = newInstance;

  }
  */
 
  /**
   * Demonstrates the messages processed by JtSingleton.
   * It also demonstrates the use of singletons via JtFactory.
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtSingleton singleton, singleton1;
    JtObject obj, obj1;

    System.out.println ("Creating an instance of a singleton ...");

    // Create a JtSingleton instance

    singleton = (JtSingleton) factory.createObject (JtSingleton.JtCLASS_NAME, "singleton");


    System.out.println ("Attempting to create a second instance of a singleton ...");

    singleton1 = (JtSingleton) factory.createObject (JtSingleton.JtCLASS_NAME, "singleton1");

    if (singleton == singleton1) 
    	System.out.println("create singleton (via inheritance): GO");
    else
    	System.out.println("create singleton (via inheritance): FAIL");
    
    
   // Demonstrate the handling of singletons (via JtFactory)
    

    
    // Create the singlenton (via factory)
    
    factory.setCreateSingleton (true);  
    obj = (JtObject) factory.createObject(JtObject.JtCLASS_NAME);
    
    // The singleton instance is returned. No new instance is created
    
    factory.setCreateSingleton (true);
    obj1 = (JtObject) factory.createObject(JtObject.JtCLASS_NAME);
    
    if (obj == obj1) 
    	System.out.println("create singleton (via JtFactory): GO");
    else
    	System.out.println("create singleton (via JtFactory): FAIL"); 
    
 
    factory.removeObject(obj);

  }

}


