package Jt;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

/**
 * Jt Adapter for the JavaMail API.
 */ 

public class JtMail extends JtObject {

    public static final String JtCLASS_NAME = JtMail.class.getName();     
    private static final long serialVersionUID = 1L;
    private String from;
    private String to;
    private String message;
    private String subject;
    private String server;
    private String cc;
    private String attachment;
    private String username;
    private String password;
    private transient Session ses = null;
    private String port;


    void activate () {
    	

        if (server == null) { 
            handleError ("Attribute 'server' needs to be set.");
            return;
        } 
        
        if (from == null) { 
            handleError ("Attribute 'from' needs to be set.");
            return;
        } 
        
        if (to == null) { 
            handleError ("Attribute 'to' needs to be set.");
            return;
        } 
        
        if (message == null) { 
            handleError ("Attribute 'message' needs to be set.");
            return;
        } 
        
        /*
        if (server == null || from == null || to == null || 
                message == null) {
            handleTrace ("JtMail: null attribute(s)");
            return; // check subject
        }
        */
        try {
            Authenticator auth = null;

            if (ses == null) {
                if (username != null || password != null)
                    auth = new SMTPAuthenticator();
                // Get system properties
                Properties props = System.getProperties(); 
                // Setup mail server 
                props.put("mail.smtp.host", server); 

                // port
                if (port != null)
                    props.put("mail.smtp.port", port); 
                if (username != null || password != null)
                    props.put("mail.smtp.auth", "true");


                // Get session 
                //ses = Session.getDefaultInstance(props, auth); 
                ses = Session.getInstance(props, auth); 

                if (logger != null && logger.getLogging())
                    ses.setDebug(true);
            }

            // Define message 

            MimeMessage msg = new MimeMessage(ses); 
            msg.setFrom(new InternetAddress(from)); 
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to)); 
            if (cc != null && !cc.equals (""))
                msg.addRecipient(Message.RecipientType.CC, new InternetAddress(cc)); 

            if (subject != null)
                msg.setSubject(subject);
            if (attachment == null)
                msg.setText(message);
            else {
                BodyPart messageBodyPart = new MimeBodyPart(); 
                // Fill the message 
                messageBodyPart.setText(message); 
                Multipart multipart = new MimeMultipart(); 
                multipart.addBodyPart(messageBodyPart); // Part two is attachment 
                messageBodyPart = new MimeBodyPart(); 
                DataSource source = new FileDataSource(attachment); 
                messageBodyPart.setDataHandler(new DataHandler(source)); 
                messageBodyPart.setFileName(attachment); 
                multipart.addBodyPart(messageBodyPart); 
                msg.setContent(multipart);

            }


            //msg.setText(message); 
            msg.setSentDate(new Date());


            // Send message 
            Transport.send(msg); 
        }
        catch (Exception e) {
            handleException (e);
        }
    }
    
    // Reset Exceptions 

    private void resetExceptions ()
    {
        this.setObjException(null);
    }

    /**
     * Process object messages.
     * <ul>
     * <li> JtACTIVATE - Sends an email message using the JavaMail API
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        //String content;
        //String query;
        JtMessage e = (JtMessage) message;


        if (e == null ||  (e.getMsgId() == null))
            return (null);
      
        // Remove this object
        if (e.getMsgId().equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        // establish connection
        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            resetExceptions ();
            activate ();
            return (null);
        }

        return (processMessage (message)); 

    }

    /**
     * Sets the "from" attribute (sender).
     */

    public void setFrom (String newFrom) {
        from = newFrom;
    }

    /**
     * Returns the "from" attribute (sender).
     */

    public String getFrom () {
        return (from);
    }


    /**
     * Sets the "to" attribute (recipient).
     */

    public void setTo (String newTo) {
        to = newTo;
    }

    /**
     * Gets the "to" attribute (recipient).
     */

    public String getTo () {
        return (to);
    }

    /**
     * Sets the CC attribute
     */

    public void setCc (String cc) {
        this.cc = cc;
    }

    /**
     * Returns the CC attribute.
     */

    public String getCc () {
        return (cc);
    }

    /**
     * Specifies the content of the email message.
     */

    public void setMessage (String newMessage) {
        message = newMessage;
    }


    /**
     * Returns the content of the email message.
     */

    public String getMessage () {
        return (message);
    }


    /**
     * Specifies the subject of the email message.
     */

    public void setSubject (String newSubject) {
        subject = newSubject;
    }


    /**
     * Returns the subject of the email message.
     */

    public String getSubject () {
        return (subject);
    }

    /**
     * Sets the user name (for authentication).
     */

    public void setUsername (String newUsername) {
        username = newUsername;
    }


    /**
     * Returns the user name (for authentication).
     */

    public String getUsername () {
        return (username);
    }

    /**
     * Sets the password (for authentication).
     */

    public void setPassword (String newPassword) {
        password = newPassword;
    }


    /**
     * Returns the password (for authentication).
     */

    public String getPassword () {
        return (password);
    }

    /**
     * Specifies the server.
     */

    public void setServer (String newServer) {
        server = newServer;
    }

    /**
     * Returns the server.
     */

    public String getServer () {
        return (server);
    } 


    /**
     * Specifies the port.
     */

    public void setPort (String newPort) {
        port = newPort;
    }

    /**
     * Returns the port.
     */

    public String getPort () {
        return (port);
    } 


    /**
     * Specifies the attachment.
     */

    public void setAttachment (String attachment) {
        this.attachment = attachment;
    }


    /**
     * Returns the attachment.
     */

    public String getAttachment () {
        return (attachment);
    } 


    /**
     * Demonstrates the use of JtMail.
     */

    public static void main (String[] args) {
        JtFactory factory = new JtFactory (); 
        JtMail jtmail;


        // Create an instance of JtMail

        jtmail = (JtMail) factory.createObject (JtMail.JtCLASS_NAME);


        // Set JtMail attributes

        jtmail.setFrom("Jt@yahoo.com");
        jtmail.setSubject("Hello World");
        jtmail.setMessage("Welcome to Jt messaging!");
        jtmail.setTo("email@yahoo.com");


        // Activate JtMail (send email)

        factory.sendMessage (jtmail, new JtMessage (JtObject.JtACTIVATE));


        // Check for exceptions (it any)

        if (jtmail.getObjException() == null)
            System.out.println  ("JtMail: GO");  
        else
            System.out.println  ("JtMail: FAIL");  


    }

    /**
     * SimpleAuthenticator is used to do simple authentication
     * when the SMTP server requires it.
     */
    private class SMTPAuthenticator extends javax.mail.Authenticator
    {

        public PasswordAuthentication getPasswordAuthentication()
        {
            //String username = SMTP_AUTH_USER;
            //String password = SMTP_AUTH_PWD;
            return new PasswordAuthentication(username, password);
        }
    }
}