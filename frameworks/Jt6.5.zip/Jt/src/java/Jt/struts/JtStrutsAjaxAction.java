package Jt.struts;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;

import org.apache.struts.action.*;
//import org.apache.struts.action.ActionErrors;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtInterface;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.jbpm.JtJBPMAdapter;
import Jt.util.JtURLString;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/** 
 *  This class allows a Struts action to be called via an AJAX request.
 */



public class JtStrutsAjaxAction extends JtStrutsAction {


    
    public ActionForward execute (ActionMapping mapping, ActionForm form,
                                    HttpServletRequest request, 
                                    HttpServletResponse response) throws IOException, ServletException {


        this.setAjax(true);
        return (super.execute(mapping, form, request, response));
    }
    
  

}
