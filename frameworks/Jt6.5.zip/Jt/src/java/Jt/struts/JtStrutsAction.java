package Jt.struts;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;

import org.apache.struts.action.*;
//import org.apache.struts.action.ActionErrors;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtInterface;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.jbpm.JtJBPMAdapter;
import Jt.util.JtURLString;
import Jt.xml.JtXMLHelper;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/** 
 *  Jt Adapter for the Struts API. It allows the user to easily integrate the Jt framework with the Struts framework.
 *  The business logic is implemented by a delegate class or via a jBPM business process.
 */



public class JtStrutsAction extends Action {
    ActionErrors errors;
    JtFactory main;
    
    private boolean ajax = false;
    //static final String RESOURCE_PATH = "/WEB-INF/" + JtObject.RESOURCE_FILE;
    
    public boolean isAjax() {
        return ajax;
    }

    public void setAjax(boolean ajax) {
        this.ajax = ajax;
    }

    
    private void updateResponse (HttpServletResponse res, Object reply) {
        String stringReply;
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
        JtFactory factory = new JtFactory ();
        

        
        if (res == null) // check
            return;
        
        if (reply instanceof String) {
            stringReply = (String) reply;
        } else {
            JtXMLHelper xmlHelper = new JtXMLHelper ();
            
            msg.setMsgContent(reply);
            
            stringReply = (String) factory.sendMessage(xmlHelper, msg);
            
        }
        
        res.setContentType("text/xml");
        res.setHeader("Cache-Control", "no-cache");
        try {
            res.getWriter().write("" + stringReply);
        } catch (Exception ex) {
            exceptionDetected (ex);
        }
        
    }
    
    public ActionForward execute (ActionMapping mapping, ActionForm form,
                                    HttpServletRequest request, 
                                    HttpServletResponse response) throws IOException, ServletException {
        String className = null;
        //JtFactory main = new JtFactory ();
        JtMessage msg = null, msg1 = null;
        JtInterface delegate;
        Object jtReply;
        String msgId;
        Exception ex;
        String parameter;
        JtJBPMAdapter jbpmAdapter;
        InputStream inputStream;
        String errorMessage;
        Collection uiErrors;
        int index;
        JtContext context;
        String tmp;
        
        main = new JtFactory ();
        errors = new ActionErrors ();
        //main.setObjTrace(1);  
        
        if (!ajax && isCancelled (request))
            return mapping.findForward ("cancel");
        
        //inputStream = determineResourceStream (JtObject.WEB_RESOURCE_PATH);
 
        //main.setLogFile("stderr");
        
        // Loading resources from input stream
        
        //if (inputStream != null) {
        //    main.handleTrace("reading resources from input stream " + "(" + JtObject.WEB_RESOURCE_PATH + ") ...");
        //    main.setResourceStream(inputStream);
        //}
        
        
        parameter = mapping.getParameter();  // Parameter within the action element (struts-config.xml)
                                             // This parameter must specify the delegate class (Jt interface)
                                             // or the jBPM process definition XML file
        
        if (parameter == null) {
            errorDetected ("The action parameter (struts-config.xml) needs to be set.");
            if (!errors.isEmpty ())                
                saveErrors (request, errors);
  
            if (ajax)
                return null;
            
            return (mapping.findForward("failure"));
        }       
        
        // jBPM process definition file
        
        if (isProcessDefinitionFile (parameter)) { 
            
            // Create an instance of JtJBPMAdapter class.
            // This class will be used to execute the BPM business process
            
            jbpmAdapter = new JtJBPMAdapter ();
            
            inputStream = determineResourceStream (parameter);
            
            //System.out.println ("inputStream:" + inputStream);
            
            main.setValue (jbpmAdapter, "inputStream", inputStream);
            
            
            msgId = request.getParameter("jtMsgId");
            if (msgId == null)
                msgId = request.getParameter("msgId");               
 /*           
            if (msgId == null) {
                errorDetected ("JtStrutsAction: the parameter jtMsgId needs to be set.");
                if (!errors.isEmpty ())                
                    saveErrors (request, errors);
      
                return (mapping.findForward("failure"));
            } 
*/            
            // Add a variable to the process (jtMessage)
            
            msg = new JtMessage (msgId);
            msg.setMsgContent (request.getParameter("jtMsgContent"));
            msg.setMsgData(request.getParameter("jtMsgData"));
            msg.setMsgAttachment(request.getParameter("jtMsgAttachment"));
            
            //msg.setMsgData(form); // pass the Action Form to the process (msgData)
            
            // Pass context information. This includes the action form
            context = new JtContext ();            
            //context.setServletContext(servlet.getServletContext());
            context.setRequest(request);
            context.setResponse(response);   
            context.setActionForm(form);  
            
            msg.setMsgContext(context);
            
            msg1 = new JtMessage (JtJBPMAdapter.JtADD_VARIABLE);
            msg1.setMsgContent ("jtMessage");
            msg1.setMsgData (msg);
            
            main.sendMessage (jbpmAdapter, msg1);
            
            // Execute the business process
            
            jtReply = main.sendMessage (jbpmAdapter, new JtMessage (JtObject.JtACTIVATE));
            ex = (Exception) main.getValue(jbpmAdapter, "objException");
            
            // check if an exception was detected during the execution
            
            if (ex != null) {
                exceptionDetected (ex);

                if (!errors.isEmpty ())                
                    saveErrors (request, errors);

                if (ajax)
                    return null;
                
                return (mapping.findForward("failure"));
            }
 
            
            errorMessage = (String) main.getValue(jbpmAdapter, "errorMessage");
            
            // check if an error message needs to be returned
            
            if (errorMessage != null) {
                processErrorMessage (errorMessage);

                if (!errors.isEmpty ())                
                    saveErrors (request, errors);
                
                if (ajax)
                    return null;
                
                return (mapping.findForward("failure"));
            }
            
            // Set the jtReply attribute
            
            request.setAttribute("jtReply", jtReply);
            
            //System.out.println (jtReply);
            
            if (ajax) {
                updateResponse (response, jtReply);
                return null;
            }
            return (mapping.findForward("success"));
        }
        
        index = parameter.indexOf('?');
              
        
        // delegate class (implements JtInterface)
        
        if (index < 0)
            className = parameter;  //The action parameter specifies the class name
        else {
            className = parameter.substring(0, index);
        }
            
        
        // Attemp to create an instance of the delegate
        
        msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
        msg.setMsgContent(className);
        
        delegate = (JtInterface) main.processMessage (msg);
                   
        if (index > 0) {
            setAttributes (delegate, parameter);
        }
        
        // Check for exceptions during creation
        
        ex = (Exception) main.getObjException();
        if (ex != null) {
            exceptionDetected (ex);

            if (!errors.isEmpty ())                
                saveErrors (request, errors);
            
            if (ajax)
                return null;
            
            return (mapping.findForward("failure"));
        }

        msgId = request.getParameter("jtMsgId");
        if (msgId == null)
            msgId = request.getParameter("msgId");   
 
        /*
        if (msgId == null) {
            errorDetected ("JtStrutsAction: the parameter jtMsgId needs to be set.");
            if (!errors.isEmpty ())                
                saveErrors (request, errors);
  
            return (mapping.findForward("failure"));
        }*/

    
        
        // Assemble the message
        if (msgId != null)
            msg = new JtMessage (msgId);
        else
            msg = new JtMessage (JtObject.JtACTIVATE);
        msg.setMsgContent (request.getParameter("jtMsgContent"));  
        if (msg.getMsgContent() == null)
            msg.setMsgContent (request.getParameter("msgContent")); 
        //msg.setMsgData(form); // send the Action Form to the delegate class (msgData)
        msg.setMsgData(request.getParameter("jtMsgData"));
        if (msg.getMsgData() == null)
            msg.setMsgData (request.getParameter("msgData"));        
        msg.setMsgAttachment(request.getParameter("jtMsgAttachment"));  
        if (msg.getMsgAttachment() == null)
            msg.setMsgAttachment(request.getParameter("msgAttachment"));   
 
        tmp = request.getParameter("jtMsgAsynchronous");  
        if (tmp == null)
            tmp = request.getParameter("msgAsynchronous");  
        //msg.setMsgAttachment(request);
        
        
        if (tmp != null && !(tmp.equalsIgnoreCase("true") ||
        		tmp.equalsIgnoreCase("false")))
        	main.handleWarning ("invalid message parameter (Asynchronous):" + tmp);

 
        if (tmp != null && tmp.equalsIgnoreCase("true"))
        	// Asynchronous messaging
        	main.setSynchronous(false);
        	       	
        
        // Pass context information. This includes the action form
        context = new JtContext ();
        
        context.setServletContext(servlet.getServletContext());
        context.setActionForm(form);      
        context.setRequest(request);
        context.setResponse(response);   
        context.setUserName(retrieveUserName (request));
        msg.setMsgContext(context);
        
        // Let the delegate class process the message
        
        jtReply = main.sendMessage (delegate, msg);
                
        // Check for exceptions
        
        ex = (Exception) main.getValue(delegate, "objException");
        uiErrors = (Collection) main.getValue(delegate, "objErrors");
        
        if (uiErrors != null || ex != null) {

            if (uiErrors != null)
                updateErrors ((LinkedList) uiErrors);   
            else
                exceptionDetected (ex);
            if (!errors.isEmpty ()) {

                saveErrors (request, errors);
            }
            
            if (ajax)
                return null;
            
            return (mapping.findForward("failure"));            
        }
 
        
        // Set the jtReply attribute
        
        request.setAttribute("jtReply", jtReply);
        
        main.handleTrace("JtStrutsAction(jtReply): " + jtReply);      
        
        //System.out.println (jtReply);
        
        main.handleTrace("JtStrutsAction: before success");
        
        if (ajax) {
            updateResponse (response, jtReply);
            return null;
        }
        
        return (mapping.findForward("success"));
    }
    
    private String retrieveUserName (HttpServletRequest request) {
        HttpSession session;
        JtContext ctx;
        JtFactory factory = new JtFactory ();
        
        
        if (request == null)
            return null;
        
        session = request.getSession();
        
        factory.handleTrace ("retrieveUserName(session):" + session);
        if (session == null)
            return null;
        
        ctx = (JtContext) session.getAttribute("jtContext");
        
        factory.handleTrace ("retrieveUserName(ctx):" + ctx);
        if (ctx == null)
            return null;
        
        factory.handleTrace ("retrieveUserName:" + ctx.getUserName());
        return (ctx.getUserName());
    }
    
    
    private void setAttributes (Object delegate, String parameter) {
        JtURLString urlString;
        JtHashTable attributes;
        JtIterator iterator;
        String attribute, value;
        JtMessage msg;
        
        if (delegate == null || parameter == null)
            return;
        urlString = new JtURLString ();
        urlString.setString(parameter);
        
        attributes = (JtHashTable) urlString.processMessage(new JtMessage (JtURLString.JtURL_DECODE));
        
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        msg = new JtMessage (JtHashTable.JtGET);
        for (;;) {
            attribute = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            
            if (attribute == null)
                break;
            
            msg.setMsgData(attribute);
            
            value = (String) attributes.processMessage(msg);
            
            if (value == null)
                continue;
            main.setValue (delegate, attribute, value);
            
        }
        
    }
     
    private InputStream determineResourceStream (String path) {
        if (path == null)
            return (null);
        
        ServletContext context = servlet.getServletContext();
     
        return (context.getResourceAsStream(path));
        //ActionServlet ac = this.getServlet();
        //ServletContext context = ac.getServletContext ();
        //return (request.getRealPath(partialPath));
        
    }
    
    // verify if the parameter represents a process definition file
    
    private boolean isProcessDefinitionFile (String path) {
        if (path == null)
            return (false);
        
        // check if the file ends with .xml (process definition file)
        
        if (path.endsWith(".xml"))
            return (true);
        return (false);
    }
    
    // exception detected
    
    private void exceptionDetected (Exception ex) {
        
        errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.exception", ex.toString()));
        
    }
    
    
    private void updateErrors (LinkedList errorList) {
        int i;

        if (errorList == null)
            return;
        for (i=0; i < errorList.size(); i++) {
            //System.out.println ("updateErrors:" + errorList.get(i));
            errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.exception", 
                    errorList.get(i)+"<br />"));
        }    

    }
    
    // error detected
    
    private void errorDetected (String error) {
        
        main.handleError(error); // forces an exception to be generated
        exceptionDetected ((Exception) main.getObjException()); 
        
    }
    // error message detected
    
    private void processErrorMessage (String error) {
        
        errors.add (ActionMessages.GLOBAL_MESSAGE, new ActionMessage ("jt.exception", error));
        
    }   

}
