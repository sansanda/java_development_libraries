package Jt.struts;


import org.apache.struts.action.ActionForm;
import org.apache.struts.action.DynaActionForm;
import org.jbpm.graph.exe.ExecutionContext;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.jbpm.JtJBPMObject;

/**
 * Jt wrapper for the Struts ActionForm class. This wrapper is used
 * to retrieve field values from the ActionForm.
 * This class can be readily included in the jBPM process definition. 
 */


//public class JtStrutsFormWrapper extends JtObject {
public class JtStrutsFormWrapper extends JtJBPMObject {

    private static final long serialVersionUID = 1L;
    public static final String JtGET_FIELD= "JtGET_FIELD";
    private transient JtFactory factory = new JtFactory ();
    
    ActionForm form = null;
    

    /**
     * Returns the ActionForm instance. 
     */
    
    public ActionForm getForm() {
        return form;
    }
    
    /**
     * Sets the ActionForm instance. 
     * @param form ActionForm instance
     */
    
    public void setForm(ActionForm form) {
        this.form = form;
    }

  

    public void execute(ExecutionContext context) throws Exception {

      JtMessage msg;
      JtContext jtContext;
 
      super.execute (context);
      try {

        // Retrieve the Action form from the JtMessage passed to the process
          
        msg = (JtMessage) context.getContextInstance().getVariable ("jtMessage");  
        if (msg == null) {
            handleError ("jtMessage not found in process context");
            return;            
        }
        
        jtContext = (JtContext) msg.getMsgContext();
        if (jtContext != null)
            form = (ActionForm) jtContext.getActionForm();
        //form = (ActionForm) msg.getMsgData();
        
        if (form == null) {
            handleError ("ActionForm is null");
            return;            
        }       
      } catch (Exception ex) {
        handleException (ex);
        return;
      }     
      //loadObjectResources (this, this.getClass().getName());
    }
    
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtGET_FIELD - Returns de value of a form field or null. msgContent specifies
     * the name of the field.
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        Object content;

        JtMessage e = (JtMessage) message;


        if (e == null ||  (e.getMsgId() == null))
            return (null);

        // Remove this object
        if (e.getMsgId().equals (JtObject.JtREMOVE)) {
            return (null);     
        }


        if (e.getMsgId().equals(JtStrutsFormWrapper.JtGET_FIELD)) {
            
            if (form == null)
                return (null);
            
            content = e.getMsgContent ();
            if (content == null) {
                handleError ("JtGET_FIELD: incorrect message content. Field is null");
                return (null);
            }
            
            if (form instanceof DynaActionForm) {
                return ((DynaActionForm) form).get ((String) content);
            } else
                return (factory.getValue(form, (String) content));
                
        }

        handleError ("invalid message id:"+ e.getMsgId());
        return (null);
    }



}
