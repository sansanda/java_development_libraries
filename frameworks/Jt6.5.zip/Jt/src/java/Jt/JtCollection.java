

package Jt;
import java.util.*;


/**
 * Handles a collection of component. This class is useful when a collection  
 * needs to be added to UML/BPM diagrams or accessed via a remote API.
 */

public class JtCollection extends JtObject {


    private static final long serialVersionUID = 1L;
    private HashMap collection = null;
    private transient Object iterator;
    //private int size = 0; 
    public static final String JtCLASS_NAME = JtCollection.class.getName(); 
    public static final String JtADD = "JtADD";
    public static final String JtCLEAR = "JtCLEAR";
    public static final String JtREMOVE_OBJECT = "JtREMOVE_OBJECT";


    public JtCollection() {
    }

    /**
     * Returns the Java Collection.
     */ 

    public Collection getCollection() {
        if (collection != null)  
            return collection.values();
        else
            return (null);
    }

    /**
     * Void operation.
     */

    public void setCollection (Collection collection) {
        // void operation
    } 


    /**
     * Void operation.
     */

    public void setSize (int size) {
        // void operation
    }

    /**
     * Returns the number of elements in the collection.
     */ 

    public int getSize () {
        return (collection != null ? collection.size (): 0);
    }

    /**
     * Returns a JtIterator over the collection. 
     */

    public JtIterator getIterator () {
        JtIterator jit;
        Collection values;

        jit = new JtIterator ();

        if (collection == null)
            return (null);

        values = collection.values ();

        if (values == null)
            return (null);
        jit.setIterator(values.iterator ());

        return (jit);
    }

    /**
     * void operation. 
     */
    public void setIterator (JtIterator iterator) {

    }
    
    
    /**
     * Broadcasts a message to all the objects in the collection.
     */

    private void broadcastMessage (JtMessage msg)
    {
        Collection values;
        Iterator it;
        JtFactory factory = new JtFactory ();

        if (msg == null || collection == null)
            return;

        values = collection.values ();
        if (values == null)
            return;
        it = values.iterator ();

        while (it.hasNext()) {
            factory.sendMessage (it.next (), msg);
        }

    }

    /**
     * Process object messages.
     * <ul>
     * <li>JtADD - Adds the object specified by msgContent to this collection
     * <li>JtREMOVE_OBJECT - Removes the object specified by msgContent.
     * <li>JtBROADCAST - Broadcast the message specified by msgContent to all the objects
     * in this collection
     * <li>JtCLEAR - Removes all the objects from this collection
     * </ul>
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object content;
        //Object data;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            //size = 0;
            collection.clear ();
            return (null);     
        }

        // JtCOLLECTION_ADD is being deprecated
        if (msgid.equals ("JtCOLLECTION_ADD") || msgid.equals (JtCollection.JtADD)) {
            // Add object to the collection

            if (content == null) {
                handleWarning 
                ("JtCollection.processMessage(JtADD):invalid message content (null)");
                return (null);

            }
            if (collection == null)
                collection = new HashMap ();
//          col = new Hashtable ();
            collection.put (content, content);        
            return (null);
        }     


        if (msgid.equals (JtCollection.JtREMOVE_OBJECT)) {
            // Remove an object from the collection

            if (content == null) {
                handleWarning 
                ("JtCollection.processMessage(JtREMOVE_OBJECT):invalid message content (null)");
                return (null);

            }
            if (collection.get(content) == null) {
                handleError ("element not found " + content);
                return (null);
            }    
            
            collection.remove (content);        
            return (null);
        }     

        // JtOBJECT and JtMESSAGE have been deprecated
        
        if (msgid.equals ("JtOBJECT") || msgid.equals ("JtMESSAGE")) {
            // Add object to the collection

            if (content == null)
                return (this);
            if (collection == null)
                collection = new HashMap ();
//          col = new Hashtable ();

            //size++;
            collection.put (content, content);        
            return (null);
        }

        if (msgid.equals (JtCollection.JtCLEAR)) {

            if (collection != null) {
                collection.clear ();
            }
            //size = 0;

            return (null);
        }

        // Broadcasts a message to all the members
        // of the collection

        if (msgid.equals (JtObject.JtBROADCAST)) {

            if (collection == null) {
                return (null);
            }

            broadcastMessage ((JtMessage) content);

            return (null);
        }

        return (super.processMessage(event));

    }


    /**
     * Demonstrates the messages processed by JtCollection
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg, msg1;
        Integer count;
        JtCollection collection;


        // Create an instance of JtColletion

        collection = (JtCollection) main.createObject (JtCollection.JtCLASS_NAME, "collection");

        msg = new JtMessage (JtCollection.JtADD);
        msg.setMsgContent("hello");
        
        // Add an object to the collection

        main.sendMessage (collection, msg);

        if (collection.getSize() == 1)
            System.err.println ("JtCollection(JtADD):GO");
        else
            System.err.println ("JtCollection:FAILED");
        
        msg = new JtMessage (JtCollection.JtREMOVE_OBJECT);
        msg.setMsgContent("hello");
        main.sendMessage (collection, msg);        

        // Clear the collection

        main.sendMessage (collection, new JtMessage (JtCollection.JtCLEAR));

        //count = (Integer) main.getValue ("collection", "size");

        if (collection.getSize() == 0)
            System.err.println ("JtCollection(JtCLEAR):GO");
        else
            System.err.println ("JtCollection:FAILED");

        //msg1 = (JtMessage) main.createObject (JtMessage.JtCLASS_NAME, "message1");
        //main.setValue ("message1", "msgId", JtObject.JtPRINT);
        
        //msg = new JtMessage (JtObject.JtBROADCAST);
        //msg.setMsgContent(msg1);

        //main.setValue ("message", "msgId", JtObject.JtBROADCAST);
        //main.setValue ("message", "msgContent", msg1);

        //main.sendMessage ("collection", "message");


    }

}


