

package Jt;


/**
 *  Represents entries in the Jt Resource file or stream.
 */

public class JtResource {

    String rclass;          // class (class name)
    String robj;            // object (object name)
    String name;            // resource name
    String value;           // resource value

    public JtResource () {
    }
    
    public String getRclass() {
        return rclass;
    }

    public void setRclass(String rclass) {
        this.rclass = rclass;
    }

    public String getRobj() {
        return robj;
    }

    public void setRobj(String robj) {
        this.robj = robj;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }



}
