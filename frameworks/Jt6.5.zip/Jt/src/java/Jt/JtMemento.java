

package Jt;

import Jt.examples.HelloWorld;
import Jt.xml.JtXMLHelper;


/**
 * Jt implementation of the Memento pattern. This class captures
 * the internal state of an object (originator) so that
 * it can be restored to this state later.
 */

public class JtMemento extends JtObject {

  public static final String JtCLASS_NAME = JtMemento.class.getName(); 
  private static final long serialVersionUID = 1L;
  protected Object state = null;
  public static final String JtSAVE = "JtSAVE";
  public static final String JtRESTORE = "JtRESTORE";
  


/**
  * Specifies (saves) the originator's internal state.
  * @param state state
  */

  public void setState (Object state) {
     this.state = state;
  }


/**
  * Returns the originator's internal state.
  */
  public Object getState () {
     return (state);
  }

  public JtMemento () {
  }


  private void saveObject (Object obj) {
      JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
      JtXMLHelper helper = new JtXMLHelper ();    

      if (obj == null)
          return;
      msg.setMsgContent (obj);

      state = helper.processMessage(msg);
      
      //handleTrace ("saving state:\n" + state);

  }



  private Object restoreObject (Object obj) {
      JtMessage msg = new JtMessage (JtObject.JtXML_DECODE);
      JtXMLHelper helper = new JtXMLHelper ();   
      Object tmp;
      JtFactory factory = new JtFactory ();

      if (state == null) {
          handleError ("JtMemento.restoreObject: invalid state (null).");
          return (null);    
      }
      
      msg.setMsgContent (state);
     
      tmp = helper.processMessage(msg);
      

      if (tmp == null) {
        handleTrace ("restoreObject failed: unable to convert object from XML:\n" + state); 
        return null;
      }
      
      if (obj == null) {
          return (tmp);
      }
      
      msg = new JtMessage (JtObject.JtCOPY);
      msg.setMsgContent (tmp);
      msg.setMsgData (obj);
      factory.sendMessage (factory, msg);
      
      return (obj);

  }
  
  /**
    * Process object messages.
    * <ul>
    * <li>JtSAVE - Saves the state of an object specified by msgContent using the XML format.
    * <li>JtRESTORE - Restores the object specified by msgContent to its original state.
    * <li>JtREMOVE - Performs any housekeeping that may be needed before this 
    * object is removed.
    * </ul>
    */

  public Object processMessage (Object event) {

   String msgid = null;
   JtMessage e = (JtMessage) event;



     if (e == null)
	   return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	  return null;


     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);     
     }

     if (msgid.equals (JtMemento.JtSAVE)) {
         saveObject (e.getMsgContent());
         return (null);     
     }
 
     if (msgid.equals (JtMemento.JtRESTORE)) {
 
         return (restoreObject (e.getMsgContent ()));
     }
     
     return (super.processMessage(event));

  }

 
  /**
   * Demonstrates the messages processed by JtMemento.
   */


  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtMemento memento;
    JtPrinter printer = new JtPrinter ();
    JtMessage msg;
    HelloWorld hello = new HelloWorld ();

    hello.setGreetingMessage("Hello World");

    // Create an instance of JtMemento

    memento = (JtMemento) factory.createObject (JtMemento.JtCLASS_NAME, "memento");
    
   
    // Save the state of hello using Memento
    
    msg = new JtMessage (JtMemento.JtSAVE);    
    msg.setMsgContent(hello);   
    factory.sendMessage (memento, msg);   
    
    System.out.println ("Saved object:");
  
    factory.sendMessage (printer, hello); 
    
    hello.setGreetingMessage("new message");
    
    System.out.println ("Object after changed:");
 
    factory.sendMessage (printer, hello); 
    
    // Restore the object
        
    msg = new JtMessage (JtMemento.JtRESTORE);    
    msg.setMsgContent(hello);     
    factory.sendMessage (memento, msg);
    
    System.out.println ("Restored Object:");   

    factory.sendMessage (printer, hello);    
    
    //factory.removeObject (memento);


  }


}


