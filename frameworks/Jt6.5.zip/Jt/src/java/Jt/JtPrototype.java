/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;

/**
 * Jt Implementation of the Prototype design pattern.
 */

public class JtPrototype extends JtObject {

  public static final String JtCLASS_NAME = JtPrototype.class.getName(); 
  private static final long serialVersionUID = 1L;


  public JtPrototype () {
  }





  /**
    * Process object messages.
    * <ul>
    * <li>JtCLONE - returns a clone of this object. The behavior is inherited from JtObject.
    * </ul>
    */

  public Object processMessage (Object event) {



     return (super.processMessage(event));

  }

 
  /**
   * Demonstrates the messages processed by JtPrototype
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtComposite aux;
    JtPrototype tree, branch;
    Double leaf1 = new Double (1.0);
    Double leaf2 = new Double (2.0);
    Double leaf3 = new Double (3.0); 
    JtMessage msg;
    JtPrinter printer = new JtPrinter ();
    
    // Create an instance of JtComposite. JtComposite inherits from JtPrototype (clone functionality).

    tree = (JtComposite) factory.createObject (JtComposite.JtCLASS_NAME);    
    
    // Add objects to the tree
        
    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(leaf1);     
    factory.sendMessage(tree, msg);
    
    msg.setMsgContent(leaf2);
    factory.sendMessage(tree, msg);
        
    branch = (JtComposite) factory.createObject (JtComposite.JtCLASS_NAME);  
    
    msg.setMsgContent(leaf3);
    factory.sendMessage(branch, msg);
    
    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(branch);
    factory.sendMessage(tree, msg);
    
    // Print the prototype tree (using XML)
    System.out.println(tree);
    factory.sendMessage(printer, tree);

    // Clone the object. In this case the tree is cloned
    
    aux = (JtComposite) factory.sendMessage(tree, new JtMessage (JtObject.JtCLONE));
    
    // Print the new tree (using XML)
    System.out.println(aux);
    factory.sendMessage(printer, aux);

    //factory.sendMessage (proto, new JtMessage ("JtTEST"));



  }

}


