
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */
package Jt;

/**
 * Jt Implementation of the Mediator pattern. Inherits functionality from
 * JtComponent.
 */

public class JtMediator extends JtComponent {



  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtMediator.class.getName(); 


  public JtMediator () {
  }



  /**
    * Process object messages. Let the superclasses handle JtComposite and JtThread related
    * messages.
    * <ul>
    * </ul>
    * @param message Message
    */

  public Object processMessage (Object message) {


     // Let the superclass handle JtComposite and JtThread related
     // messages.

     return (super.processMessage (message));              

  }

 
  /**
   * Demonstrates the messages processed by JtMediator
   */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();

    JtMediator mediator;

    // Create an instance of JtColletion

    mediator = (JtMediator) main.createObject (JtMediator.JtCLASS_NAME);




  }

}


