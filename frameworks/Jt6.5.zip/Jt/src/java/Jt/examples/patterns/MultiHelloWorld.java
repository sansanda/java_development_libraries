package Jt.examples.patterns;

import Jt.*;
import Jt.examples.swing.JtDialog;

/*
 * Demonstrates the use of JtChainOfResposibility. 
 * This implementation is able to handle multiple languages
 * by using the chain of reponsibility design pattern.
 */

public class MultiHelloWorld extends JtChainOfResponsibility {
  public static final String JtCLASS_NAME = MultiHelloWorld.class.getName(); 
  public static final String JtHELLO = "JtHELLO";

  private static final long serialVersionUID = 1L;

  private String greetingMessage;

  public MultiHelloWorld() {
  }

  private void showDialog () { 
      JtFactory factory = new JtFactory ();
      JtDialog dialog;

      dialog = (JtDialog) factory.createObject (JtDialog.JtCLASS_NAME, "dialog");
      dialog.setMessage("Hello World...");
      factory.sendMessage(dialog, new JtMessage (JtObject.JtACTIVATE));
  }
  
  // Process object messages

  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage msg = (JtMessage) message;
   //Object obj;
   JtFactory factory = new JtFactory ();


     if (msg == null)
	  return null;

     msgid = (String) msg.getMsgId ();

     if (msgid == null)
	  return null;


     if (msgid.equals (MultiHelloWorld.JtHELLO)) {

         if (greetingMessage == null)
             greetingMessage = "Hello World ...";
         showDialog ();
         return (greetingMessage);
     }
          
     if (msgid.equals (JtObject.JtREMOVE)) {
         return (null);     
     }

     // Unable to handle the request, let the successor process the request

     if (getSuccessor () == null) {
         handleError 
         ("JtChainOfResposibility.processMessage: last in the chain was unable to process message ID:" + msgid);
         return (null);
     }

     return (factory.sendMessage (getSuccessor (), message));


  }


  /**
   * Demontrates the use of JtChainOfResposibility. This version of 
   * HelloWorld is able to handle
   * additional languages.
   */ 


  public static void main(String[] args) {

    JtFactory factory = new JtFactory (); 
    JtChainOfResponsibility multiHelloWorld;


    // Creates an instance of the chain of responsibility
    
    multiHelloWorld = (JtChainOfResponsibility) factory.createObject (MultiHelloWorld.JtCLASS_NAME);
    
    // Defines a successor to handle the new messages (JtBonjour)
    
    multiHelloWorld.setSuccessor(new FrenchHelloWorld ());

    // Send a message to the chain
    
    factory.sendMessage (multiHelloWorld, new JtMessage (MultiHelloWorld.JtHELLO));

    factory.sendMessage (multiHelloWorld, new JtMessage (FrenchHelloWorld.JtBONJOUR));
    

  }

}



