package Jt.examples.patterns;

import Jt.*;
import java.util.*;


/**
 * Timer implementation. The timer runs in a separate
 * Thread. 
 */


public class TimerComponent extends JtComponent {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = TimerComponent.class.getName();   
    public static final String DISPLAY_TIME = "DISPLAY_TIME";
    private long tstart = 0L;        // t0
    private long tend;               // t1
    private double time;             // Elapsed time in seconds (delta)

    public TimerComponent() {
        //this.setSynchronous (false);   // asynchronous processing (separate thread). It can also
    	                                 // be added inside the constructor
    }


    // Attributes

    public double getTime () {
        return (time);
    }


    public void setTime (double time) {
        this.time = time;
    }

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        JtFactory factory = new JtFactory ();

        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        // Start timer

        // Display the time

        if (msgid.equals (TimerComponent.DISPLAY_TIME)) {

            if (tstart == 0L) 
                tstart = (new Date()).getTime ();  

            tend = (new Date ()).getTime ();
            time = (tend - tstart)/1000.0;
            System.out.println ("Timer:" + time);

            // Send a message to itself
            // Add another DISPLAY_TIME request to the message queue

            factory.setSynchronous(false);
            factory.sendMessage (this, new JtMessage (TimerComponent.DISPLAY_TIME));  
            //enqueueMessage (new JtMessage (Timer.DISPLAY_TIME));
            
            
            return (null);
        }




        // Let the superclass handle JtSTOP, JtREMOVE, etc

        if (message instanceof JtMessage) 
        	return (super.processMessage (message));         
        else {
        	handleError ("Invalid message:" + message);
        	return (null);
        }	


    }

    static private char waitForInputKey () {
        char c = ' ';

        try {

            c = (char) System.in.read ();
            while (System.in.available () > 0)
                System.in.read ();

        } catch (Exception e) {
            e.printStackTrace ();
        }

        return (c);
    }

    // Test program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        TimerComponent timer;


        // Create the component

        timer = (TimerComponent) main.createObject (TimerComponent.JtCLASS_NAME);
        timer.setSynchronous(false);  // Asynchronous processing of messages. 

        System.out.println ("Press any key to start/stop the timer ....");
        waitForInputKey (); 
        
        //main.sendMessage (timer, new JtMessage (JtObject.JtSTART)); // The START message may be sent
                                                                      // to start the component. It is not
                                                                      // required.

        // Start the timer using a separate/independent thread.
        // Messages are processed Asynchronously
        // via a message queue.

        main.setSynchronous(false);
        main.sendMessage (timer, new JtMessage (TimerComponent.DISPLAY_TIME));

        waitForInputKey ();    

        // Stop the timer

        //main.sendMessage (timer, new JtMessage (JtComponent.JtSTOP));// The STOP message may be sent to stop
                                                                       // the component.
        main.removeObject(timer); // This also stops the component

        //System.out.println (main.getValue ("timer", "time") + " second(s) elapsed");
        System.out.println (timer.getTime() + " second(s) elapsed");
  

    }

}



