package Jt.examples.patterns;

import Jt.*;
import Jt.examples.swing.JtDialog;


/**
 * Demonstrates the use of JtObservable. 
 */


public class Alarm extends JtObservable {

    public static final String JtCLASS_NAME = Alarm.class.getName();
    private static final long serialVersionUID = 1L;
    private long time;             // Elapsed time in milliseconds (delta)


    public Alarm() {
    }


    // Attributes

    public long getTime () {
        return (time);
    }


    public void setTime (long time) {
        this.time = time;
    }

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        //Object content;
        JtFactory factory = new JtFactory ();

        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        // Activate


        if (msgid.equals (JtObject.JtACTIVATE)) {


            // Log the message 
            //logMessage (msg);


            // Sleep before sending the notification

            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                handleException (e);
            }

            // Enqueue a message to notify the observers

            msg = new JtMessage (JtObservable.JtNOTIFY_OBSERVERS);
            msg.setMsgContent(new JtMessage (JtObject.JtACTIVATE)); // message to be sent to each observer
            //enqueueMessage (msg);
            factory.setSynchronous(false);
            factory.sendMessage (this, msg);  


            // Enqueue a message to stop the thread
            
            //enqueueMessage(new JtMessage (JtThread.JtSTOP));   
            factory.sendMessage (this, new JtMessage (JtThread.JtSTOP));  

            return (null);
        }


        return (super.processMessage (message));         

    }



    /**
     * Demonstrates the use of JtObservable. This program notifies the
     * user after a predetermined amount of time. A notification is sent
     * to the observer and a dialog pops up. 
     */
    
    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        JtDialog dialog = new JtDialog (); // Dialog box
        Alarm alarm;


        // Create the alarm

        alarm = (Alarm) main.createObject (Alarm.JtCLASS_NAME, "alarm");

        alarm.setdaemon(false); // user thread. It will keep running after this program exits.

        // Add an observer (dialog object). A dialog should pop up once
        // the time is up.

        msg = new JtMessage (JtObservable.JtADD_OBSERVER);
        dialog.setMessage("Time is up ....");
        msg.setMsgContent (dialog);
        main.sendMessage (alarm, msg);  
        
        alarm.setTime(4000L);   // Notify the observer(s) after 4 seconds

        // Activate the alarm

        main.setSynchronous(false);
        main.sendMessage (alarm, new JtMessage (JtObject.JtACTIVATE));
           

    }

}



