package Jt.examples.patterns;

import Jt.*;
import java.util.*;


/**
 * Timer implementation based on the Command pattern. The timer runs in a separate
 * Thread. 
 */


public class Timer extends JtCommand {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Timer.class.getName();   
    public static final String DISPLAY_TIME = "DISPLAY_TIME";
    private long tstart = 0L;        // t0
    private long tend;               // t1
    private double time;             // Elapsed time in seconds (delta)

    public Timer() {
        //this.setSynchronous (false);   // asynchronous processing (separate thread)
    }


    // Attributes

    public double getTime () {
        return (time);
    }


    public void setTime (double time) {
        this.time = time;
    }

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        JtFactory factory = new JtFactory ();

        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        // Start timer

/*
        if (msgid.equals (JtObject.JtSTART)) {

            tstart = (new Date()).getTime ();    

            // Log the message 
            logMessage (msg);


            // Let the superclass process JtSTART. A new thread is started
            // to process Jt messages.

            super.processMessage (message);

            // Start displaying the time

            enqueueMessage (new JtMessage (Timer.DISPLAY_TIME));
            return (null);
        }
*/

        // Display the time

        if (msgid.equals (Timer.DISPLAY_TIME)) {

            if (tstart == 0L) 
                tstart = (new Date()).getTime ();  

            tend = (new Date ()).getTime ();
            time = (tend - tstart)/1000.0;
            System.out.println ("Timer:" + time);

            // Send a message to itself
            // Add another DISPLAY_TIME request to the message queue
            factory.setSynchronous(false);
            factory.sendMessage (this, new JtMessage (Timer.DISPLAY_TIME));  

            //enqueueMessage (new JtMessage (Timer.DISPLAY_TIME));
            
            
            return (null);
        }




        // Let the superclass handle JtSTOP, JtREMOVE, etc

        return (super.processMessage (message));         


    }

    static private char waitForInputKey () {
        char c = ' ';

        try {

            c = (char) System.in.read ();
            while (System.in.available () > 0)
                System.in.read ();

        } catch (Exception e) {
            e.printStackTrace ();
        }

        return (c);
    }

    // Test program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        Timer timer;


        // Create the component

        timer = (Timer) main.createObject (Timer.JtCLASS_NAME);

        System.out.println ("Press any key to start/stop the timer ....");
        waitForInputKey (); 

        // Start the timer using a separate/independent thread.
        // Messages are processed Asynchronously
        // via a message queue.

        //main.sendMessage (timer, new JtMessage (JtObject.JtSTART));
        main.setSynchronous(false);
        main.sendMessage (timer, new JtMessage (Timer.DISPLAY_TIME));

        waitForInputKey ();    

        // Stop the timer

        main.sendMessage (timer, new JtMessage (JtComponent.JtSTOP));

        //System.out.println (main.getValue ("timer", "time") + " second(s) elapsed");
        System.out.println (timer.getTime() + " second(s) elapsed");
  

    }

}



