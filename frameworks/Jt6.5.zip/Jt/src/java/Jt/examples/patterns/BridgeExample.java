

package Jt.examples.patterns;

import Jt.JtBridge;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.examples.HelloWorld;
import Jt.xml.JtXMLHelper;


/**
 * Example of the use of JtBridge.
 */

public class BridgeExample  {



  public BridgeExample () {
  }


  /**
   * Demonstrates the use of JtBridge. It encodes
   * an object using two XML implementations.
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtBridge bridge;
    JtObject implementor;
    JtMessage msg;
    HelloWorld hello = new HelloWorld ();
    
    hello.setGreetingMessage("Hello World ...");

    // Create an instance of JtBridge

    bridge = (JtBridge) factory.createObject (JtBridge.JtCLASS_NAME);

    // Specify the implementor to be executed.

    implementor = (JtObject) factory.createObject (JtXMLHelper.JtCLASS_NAME);
    bridge.setImplementor(implementor);

    // Encode the object using the XML implemetor selected
    
    msg = new JtMessage (JtObject.JtXML_ENCODE); 
    msg.setMsgContent(hello);
    System.out.println ("Java encoding:" +  factory.sendMessage (bridge, msg));
    
    // Use a different encoding implementation (the one provided by JtFactory)
    
    bridge.setImplementor(new JtFactory ());
    
    System.out.println ("Jt encoding:" + factory.sendMessage (bridge, msg));
    


  }

}


