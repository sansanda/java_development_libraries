package Jt.examples.patterns;

import Jt.*;
import Jt.examples.HelloWorld;

/*
 * Demonstrates the use of JtDecorator
 */

public class DecoratedHelloWorld extends JtDecorator {

  public static final String JtCLASS_NAME = DecoratedHelloWorld.class.getName(); 
  public static final String JtHOLA = "JtHOLA";
  private static final long serialVersionUID = 1L;

  private String greetingMessage;

  public DecoratedHelloWorld() {
  }


  // Process object messages

  public Object processMessage (Object message) {

	  String msgid = null;
	  JtMessage msg;


	  if (message == null)
		  return null;

	  if (message instanceof JtMessage ) {
		  msg = (JtMessage) message;
		  
		  msgid = (String) msg.getMsgId ();

		  if (msgid == null)
			  return null;


		  // Process JtHOLA (new functionality/messages)

		  if (msgid.equals (DecoratedHelloWorld.JtHOLA)) {

			  if (greetingMessage == null)
				  greetingMessage = "Hola mundo ...";

			  handleTrace ("HelloWorld returning a greeting message: " +  greetingMessage);

			  return (greetingMessage);
		  }
	  }

	  // Original functionality 

	  return (super.processMessage(message));

  }


  // Demonstrates the use of JtDecorator. This version of HelloWorld is able to handle an
  // additional language.

  public static void main(String[] args) {

    JtFactory factory = new JtFactory (); 
    String reply;
    JtDecorator decorator;
    HelloWorld helloWorld = new HelloWorld ();

    // Create helloWorld (DecoratedHelloWorld class)

    decorator = (JtDecorator) factory.createObject (DecoratedHelloWorld.JtCLASS_NAME);
    decorator.setComponent(helloWorld) ; // Component to be decorated

    // Send the Message

    reply = (String) factory.sendMessage (decorator, new JtMessage (HelloWorld.JtHELLO));

    // Print the reply message (Greeting)

    System.out.println (reply); 
  
    // Try the new functionality provided by JtHOLA

    reply = (String) factory.sendMessage (decorator, new JtMessage (DecoratedHelloWorld.JtHOLA));

    // Print the reply message
    System.out.println (reply);   

    

  }

}



