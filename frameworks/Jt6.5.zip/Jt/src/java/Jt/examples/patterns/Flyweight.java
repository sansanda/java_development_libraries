

package Jt.examples.patterns;
import java.util.*;
import Jt.*;


/**
 * Demonstrates the use of Flyweight, Abstract Factory and State.
 */

public class Flyweight extends JtComponent {

    public static final String JtCLASS_NAME = Flyweight.class.getName(); 
    private static final long serialVersionUID = 1L;


  /**
    * Process object messages.
    * <ul>
    * </ul>
    * @param message Jt Message
    */


  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage e = (JtMessage) message;
   //Object content;
   //Object data;
   //JtMessage tmp;
   //JtInterface aux, aux1;
   


     if (e == null)
	return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	return null;

     //content = e.getMsgContent();
     //data = e.getMsgData ();

     // Remove this object
     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);     
     }

      
     return (super.processMessage (message));
     
  }

 
  /**
   * Main program. It 
   */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    SwitchFactory switchFactory;
    JtMessage msg;
    Vector switches;
    int i;
    JtState myswitch;


    JtFlyweight flyweightp;

    // Create instances of JtFlyweight and SwitchFactory

    flyweightp = (JtFlyweight) main.createObject (JtFlyweight.JtCLASS_NAME, "flyweight");
    switchFactory = (SwitchFactory) main.createObject 
      (SwitchFactory.JtCLASS_NAME, "switchFactory");
    main.setValue (flyweightp, "factory", switchFactory);


    // Manages and shares 100 flyweights (switches). Only two State 
    // instances are created.

    switches = new Vector ();

    msg = new JtMessage (JtFlyweight.JtGET_FLYWEIGHT);


    System.out.println ("Requesting and sharing  100 flyweights (switches) ...");

    for (i = 0; i <= 100; i++) {   
      if (i % 2 == 0) 
        msg.setMsgContent ("On");  
      else
        msg.setMsgContent ("Off");     
      myswitch = (JtState) main.sendMessage (flyweightp, msg); 
      switches.addElement (myswitch);
    }

    // Display the switches


    System.out.println ("Displaying the state of the 100 switches ...");

    for (i = 0; i <= 100; i++) {   
      myswitch = (JtState) switches.elementAt (i); 
            
      System.out.println ("Switch" + i + ":" + ((Switch) myswitch).getSwitchValue());

    }


    main.removeObject ("flyweight");


  }

}


