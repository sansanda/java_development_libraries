package Jt.examples.patterns;

import Jt.JtFacade;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.examples.HelloWorld;


/**
 * Demonstrates the use of JtFacade
 */

public class TestFacade extends JtFacade {

    public static final String JtCLASS_NAME = TestFacade.class.getName(); 

    private static final long serialVersionUID = 1L;


    public TestFacade () {
    }


    // Test the facade subsystems

    private boolean test () {
        String reply;
        JtFactory factory = new JtFactory ();
        String greeting;
        boolean status = true;
        

        HelloWorld helloWorld;

        helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME);

        if (helloWorld == null) {
            System.out.println ("createObject: FAIL");
            status = false;
        } else
            System.out.println  ("createObject: PASS");  


        factory.setValue (helloWorld, "greetingMessage", "Hi");

        greeting = (String) factory.getValue (helloWorld, "greetingMessage");

        if (!("Hi".equals (greeting))) {
            System.out.println  ("setValue/getValue: FAIL");
            status = false;
        } else
            System.out.println  ("setValue/getValue: PASS");    

        reply = (String) factory.sendMessage (helloWorld, new JtMessage (HelloWorld.JtHELLO) );

        if (!("Hi".equals (reply))) {
            System.out.println  ("sendMessage: FAIL");
            status = false;
        } else
            System.out.println  ("sendMessage: PASS"); 


        return (status);

    }

    /**
     * Process object messages.
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;



        if (msgid.equals (JtObject.JtTEST)) {
            return (new Boolean (test ()));     
        }

        return (super.processMessage (event));


    }


    /**
     * Implements a testing Facade to the Jt framework
     */


    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtFacade facade;
        Boolean status;

        // Create an instance of JtFacade

        facade = (JtFacade) factory.createObject (TestFacade.JtCLASS_NAME);

        // Test the Jt modules using the Facade
        
        status = (Boolean) factory.sendMessage (facade, new JtMessage (JtObject.JtTEST));

        if (!status.booleanValue()) {
            System.out.println ("TestFacade: one of more tests failed");
            System.exit (1);
        } 
  



    }


}


