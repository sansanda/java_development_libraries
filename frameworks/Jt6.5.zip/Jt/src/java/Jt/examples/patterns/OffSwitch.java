package Jt.examples.patterns;
import Jt.*;



/**
 * Demonstrates the use of the State pattern (see Flyweight.java).
 */


public class OffSwitch extends JtObject  {

    public static final String JtCLASS_NAME = OffSwitch.class.getName(); 
    //public static final String JtSWITCH_VALUE = "JtSWITCH_VALUE";
    private static final long serialVersionUID = 1L;
    private String switchValue = "Off";



    public OffSwitch () {
    }



    public String getSwitchValue() {
        return switchValue;
    }




    public void setSwitchValue(String switchValue) {
        //this.switchValue = switchValue;
    }



    /**
     * Process object messages. 
     * <ul>
     * </ul>
     * @param event Jt Message    
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        //Object content;
        //Object data;
        //JtMessage aux;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        //if (msgid.equals (OffSwitch.JtSWITCH_VALUE)) {
        //    return ("Off");     
        //}
        handleError ("processMessage: invalid message id:" + msgid);
        return (null);

    }


}
