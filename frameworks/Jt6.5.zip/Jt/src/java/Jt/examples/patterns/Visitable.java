package Jt.examples.patterns;

import Jt.*;


/**
 * Demonstrates the use of the Visitor design pattern.
 */


public class Visitable extends JtObject {



private static final long serialVersionUID = 1L;


public Visitable() {
  }


  /**
    * Process object messages. 
    * <ul>
    * <li>JtACCEPT - Accept operation. This message contains a reference to
    * the visitor (msgContent). As a result of this operation, a JtVISIT
    * message is sent to the visitor. A reference to this object is passed to the visitor.
    * </ul>
    * @param event Jt Message    
    */

  public Object processMessage (Object event) {

   String msgid = null;
   JtMessage e = (JtMessage) event;
   Object content;
   JtMessage aux;

     if (e == null)
	return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	return null;

     content = e.getMsgContent();

     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);     
     }
/*
     if (msgid.equals (JtObject.JtACCEPT)) {

       if (content == null) {
         handleError ("processMessage: invalid ACCEPT message; visitor reference is null");
         return (null);
       }

       // Send a JtVISIT message to the visitor.
       // Include a reference to this object

       aux = new JtMessage (JtVisitor.JtVISIT);
       aux.setMsgContent (this);
       return (sendMessage (content, aux));   
     }
*/
     return (super.processMessage (event));

  }


}
