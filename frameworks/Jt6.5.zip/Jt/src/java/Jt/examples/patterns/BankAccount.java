package Jt.examples.patterns;

import Jt.*;

/**
 * Example of the use of JtCommand
 */

public class BankAccount extends JtCommand {

    public static final String JtCLASS_NAME = BankAccount.class.getName();
    private static final long serialVersionUID = 1L;
    public static final String DEPOSIT = "DEPOSIT";
    public static final String WITHDRAWAL = "WITHDRAWAL";
    public static final String PRINT_TRANSACTIONS = "PRINT_TRANSACTIONS";   
    private double balance = 0;                // Account Balance

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public BankAccount () {
    }

    /**
     * Process object messages (Command requests).
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        Object content;
        JtPrinter printer = new JtPrinter ();

        if (msg == null)
            return null;

        // Retrieve Message ID and content

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        content = msg.getMsgContent();

        // Add a number to the total

        if (msgid.equals (BankAccount.DEPOSIT)) {

            balance += ((Double) content).doubleValue ();    

            // Log the message 
            logMessage (msg);  
            return (new Double (balance));
        }


        if (msgid.equals (BankAccount.WITHDRAWAL)) {

            balance -= ((Double) content).doubleValue ();    

            // Log the message 
            logMessage (msg);  
            return (new Double (balance));
        }
        
        
        if (msgid.equals (BankAccount.PRINT_TRANSACTIONS)) {

            
            //sendMessage (this.getMessageLog(), new JtMessage (JtObject.JtPRINT));
            printer.processMessage(this.getMessageLog());
            return (null);
        }
        

        // JtRemove message (Remove Object)

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);
        }

        return (super.processMessage(message));
    }



    /**
     * Bank Account implementation (main)
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        BankAccount account;

        // Create a BankAccount

        account = (BankAccount) main.createObject (BankAccount.JtCLASS_NAME);

        // Perform some transactions (operations on the account) 
        
        System.out.println ("Deposit: 500.1");
        msg =  new JtMessage (BankAccount.DEPOSIT);
        msg.setMsgContent (new  Double (500.1));      
        main.sendMessage (account, msg);
        System.out.println ("Balance:" + account.getBalance ());
        
        System.out.println ("Withdrawal: 200.1");
        msg =  new JtMessage (BankAccount.WITHDRAWAL);
        msg.setMsgContent (new  Double (200.1));
        main.sendMessage (account, msg);
        System.out.println ("Balance:" + account.getBalance ());

        // Print the log (list of transactions)

        System.out.println ("Transaction log:\n"); 
        main.sendMessage (account, new JtMessage (BankAccount.PRINT_TRANSACTIONS));

     

    }

}


