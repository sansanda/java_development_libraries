package Jt.examples.patterns;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Jt.*;


public class TemplateMethodExample extends JtTemplateMethod {

    public static final String JtCLASS_NAME = TemplateMethodExample.class.getName();   
    private static final long serialVersionUID = 1L;
    public static final String JtHELLO = "JtHELLO";

    private String greetingMessage;




    public TemplateMethodExample() {
    }

    // Attributes


    public void setGreetingMessage (String greetingMessage) {
        this.greetingMessage = greetingMessage; 

    }

    public String getGreetingMessage () {
        return (greetingMessage);
    }

    // show the greeting message

    private void showGreeting () {
        JOptionPane pane = new JOptionPane(greetingMessage);
        JDialog dialog = pane.createDialog(new JFrame(), "Dialog");
        dialog.show();
    }


    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;


        // Process JtHello Message

        if (msgid.equals (TemplateMethodExample.JtHELLO)) {

            if (greetingMessage == null)
                greetingMessage = "Hello World ...";

            showGreeting ();  
            return (greetingMessage);
        }

        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }

        //return (super.processMessage (message));
        handleError ("processMessage: invalid message id:" + msgid);
        return (null);

    }


    // Test program

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        JtTemplateMethod template;


        // Create an instance of JtTemplateMethod

        template = (JtTemplateMethod) factory.createObject (TemplateMethodExample.JtCLASS_NAME, "helloWorld");

        // Send JtHello

        factory.sendMessage (template, new JtMessage (TemplateMethodExample.JtHELLO));

        // Remove helloWorld

        factory.removeObject ("helloWorld");



    }

}



