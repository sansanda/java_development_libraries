package Jt.examples.patterns;
import Jt.*;



/**
 * Demonstrates the use of the State design pattern.
 */


public class Switch extends JtState {



    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Switch.class.getName();   
    public static final String FLIP_SWITCH = "FLIP_SWITCH";
    


    public String getSwitchValue() {
        Object temp;
        
        temp = getConcreteState ();
        
        if (temp == null)
            return (null);
        
        if (temp instanceof OffSwitch)
            return (((OffSwitch) temp).getSwitchValue());
        
        if (temp instanceof OnSwitch)
            return (((OnSwitch) temp).getSwitchValue());
        
        return (null);

    }




    public void setSwitchValue(String switchValue) {

    }




    public Switch () {
        this.setConcreteState(new OffSwitch ()); // Initial state - off
    }




    /**
     * Process object messages. 
     * <ul>
     * </ul>  
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;



        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (Switch.FLIP_SWITCH)) {
            if (this.getConcreteState() instanceof OffSwitch)
                this.setConcreteState(new OnSwitch ());
            else
                this.setConcreteState(new OffSwitch ());               
            return (null);     
        }

        return (super.processMessage(event));


    }

    /**
     * Demonstrates the use of the State design pattern.
     * The Switch class handles two possible states (OnSwitch and OffSwitch)
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        Switch mySwitch;


        // Create an instance of JtState (Switch)

        mySwitch = (Switch) factory.createObject (Switch.JtCLASS_NAME);

        // Set the concrete state (On Switch)

        mySwitch.setConcreteState(new OnSwitch ());

        
        System.out.println ("switch value: " + mySwitch.getSwitchValue());

        // Flip the switch

        factory.sendMessage(mySwitch, new JtMessage (Switch.FLIP_SWITCH));

        System.out.println ("flipping the switch: " +  mySwitch.getSwitchValue());

        factory.sendMessage(mySwitch, new JtMessage (Switch.FLIP_SWITCH));

        System.out.println ("flipping the switch: " + mySwitch.getSwitchValue());




    }
}
