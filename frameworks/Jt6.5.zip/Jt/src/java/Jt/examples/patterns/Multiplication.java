package Jt.examples.patterns;

import Jt.*;


/**
 * Calculator implementation based on Strategy. Refer to Calculator3.java
 */

public class Multiplication extends JtStrategy {



  private static final long serialVersionUID = 1L;
  public static final String MULTIPLY = "MULTIPLY";


  public Multiplication () {
  }


  /**
    * Process object messages (Command requests).
    */

  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage msg = (JtMessage) message;
   //Object content;

     if (msg == null)
	return null;

     // Retrieve Message ID and content

     msgid = (String) msg.getMsgId ();

     if (msgid == null)
	   return null;

     //content = msg.getMsgContent();

     // Let the superclass (JtStrategy) handle this message.
     // Strategy will forward the message to its concrete strategy.


     if (msgid.equals (Multiplication.MULTIPLY)) {

        return (super.processMessage (message)); 

     }


     // JtRemove message (Remove Object)

     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);
     }

     handleError ("Multiplication.processMessage: invalid message id:" + msgid);
     return (null);
  }


}



