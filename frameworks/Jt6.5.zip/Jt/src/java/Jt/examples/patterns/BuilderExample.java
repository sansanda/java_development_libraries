

package Jt.examples.patterns;

import Jt.JtBuilder;
import Jt.JtComposite;
import Jt.JtFactory;
import Jt.JtInterface;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;


/**
 * Demonstrates the use of the JtBuilder design pattern.
 */

public class BuilderExample extends JtBuilder {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = BuilderExample.class.getName();   

    
    public BuilderExample () {
    }

    private Object build () {
        Expression expression = new Expression ();
        JtMessage msg = new JtMessage (JtComposite.JtADD_CHILD);
        JtFactory factory = new JtFactory ();
        
        
        expression.setOperand ("+");
        
        msg.setMsgContent(new Integer (1));
        
        factory.sendMessage (expression, msg);
        
        msg.setMsgContent(new Integer (2));
        
        factory.sendMessage (expression, msg);
        
        return (expression);        
    }


    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }
        
        if (msgid.equals (JtBuilder.JtBUILD)) {
            return (build ());     
        }

        return (super.processMessage(event));

    }


    /**
     * Demonstrates the use of the JtBuilder design pattern.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtBuilder builder, builder1;
        JtInterface expression;
        JtPrinter printer = new JtPrinter ();


        // Create an instance of JtBuilder

        builder = (JtBuilder) factory.createObject (BuilderExample.JtCLASS_NAME);
              
        // Build the expression using a composite (tree representation)

        expression = (JtInterface) factory.sendMessage (builder, new JtMessage (JtBuilder.JtBUILD));

        //factory.sendMessage (expression, new JtMessage (JtObject.JtPRINT));
        factory.sendMessage (printer, expression);
        
        // Build the expression using another concrete builder (list representation)
        
        builder1 = (JtBuilder) factory.createObject (BuilderExample1.JtCLASS_NAME);
        
        expression = (JtInterface) factory.sendMessage (builder1, new JtMessage (JtBuilder.JtBUILD));
        factory.sendMessage (printer, expression);

        //factory.sendMessage (expression, new JtMessage (JtObject.JtPRINT));
        


    }


}


