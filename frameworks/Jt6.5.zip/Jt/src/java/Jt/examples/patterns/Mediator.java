
package Jt.examples.patterns;
import java.util.Iterator;
import java.util.List;

import Jt.*;

/**
 * Chat room implementation based on the Mediator pattern. Colleagues run in separate
 * threads. 
 */

public class Mediator extends JtMediator {

    public static final String JtCLASS_NAME = Mediator.class.getName(); 
    private static final long serialVersionUID = 1L;
    public static final String JOIN = "JOIN";
    public static final String MESSAGE = "MESSAGE";
    public static final String EXIT = "EXIT";

    public Mediator () {
    }


    private synchronized void broadcastMessageFrom (Object sender, Object msg)
    {
        Object obj;
        JtMessage msg1;
        JtFactory factory = new JtFactory ();
        Iterator iterator;
        List list;
        
        list = this.getList();
        
        if (msg == null || list == null)
            return;


        iterator = list.iterator();
        
        while (iterator.hasNext()) {
      	  
            obj = iterator.next ();  
            if (!(obj instanceof JtInterface)) {
          	  handleWarning ("Mediator.broadcast: unable to broadcast message to " + obj);
                continue;
            }    

            if (obj == sender)
            	continue;
            
            // Use asynchronous messaging
            factory.setSynchronous(false);
            factory.sendMessage (obj, msg);
        }


    }
    
    
    // Broadcast a message to all the members



    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message Message
     */


    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        JtMessage tmp;
        JtObject colleague;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();
        //data = e.getMsgData ();

        // Remove this object

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }


        // Join the chat room

        if (msgid.equals (Mediator.JOIN)) {



            colleague = (JtObject) e.getMsgContent ();       

            System.out.println ("Mediator: " + colleague + " has joined");
            tmp = new JtMessage (Mediator.MESSAGE);
            tmp.setMsgContent (colleague + " has joined");

            // Alert everyone about the new member

            broadcastMessageFrom (colleague, tmp);

            // Add the new member to the chat room

            tmp = new JtMessage (JtComposite.JtADD_CHILD);
            tmp.setMsgContent (e.getMsgContent ());
            //tmp.setMsgData (colleague.getObjName());
            processMessage (tmp);

            return (this);

        }    

        // Send a message to the chat room (everyone)

        if (msgid.equals (Mediator.MESSAGE)) {

            colleague = (JtObject) e.getMsgData ();  

            broadcastMessageFrom (colleague, e);     

            //System.out.println (colleague + ":" + content);
            return (this);

        }       

        // Exit the chat room

        if (msgid.equals (Mediator.EXIT)) {

            colleague = (JtObject) e.getMsgContent ();  

            tmp = new JtMessage (Mediator.MESSAGE);
            tmp.setMsgContent (colleague + " is exiting ...");

            broadcastMessageFrom (colleague, tmp);     

            System.out.println ("Mediator: " + colleague + " is exiting ...");

            tmp = new JtMessage (JtComposite.JtREMOVE_CHILD);
            tmp.setMsgData (e.getMsgFrom ());

            return (this);

        } 

        // Let the superclass handle all the other messages

        return (super.processMessage (message));


    }


    static private char waitForInputKey () {
        char c = ' ';

        try {

            c = (char) System.in.read ();
            while (System.in.available () > 0)
                System.in.read ();

        } catch (Exception e) {
            e.printStackTrace ();
        }

        return (c);
    } 

    // Demonstration program (Mediator design pattern)

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();

        JtMediator mediator;
        Colleague colleague1, colleague2, colleague3;

        System.out.println ("Press any key to start/stop the chat room demo ...");
        waitForInputKey (); 


        // Create an instance of the chat room

        mediator = (JtMediator) factory.createObject (Mediator.JtCLASS_NAME, "mediator");

        colleague1 = (Colleague) factory.createObject (Colleague.JtCLASS_NAME, "Jenny");
        factory.setValue (colleague1, "greetingMessage", "Hi folks! I'm Jenny. How are you all doing ?");


        // Use asyncronous messaging
        factory.setSynchronous(false);
        // Activate the first member

        factory.setValue (colleague1, "mediator", mediator);   
        factory.sendMessage (colleague1, new JtMessage (JtObject.JtACTIVATE));


        // Activate the second member

        colleague2 = (Colleague) factory.createObject (Colleague.JtCLASS_NAME, "Daniel");

        factory.setValue (colleague2, "mediator", mediator);   
        factory.setValue (colleague2, "greetingMessage", "Hi, I'm Daniel.");
        factory.sendMessage (colleague2, new JtMessage (JtObject.JtACTIVATE));


        // Activate the third member

        colleague3 = (Colleague) factory.createObject (Colleague.JtCLASS_NAME, "Mary");

        factory.setValue (colleague3, "mediator", mediator);   
        factory.setValue (colleague3, "greetingMessage", "Hi, I'm Mary.");
        factory.sendMessage (colleague3, new JtMessage (JtObject.JtACTIVATE));



        waitForInputKey (); 
        
        // Stop the independent threads
        factory.sendMessage (colleague1, new JtMessage (JtComponent.JtSTOP));
        factory.sendMessage (colleague2, new JtMessage (JtComponent.JtSTOP));
        factory.sendMessage (colleague3, new JtMessage (JtComponent.JtSTOP));
        
        factory.sendMessage (mediator, new JtMessage (JtComponent.JtSTOP));

    }

}


