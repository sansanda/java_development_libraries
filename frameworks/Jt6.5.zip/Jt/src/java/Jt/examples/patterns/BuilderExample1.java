

package Jt.examples.patterns;

import Jt.JtBuilder;
import Jt.JtFactory;
import Jt.JtList;
import Jt.JtMessage;
import Jt.JtObject;


/**
 * Demonstrates the use of the JtBuilder design pattern.
 */

public class BuilderExample1 extends JtBuilder {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = BuilderExample1.class.getName();   

    
    public BuilderExample1 () {
    }

    private Object build () {
        JtList expression = new JtList ();
        JtMessage msg = new JtMessage (JtList.JtADD);
        JtFactory factory = new JtFactory ();
        
        
        msg.setMsgContent(new Integer (1));
        
        factory.sendMessage (expression, msg);
        
        msg.setMsgContent("+");
        
        factory.sendMessage (expression, msg);
        
        msg.setMsgContent(new Integer (2));
        
        factory.sendMessage (expression, msg);
        
        return (expression);        
    }



    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }
        
        if (msgid.equals (JtBuilder.JtBUILD)) {
            return (build ());     
        }

        return (super.processMessage(event));

    }




}


