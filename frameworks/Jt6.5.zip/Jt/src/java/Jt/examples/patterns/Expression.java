

package Jt.examples.patterns;

import Jt.JtComposite;


/**
 * Expression
 */

public class Expression extends JtComposite {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Expression.class.getName();  
    private String operand;
    

    
    public Expression () {
    }



    public String getOperand() {
        return operand;
    }



    public void setOperand(String operand) {
        this.operand = operand;
    }

   

}


