

package Jt.examples.patterns;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtStrategy;
import Jt.examples.HelloWorld;
import Jt.xml.JtXMLHelper;


/**
 * Example of the use of JtStrategy.
 */

public class StrategyExample  {



  public StrategyExample () {
  }


  /**
   * Demonstrates the use of JtStrategy. It encodes
   * an object using two XML strategies.
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtStrategy strategy;
    JtXMLHelper concreteStrategy;
    JtMessage msg;
    HelloWorld hello = new HelloWorld ();
    
    hello.setGreetingMessage("Hello World ...");

    // Create an instance of JtStrategy

    strategy = (JtStrategy) factory.createObject (JtStrategy.JtCLASS_NAME);

    // Specify the concrete strategy to be executed.

    concreteStrategy = (JtXMLHelper) factory.createObject (JtXMLHelper.JtCLASS_NAME);
    strategy.setConcreteStrategy(concreteStrategy);

    // Encode the object using the XML strategy selected
    
    msg = new JtMessage (JtObject.JtXML_ENCODE); 
    msg.setMsgContent(hello);
    System.out.println ("Jt encoding:" +  factory.sendMessage (strategy, msg));
    
    // Use a different encoding strategy
    
    strategy.setConcreteStrategy(new JtFactory ());
    System.out.println ("Java encoding:" + factory.sendMessage (strategy, msg));
    


  }

}


