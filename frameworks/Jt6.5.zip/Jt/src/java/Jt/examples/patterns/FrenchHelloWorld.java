package Jt.examples.patterns;

import Jt.*;
import Jt.examples.swing.JtDialog;

/*
 * Demonstrates the use of JtChainOfResponsibility (see MultiHelloWorld.java)
 */

public class FrenchHelloWorld extends JtChainOfResponsibility {


  private static final long serialVersionUID = 1L;
  public static final String JtBONJOUR = "JtBONJOUR"; 

  private String greetingMessage;

  public FrenchHelloWorld() {
  }

  private void showDialog () { 
      JtFactory factory = new JtFactory ();
      JtDialog dialog;

      dialog = (JtDialog) factory.createObject (JtDialog.JtCLASS_NAME);
      dialog.setMessage(greetingMessage);
      factory.sendMessage(dialog, new JtMessage (JtObject.JtACTIVATE));
  }
  
  // Process object messages

  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage msg = (JtMessage) message;
   JtFactory factory = new JtFactory ();
   


     if (msg == null)
	  return null;

     msgid = (String) msg.getMsgId ();

     if (msgid == null)
	  return null;


     // Process JtBonjour

     if (msgid.equals (FrenchHelloWorld.JtBONJOUR)) {

        if (greetingMessage == null)
            greetingMessage = "Bonjour Monde ...";
        
        showDialog ();     
        return (greetingMessage);
     }
     
     if (getSuccessor () == null) {
         handleError 
         ("JtChainOfResposibility.processMessage: last in the chain was unable to process message ID:" + msgid);
         return (null);
     }

     return (factory.sendMessage (getSuccessor (), message));

  }


}



