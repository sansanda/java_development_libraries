package Jt.examples.patterns;

import Jt.*;


/**
 * Demonstrates the use of the Abstract Factory pattern (see Flyweight.java).
 */


public class SwitchFactory extends JtAbstractFactory {

    public static final String JtCLASS_NAME = SwitchFactory.class.getName(); 
    private static final long serialVersionUID = 1L;

    public SwitchFactory() {
    }

    /**
     * Process object messages. 
     * @param event Jt Message    
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        //Object content;
        String data;
        Switch output;
        JtFactory factory = new JtFactory ();


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();


        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtFlyweight.JtCREATE_FLYWEIGHT)) {
            data = (String) e.getMsgContent ();
            if (data == null) {
                handleError ("JtCREATE_FLYWEIGHT: invalid key");
                return (null);
            }

            if (data.equals ("On")) {
                //output = new OnSwitch ();
                output = (Switch) factory.createObject (Switch.JtCLASS_NAME, "On");
                output.setConcreteState(new OnSwitch ());
            } else {
                output = (Switch) factory.createObject (Switch.JtCLASS_NAME, "Off");
                output.setConcreteState(new OffSwitch ());
                //output = new OffSwitch ();
            }
            return (output);     
        }

        return (super.processMessage(event));
        //handleError ("processMessage: invalid message id:" + msgid);
        //return (null);

    }

}

