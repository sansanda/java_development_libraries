

package Jt.examples;

import java.util.Date;

import Jt.JtEcho;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.examples.Test;


/**
 * Echo the message received using XML format.
 */

public class Echo extends JtEcho {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Echo.class.getName(); 

    public Echo() {
    }




    /**
     * Demonstrates the messages processed by Echo.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        Echo echo;
        JtMessage msg = new JtMessage (JtObject.JtTEST);
        Test test = new Test ();



        // Create an instance of JtEcho

        echo = (Echo) main.createObject (Echo.JtCLASS_NAME);

        msg.setMsgContent(new Date ());
        msg.setMsgData(new Integer (10));
        main.sendMessage (echo, msg);
        
        // Message is an instance of Date
        
        main.sendMessage (echo, new Date ());

        // Message is an instance of Integer
        
        main.sendMessage (echo, new Integer (10));
        
        // Message is an instance of Test
        
	    test.setComments("<comments>");
	    test.setStatus(1);
	    test.setLongField (1L);
	    test.setShortField ((short) 1);
	    test.setC ('<');
	    //test.setDate(date);
	    test.setDoubleField(1.0);
	    test.setFlag(true);
	    test.setFloatField((float) 1.0);
	    test.setByteField((byte) 1);
	    
        main.sendMessage (echo, test);

    }

}


