/**
 * DateService - Class invoked via the Web service adapter and proxy. 
 * It returns the date & time
 */

package Jt.examples;
import java.util.*;
import Jt.*;


public class DateService extends JtObject {

    public static final String JtCLASS_NAME = DateService.class.getName(); 
    private static final long serialVersionUID = 1L;
    public static final String GET_DATE = "GET_DATE"; 
    public static final String GET_TIME = "GET_TIME"; 
    public static final String GET_DATE_TIME = "GET_DATE_TIME"; 
    public static final String DISPLAY_DATE = "DISPLAY_DATE"; // Return date (String form)


    public DateService() {
    }

    // Process object messages

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        JtList col;
        JtMessage msg;
        Date date;
        JtFactory factory = new JtFactory ();

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;



        if (msgid.equals (DateService.GET_DATE)) {
            return  (new Date ());             
        }


        if (msgid.equals (DateService.GET_TIME)) {             
            return (new Long ((new Date ()).getTime ()));
        }

        if (msgid.equals (DateService.DISPLAY_DATE)) {             
            return ((new Date ()).toString());
        }
        
        if (msgid.equals (DateService.GET_DATE_TIME)) {
            col = new JtList ();
            date = new Date ();

            msg = new JtMessage (JtList.JtADD);
            msg.setMsgContent(date);

            factory.sendMessage (col, msg);

            msg = new JtMessage (JtList.JtADD);
            msg.setMsgContent(new Long (date.getTime()));

            factory.sendMessage (col, msg);
            return (col);

        } 

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);
        }
        
        return (super.processMessage(event));
        //handleError ("DateService.processMessage: invalid message id:" + msgid);
        //return (null);

    }


    // Demo program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg1;
        DateService service;

        msg1 = new JtMessage ();


        msg1.setMsgId (DateService.GET_DATE);

        service = (DateService) main.createObject (DateService.JtCLASS_NAME);

        // Send JtMessage1

        System.out.println (main.sendMessage (service, msg1));





    }

}


