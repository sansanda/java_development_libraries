package Jt.examples;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import Jt.*;


public class SwingHelloWorld extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtHELLO = "JtHELLO"; 

    private String greetingMessage;

    public SwingHelloWorld() {
    }

    // Attributes


    public void setGreetingMessage (String greetingMessage) {
        this.greetingMessage = greetingMessage; 

    }

    public String getGreetingMessage () {
        return (greetingMessage);
    }


    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;


        // Process JtHello Message

        if (msgid.equals (SwingHelloWorld.JtHELLO)) {

            if (greetingMessage == null)
                greetingMessage = "Hello World ...";

            handleTrace ("HelloWorld returning a greeting message: " +  greetingMessage);

            return (greetingMessage);
        }

        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }

        return (super.processMessage (message));


    }


    // Test program

    public static void main(String[] args) {

        /*
      JFrame frame = new JFrame("HelloWorldSwing");
      JLabel label = new JLabel("Hello World");
      frame.getContentPane().add(label);


      label.setText ("good bye");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.pack();
      frame.setVisible(true);
      for (int i=1;i<5000;i++)
      label.setText ("good bye"+i);
         */


        String message = "William Shakespeare was born\n"
            + "on April 23, 1564 in\n" + "Stratford-on-Avon near London.";
        JOptionPane pane = new JOptionPane(message);
        JDialog dialog = pane.createDialog(new JFrame(), "Dialog");
        //dialog.show();
        for (int i=1;i<5000;i++) {
            pane.setMessage("good bye"+i);
            //dialog.setContentPane(pane);
            dialog.show ();
        }
    }


}



