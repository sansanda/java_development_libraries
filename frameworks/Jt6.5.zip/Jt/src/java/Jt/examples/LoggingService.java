package Jt.examples;


import Jt.*;
import Jt.security.JtAccessManager;
import Jt.security.Role;
import Jt.security.UserRole;

/**
 * Enable Logging
 */

public class LoggingService extends JtComponent {
    public static final String JtCLASS_NAME = LoggingService.class.getName(); 


    private static final long serialVersionUID = 1L;


    public LoggingService() {
    }

    
    private String retrieveUserRole (String userId) {
        UserRole userRole = new UserRole ();
        JtMessage msg = new JtMessage ();
        String roleId;
        JtFactory factory = new JtFactory ();

        if (userId == null)
            return (null);
        
        if (userId.equals(JtAccessManager.ADMIN_USER))
            return (Role.ADMINISTRATOR);
        
        msg.setMsgId (UserRole.RETRIEVE_USER_ROLE);
        msg.setMsgContent(userId);

        roleId = (String) factory.sendMessage(userRole, msg);
        
        handleTrace ("Logging.retrieveUserRole:" + roleId);

        if (roleId == null || roleId.equals(""))
            return (Role.USER);
        
        return (roleId);
    }
    
    private boolean checkAdminAccess (String userId) {
        
        String userRole;
        
        if (userId == null)
            return (false);
            
        userRole = retrieveUserRole (userId);
        
        if (Role.ADMINISTRATOR.equals(userRole)) {
            return (true);
        }
        
        return (false);
    }
    

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        JtContext context;
        JtFactory factory = new JtFactory ();
        JtLogger logger;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        /*
        context = (JtContext) msg.getMsgContext();
        if (context != null) {
            if (!checkAdminAccess (context.getUserName())) {
                handleError ("Access denied.");
                return (new Boolean (false));
            }
        } else {
            handleError ("Invalid Jt context. Please log in.");
            return (new Boolean (false));
        } 
        */ 

        // Process the JtLogger.JtENABLE_LOGGING Message
        // This service can be exposed to the outside world
        // via configuration files (Jt.properties)

        if (msgid.equals (JtLogger.JtENABLE_LOGGING) ||
        		msgid.equals (JtLogger.JtDISABLE_LOGGING)) {
 
        	logger = factory.getLogger();
        	
        	if (logger == null) {
        		handleError ("Logger component not found.");
        		return (new Boolean (false));
        	}	
        	
        	factory.sendMessage (logger, message);

            if (logger.getObjException() != null)
            	return (new Boolean (false));
            return (new Boolean (true));
        }

        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }
        

        handleError ("Invalid message Id:" + msgid);
        
        return (null);

    }




}



