/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.examples;


import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;



/**
 * Example of a Login Strategy
 */

public class LoginStrategy extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = LoginStrategy.class.getName(); 
    private String username;
	private String password;

    public LoginStrategy() {
    }


    public String getUsername() {
		return username;
	}




	public void setUsername(String username) {
		this.username = username;
	}

	
	
	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	private boolean login () {
		
		if (username == null) {
			handleError ("Invalid username attribute");
			return (false);
		}

		if (password == null) {
			handleError ("Invalid password attribute");
			return (false);
		}
		
		if (!username.equals("jt"))
			return (false);
		
		if (!password.equals("messaging"))
			return (false);		
		
		return (true);
	}
	
	
	  /**
	   * Process object messages.
	   * <ul>
	   * </ul>
	   */

	  public Object processMessage (Object message) {
	      JtMessage e = (JtMessage) message;
	      
	      String msgid;

	      if (e == null)
	          return null;

	      msgid = (String) e.getMsgId ();

	      if (msgid == null)
	          return null;

	      
	      if (msgid.equals (JtObject.JtACTIVATE))    	  
	    	  return new Boolean (login ());
	     
	      	      
	      handleError ("Invalid message Id:" + msgid);

	      return (null);

	  }
    /**
     * Demonstrates the messages processed by LoginStrategy.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        LoginStrategy login;
        JtMessage msg = new JtMessage (JtObject.JtACTIVATE);



        // Create an instance of JtEcho

        login = (LoginStrategy) factory.createObject (LoginStrategy.JtCLASS_NAME);

        
        login.setUsername("jt");
        login.setPassword("messaging");        
        
        factory.sendMessage (login, msg);
        

    }

}


