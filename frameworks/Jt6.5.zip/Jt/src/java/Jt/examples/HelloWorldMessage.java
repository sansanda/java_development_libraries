package Jt.examples;

import Jt.*;

/**
 * Demonstrates the Jt framework API.
 */

public class HelloWorldMessage extends JtObject {
    public static final String JtCLASS_NAME = HelloWorldMessage.class.getName(); 
    //public static final String JtHELLO = "JtHELLO"; 


    private static final long serialVersionUID = 1L;

    private String greetingMessage = "Hello World ... Welcome to Jt messaging!";

    public HelloWorldMessage() {
    }

    // Attributes


    public void setGreetingMessage (String greetingMessage) {
        this.greetingMessage = greetingMessage; 

    }

    public String getGreetingMessage () {
        return (greetingMessage);
    }


    // Process object messages

    public Object processMessage (Object message) {



        // Process the message

        if (message.equals("hi") || message.equals("hello"))
            return (greetingMessage);


        // Let the superclass handle all other messages
        return (super.processMessage (message));

    }


    /**
     * HelloWorld program. Demonstrates the use of the 
     * framework messaging API.
     * 1) JtFactory creates an instance of HelloWorld.
     * 2) Sends an message to the new instance and prints the reply.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        String reply;
        HelloWorldMessage helloWorld;

        
        // Create helloWorld (HelloWorldMessage class)

        helloWorld = (HelloWorldMessage) factory.createObject (HelloWorldMessage.JtCLASS_NAME);
        
        // Send the Message

        factory.handleTrace ("main:sending a message to the helloWorld object ...");
        reply = (String) factory.sendMessage (helloWorld, "hi");

        // Print the reply message (Greeting)
        
        System.out.println (reply);    



    }

}



