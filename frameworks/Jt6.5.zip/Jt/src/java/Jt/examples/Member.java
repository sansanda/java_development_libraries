package Jt.examples;

import Jt.*;


import java.util.*;
import java.text.*;

public class Member extends JtObject   {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Member.class.getName(); 
    private String email;
    private String firstname;
    private String lastname;
    private int status;
    private String subject;
    private String comments;
    private Date tstamp;
    private int email_flag;
    private Date mdate;
    private String location;

    public Member() {
    }

    public int getStatus () {
        return (status);
    }

    public void setStatus (int newStatus) {
        status = newStatus;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail (String newEmail) {
        email = newEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject (String newSubject) {
        subject = newSubject;
    }

    public String getComments() {
        return comments;
    }

    public void setComments (String newComments) {
        comments = newComments;
    }

    public void setFirstname (String newFirstname) {
        firstname = newFirstname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setLastname (String newLastname) {
        lastname = newLastname;
    }

    public String getLastname() {
        return lastname;
    }


    public void setTstamp (Date tstamp) {
        this.tstamp = tstamp;
    }

    public Date getTstamp () {
        return tstamp;
    }

    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param event message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //JtValueObject valueObj;
        //JtMessage msg;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);
        }
        
        if (msgid.equals (JtObject.JtVALUE_OBJECT)) { 
        	return (this);
        }

        return (super.processMessage(message));
        //handleError ("processMessage: invalid message id:" + msgid);
        //return (null);

    }

    // Demo program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        Date date = new Date ();
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
        JtPrinter printer = new JtPrinter ();
        Member member;


        member = (Member) main.createObject (Member.JtCLASS_NAME, "member");

        main.setValue ("member", "tstamp", df.format (date));

        printer.processMessage(member);
        
        main.setValue ("member", "tstamp", date);
        
        printer.processMessage(member);        


    }

    public int getEmail_flag() {
        return email_flag;
    }

    public void setEmail_flag(int email_flag) {
        this.email_flag = email_flag;
    }

    public Date getMdate() {
        return mdate;
    }

    public void setMdate(Date mdate) {
        this.mdate = mdate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


} 