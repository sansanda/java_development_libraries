package Jt.examples;

import Jt.*;

import java.text.DateFormat;
import java.util.*;


public class Test extends JtComponent   {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = Test.class.getName();    
    private String email;
    private String firstname;
    private int status;
    private String comments;
    private Date date;
    private boolean flag;
    private char c;
    private byte byteField;
    private short shortField;
    private long longField;
    private float floatField;
    private double doubleField;
    private String creditCard;
    private byte byteArray[];

    
    


    public Test() {
    }

    public int getStatus () {
        return (status);
    }

    public void setStatus (int newStatus) {
        status = newStatus;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail (String newEmail) {
        email = newEmail;
    }

    public String getComments() {
        return comments;
    }

    public void setComments (String newComments) {
        comments = newComments;
    }

    public void setFirstname (String newFirstname) {
        firstname = newFirstname;
    }

    public String getFirstname() {
        return firstname;
    }


    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public char getC() {
		return c;
	}

	public void setC(char c) {
		this.c = c;
	}

	public byte getByteField() {
        return byteField;
    }

    public void setByteField(byte byteField) {
        this.byteField = byteField;
    }

    public short getShortField() {
        return shortField;
    }

    public void setShortField(short i) {
        this.shortField = i;
    }

    public long getLongField() {
        return longField;
    }

    public void setLongField(long longField) {
        this.longField = longField;
    }


    public float getFloatField() {
        return floatField;
    }

    public void setFloatField(float floatField) {
        this.floatField = floatField;
    }

    public double getDoubleField() {
        return doubleField;
    }

    public void setDoubleField(double doubleField) {
        this.doubleField = doubleField;
    }

    public String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(String creditCard) {
        this.creditCard = creditCard;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    public byte[] getByteArray() {
		return byteArray;
	}

	public void setByteArray(byte[] byteArray) {
		this.byteArray = byteArray;
	}

	public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        Date date = new Date ();
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
        JtPrinter printer = new JtPrinter ();
        Test test, test1;
        String str = "Welcome to Jt messaging ...";


        test = (Test) main.createObject (Test.JtCLASS_NAME, "test");

        main.setValue ("test", "date", df.format (date));
        test.setByteArray(str.getBytes());

        printer.processMessage(test);
        
        main.setValue ("test", "date", date);
        
        printer.processMessage(test);   
        
        // Clone the component
        
        test1 = (Test) main.sendMessage(test, new JtMessage (JtComponent.JtCLONE));

        main.sendMessage(test1, new JtMessage (JtComponent.JtPRINT));
    }

} 