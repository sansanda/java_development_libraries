

package Jt.examples;

import Jt.JtComponent;
import Jt.JtEcho;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;


/**
 * Echo Service (demo)
 */

public class EchoService extends JtComponent {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = EchoService.class.getName(); 
    private String greeting = "greeting";


    public EchoService() {
    }

    
    public String getGreeting() {
		return greeting;
	}


	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}


	private Object componentLookup (Object id) {
    	JtFactory factory = new JtFactory ();
    	JtMessage msg;
    	Object obj;
    	
    	if (id == null)
    		return (null);
    	
    	msg = new JtMessage (JtFactory.JtLOOKUP);
    	msg.setMsgContent(id);
    	
    	obj = factory.processMessage(msg);
    	
    	return (obj);
    	
    }

    /**
     * Process component messages. Creates and registers jtEchoComponent.
     * This component/service echoes the incoming message. Nothing is done
     * if the component is already registered.
     */

    public Object processMessage (Object message) {
    	JtFactory factory = new JtFactory ();
    	
        String msgid = null;
        JtMessage e;
        Object obj;

        if (message == null)
            return null;

        e = (JtMessage) message;
        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        if (msgid.equals (JtComponent.JtACTIVATE)) {
        	

        	
        	if (componentLookup ("jtEchoComponent") != null) {
        		handleTrace ("Component already exists:" + "jtEchoComponent");
        		return (new Boolean (true));
        	}
        	
        	// Create and register the echo component.
        	
            obj = factory.createObject(JtEcho.JtCLASS_NAME, "jtEchoComponent");
            
            if (obj != null)
            	return (new Boolean (true));
            else
                return  (null);             
        }

        if (msgid.equals (JtObject.JtREMOVE)) {
        	// nothing to do
        	return (new Boolean (true));
        }
        
        handleError ("Invalid message:" + msgid);
        return (null);

    }


    /**
     * Demonstrates the messages processed by JtEcho.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        EchoService echoService;
        Object reply;
        JtPrinter printer = new JtPrinter ();




        // Create an instance of JtEcho

        echoService = (EchoService) factory.createObject (EchoService.JtCLASS_NAME);

        // Register the echo Component
        
        factory.sendMessage(echoService, new JtMessage (JtComponent.JtACTIVATE));
        
        // Send a message to the echo component
        
        reply =  factory.sendMessage("jtEchoComponent", "hello World");        

        factory.setValue(echoService, "greeting", "Welcome to messaging ...");
        //printer.processMessage(reply);
        
        reply = factory.getValue(echoService, "greeting");
        
        System.out.println ("greeting attribute:" + reply);
    }

}


