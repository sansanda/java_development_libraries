

//Illustrates the use of Jt Data Access Objects
// This class has been deprecated


package Jt.examples;

import Jt.*;
import Jt.DAO.JtDAOAdapter;
import Jt.xml.*;


import java.util.*;
import java.text.*;
import java.io.*;

public class DAOMembers extends JtDAO   {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = DAOMembers.class.getName(); 
    private String email;
    private String firstname;
    private String lastname;
    private int status;
    private String subject;
    private String comments;
    private Date tstamp;
    private int email_flag;
    private Date mdate;
    private String location;
    private long lval;
    private float fval;
    private double dval;
    private byte bval;
    private boolean booleanv;
    private transient JtFactory factory = new JtFactory ();

    public DAOMembers() {
    }

    public void setEmail_flag (int newEmail_flag) {
        email_flag = newEmail_flag;
    }

    public int getEmail_flag () {
        return (email_flag);
    }

    public int getStatus () {
        return (status);
    }


    public void setStatus (int newStatus) {
        status = newStatus;
    }

    public byte getBval () {
        return (bval);
    }

    public void setBval (byte bval) {
        this.bval = bval;
    }

    public long getLval () {
        return (lval);
    }

    public void setLval (long lval) {
        this.lval = lval;
    }

    public boolean getBooleanv () {
        return (booleanv);
    }

    public void setBooleanv (boolean booleanv) {
        this.booleanv = booleanv;
    }

    public float getfval () {
        return (fval);
    }


    public void setDval (double dval) {
        this.dval = dval;
    }

    public double getdval () {
        return (dval);
    }


    public void setFval (float fval) {
        this.fval = fval;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail (String newEmail) {
        email = newEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject (String newSubject) {
        subject = newSubject;
    }

    public String getComments() {
        return comments;
    }

    public void setComments (String newComments) {
        comments = newComments;
    }

    public void setFirstname (String newFirstname) {
        firstname = newFirstname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setLastname (String newLastname) {
        lastname = newLastname;
    }

    public String getLastname() {
        return lastname;
    }


    public void setTstamp (Date tstamp) {
        this.tstamp = tstamp;
    }

    public Date getTstamp () {
        return tstamp;
    }

    public void setMdate (Date mdate) {
        this.mdate = mdate;
    }

    public Date getMdate () {
        return mdate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation (String location) {
        this.location = location;
    }

    // ConfigFileExist - Verify if the configuration
    //                   file exists

    private boolean configFileExists (String configFile) {

        String fname;
        File file;

        //fname = (String) getValue (this, configFile);
        fname = configFile;

        if (fname == null)
            return false;

        file = new File (fname);
        return (file.exists ());
    }

    public void realize () {

        JtMessage msg;

        msg = new JtMessage ();

        // Set attribute/column mappings

        if (factory.getValue (this, "configFile") != null)
            return;

        // Use the following fallback mappings (attribute/column)
        // if the config file is not present

        handleWarning ("DAOMembers: config file (DAOMembers.xml) not found.");
        handleWarning ("DAOMembers: fallback mappings will be used.");
        factory.setValue (msg, "msgContent", "status");
        factory.setValue (msg, "msgData", "status");
        factory.setValue (msg, "msgId", "JtMAP_ATTRIBUTE");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "email");
        factory.setValue (msg, "msgData", "email");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "mdate");
        factory.setValue (msg, "msgData", "mdate");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "tstamp");
        factory.setValue (msg, "msgData", "tstamp");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "email_flag");
        factory.setValue (msg, "msgData", "email_flag");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "booleanv");
        factory.setValue (msg, "msgData", "booleanv");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "fval");
        factory.setValue (msg, "msgData", "fval");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "lval");
        factory.setValue (msg, "msgData", "lval");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "dval");
        factory.setValue (msg, "msgData", "dval");
        factory.sendMessage (this, msg);

        factory.setValue (msg, "msgContent", "bval");
        factory.setValue (msg, "msgData", "bval");
        factory.sendMessage (this, msg);

    }

    // processMessageEvent: process messages

    public Object processMessage (Object event) {
        String content;
        String query;
        JtMessage e = (JtMessage) event;


        if (e == null ||  (e.getMsgId() == null)) {
            handleError ("processMessage:invalid message:" +
                    e); 
            return (null);
        }
        // Let the superclass handle all the messages

        if (e.getMsgId().equals(JtDAO.JtREALIZE)) {
            super.processMessage (new JtMessage (JtDAO.JtREALIZE));
            //super.realize ();
            realize ();
            return (null);
        }

        return (super.processMessage (event));

    }

    // Test program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg, msg1;
        Integer count;
        Date date = new Date ();
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
        DAOMembers tmp, member;
        Exception ex;
        Object tmp1;
        File file;
        JtPrinter printer = new JtPrinter ();

        //main.setObjTrace (1);

        // Create DAO object

        member = (DAOMembers) main.createObject (DAOMembers.JtCLASS_NAME, "member");
        msg = (JtMessage) main.createObject (JtMessage.JtCLASS_NAME, "message");


        // Set database key and table

        main.setValue (member, "key", "email");
        main.setValue (member, "table", "members");

        file = new File ("DAOMembers.xml");

        if (file.exists ())
            main.setValue (member, "configFile", "DAOMembers.xml");


        // Realize object

        //main.setValue (msg, "msgId", "JtREALIZE");
        main.sendMessage (member, new JtMessage (JtDAO.JtREALIZE));

        // Set JDBC driver and url  

        main.setValue ("db", "driver", "com.mysql.jdbc.Driver");
        main.setValue ("db", "url", "jdbc:mysql://localhost/test");
        main.setValue ("db", "user", "root");
        main.setValue ("db", "password", "123456");



        //main.setValue ("member", "tstamp", "December 12, 2004");
        //main.setValue ("member", "tstamp", df.format (date));

        // Set attribute/column mappings


        //main.setValue (member, "status", "2005");
        //main.setValue (member, "fval", "3.1");


        main.setValue (member, "email", "user@freedom.com");
        main.setValue (member, "tstamp", new Date ());
        main.setValue (member, "status", "2005");
        main.setValue (member, "email_flag", "100");
        main.setValue (member, "lval", "300000");
        main.setValue (member, "fval", "3.1");
        main.setValue (member, "dval", "4.1");
        main.setValue (member, "bval", "1");
        main.setValue (member, "booleanv", "true");

        // Insert object

        //main.setValue (msg, "msgId", "JtINSERT");
        tmp = (DAOMembers) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtINSERT));

        if (tmp == null) { 
            System.out.println ("JtINSERT: FAIL");
        } else {
            System.out.println ("JtINSERT: PASS");
        }


        main.setValue (msg, "msgId", "JtCLEAR");
        main.sendMessage (member, msg);

        main.setValue (member, "email", "user@freedom.com");
        main.setValue (member, "key", "email");
        main.setValue (member, "table", "members");

        // Find object

        tmp = (DAOMembers) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtFIND));

        if (tmp != null)
            System.out.println ("JtFIND: PASS");
        else
            System.out.println ("JtFIND: FAIL");

        //main.sendMessage (member,  new JtMessage (JtObject.JtPRINT));


        main.setValue (member, "status", "2006");
        main.setValue (member, "email_flag", "101");

        // Update object

        tmp = (DAOMembers) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtUPDATE));


        if (tmp == null){ 
            System.out.println ("JtUPDATE: FAIL");
        } else  {
            System.out.println ("JtUPDATE: PASS");
        }

        main.setValue (msg, "msgId", JtDAOAdapter.JtCLEAR);
        main.sendMessage (member, msg);

        main.setValue (member, "email", "user@freedom.com");
        main.setValue (member, "key", "email");
        main.setValue (member, "table", "members");

        main.setValue (msg, "msgId", "JtFIND");
        tmp = (DAOMembers) main.sendMessage (member, msg);

        ex = (Exception) main.getValue (member, "objException");

        if (ex != null) {
            System.out.println ("JtFIND: FAIL");
        } else
            if (tmp == null)
                System.out.println ("JtFIND: FAIL");


        //main.sendMessage (member,  new JtMessage (JtObject.JtPRINT));
        printer.processMessage(member);

        main.setValue (member, "email", "user@freedom.com");
        //main.setValue ("member", "status", "2005");
        //main.setValue ("member", "email_flag", "100");

        //main.sendMessage ("member", "message");

        // Delete object

        tmp = (DAOMembers) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtDELETE));

        if (tmp == null){ 
            System.out.println ("JtDELETE: FAIL");
        } else {
            System.out.println ("JtDELETE: PASS");
        }

        main.sendMessage (member, new JtMessage (JtObject.JtREMOVE));

    }


} 