package Jt.examples;

import Jt.*;


public class SingletonHelloWorld extends JtSingleton {


  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = SingletonHelloWorld.class.getName(); 
  public static final String JtHELLO = "JtHELLO";

  private String greetingMessage;

  public SingletonHelloWorld() {
  }

  // Attributes


  public void setGreetingMessage (String greetingMessage) {
     this.greetingMessage = greetingMessage; 

  }

  public String getGreetingMessage () {
     return (greetingMessage);
  }


  // Process object messages

  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage msg = (JtMessage) message;


     if (msg == null)
	  return null;

     msgid = (String) msg.getMsgId ();

     if (msgid == null)
	  return null;


     // Process JtHello Message

     if (msgid.equals (SingletonHelloWorld.JtHELLO)) {

        if (greetingMessage == null)
            greetingMessage = "Hello World ...";
        
        handleTrace ("HelloWorld returning a greeting message: " +  greetingMessage);
             
        return (greetingMessage);
     }

     if (msgid.equals (JtObject.JtREMOVE)) {             
        return (null);
     }
      
     return (super.processMessage (message));
     //handleError ("HelloWorld.processMessage: invalid message id:" + msgid);
     //return (null);

  }


  // Test program

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();  // Jt Factory
    String reply;
    JtSingleton singleton, singleton1;


    // Create an instance of the singleton

    singleton = (JtSingleton) factory.createObject (SingletonHelloWorld.JtCLASS_NAME);
    
    // Attempt to create a second instance the singleton.
    // No new instance is created. createObject returns
    // the same instance.
    
    singleton1 = (JtSingleton) factory.createObject (SingletonHelloWorld.JtCLASS_NAME);

    
    if (singleton != singleton1)
        System.err.println ("Singleton creation: FAIL");
    else
        System.err.println ("Singleton creation: PASS");       

    // Send the Message

    reply = (String) factory.sendMessage (singleton1, new JtMessage (SingletonHelloWorld.JtHELLO));

    // Print the reply message (Greeting)
    
    System.out.println (reply);    

    // Remove helloWorld

    factory.removeObject (singleton1);

        

  }

}



