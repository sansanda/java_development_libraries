package Jt.examples.jms;

import Jt.*;
import Jt.jms.JtJMSAdapter;
import Jt.jms.JtJMSQueueAdapter;



//Demonstrates the use of JtJMSQueueAdapter (synchronous mode).
//Use the adapter to receive messages from the 
//JMS queue.

public class JMSReceiver  {


    // Test program (JMSQueue adapter)

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        Object msg;
        JtJMSQueueAdapter jmsAdapter;
        JtPrinter printer = new JtPrinter ();


        // Create the JMS adapter (point-to-point)

        jmsAdapter = (Jt.jms.JtJMSQueueAdapter) main.createObject 
        (JtJMSQueueAdapter.JtCLASS_NAME, "jmsAdapter");


        // Receive all the messages

        for (;;) {

            msg = (Object) main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtRECEIVE));

            if (msg == null) {
                System.out.println ("no more messages");
                break;
            } 

            printer.processMessage(msg);

        }


        // Remove jmsAdapter

        main.removeObject ("jmsAdapter");



    }

}



