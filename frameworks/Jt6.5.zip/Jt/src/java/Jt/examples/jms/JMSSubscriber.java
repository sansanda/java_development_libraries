package Jt.examples.jms;

import Jt.*;
import Jt.jms.JtJMSAdapter;
import Jt.jms.JtJMSTopicAdapter;


//Demonstrates the use of JtJMSTopicAdapter (JMS publish/subscriber adapter)

public class JMSSubscriber {



    // Demo program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtJMSTopicAdapter jmsAdapter;
        JtEcho echo = new JtEcho ();
        JtKeyboard keyboard = new JtKeyboard ();


        jmsAdapter = (JtJMSTopicAdapter) main.createObject 
        (JtJMSTopicAdapter.JtCLASS_NAME, "jmsAdapter");


        jmsAdapter.setSubject(echo); 
        main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtSTART_LISTENING));

        main.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));


        // Remove jmsAdapter

        main.removeObject ("jmsAdapter");



    }

}



