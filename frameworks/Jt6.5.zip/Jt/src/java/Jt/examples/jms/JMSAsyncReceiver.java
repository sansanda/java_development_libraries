package Jt.examples.jms;

import Jt.*;
import Jt.jms.JtJMSQueueAdapter;



//Demonstrates the use of JtJMSQueueAdapter (asynchronous mode).

public class JMSAsyncReceiver {




    // Test program

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtJMSQueueAdapter jmsAdapter;
        JtEcho echo = new JtEcho ();
        JtKeyboard keyboard = new JtKeyboard ();


        // Create the JMS adapter (point-to-point)

        jmsAdapter = (JtJMSQueueAdapter) main.createObject 
        (JtJMSQueueAdapter.JtCLASS_NAME, "jmsAdapter");

        // Asynchronous mode. Incoming messages will be redirected to echo

        jmsAdapter.setSubject(echo); 
        main.sendMessage (jmsAdapter, new JtMessage (JtJMSQueueAdapter.JtSTART_LISTENING));


        System.out.println ("Listening for asynchronous messages ... ");

        main.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));


        // Remove jmsAdapter

        main.removeObject ("jmsAdapter");



    }

}



