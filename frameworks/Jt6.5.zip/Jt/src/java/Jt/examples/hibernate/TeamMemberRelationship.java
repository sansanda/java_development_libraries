// Data Access Object


package Jt.examples.hibernate;

import Jt.*;


public class TeamMemberRelationship extends JtObject   {

private static final long serialVersionUID = 1L;
private long id;      // Team id 
private String email; // email


public TeamMemberRelationship() {
}


public long getId() {
    return id;
}


public void setId(long id) {
    this.id = id;
}


public void setEmail (String newFirstname) {
    email = newFirstname;
}

public String getEmail() {
    return email;
}


} 