package Jt.examples.hibernate;

import java.util.Date;
import java.util.List;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;



/**
  * Hibernate (DAO) example. It illustrates the use of the DAO strategy Adapter and
  * many-to-many associations. A team has several team members. A team member
  * can play for several teams. TeamMemberRelationship is used to model this many-to-many
  * relationship.
  */

public class HBDAOExample3 {
    
    
    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        //JtHibernateAdapter adapter;
        JtDAOStrategy adapter;
        int i;
        Member mem, mem1, mem2, tmem;
        Team team, team1;
        TeamMemberRelationship team_member, team_member1, team_member2, team_member3;
        List members;
        List teams;
        List teamMembers;
        Exception ex;

        
        // Create the DAO Strategy adapter

        //adapter = (JtHibernateAdapter) main.createObject (JtHibernateAdapter.JtCLASS_NAME);
               
        adapter = (JtDAOStrategy) main.createObject (JtDAOStrategy.JtCLASS_NAME);
        
        
        // Start a transaction
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));    

        // Team Members
        
        mem = new Member ();
        mem.setEmail("john@jt.net");
        mem.setFirstname("John");
        mem.setLastname("Doe");
        mem.setTstamp (new Date ());
        mem.setStatus(1);
     
        mem1 = new Member ();
        mem1.setEmail("daniel@jt.net");
        mem1.setFirstname("Daniel");
        mem1.setLastname("Doe");
        mem1.setTstamp (new Date ());
        mem1.setStatus(1);
        
        mem2 = new Member ();
        mem2.setEmail("lisa@jt.net");
        mem2.setFirstname("Lisa");
        mem2.setLastname("Doe");
        mem2.setTstamp (new Date ());
        mem2.setStatus(1);
        
        // Insert members
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(mem);
        main.sendMessage (adapter, msg);
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(mem1);
        main.sendMessage (adapter, msg);      
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(mem2);
        main.sendMessage (adapter, msg);   
        
                     
        // Insert Teams
        
        team = new Team ();
        team.setName("Team Blue");
        team.setId(1L);
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team);
        main.sendMessage (adapter, msg);    
        
        team1 = new Team ();
        team1.setName("Team Red");  
        team1.setId(2L);
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team1);
        main.sendMessage (adapter, msg); 
              
        
        //System.out.println ("id:" + team.getId());
        
        // Add members to the teams
        
        team_member = new TeamMemberRelationship ();
        team_member.setId(team.getId());
        team_member.setEmail(mem.getEmail());
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team_member);
        main.sendMessage (adapter, msg);    
        
        team_member1 = new TeamMemberRelationship ();
        team_member1.setId(team.getId());
        team_member1.setEmail(mem1.getEmail());
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team_member1);
        main.sendMessage (adapter, msg);   
        
        team_member2 = new TeamMemberRelationship ();       
        team_member2.setId(team1.getId());
        team_member2.setEmail(mem1.getEmail());
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team_member2);
        main.sendMessage (adapter, msg);   
        
        team_member3 = new TeamMemberRelationship ();        
        team_member3.setId(team1.getId());
        team_member3.setEmail(mem2.getEmail());
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(team_member3);
        main.sendMessage (adapter, msg);   
        
        
        ex = (Exception) adapter.getObjException();
        if (ex != null)
            main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtROLLBACK)); 
        else
            main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));           
          
        // Retrieve all the members from a team
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION)); 
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select r.email, r.firstname from team_member tm, roster r, team t where tm.id=t.id and tm.email = r.email and t.name = 'Team Blue'");
        msg.setMsgData(new Member ());
        members = (List) main.sendMessage (adapter, msg);
        
        
        if (members != null) {
            System.out.println("Count:" + members.size());
            for (i = 0; i < members.size(); i++) {

                Member theMember = (Member) members.get(i);
                if (theMember != null) {
                  System.out.println("Email: " + theMember.getEmail());
                  System.out.println("Name: " + theMember.getFirstname());
                }  
            }
        }
 
        // Retrieve all the team-member associations for Team blue.
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select tm.email, tm.id from team_member tm, team t where tm.id=t.id and t.name = 'Team Blue'");
        msg.setMsgData(new TeamMemberRelationship ());
        teamMembers = (List) main.sendMessage (adapter, msg);
        
        
        if (teamMembers != null) {
            System.out.println("Count:" + teamMembers.size());
            for (i = 0; i < teamMembers.size(); i++) {

                TeamMemberRelationship entry = (TeamMemberRelationship) teamMembers.get(i);
                
                // Retrieve a team member 
                
                msg = new JtMessage (JtDAOAdapter.JtREAD);
                msg.setMsgContent(new Member ());
                msg.setMsgData (entry.getEmail());
                tmem = (Member) main.sendMessage (adapter, msg);
                if (tmem != null) {
                  System.out.println("Email: " + tmem.getEmail());
                  System.out.println ("Name: " + tmem.getFirstname());
                }
            }
        }
 
        // Retrieve all the teams a member belongs to.
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select t.id, t.name from team_member tm, team t where tm.id=t.id and tm.email = 'daniel@jt.net'");
        msg.setMsgData(new Team ());
        teams = (List) main.sendMessage (adapter, msg);
        
        
        if (teams != null) {
            System.out.println("Count:" + teams.size());
            for (i = 0; i < teams.size(); i++) {

                Team theTeam = (Team) teams.get(i);
                if (theTeam != null) {
                  System.out.println("Team Id: " + theTeam.getId());
                  System.out.println("Team name: " + theTeam.getName());
                }
            }
        }
        
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));     
        
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));     
        
 
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team_member);
        main.sendMessage (adapter, msg); 
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team_member1);
        main.sendMessage (adapter, msg); 
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team_member2);
        main.sendMessage (adapter, msg); 
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team_member3);
        main.sendMessage (adapter, msg);        

        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team);
        main.sendMessage (adapter, msg); 
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(team1);
        main.sendMessage (adapter, msg); 
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(mem);
        main.sendMessage (adapter, msg);
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(mem1);
        main.sendMessage (adapter, msg);      
        
        msg = new JtMessage (JtDAOAdapter.JtDELETE);
        msg.setMsgContent(mem2);
        main.sendMessage (adapter, msg);   
       

     
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));        
        
        // Send a JtREMOVE message to the Hibernate adapter.
        // This closes the session and performs a cleanup (DB connection).
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtREMOVE));
        
        

        
      }
}
