package Jt.examples.hibernate;

import java.util.Date;
import java.util.List;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.hibernate.JtHibernateAdapter;


/**
  * Hibernate (DAO) example. It illustrates the use of the Hibernate Adapter.
  */

public class HBDAOExample {
    
    
    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        JtHibernateAdapter adapter;
        String emailId = "user@freedom.com"; // Key
        int i;
        Member mem;
        List members;

        
        // Create the Hibernate adapter

        adapter = (JtHibernateAdapter) main.createObject (JtHibernateAdapter.JtCLASS_NAME);
        

        // Member object
        
        mem = new Member ();
        mem.setEmail(emailId);
        mem.setFirstname("John");
        mem.setLastname("Daw");
        mem.setTstamp (new Date ());
        mem.setStatus(1);
     
        
        // Insert object
        
        msg = new JtMessage (JtDAOAdapter.JtCREATE);
        msg.setMsgContent(mem);
        main.sendMessage (adapter, msg);
            
        // Check if the object was inserted
        
        msg = new JtMessage (JtDAOAdapter.JtREAD);
        msg.setMsgContent(mem);
        msg.setMsgData (emailId);
        mem = (Member) main.sendMessage (adapter, msg);
        
        if (mem != null) {
            System.out.println("JtINSERT: GO");
            System.out.println("Email:" + mem.getEmail());
            System.out.println("Firstname:" + mem.getFirstname());
        } else
            System.out.println("JtINSERT: FAIL");           
        
       
        // Update the object

        if (mem != null)
            mem.setFirstname("Jane");
        msg = new JtMessage (JtDAOAdapter.JtUPDATE);
        msg.setMsgContent(mem);
        main.sendMessage (adapter, msg);

        
        // Check that the object was updated
        
        msg.setMsgId (JtDAOAdapter.JtREAD);
        msg.setMsgContent(mem);
        msg.setMsgData (emailId);
        mem = (Member) main.sendMessage (adapter, msg);
        
        if (mem != null) {          
            if ("jane".equals (mem.getEmail()))
                System.out.println("JtUPDATE: GO");               
            else 
                System.out.println("JtUPDATE: GO");
        } else
            System.out.println("JtUPDATE: FAIL");         
            
               
        mem = new Member ();
        mem.setEmail(emailId);
        
        // Delete the object

        msg = new JtMessage (JtDAOAdapter.JtDELETE);   
        msg.setMsgContent(mem);
        //msg.setMsgData(emailId);
        main.sendMessage (adapter, msg); 
 
 
        // Check that the object was deleted
        
        msg.setMsgId (JtDAOAdapter.JtREAD);
        msg.setMsgContent(new Member ());
        msg.setMsgData (emailId);
        mem = (Member) main.sendMessage (adapter, msg);
 
        
        if (mem == null) {           
            System.out.println("JtDELETE: GO");
        } else
            System.out.println("JtDELETE: FAIL");         
                      
        
        // Execute a SQL query
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select * from roster");
        msg.setMsgData(new Member ());
        members = (List) main.sendMessage (adapter, msg);
        
        
        if (members != null) {
            System.out.println("count:" + members.size());
            for (i = 0; i < members.size(); i++) {

                Member theMember = (Member) members.get(i);
                System.out.println("Email: " + theMember.getEmail() +
                                   "\nName: " + theMember.getFirstname());
            }
        }
      
        // Send a JtREMOVE message to the Hibernate adapter.
        // This closes the session and performs a cleanup (DB connection).
        
        main.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        
        msg.setMsgId (JtHibernateAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select * from history");
        msg.setMsgData(new History ());        
        
      }
}
