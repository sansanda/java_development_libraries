// Data Access Object


package Jt.examples.hibernate;

import java.util.*;

import Jt.JtObject;


public class Member extends JtObject {

private static final long serialVersionUID = 1L;
private String email;
private String firstname;
private String lastname;
private int status;
private String subject;
private String comments;
private Date tstamp;
private int email_flag;
private Date mdate;
private String location;


  public Member() {
  }

  public void setEmail_flag (int newEmail_flag) {
    email_flag = newEmail_flag;
  }

  public int getEmail_flag () {
    return (email_flag);
  }

  public int getStatus () {
    return (status);
  }


  public void setStatus (int newStatus) {
    status = newStatus;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail (String newEmail) {
    email = newEmail;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject (String newSubject) {
    subject = newSubject;
  }

  public String getComments() {
    return comments;
  }

  public void setComments (String newComments) {
    comments = newComments;
  }

  public void setFirstname (String newFirstname) {
    firstname = newFirstname;
  }

  public String getFirstname() {
    return firstname;
  }

  public void setLastname (String newLastname) {
    lastname = newLastname;
  }

  public String getLastname() {
    return lastname;
  }


  public void setTstamp (Date tstamp) {
    this.tstamp = tstamp;
  }

  public Date getTstamp () {
    return tstamp;
  }

  public void setMdate (Date mdate) {
    this.mdate = mdate;
  }

  public Date getMdate () {
    return mdate;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation (String location) {
    this.location = location;
  }


} 