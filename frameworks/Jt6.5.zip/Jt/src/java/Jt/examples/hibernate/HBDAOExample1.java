package Jt.examples.hibernate;

import java.util.Date;
import java.util.List;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;
import Jt.hibernate.JtHibernateAdapter;

/**
 * Hibernate (DAO) example1. It illustrates the use of the Hibernate Adapter. Composite keys
 * and manual transactions are used.
 */

public class HBDAOExample1 {
    

    
    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        //JtHibernateAdapter adapter;
        JtDAOStrategy adapter;
        String emailId = "member@hotmail.com";
        int i;
        History hist;
        List hists;
        Date dat = new Date ();
        Member mem = new Member ();
        Member temp = null;
        
        // Create the Hibernate adapter


        adapter = (JtDAOStrategy) main.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter = (JtHibernateAdapter) main.createObject (JtHibernateAdapter.JtCLASS_NAME);
        //adapter.setConcreteStrategyClassName("Jt.hibernate.JtHibernateAdapter");;

        
        msg = new JtMessage (JtDAOAdapter.JtREAD);
        msg.setMsgContent(mem);
        msg.setMsgData (emailId);
        temp = (Member) main.sendMessage (adapter, msg);
        
        if (temp == null) {
            System.out.println("Email:" + emailId + " is being inserted");
            mem.setEmail(emailId);
            mem.setFirstname("John");
            mem.setLastname("Daw");
            mem.setTstamp (new Date ());
            mem.setStatus(1);
            msg = new JtMessage (JtDAOAdapter.JtCREATE);
            msg.setMsgContent(mem);
            main.sendMessage (adapter, msg);
        }

        
        
        // Disable autocomit
        
        //adapter.setAutocommit(false);
        //((JtHibernateAdapter)adapter.getConcreteStrategy()).setAutocommit(false);
        main.setValue(adapter.getConcreteStrategy(), "autocommit", "false");
        
        // Start a transaction
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));                 

        hist = new History ();
        hist.setEmail(emailId);
        hist.setTstamp(dat);
        hist.setSubject("Subject");

        // Insert object
        
        msg = new JtMessage (JtDAOAdapter.JtINSERT);
        msg.setMsgContent(hist);
        main.sendMessage (adapter, msg);
            
        // Check if the object was inserted
        
        msg = new JtMessage (JtDAOAdapter.JtFIND);
        msg.setMsgContent(hist);
        msg.setMsgData (hist);
        hist = (History) main.sendMessage (adapter, msg);
        
        if (hist != null) {
            System.out.println("JtINSERT: GO");
            System.out.println(hist.getEmail());
            System.out.println(hist.getTstamp());
            //main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtROLLBACK));
            //System.exit (1);
        } else
            System.out.println("JtINSERT: FAIL");     
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));   
        
        // Update the object

        if (hist != null)
            hist.setSubject("NewSubject");
        msg = new JtMessage (JtDAOAdapter.JtUPDATE);
        msg.setMsgContent(hist);
        msg.setMsgData(hist);
        main.sendMessage (adapter, msg);

        
        // Check that the object was updated
        
        msg.setMsgId (JtDAOAdapter.JtFIND);
        msg.setMsgContent(hist);
        msg.setMsgData (hist);
        hist = (History) main.sendMessage (adapter, msg);
        
        if (hist != null) {          
            if ("NewSubject".equals (hist.getSubject()))
                System.out.println("JtUPDATE: GO");               
            else 
                System.out.println("JtUPDATE: GO");
        } else
            System.out.println("JtUPDATE: FAIL");      
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtBEGIN_TRANSACTION));   
        
        hist = new History ();
        hist.setEmail(emailId);
        hist.setTstamp(dat);
        
        // Delete the object

        msg = new JtMessage (JtDAOAdapter.JtDELETE);   
        msg.setMsgContent(hist);
        //msg.setMsgData(hist);
        main.sendMessage (adapter, msg); 
 
 
        // Check that the object was deleted
        
        msg.setMsgId (JtDAOAdapter.JtFIND);
        msg.setMsgContent(hist);
        msg.setMsgData (hist);
        hist = (History) main.sendMessage (adapter, msg);
 
        
        
        if (hist == null) {           
            System.out.println("JtDELETE: GO");
        } else
            System.out.println("JtDELETE: FAIL");     
        

        
        // Execute a SQL query
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent("select * from history");
        msg.setMsgData(new History ());
        
        
        
        hists = (List) main.sendMessage (adapter, msg);

        
        // Commit the changes
        
        main.sendMessage (adapter, new JtMessage (JtDAOAdapter.JtCOMMIT));
        
        if (hists != null) {
            System.out.println("count:" + hists.size());
            for (i = 0; i < hists.size(); i++) {

                History theHistory = (History) hists.get(i);
                System.out.println("Email: " + theHistory.getEmail());                
                System.out.println("Tstamp: " + theHistory.getTstamp());
                System.out.println("Subject: " + theHistory.getSubject());
            }
        }

        // Send a JtREMOVE message to the Hibernate adapter.
        // This closes the session.
        
        main.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        

        
      }
}
