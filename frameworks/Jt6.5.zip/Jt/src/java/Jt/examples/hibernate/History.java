// Data Access Object


package Jt.examples.hibernate;


import java.io.Serializable;
import java.util.*;


public class History implements Serializable   {

private static final long serialVersionUID = 1L;
private String email;
private String subject;
private String comments;
private Date tstamp;
private String location;

  public History() {
  }



  public String getEmail() {
    return email;
  }

  public void setEmail (String newEmail) {
    email = newEmail;
  }

  public String getSubject() {
    return subject;
  }

  public void setSubject (String newSubject) {
    subject = newSubject;
  }

  public String getComments() {
    return comments;
  }

  public void setComments (String newComments) {
    comments = newComments;
  }


  public void setTstamp (Date tstamp) {
    this.tstamp = tstamp;
  }

  public Date getTstamp () {
    return tstamp;
  }



  public String getLocation() {
    return location;
  }

  public void setLocation (String location) {
    this.location = location;
  }


  public boolean equals (Object other) {
      History h;
      if ((other == null) || !(other instanceof History))
         return false;
      h = (History) other;
      return (email.equalsIgnoreCase(h.email) && tstamp.equals(h.tstamp));
  }
  
  public int hashcode () {
      if (email != null)
        return (email + tstamp).hashCode();
      else
        return ("" + tstamp).hashCode();         
  }
  
   // processMessageEvent: process messages

  /*
  public Object processMessage (Object event) {
  //String content;
  //String query;
  JtMessage e = (JtMessage) event;


   if (e == null ||  (e.getMsgId() == null))
     return (null);

   if (!initted) {
     initted = true;
     //mapAttributes ();
   }

   if (e.getMsgId().equals("UPDATE_RECORD")) {
	updateRecord ();
	return (this);
   }

   
   if (e.getMsgId().equals("INPUT_RECORD")) {
		inputRecord ();
		return (this);
   }
    // Let the superclass handle all the messages

    return (super.processMessage (event));


  }
*/



  
  
  // Test program

  public static void main(String[] args) {



  }


} 