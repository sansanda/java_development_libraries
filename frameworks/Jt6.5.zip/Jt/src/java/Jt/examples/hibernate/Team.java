// Data Access Object


package Jt.examples.hibernate;

import Jt.*;
import java.util.*;


public class Team extends JtObject   {

private static final long serialVersionUID = 1L;
private long id;
private String name; // Team name
private Date tstamp;
private int status;
private String comments;


public Team() {
}


public long getId() {
    return id;
}


public void setId(long id) {
    this.id = id;
}


public int getStatus () {
    return (status);
  }


  public void setStatus (int newStatus) {
    status = newStatus;
  }


  public String getComments() {
    return comments;
  }

  public void setComments (String newComments) {
    comments = newComments;
  }

  public void setName (String newFirstname) {
    name = newFirstname;
  }

  public String getName() {
    return name;
  }


  public void setTstamp (Date tstamp) {
    this.tstamp = tstamp;
  }

  public Date getTstamp () {
    return tstamp;
  }




} 