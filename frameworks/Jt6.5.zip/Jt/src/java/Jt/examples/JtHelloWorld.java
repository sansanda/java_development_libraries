package Jt.examples;

import Jt.*;

/**
 * Demonstrates the Jt framework messaging API.
 */

public class JtHelloWorld implements JtInterface {
    public static final String JtCLASS_NAME = JtHelloWorld.class.getName(); 
    public static final int JtHELLO = 1;     
    private JtFactory factory = new JtFactory ();


    private static final long serialVersionUID = 1L;

    private String greetingMessage;

    public JtHelloWorld() {
    }

    // Attributes


    public void setGreetingMessage (String greetingMessage) {
        this.greetingMessage = greetingMessage; 

    }

    public String getGreetingMessage () {
        return (greetingMessage);
    }


    // Process object messages

    public Object processMessage (Object message) {

        Integer msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (Integer) msg.getMsgId ();

        if (msgid == null)
            return null;


        // Process the JtHELLO Message

        switch (msgid.intValue()) {
        case JtHELLO: 

        	if (greetingMessage == null)
        		greetingMessage = "Hello World ...";

        	factory.handleTrace ("HelloWorld returning a greeting message: " +  greetingMessage);

        	return (greetingMessage);
        default:
           	factory.handleError ("Invalid message Id: " +  msgid.intValue());

        }

        return (null);

    }


    /**
     * HelloWorld program. Demonstrates the use of the 
     * framework messaging API.
     * 1) JtFactory creates an instance of HelloWorld.
     * 2) Sends an message to the new instance and prints the reply. 
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        String reply;
        JtHelloWorld helloWorld;

        
        // Create helloWorld (HelloWorld class)

        helloWorld = (JtHelloWorld) factory.createObject (JtHelloWorld.JtCLASS_NAME);
        

        // Create a Message ("JtHELLO")

        JtMessage msg = new JtMessage (JtHELLO);
        
        // Send the Message

        factory.handleTrace ("main:sending a message (JtHello) to the helloWorld object ...");
        reply = (String) factory.sendMessage (helloWorld, msg);

        // Print the reply message (Greeting)
        
        System.out.println (reply);    


    }

}



