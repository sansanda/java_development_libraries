package Jt.examples.struts;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;

public class TeamMemberRelForm extends ActionForm {

    private String email;
    private long id;


    public String getEmail() {
        return (email);
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public long getId() {
        return (id);
    }

    public void setId(long id) {
        this.id=id;
    }

}
 
