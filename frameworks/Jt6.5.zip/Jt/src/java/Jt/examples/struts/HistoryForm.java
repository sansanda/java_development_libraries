package Jt.examples.struts;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;

public class HistoryForm extends ActionForm {

    private String comments;
    private String email;
    private String tstamp;
    private String subject;
    private String location;


    public String getComments() {
        return (comments);
    }

    public void setComments(String comments) {
        this.comments=comments;
    }

    public String getEmail() {
        return (email);
    }

    public void setEmail(String email) {
        this.email=email;
    }

    public String getTstamp() {
        return (tstamp);
    }

    public void setTstamp(String tstamp) {
        this.tstamp=tstamp;
    }

    public String getSubject() {
        return (subject);
    }

    public void setSubject(String subject) {
        this.subject=subject;
    }

    public String getLocation() {
        return (location);
    }

    public void setLocation(String location) {
        this.location=location;
    }

}
