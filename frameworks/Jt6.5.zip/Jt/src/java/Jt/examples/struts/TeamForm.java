package Jt.examples.struts;

import org.apache.struts.action.*;

public class TeamForm extends ActionForm {


private static final long serialVersionUID = 1L;
private String comments;
private String tstamp;
private int status;
private String name;
private long id;


public String getComments() {
  return (comments);
}

public void setComments(String comments) {
  this.comments=comments;
}

public String getTstamp() {
  return (tstamp);
}

public void setTstamp(String tstamp) {
  this.tstamp=tstamp;
}

public int getStatus() {
  return (status);
}

public void setStatus(int status) {
  this.status=status;
}

public String getName() {
  return (name);
}

public void setName(String name) {
  this.name=name;
}

public long getId() {
  return (id);
}

public void setId(long id) {
  this.id=id;
}

}
 
