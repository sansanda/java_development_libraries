package Jt.examples.struts;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;

public class MemberForm extends ActionForm {


private static final long serialVersionUID = 1L;
private String lastname;
private String comments;
private int email_flag;
private String objName;
private String firstname;
private String mdate;
private String email;
private String tstamp;
private String subject;
private int status;
private String location;


public String getLastname() {
  return (lastname);
}

public void setLastname(String lastname) {
  this.lastname=lastname;
}

public String getComments() {
  return (comments);
}

public void setComments(String comments) {
  this.comments=comments;
}

public int getEmail_flag() {
  return (email_flag);
}

public void setEmail_flag(int email_flag) {
  this.email_flag=email_flag;
}

public String getObjName() {
  return (objName);
}

public void setObjName(String objName) {
  this.objName=objName;
}

public String getFirstname() {
  return (firstname);
}

public void setFirstname(String firstname) {
  this.firstname=firstname;
}


public String getMdate() {
  return (mdate);
}

public void setMdate(String mdate) {
  this.mdate=mdate;
}


public String getEmail() {
    return (email);
}

public void setEmail(String email) {
    this.email=email;
}

public String getTstamp() {
    return (tstamp);
}

public void setTstamp(String tstamp) {
    this.tstamp=tstamp;
}


public String getSubject() {
  return (subject);
}

public void setSubject(String subject) {
  this.subject=subject;
}

public int getStatus() {
  return (status);
}

public void setStatus(int status) {
  this.status=status;
}

public String getLocation() {
  return (location);
}

public void setLocation(String location) {
  this.location=location;
}

}

