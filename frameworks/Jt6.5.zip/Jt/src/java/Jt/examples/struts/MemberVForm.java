package Jt.examples.struts;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;
import org.apache.struts.validator.ValidatorForm;

public class MemberVForm extends ValidatorForm {

private String lastname;
private String comments;
private String firstname;
private String email;
private String tstamp;
private String subject;
private int status;
private int email_flag;


public String getLastname() {
  return (lastname);
}

public void setLastname(String lastname) {
  this.lastname=lastname;
}

public String getComments() {
  return (comments);
}

public void setComments(String comments) {
  this.comments=comments;
}

public String getFirstname() {
  return (firstname);
}

public void setFirstname(String firstname) {
  this.firstname=firstname;
}

public String getEmail() {
  return (email);
}

public void setEmail(String email) {
  this.email=email;
}

public String getTstamp() {
  return (tstamp);
}

public void setTstamp(String tstamp) {
  this.tstamp=tstamp;
}

public String getSubject() {
  return (subject);
}

public void setSubject(String subject) {
  this.subject=subject;
}

public int getStatus() {
  return (status);
}

public void setStatus(int status) {
  this.status=status;
}

public int getEmail_flag() {
    return email_flag;
}

public void setEmail_flag(int email_flag) {
    this.email_flag = email_flag;
}

}
 
