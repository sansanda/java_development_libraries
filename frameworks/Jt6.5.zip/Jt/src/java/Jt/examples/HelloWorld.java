package Jt.examples;

import Jt.*;

/**
 * Demonstrates the Jt framework API.
 */

public class HelloWorld extends JtObject {
    public static final String JtCLASS_NAME = HelloWorld.class.getName(); 
    public static final String JtHELLO = "JtHELLO"; 


    private static final long serialVersionUID = 1L;

    private String greetingMessage;

    public HelloWorld() {
    }

    // Attributes


    public void setGreetingMessage (String greetingMessage) {
        this.greetingMessage = greetingMessage; 

    }

    public String getGreetingMessage () {
        return (greetingMessage);
    }


    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;


        // Process the JtHELLO Message

        if (msgid.equals (HelloWorld.JtHELLO)) {

            if (greetingMessage == null)
                greetingMessage = "Hello World ...";

            handleTrace ("HelloWorld returning a greeting message: " +  greetingMessage);

            return (greetingMessage);
        }

        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }
        // Let the superclass handle all other messages
        return (super.processMessage (message));

    }


    /**
     * HelloWorld program. Demonstrates the use of the 
     * framework messaging API.
     * 1) JtFactory creates an instance of HelloWorld.
     * 2) Sends an message to the new instance and prints the reply.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        String reply;
        HelloWorld helloWorld;

        
        // Create helloWorld (HelloWorld class)

        helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME);
        

        // Create a Message ("JtHELLO")

        JtMessage msg = new JtMessage (HelloWorld.JtHELLO);
        
        // Send the Message

        factory.handleTrace ("main:sending a message (JtHello) to the helloWorld object ...");
        reply = (String) factory.sendMessage (helloWorld, msg);

        // Print the reply message (Greeting)
        
        System.out.println (reply);    



    }

}



