package Jt.examples;

import Jt.*;
import Jt.DAO.JtDAOAdapter;

import java.util.*;
import java.io.*;


/**
  * Data Access Object (DAO) example. This subclass of JtDAO contains the 
  * attributes to be mapped to database columns. This class has been deprecated.
  * JtDAO is obsolete.
  */

public class DAOExample extends JtDAO   {
public static final String JtCLASS_NAME = DAOExample.class.getName();
private static final long serialVersionUID = 1L;
private String email;
private String name;
private int status;
private Date tstamp;
private boolean booleanv;
private transient JtFactory factory = new JtFactory ();


  public DAOExample () {
  }

  public int getStatus () {
    return (status);
  }


  public void setStatus (int newStatus) {
    status = newStatus;
  }

  public boolean getBooleanv () {
    return (booleanv);
  }

  public void setBooleanv (boolean booleanv) {
    this.booleanv = booleanv;
  }


  public String getEmail() {
    return email;
  }

  public void setEmail (String newEmail) {
    email = newEmail;
  }

  public void setName (String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }


  public void setTstamp (Date tstamp) {
    this.tstamp = tstamp;
  }

  public Date getTstamp () {
    return tstamp;
  }


  // ConfigFileExist - Verify if the configuration
  //                   file exists
/*
  private boolean configFileExists (String configFile) {

    String fname;
    File file;
 
    //fname = (String) getValue (this, configFile);
    fname = configFile;

    if (fname == null)
      return false;

    file = new File (fname);
    return (file.exists ());
  }
*/
  public void realizeObject () {

    JtMessage msg;

    msg = new JtMessage ();

    // Set attribute/column mappings

    if (factory.getValue (this, "configFile") != null)
      return;

    // Use the following fallback mappings (attribute/column)
    // if the config file is not present

    handleWarning ("DAOExample: config file (DAOExample.xml) not found.");
    handleWarning ("DAOExample: fallback mappings will be used.");
    factory.setValue (msg, "msgContent", "status");
    factory.setValue (msg, "msgData", "status");
    factory.setValue (msg, "msgId", JtDAOAdapter.JtMAP_ATTRIBUTE);
    factory.sendMessage (this, msg);

    factory.setValue (msg, "msgContent", "email");
    factory.setValue (msg, "msgData", "email");
    factory.sendMessage (this, msg);

    factory.setValue (msg, "msgContent", "name");
    factory.setValue (msg, "msgData", "name");
    factory.sendMessage (this, msg);

    factory.setValue (msg, "msgContent", "tstamp");
    factory.setValue (msg, "msgData", "tstamp");
    factory.sendMessage (this, msg);

    factory.setValue (msg, "msgContent", "booleanv");
    factory.setValue (msg, "msgData", "booleanv");
    factory.sendMessage (this, msg);

  }

  // processMessageEvent: process messages

  public Object processMessage (Object event) {
  //String content;
  //String query;
  JtMessage e = (JtMessage) event;


    if (e == null ||  (e.getMsgId() == null)) {
      handleError ("processMessage:invalid message:" +
        e); 
      return (null);
    }
    // Let the superclass handle all the messages

    if (e.getMsgId().equals(JtDAO.JtREALIZE)) {
        super.processMessage (new JtMessage (JtDAO.JtREALIZE));
	    realizeObject ();
        return (null);
    }

    return (super.processMessage (event));

  }

  // Test program

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtMessage msg = new JtMessage ();
    //Date date = new Date ();
    DAOExample tmp, member;
    Exception ex;
    //Object tmp1;
    File file;
    JtPrinter printer = new JtPrinter ();

    // Create DAO object

    member = (DAOExample) main.createObject (DAOExample.JtCLASS_NAME, "member");


    // Set database key and table

    main.setValue (member, "key", "email");
    main.setValue (member, "table", "members");

    file = new File ("DAOExample.xml");

    if (file.exists ())
      main.setValue (member, "configFile", "DAOExample.xml");


    // Realize object

    //main.setValue (msg, "msgId", "JtREALIZE");
    main.sendMessage (member, new JtMessage (JtDAO.JtREALIZE));

    // Set JDBC driver and url  
 
    main.setValue ("db", "driver", "com.mysql.jdbc.Driver");
    main.setValue ("db", "url", "jdbc:mysql://localhost/test");
    main.setValue ("db", "user", "root");
    main.setValue ("db", "password", "123456");

    // Set Object attributes

    main.setValue (member, "email", "user@freedom.com");
    main.setValue (member, "name", "John Dow");
    main.setValue (member, "tstamp", new Date ());
    main.setValue (member, "status", "2005");
    main.setValue (member, "booleanv", "true");


    // Insert object (object is added to the database)

    tmp = (DAOExample) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtCREATE));

    if (tmp == null) { 
      System.out.println ("JtCREATE: FAIL");
    } else {
      System.out.println ("JtCREATE: PASS");
    }


    main.setValue (member, "email", "user@freedom.com");
    main.setValue (member, "key", "email");
    main.setValue (member, "table", "members");

    // Find object

    tmp = (DAOExample) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtREAD));

    if (tmp != null)
      System.out.println ("JtREAD: PASS");
    else
      System.out.println ("JtREAD: FAIL");

    //main.sendMessage (member,  new JtMessage (JtObject.JtPRINT));
    printer.processMessage (member);
    
    main.setValue (member, "status", "2006");
    main.setValue (member, "name", "Jane Dow");
    main.setValue (member, "booleanv", "false");

    // Update object

    tmp = (DAOExample) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtUPDATE));


    if (tmp == null){ 
      System.out.println ("JtUPDATE: FAIL");
    } else  {
      System.out.println ("JtUPDATE: PASS");
    }

    main.setValue (member, "email", "user@freedom.com");

    main.setValue (msg, "msgId", JtDAOAdapter.JtREAD);
    tmp = (DAOExample) main.sendMessage (member, msg);

    ex = (Exception) main.getValue (member, "objException");

    if (ex != null) {
        System.out.println ("JtREAD: FAIL");
    } else
      if (tmp == null)
        System.out.println ("JtREAD: FAIL");


    //main.sendMessage (member,  new JtMessage (JtObject.JtPRINT));
    printer.processMessage (member);

    main.setValue (member, "email", "user@freedom.com");

    // Delete object

    tmp = (DAOExample) main.sendMessage (member, new JtMessage (JtDAOAdapter.JtDELETE));

    if (tmp == null){ 
      System.out.println ("JtDELETE: FAIL");
    } else {
      System.out.println ("JtDELETE: PASS");
    }

    // Remove the DAO. This closes the database connection

    main.sendMessage (member, new JtMessage (JtObject.JtREMOVE));

  }


} 