package Jt.examples;

import Jt.*;
import Jt.rest.JtRestService;


/**
 * Demonstrates the use of the JtRestProxy. This proxy provides transparent access to remote components
 * via RESTful services 
 */

public class RestServicesExample  {


    private static final long serialVersionUID = 1L;

    public RestServicesExample () {
    }


    public static void main(String[] args) {


		JtFactory factory = new JtFactory ();
		JtMessage msg; 
		String sReply;
		JtRestService service;
		//String url = "http://localhost:7001/JtBlankApp/JtRestService";
		String url = "http://localhost:8080/JtPortal/JtRestService";
		Boolean Bool;
		JtMessenger messenger;

		
		messenger = new JtMessenger ();
		// Create an instance of JtRestService

		service = (JtRestService) factory.createObject (JtRestService.JtCLASS_NAME);
		//service.setEncrypted(true);
		
		// Assign the URL for the REST service/resource

		service.setUrl(url);
		service.setClassname ("Jt.examples.EchoService");

		
		messenger.setEncrypted(true);
		
        // Invoke the remote service (Make the REST request to access the remote resource/service).
		
		msg = new JtMessage (JtObject.JtACTIVATE);
		Bool = (Boolean) messenger.sendMessage (service, msg);


	    if (Bool == null) {
	    	System.err.println("Unable to create/register echo component.");
	    	System.exit(1);	    	
	    }
	    
		service = (JtRestService) factory.createObject (JtRestService.JtCLASS_NAME);
		
		// Assign the URL for the REST service/resource

		service.setUrl(url);
		service.setRemoteComponentId("jtEchoComponent");
		//service.setEncrypted(true);

        // Invoke the remote service (Make the REST request to access the remote resource/service).
		
		sReply = (String) messenger.sendMessage (service, "Hello there ... Welcome to Jt messaging");

		System.out.println ("Reply:" + sReply);
 
		sReply = (String) messenger.sendMessage (service, "Echo this message ...");

		System.out.println ("Reply:" + sReply);

    }

}


