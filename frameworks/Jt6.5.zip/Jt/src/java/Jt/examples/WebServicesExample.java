package Jt.examples;

import java.util.Date;

import Jt.*;
import Jt.axis.JtAxisProxy;


/**
 * Demonstrates the use of the JtAxisProxy and the MDP distributed component model. 
 * MDP provides transparent access to remote components via an Axis adapter.  
 */

public class WebServicesExample  {


    private static final long serialVersionUID = 1L;
    public static final String GET_DATE = "GET_DATE"; 
    public static final String GET_DATE_TIME = "GET_DATE_TIME"; 

    public WebServicesExample () {
    }


    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        Date reply = null;
        Exception ex;
        JtMessage msg;
        JtList col;
        JtIterator iterator = null;
        Long time;
        JtAxisProxy proxy;
        Boolean Bool;
        String sReply;
        String url = "http://localhost:8080/axis/services/JtAxisService";
        JtMessenger messenger = new JtMessenger ();

       
        // Create a local instance of JtAxisProxy (references a remote component)
        
        proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
        
        // Set the service url property (if it is not present in the resource file)
        if (proxy.getUrl() == null)
        	proxy.setUrl("http://localhost:8080/axis/services/JtAxisService");
	    proxy.setClassname("Jt.examples.DateService");
	    
        
        // Send a message to the remote MDP component    

        reply = (Date) factory.sendMessage (proxy, new JtMessage (WebServicesExample.GET_DATE));
 
        ex = (Exception) proxy.getObjException();

        // Display the reply unless an exception is detected

        if (ex == null)    
            System.out.println ("Date:" + reply);
	
        // Request date and time
        
        msg = new JtMessage (WebServicesExample.GET_DATE_TIME);
        col = (JtList) factory.sendMessage (proxy, msg);


        ex = (Exception) proxy.getObjException();

        if (ex == null) {
            if (col != null)
                iterator = (JtIterator) col.getIterator();

            msg = new JtMessage (JtIterator.JtNEXT);

            if (iterator != null) {
                reply = (Date) factory.sendMessage (iterator, msg);

                System.out.println ("Date:" + reply);

                time = (Long) factory.sendMessage (iterator, msg);

                System.out.println ("Time:" + time);
            }
        }

        // Remove the local proxy. The remote component is removed as well.

        factory.removeObject (proxy);
        
        
        // Create another proxy
        
        proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
        
        // Set the service url property 
 
        proxy.setUrl(url);
	    proxy.setClassname("Jt.examples.EchoService"); // This component creates and registers jtEchoComponent

        
	    messenger.setEncrypted(true);
	    Bool = (Boolean) messenger.sendMessage (proxy, new JtMessage (JtObject.JtACTIVATE));

	    if (Bool == null) {
	    	System.err.println("Unable to create/register echo component.");
	    	System.exit(1);
	    	
	    }
               
        // Remove the local proxy. 

        factory.removeObject (proxy);
        
        // Create a proxy for jtEchoComponent
        
        proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
        
        // Set the service url property 
 
        proxy.setUrl(url);
		proxy.setRemoteComponentId("jtEchoComponent");
        

        // Send a secret message to the remote component (jtEchoComponent)
	    // Encrypted/secure messaging is used to communicate between
	    // this client and the remote component.
		
		messenger.setEncrypted(true);
		sReply = (String) messenger.sendMessage (proxy, "Hello there ... Welcome to Jt messaging");

		System.out.println ("Reply:" + sReply);
        
       
        // Remove the local proxy.

        factory.removeObject (proxy);

    }

}


