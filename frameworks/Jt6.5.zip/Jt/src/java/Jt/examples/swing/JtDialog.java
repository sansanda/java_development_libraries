package Jt.examples.swing;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import Jt.*;



public class JtDialog extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtDialog.class.getName(); 

    private String message;

    public JtDialog() {
    }

    // Attributes


    public void setMessage (String message) {
        this.message = message; 

    }

    public String getMessage () {
        return (message);
    }

    
    private void showDialog () {
        JOptionPane pane = new JOptionPane(message);
        JDialog dialog = pane.createDialog(new JFrame(), "Dialog");
        dialog.show();

    }

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;


        // Process JtHello Message

        if (msgid.equals (JtObject.JtACTIVATE)) {


            showDialog ();
            return (null);
        }

        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }

        return (super.processMessage (message));

    }


    // Test program

    public static void main(String[] args) {

      JtFactory factory = new JtFactory ();
      JtDialog dialog;

      dialog = (JtDialog) factory.createObject (JtDialog.JtCLASS_NAME);
      dialog.setMessage("Hello ...");
      factory.sendMessage(dialog, new JtMessage (JtObject.JtACTIVATE));
      
    }


}



