/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.bpel;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

//import com.sun.org.apache.xpath.internal.Expression;

import Jt.*;
import Jt.axis.JtAxisProxy;
import Jt.util.JtExpression;
import Jt.xml.JtSAXAdapter;
import Jt.xml.JtXMLElement;

/**
 * Jt BPEL Engine (revision 0.6). Implements Messaging Design Pattern (MDP) extensions.
 * Executes a BPEL business process.
 */

public class JtBPELEngine extends JtObject {
    public static final String JtCLASS_NAME = JtBPELEngine.class.getName(); 
    JtFactory factory = new JtFactory ();
    JtSAXAdapter saxAdapter = new JtSAXAdapter ();
    private boolean initialized = false;
    private boolean exited = false;
    private boolean exitOnException = true;
    private boolean debug = false;
    
    private HashMap partnerLinkTable = new HashMap ();
    private HashMap variableTable = new HashMap ();
    private HashMap variableClassTable = new HashMap ();
    //private HashMap componentTable = new HashMap ();
    private HashMap runtimeVariableTable = new HashMap ();
    
    public static final String PARTNER_LINK_ELEMENT = "bpel:partnerLink";
    public static final String PARTNER_LINKS_ELEMENT = "bpel:partnerLinks";
    
    
    public static final String VARIABLE_ELEMENT = "bpel:variable";
    public static final String VARIABLES_ELEMENT = "bpel:variables";
    
    public static final String PROCESS_ELEMENT = "bpel:process";
    
    public static final String INVOKE_ELEMENT = "bpel:invoke";
    public static final String ASSIGN_ELEMENT = "bpel:assign";
    public static final String EMPTY_ELEMENT = "bpel:empty";
    public static final String CATCH_ELEMENT = "bpel:catch";
    public static final String CATCHALL_ELEMENT = "bpel:catchAll";
    public static final String THROW_ELEMENT = "bpel:throw";
    public static final String RETHROW_ELEMENT = "bpel:rethrow";
    public static final String WHILE_ELEMENT = "bpel:while";
    public static final String COPY_ELEMENT = "bpel:copy";
    public static final String FROM_ELEMENT = "bpel:from";
    public static final String TO_ELEMENT = "bpel:to";
    public static final String IF_ELEMENT = "bpel:if";
    public static final String ELSEIF_ELEMENT = "bpel:elseif";
    public static final String ELSE_ELEMENT = "bpel:else";
    public static final String CONDITION_ELEMENT = "bpel:condition";   
    public static final String SEQUENCE_ELEMENT = "bpel:sequence";   
    public static final String REPEAT_UNTIL_ELEMENT = "bpel:repeatUntil";   
    public static final String EXIT_ELEMENT = "bpel:exit";   
    public static final String WAIT_ELEMENT = "bpel:wait";   
    public static final String FOR_ELEMENT = "bpel:for";   
  
    private static final long serialVersionUID = 1L;

    private String processDefinition;

    public JtBPELEngine() {
    }


    /**
     * Returns the XML file that contains the process definition.
     */
	  
	public String getProcessDefinition() {
		return processDefinition;
	}

    /**
     * Specifies the XML file that contains the process definition.
     */

	public void setProcessDefinition(String processDefinition) {
		this.processDefinition = processDefinition;
	}

	

	// Execute the BPEL process
	
    /**
     * .
     */
	
	public boolean isExitOnException() {
		return exitOnException;
	}

    /**
     * .
     */
	
	public void setExitOnException(boolean exitOnException) {
		this.exitOnException = exitOnException;
	}


	public boolean isDebug() {
		return debug;
	}


	public void setDebug(boolean debug) {
		this.debug = debug;
	}


	private Object executeProcess (Object message) {
		
		// Reserved variable jtMessage (input message)
		
        runtimeVariableTable.put("jtMessage", message);
        variableClassTable.put("jtMessage", message.getClass());
		
		// Parse the XML process definition file
		
	    factory.sendMessage(saxAdapter, new JtMessage (JtComponent.JtACTIVATE));	
	    
	    return (retrieveVariable ("jtReply"));
		
	}
	
	private boolean initialize () {
		
		if (processDefinition == null) {
			handleError ("processDefinition attribute needs to be set.");
			return (false);
		}
		
		exited = false;
		
        saxAdapter = (JtSAXAdapter) factory.createObject (JtSAXAdapter.JtCLASS_NAME);

        saxAdapter.setPath(processDefinition);
        
        saxAdapter.setDelegateComponent(this);
        
        // Reserved variable jtReply (output message)
        
        runtimeVariableTable.put("jtReply", null);
        variableClassTable.put("jtReply", Object.class);
        
		return (true);
		
	}
	
	
	private void updateVariable (String name, Object value) {
		JtXMLElement varElem;
		Class cl;
		
		
		if (name == null || name.equals(""))
			return;

		/*
		varElem = (JtXMLElement) variableTable.get (name);

		if (varElem == null) {
			handleError ("Invalid variable:" + name);
			return;
		}
        */
		
		cl = (Class) variableClassTable.get (name);
		
		if (cl == null) {
			handleError ("Invalid variable:" + name);
			return;			
		}
		
		if (value instanceof Integer) {
			
			// Conversion
			if (cl.getName().equals("java.lang.Long")) {
				runtimeVariableTable.put(name, new Long (((Integer) value).intValue()));
				return;
			}
		}
		if (value != null && !cl.isAssignableFrom(value.getClass())) {
			handleError ("Invalid value type (" + name + ") " + value.getClass());
			return;
		}
		
		runtimeVariableTable.put(name, value);
		
	}
	
	
	private boolean validateVariableName (String name) {
		
		JtXMLElement varElem;
		Object variable = null;
		
		if (name == null)
			return (false);
		
		variable = runtimeVariableTable.get(name);
		
		if (runtimeVariableTable.containsKey(name))
			return (true);
		
		varElem = (JtXMLElement) variableTable.get (name);

		if (varElem != null) {
			if (!initializeVariable (varElem))
				return (false);
			else
				return (true);
		}
		
		return (false);		
		
	}
	
	private Object retrieveVariable (String name) {
		
		JtXMLElement varElem;
		Object variable;
		
		if (name == null)
			return (null);
		
		variable = runtimeVariableTable.get(name);
		
		if (runtimeVariableTable.containsKey(name))
			return (variable);
		
		varElem = (JtXMLElement) variableTable.get (name);

		if (varElem != null) {
			initializeVariable (varElem);
			//handleError ("Invalid variable:" + name);
			//return (null);
		}
		
		return (runtimeVariableTable.get(name));
	}
	
	
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}
	
	private Object createComponent (String type) {
		String classname;
		Object component;
		
		if (type == null)
				return (null);
		
		if (type.startsWith("java:"))  // Support for Java components. Other languages can be supported.
			
			classname = type.substring(5);
		else
			classname = type;
		
		
		if (classname.equals("java.lang.Integer")) {
			return (new Integer (0));			
		}
		
		if (classname.equals("java.lang.Long")) {
			return (new Long (0));			
		}
		
		if (classname.equals("java.lang.Short")) {
			return (new Short ((short) 0));			
		}
		
		if (classname.equals("java.lang.Float")) {
			return (new Float (0.0));			
		}	
		
		if (classname.equals("java.lang.Double")) {
			return (new Double (0.0));			
		}		
		
		if (classname.equals("java.lang.Character")) {
			return (new Character ('\0'));			
		}	
		
		if (classname.equals("java.lang.Boolean")) {
			return (new Boolean (false));			
		}
		
		if (classname.equals("java.lang.Byte")) {
			return (new Byte ((byte) 0));			
		}
		
		
		
		component = factory.createObject(classname);
		
		if (propagateException (factory) != null)
			return (null);

		
		return (component);
		
	}
	
	private void processSubElements (JtXMLElement element, Exception ex) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			
			if (exited)
				return;
			
			if (this.getObjException() != null && exitOnException)
				return;
			
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);

			if (qName.equals(JtBPELEngine.CONDITION_ELEMENT)) //ignore condition
				continue;			
			
			//elemChild.processMessage(new JtMessage (JtComponent.JtPRINT));
			
			processActivity (elemChild, ex);
			
			if (exited)
				return;
			
			if (this.getObjException() != null && exitOnException)
				return;

			
		}
		return;		
		
	}
	
	
	private void processCatchSubElements (JtXMLElement element, Exception ex) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null || ex == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			
			if (exited)
				return;
			
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);


			if (this.getObjException() != null && exitOnException)
				return;
			
			processActivity (elemChild, ex);

			
		}
		return;		
		
	}
	
	private void processCatchAllElement (JtXMLElement elem, Exception ex) {
		if (elem == null || ex == null)
			return;
		
		processCatchSubElements (elem, ex);	
	}
	
	private boolean processCatchElement (JtXMLElement elem, Exception ex) {
		String faultType;
		//String faultVariable;
		Object fault;
		
		
		if (elem == null || ex == null)
			return (false);
		
		faultType = retrieveAttributeValue (elem, "faultMessageType");
		
		if (faultType == null || faultType.equals("")) {
			handleError ("Invalid catch element (missing/empty faultMessageType)");
			return (false);
		}
		
		fault = createComponent (faultType);
		
		if (fault == null) {
			handleError ("Unable to create fault class:" + faultType);
			return (false);
		}
		
		if (!fault.getClass().isAssignableFrom(ex.getClass()))
			return (false);

		//faultVariable = retrieveAttributeValue (elem, "faultVariable");
		
		// Add exception variable
		
		//if (faultVariable != null)
		//	runtimeVariableTable.put(faultVariable, ex);
			
		//System.out.println(fault);
		processCatchSubElements (elem, ex);	
		
		//if (faultVariable != null)
		//	runtimeVariableTable.remove(faultVariable);
		
		return (true);
	}
	
	private boolean invokeActivity (JtXMLElement elem) {
		//String partnerLinkName;
		//JtXMLElement partnerLink;
		Object component;
		String inputVariableName;
		String outputVariableName;
		String exceptionVariableName;
		Object message;
		Object reply;
		//String partnerLinkType;
		Exception ex;
		JtXMLElement catchElem;
		String componentName;
		String asynchronousAttribute;
		boolean asynchronousMode = false;
		
		if (elem == null)
			return (false);
		
		/*
		partnerLinkName = retrieveAttributeValue (elem, "partnerLink");
		
		if (partnerLinkName == null || partnerLinkName.equals("")) {
			handleError ("Invoke: partnerLink attribute is missing.");
			return (false);
		}
		
		
	    partnerLink = (JtXMLElement) partnerLinkTable.get(partnerLinkName);	
		
		if (partnerLink == null) {
			handleError ("Invalid partnerLink:" + partnerLinkName);
			return (false);
		}
		*/
		
		componentName = retrieveAttributeValue (elem, "component");
		
		if (componentName == null || componentName.equals("")) {
			handleError ("Invoke activity: component attribute is empty/missing.");
			return (false);
		}
		
		component = retrieveVariable (componentName);
	    
		if (component == null) {
			handleError ("Invoke activity: invalid component name (" + componentName + ")");
			return (false);
		}
		/*
		component = componentTable.get(partnerLinkName);
		
		if (component == null) {
			partnerLinkType =  retrieveAttributeValue (partnerLink, "partnerLinkType");
			
			if (partnerLinkType == null) {
				handleError ("Invoke: partnerLinkType attribute is missing.");
				return (false);
			}
			
			component = createComponent (partnerLinkType);
			
			if (component == null) {
				handleError ("Unable to create component:" +
						partnerLinkType);
				return (false);
			}
			
			componentTable.put(partnerLinkName, component);
			
		}
		*/
		
		
		inputVariableName = retrieveAttributeValue (elem, "inputVariable");
	
		if (inputVariableName == null || inputVariableName.equals("")) {
			handleError ("Invoke: inputVariable attribute is missing or mepty.");
			return (false);
		}
				
		
		message = retrieveVariable (inputVariableName);
		
		if (message == null) {
			handleError ("Invoke: invalid inputVariable (" + inputVariableName + ")");
			return (false);
		}
		
		
		asynchronousAttribute = retrieveAttributeValue (elem, "asynchronous");
		
		if (asynchronousAttribute != null) {
			if (!(asynchronousAttribute.equals("true") ||
				asynchronousAttribute.equals("false"))) {
				handleError ("Invoke: invalid asynchronous attribute (" + asynchronousAttribute + ")");
				return (false);
			}
			if (asynchronousAttribute.equals("true"))
				asynchronousMode = true;
		}
		

		factory.setSynchronous(!asynchronousMode);
			
		reply = factory.sendMessage(component, message);
		
		factory.setSynchronous(true); //check

		outputVariableName = retrieveAttributeValue (elem, "outputVariable");
		
		if (outputVariableName != null)
			updateVariable (outputVariableName, reply);
			//runtimeVariableTable.put(outputVariableName, reply);
		
		if (component instanceof JtProxy)
			ex = (Exception) ((JtProxy) component).getObjException();
		else
			ex = (Exception) factory.getValue (component, "objException");
		
		
		exceptionVariableName = retrieveAttributeValue (elem, "exception");
		
		if (exceptionVariableName != null)
			updateVariable (exceptionVariableName, ex);
			//runtimeVariableTable.put(exceptionVariableName, ex);
		
		if (ex == null)
			return (true);
		
		catchElem = getSubElement (elem, JtBPELEngine.CATCH_ELEMENT);
		
		if (catchElem == null)
			return (true);
		
		processCatchElements (elem, ex);
		
		
		return (true);
	}
	
	private String retrieveAttributeValue (JtXMLElement element, String attrName) {
		JtMessage msg = new JtMessage (JtXMLElement.JtGET_ATTRIBUTE);
		if (element == null || attrName == null)
			return (null);
		
		msg.setMsgContent(attrName);
		return ((String) element.processMessage(msg));
	}
	
	
	private JtXMLElement getSubElement (JtXMLElement element,
			String qName) {
		JtMessage msg = new JtMessage (JtXMLElement.JtGET_SUBELEMENT);
		
		if (element == null || qName == null)
			return (null);
		
		msg.setMsgContent(qName);
		return ((JtXMLElement) element.processMessage(msg));
		
	}
	
	
	private String retrieveVariableName (String expression) {
		int index;
		if (expression == null)
			return (null);
		
		index = expression.indexOf('.');
		if (index <= 0)
			return (expression);
		
		return (expression.substring(0, index));
	}
	
	private String retrieveAttributeName (String expression) {
		int index;
		if (expression == null)
			return (null);
		
		index = expression.indexOf('.');
		if (index <= 0)
			return (null);

		
		return (expression.substring(index + 1));
	}
	
	private String retrieveName (String qName) {
		int index;
		if (qName == null)
			return (null);
		
		index = qName.indexOf(':');
		
		return (qName.substring(index+1));
	}
	
	private boolean initializeVariable (JtXMLElement varElem) {
		String name;
		String type;
		Object tmp;
		
		if (varElem == null)
			return (false);
		
		name = retrieveAttributeValue (varElem, "name");
		
		if (name == null || name.equals("")) {
			handleError ("Invalid variable name (empty or null)");			
			return (false);
		}
		
		type = retrieveAttributeValue (varElem, "type");

		
		if (type == null || name.equals("")) {
			handleError ("Invalid variable type.");				
			return (false);
		}		
		type = retrieveName (type);
		type = type.trim();
		
		//if (type.equals("java.lang.Exception"))
		//	tmp = new Exception ();
		//	//tmp = new Integer (2);
		//else   
		tmp = createComponent(type);
		
		if (tmp == null)
			return (false);
		
		runtimeVariableTable.put(name, tmp);
		
		return (true);
	}
	
	
	private Object evaluateExpression (JtExpression exp) {

		JtMessage msg = new JtMessage (JtExpression.EVALUATE);
		JtMessage msg1 = new JtMessage (JtExpression.ADD_VARIABLE);
		Object res;
		Iterator iterator;
		String variableName;
		List variableList;
		

		if (exp == null)
			return (null);
		
		iterator = runtimeVariableTable.keySet().iterator();
		
		variableList = (List) exp.processMessage(new JtMessage (JtExpression.RETRIEVE_VARIABLES));
		
		
		iterator = variableList.iterator();
		
		while (iterator.hasNext()) {
			variableName = (String) iterator.next();
			
			if (variableName.startsWith("$")) 
				variableName = variableName.substring(1);
			
			if (!validateVariableName (variableName)) {
				handleError ("Invalid variable:" + variableName);
				return (null);
			}	
			handleTrace ("Adding variable:" + variableName, JtLogger.JtMIN_LOG_LEVEL);
			msg1.setMsgContent("$" + variableName);
			msg1.setMsgData(runtimeVariableTable.get(variableName));
			exp.processMessage(msg1);
			
		}
		
		
		//exp = new JtExpression ();
		
		//exp.setString(expression);
		
		/*
		while (iterator.hasNext()) {
			variableName = (String) iterator.next();
			handleTrace ("Adding variable:" + variableName, JtLogger.JtMIN_LOG_LEVEL);
			msg1.setMsgContent("$" + variableName);
			msg1.setMsgData(runtimeVariableTable.get(variableName));
			exp.processMessage(msg1);
		}
		*/
		
		res = factory.sendMessage(exp, msg);
		
		if (propagateException (exp) != null)
			return (null);
		
		return (res);
		
	}
	
	
	private Object processFromElement (JtXMLElement element) {
		JtExpression Exp;
		String exp;
		Object from;
		
		if (element == null) 
			return (null);		
		
		exp = element.getText();

		if (exp != null)
			exp = exp.trim();
		
		if (exp == null) {
			handleError ("Invalid from element (null)");
			return (null);
		}
		
		Exp = new JtExpression ();
		Exp.setString(exp);
		
		from = evaluateExpression (Exp);
		
		if (Exp.getObjException() != null)
			return (null);
		
		return (from);
		
	}
	
	private boolean copyActivity (JtXMLElement element) {
		JtXMLElement fromElem, toElem, varElem;
		Object from;
		String to;
		String variableName;
		Object variable;
		String attrName;
		String exp;
		Throwable ex = new Exception ();
		JtExpression Exp;

		if (element == null)
			return (false);

	
		fromElem = getSubElement (element, JtBPELEngine.FROM_ELEMENT);

		if (fromElem == null || fromElem.equals("")) {
			handleError ("Invalid copy activity (missing/empty from element).");
			return (false);
		}
		
		exp = fromElem.getText();

		if (exp != null)
			exp = exp.trim();
		
		if (exp == null || exp.equals("")) {
			handleError ("Invalid from element (null or empty)");
			return (false);
		}

		
		Exp = new JtExpression ();
		Exp.setString(exp);
		
		from = evaluateExpression (Exp);
		
		if (Exp.getObjException() != null)
			return (false);

		toElem = getSubElement (element, JtBPELEngine.TO_ELEMENT);

		if (toElem == null || toElem.equals("")) {
			handleError ("Invalid copy activity (missing/empty to element).");
			return (false);	

		}		
		to = toElem.getText();
		
		if (to != null)
			to = to.trim();
		
		if (to == null || to.equals("")) {
			handleError ("Invalid copy activity (missing/empty to element).");
			return (false);	
		}	
		
		if (to.startsWith("$"))
			to = to.substring(1);
		
		variableName = retrieveVariableName (to);

		variable = retrieveVariable (variableName);
		
		if (variable == null && !variableClassTable.containsKey(variableName)) {
			handleError ("Invalid copy activity (variable name:" + variableName + ") ");
			return (false);
		}
		
		//varElem = (JtXMLElement) variableTable.get (variableName);

		/*
		if (varElem == null) {
			handleError ("Invalid variable:" + variableName);
			return (false);
		}

		variable = runtimeVariableTable.get(variableName);

		if (variable == null)
			initializeVariable (varElem);
        */

		attrName = retrieveAttributeName (to);

		if (attrName == null || attrName.equals("")) {
			handleTrace ("Copy " + variableName + ":" + from);
			updateVariable (variableName, from);
			//runtimeVariableTable.put(variableName, from);
			return (true);
		}
		//variable = runtimeVariableTable.get(variableName);

		if (variable == null) {
			handleError ("variable points to null:" + variableName);
			return (false);
		}
		//handleTrace ("copyActivity (variable):" + variable.getClass());
		
		// check Proxies
		if (variable instanceof JtRemoteProxy) {

			if (attrName.equals("classname")) 
				((JtRemoteProxy) variable).setClassname ((String) from);
			else
				if (attrName.equals("url")) 
					((JtRemoteProxy) variable).setUrl ((String) from);
				else
					if (attrName.equals("remoteComponentId")) 
						((JtRemoteProxy) variable).setRemoteComponentId ((String) from);
					
			
		} else
			factory.setValue(variable, attrName, from);			

		return (true);

	}
	
	
	private void sequenceActivity (JtXMLElement element, Exception ex) {
				
		processSubElements (element, ex);
		
	}

	private void partnerLinks (JtXMLElement element) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);

			if (qName.equals(JtBPELEngine.PARTNER_LINK_ELEMENT))		
				partnerLink (elemChild);

			
		}
		return;		
		
	}
	
	private void processVariables (JtXMLElement element) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);

			if (qName.equals(JtBPELEngine.VARIABLE_ELEMENT))		
				processVariable (elemChild);

			
		}
		return;		
		
	}
	
	
	private void processCatchElements (JtXMLElement element, Exception ex) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null || ex == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			
			if (exited)
				return;
			
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);

			if (qName.equals(JtBPELEngine.CATCH_ELEMENT)) 
				if (processCatchElement (elemChild, ex))
					return;		

			if (this.getObjException() != null && exitOnException)
				return;
		}
		
		elemChild = getSubElement (element, JtBPELEngine.CATCHALL_ELEMENT);
		processCatchAllElement (elemChild, ex);
		return;		
		
	}
	
	private void processIfSubElements (JtXMLElement element) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);

			if (qName.equals(JtBPELEngine.CONDITION_ELEMENT)) //ignore condition
				continue;			
			
			if (qName.equals(JtBPELEngine.ELSEIF_ELEMENT))
				continue;

			
			if (qName.equals(JtBPELEngine.ELSE_ELEMENT)) 
				continue;

			if (this.getObjException() != null && exitOnException)
				return;

			processActivity (elemChild, null);

			if (exited) 
				return;
			
		}
		return;		
		
	}
	
	public boolean processElseIfSubElements (JtXMLElement element) {
		
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		
		if (element == null)
			return (false);
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("element(" + element.getQname() + "): no children");
			return (false);
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			
			
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid qualified name (null");
				return (false);
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);
			
			if (qName.equals(JtBPELEngine.ELSEIF_ELEMENT)) {
				if (processElseIfElement (elemChild)) {
					//handleTrace ("elseif succeeded.");
					return (true);
				}	
				continue;
			}

			
			if (qName.equals(JtBPELEngine.CONDITION_ELEMENT)) {
				continue;
				//Skip
			}

			//handleError ("Invalid element:" + qName);
		}
		
		elemChild = getSubElement (element, JtBPELEngine.ELSE_ELEMENT);
		processSubElements (elemChild, null);
		
		return (true);		
		
	}
	
	public boolean processElseIfElement (JtXMLElement element) {
		
		return (processIfElement (element));
	}
	
	//public void processElseElement (JtXMLElement element) {
		
	//	processSubElements (element);
	//}
	
	public boolean processIfElement (JtXMLElement element) {
		JtXMLElement conditionElem;
		String condition;
		Object result;
		JtExpression Exp;
		
		if (element == null)
			return (false);		
		conditionElem = getSubElement (element, JtBPELEngine.CONDITION_ELEMENT);
		
		if (conditionElem == null) {
			handleError ("Condition element is missing.");
			return (false);
		}
		
		condition = conditionElem.getText();
		
		if (condition == null || condition.equals("")) {
			handleError ("Invalid condition.");
			return (false);			
		}
		
		Exp = new JtExpression ();
		Exp.setString(condition);
		
		result = evaluateExpression (Exp);
		
		if (!(result != null && result instanceof Boolean)) { 
			handleError ("Invalid condition:" + condition);
		    return (false);			
		}
		
		if (!(((Boolean) result).booleanValue()))
			return (processElseIfSubElements (element));
			
		processIfSubElements (element);
		handleTrace ("True condition:" + condition);
		return (true);
			
	}
	
	
	private void processWhileElement (JtXMLElement element) {
		JtXMLElement conditionElem;
		String condition;
		Object result;
		JtExpression Exp;
		
		if (element == null)
			return;		
		conditionElem = getSubElement (element, JtBPELEngine.CONDITION_ELEMENT);
		
		if (conditionElem == null) {
			handleError ("condition element is missing.");
			return;
		}
		
		condition = conditionElem.getText();
		
		if (condition == null || condition.equals("")) {
			handleError ("Invalid condition element");
			return;			
		}

		
		for (;;) {
			
			Exp = new JtExpression ();
			Exp.setString(condition);
			
			result = evaluateExpression (Exp);
			
			if (!(result != null && result instanceof Boolean)) { 
				handleError ("Invalid condition:" + condition);
			    return;			
			}
			
			if (!(((Boolean) result).booleanValue()))
				return;

			if (exited)
				return;
			
			if (this.getObjException() != null && exitOnException)
				return;
			
			processSubElements (element, null);
			

		}
			
	}
	
	private void processExitElement (JtXMLElement element) {
		exited = true;
		
	}
	
	private void sleep (long time) {
		handleTrace ("sleeping ..." + time);
		try {
			Thread.currentThread().sleep(time);
		} catch (Exception ex) {
			handleException (ex);
		}
	}
	
	private void waitActivity (JtXMLElement element) {
		JtXMLElement elem;
		Integer period;
		
		if (element == null)
			return;
		
		elem = getSubElement (element, JtBPELEngine.FOR_ELEMENT);
		
		period = (Integer) processFromElement (elem);
		
		sleep (period.longValue());
		
	}
	
	
	private void processRepeatUntilElement (JtXMLElement element) {
		JtXMLElement conditionElem;
		String condition;
		Object result;
		JtExpression Exp;
		
		if (element == null)
			return;
		
		conditionElem = getSubElement (element, JtBPELEngine.CONDITION_ELEMENT);
		
		if (conditionElem == null) {
			handleError ("condition element is missing.");
			return;
		}
		
		condition = conditionElem.getText();
		
		if (condition == null || condition.equals("")) {
			handleError ("Invalid condition element (empty).");
			return;			
		}

		
		for (;;) {
			
			Exp = new JtExpression ();
			Exp.setString(condition);
			
			result = evaluateExpression (Exp);
			
			if (!(result != null && result instanceof Boolean)) { 
				handleError ("Invalid condition:" + condition);
			    return;			
			}
			

			if ((((Boolean) result).booleanValue()))
				return;

			processSubElements (element, null);
			
			if (exited)
				return;
			
			if (this.getObjException() != null && exitOnException)
				return;
		}
			
	}
	
	public void processAssignElement (JtXMLElement element) {
		JtMessage msg = new JtMessage (JtComposite.JtGET_CHILDREN);
		List list;
		Iterator iterator;
		JtXMLElement elemChild;
		String qName;
		boolean output;
		boolean bool = false;
		
		if (element == null)
			return;
		
		list = (List) element.processMessage(msg);
		
		if (list == null) {
			handleTrace ("Assign element:no children");
			return;
		}
		
		iterator = list.iterator();
		while (iterator.hasNext()) {
			
			if (this.getObjException() != null && exitOnException)
				return;
			
			elemChild = (JtXMLElement) iterator.next();
			
			qName = elemChild.getQname();
			
			if (qName == null) {
				handleError ("Invalid Element (Assign)");
				return;
			}
			handleTrace ("Child:" + elemChild.getQname(), JtLogger.JtMIN_LOG_LEVEL);
						
			if (qName.equals(JtBPELEngine.COPY_ELEMENT)) {
				copyActivity (elemChild);
				bool = true;
			}
			
		}
		
		if (!bool) 
			handleWarning ("Assign activity: copy element not found.");
		
		return;
	}
	
	
	public void rethrowActivity (JtXMLElement element, Exception ex) {
		if (element == null || ex == null)
			return;	
		
		try {
			throw (ex);
		} catch (Exception ex1) {
			handleException (ex1);			
		}				
		
	}

	public void throwActivity (JtXMLElement element) {
		String faultVariableName;
		Object faultVariable;
		
		if (element == null)
			return;	
		
		faultVariableName = retrieveAttributeValue (element, "faultVariable");
		
		if (faultVariableName == null || faultVariableName.equals("")) {
			handleError ("Invalid throw activity (missing/empty faultVariable).");
			return;
		}
		
		faultVariable = retrieveVariable (faultVariableName); 
		
		if (faultVariable == null) {
			handleError ("Invalid throw activity (faultVariable does not exist):" +
					faultVariableName);
			return;						
		}
		
		if (!(faultVariable instanceof Throwable)) {
			handleError ("Invalid throw activity (Exception type expected): " + faultVariable.getClass().getName());
			return;						
		}
		
		//faultVariable = new Exception ();
		
		try {
		//handleException ((Throwable) faultVariable);
			throw (new Exception (((Throwable) faultVariable).getMessage()));
		} catch (Exception ex) {
			handleException (ex);			
		}
		
	}
	
	public void processActivity (JtXMLElement element, Exception ex) {
		String qName;
		String name;
		
		if (element == null)
			return;
		
		if (exited) 
			return;
		
		
		handleTrace ("processElement:" + element.getQname());
			
		qName = element.getQname();
		

		if (qName.equals(JtBPELEngine.SEQUENCE_ELEMENT)) {
			sequenceActivity (element, ex);
			return;
		}
		
		if (qName.equals(JtBPELEngine.INVOKE_ELEMENT)) {			
			invokeActivity (element);			
			return;			
		}	
		
		if (qName.equals(JtBPELEngine.ASSIGN_ELEMENT)) {

			processAssignElement (element);
			
			return;
			
		}
		
		
		if (qName.equals(JtBPELEngine.IF_ELEMENT)) {

			processIfElement (element);
			
			return;
			
		}
		
		if (qName.equals(JtBPELEngine.WHILE_ELEMENT)) {

			processWhileElement (element);
			
			return;
			
		}
		
		if (qName.equals(JtBPELEngine.REPEAT_UNTIL_ELEMENT)) {

			processRepeatUntilElement (element);
			
			return;
			
		}
		
		if (qName.equals(JtBPELEngine.EXIT_ELEMENT)) {

			processExitElement (element);
			
			return;
			
		}
		
		if (qName.equals(JtBPELEngine.WAIT_ELEMENT)) {

			waitActivity (element);
			
			return;
			
		}
		
		
		if (qName.equals(JtBPELEngine.THROW_ELEMENT)) {			
			throwActivity (element);			
			return;			
		}	
		
		if (qName.equals(JtBPELEngine.RETHROW_ELEMENT)) {	
			
			if (ex == null) {
				handleError ("Rethrow activity must be inside a catch activity.");
				return;
			}	
			rethrowActivity (element, ex);			
			return;			
		}	
		
		if (qName.equals(JtBPELEngine.EMPTY_ELEMENT)) {					
			return;			
		}
		
		handleError ("Invalid activity:" + qName);
		
	}
	
	private void partnerLink (JtXMLElement element) {
		String name;
		
		if (element == null)
			return;
		
		name = (String) retrieveAttributeValue (element, "name");
		if (name == null || name.equals("")) {
			handleError ("Invalid attribute (name)");
			return;
		}	
		handleTrace ("partnerLink:" + name);
		partnerLinkTable.put(name, element);		
	}
	
	private void initializeFrom (Object component, String name, JtXMLElement fromElem) {
		Class cl;
		Object value;
		
		if (component == null || fromElem == null || name == null)
			return;
		
		//cl= component.getClass();
		cl = (Class) variableClassTable.get (name);
		
		if (cl == null) {
			handleError ("Invalid variable:" + name);
			return;			
		}
				
		
		value = processFromElement (fromElem);
		
		if (component instanceof JtMessage) {
			
			try {
				((JtMessage) component).setMsgId(value);
				runtimeVariableTable.put(name, component);	
				return;
			} catch (Exception ex) {
				handleError ("Invalid value type for msgId:" + value.getClass());
				return;
			}
		}
		
		if (value instanceof Integer) {
			
			// Conversion
			if (cl.getName().equals("java.lang.Long")) {
				runtimeVariableTable.put(name, new Long (((Integer) value).intValue()));
				return;
			}
		}
		if (value != null && !cl.isAssignableFrom(value.getClass())) {
			handleError ("Invalid value type (" + name + ") " + value.getClass());
			return;
		}
		
		runtimeVariableTable.put(name, value);		
	}
	
	private void processVariable (JtXMLElement element) {
		String name;
		String type;
		Object component;
		JtXMLElement fromElem;
		
		
		name = (String) retrieveAttributeValue (element, "name");
		if (name == null || name.equals("")) {
			handleError ("Invalid attribute (name)");
			return;
		}
		
		type = (String) retrieveAttributeValue (element, "type");
		if (type == null || type.equals("")) {
			handleError ("Invalid attribute (empty/missing type)");
			return;
		}		

		component = createComponent (type);
		
		if (component == null) {
			handleError ("Unable to create variable (" + name + "):" + type);
			return;
		}	
		
		
		variableClassTable.put(name, component.getClass());
		
		handleTrace ("variable:" + name);
		
		variableTable.put(name, element);
		
		fromElem = getSubElement (element, JtBPELEngine.FROM_ELEMENT);
		
		if (fromElem != null) {
			initializeFrom (component, name, fromElem);
		}
		
		return;	
	}
	
	
	public void BPELProcess (JtXMLElement element) {
		
		JtXMLElement childElem;
		
		if (element == null)
			return;
		
		childElem = getSubElement (element, JtBPELEngine.PARTNER_LINKS_ELEMENT);
		
		if (childElem != null)
			partnerLinks (childElem);
		
		childElem = getSubElement (element, JtBPELEngine.VARIABLES_ELEMENT);
		
		if (childElem != null)
			processVariables (childElem);		

		childElem = getSubElement (element, JtBPELEngine.SEQUENCE_ELEMENT);
		
		if (childElem != null)
			sequenceActivity (childElem, null);
		else
			handleTrace ("Empty process");
		
		
	}
	
	
	public void processElement (JtXMLElement element) {
		String qName;
		String name;
		
		if (element == null)
			return;
		
		if (exited)
			return;
		
		handleTrace ("processElement:" + element.getQname());
			
		qName = element.getQname();
		
		
		if (qName.equals(JtBPELEngine.PROCESS_ELEMENT)) {
			
			BPELProcess (element);
			
			return;
			
		}
	


	}
	
	
	   /**
	    * Process messages.
	    * <ul>
	    * </ul>
	    */


    public Object processMessage (Object message) {

        //String msgid = null;
        //JtMessage msg;


        if (message == null)
            return null;


        this.setObjException(null);
        
        if (!initialized) {
        	
        	initialized = initialize ();
        	
        	if (!initialized)
        		return (null);
        }

        /*
        if (message instanceof JtMessage) {
        	
            msg = (JtMessage) message;
            
            msgid = (String) msg.getMsgId ();

            if (msgid == null)
                return null;
        	
        	if (msgid.equals (JtComponent.JtACTIVATE)) {
        		executeProcess ();

        		return (new Boolean (true));
        	}

        	if (msgid.equals (JtObject.JtREMOVE))             
        		return (new Boolean (true));
        	
            handleError ("Invalid message Id:" + msgid);
            
            return (null);
        }
        */
        if (message instanceof JtXMLElement) {
        	processElement ((JtXMLElement) message);
        	
        	return (null);
        }

		return (executeProcess (message));

        //handleError ("Invalid message:" + message);
        //return (null);
        // Let the superclass handle all other messages
        //return (super.processMessage (message));

    }




    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        JtBPELEngine bpelEngine;
        Object reply;
        
    	String message = "http://www.google.com\n" +
        "http://www.yahoo.com\n"; 

        
        // Create JtBelpEngine instance

        bpelEngine = (JtBPELEngine) factory.createObject (JtBPELEngine.JtCLASS_NAME);
        
        if (args.length < 1) {
        	System.err.println ("Usage: java Jt.bpel.JtBELEngine processdefinition.xml");
        	return;
        }
        
        bpelEngine.setDebug(true);
        bpelEngine.setProcessDefinition(args[0]);

        
        // Send the Message to the process

        reply = factory.sendMessage (bpelEngine, message);

        // Prints the reply
        
        System.out.println("reply:" + reply);

    }

}



