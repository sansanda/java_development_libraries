

package Jt;
import java.util.*;


/**
 * Iterator over the elements of a Jt collection.
 */


public class JtIterator extends JtObject {

    public static final String JtCLASS_NAME = JtIterator.class.getName(); 
    private static final long serialVersionUID = 1L;
    private transient Iterator iterator;

    // Messages

    public static final String JtNEXT = "JtNEXT";
    public static final String JtREMOVE_CURRENT = "JtREMOVE_CURRENT";

    public JtIterator() {
    }



    /**
     * Void operation.
     */

    public void setIterator (Iterator iterator) {
        this.iterator = iterator; 
    }


    /**
     * Returns the Java Iterator.
     */

    public Iterator getIterator () {
        return (iterator);
    }


    private void removeCurrent () {
    	
    	
    	iterator.remove();
    }
    
    // next element

    private Object next () {
        if (iterator == null) // check
            return (null);
        if (iterator.hasNext()) {
            return (iterator.next ());
        }

        return (null);
    }

    /**
     * Process object messages.
     * <ul>
     * <li>JtNEXT - returns the next element in the iteration
     * </ul> 
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtIterator.JtNEXT)) {
            return (next ());
        }     
        
        if (msgid.equals (JtIterator.JtREMOVE_CURRENT)) {
        	removeCurrent ();
            return (null);
        } 

        return (super.processMessage (event));          


    }


    /**
     * Demonstrate the messages processed by JtIterator.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtMessage msg;
        JtIterator it;
        Integer intObj;
        JtCollection collection;

        // Create a JtColletion

        collection = (JtCollection) factory.createObject (JtCollection.JtCLASS_NAME);

        msg = new JtMessage (JtCollection.JtADD);  

        // Add objects to the collection

        msg.setMsgContent (new Integer(1));
        factory.sendMessage (collection, msg);

        msg.setMsgContent (new Integer(2));       
        factory.sendMessage (collection, msg);

        // Retrieve the iterator associated with the collection

        it = collection.getIterator();


        msg = new JtMessage (JtIterator.JtNEXT);

        // Traverse the collection using the iterator (JtNEXT message)

        while ((intObj = (Integer) factory.sendMessage (it, msg)) != null) {
            System.out.println ("Object=" + intObj);
            
            factory.sendMessage (it, new JtMessage (JtIterator.JtREMOVE_CURRENT));

        }    

        it = collection.getIterator();
        
        while ((intObj = (Integer) factory.sendMessage (it, msg)) != null) {
            System.out.println ("Object=" + intObj);           
 
        }    

    }

}


