/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Hashtable;
import Jt.examples.HelloWorld;
import Jt.security.JtAccessManager;
import Jt.security.JtClassAccessEntry;
import Jt.security.JtComponentAccessEntry;
import Jt.security.JtEncryptedMessage;
import Jt.security.JtMessageAuthenticator;
import Jt.security.JtMessageCipher;
import Jt.xml.JtXMLHelper;


/**
 * Jt Remote Facade. Component responsible for sending messages to
 * other remote components. It handles security, encryption, etc. 
 */


public class JtRemoteFacade extends JtFacade  {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtRemoteFacade.class.getName(); 
 

    private boolean useComponentReference = false;
	static private Hashtable componentTable = new Hashtable ();
	//private boolean xmlMessageFormat = false;
	private JtAccessManager accessManager = null;
	private JtFactory factory = new JtFactory ();
	private boolean initialized = false;
	private boolean createClassInstance = false;
	private JtMessageAuthenticator messageAuthenticator = null;
    private transient JtMessageCipher messageCipher = null;


	public JtRemoteFacade () {
	}



/*
	public boolean isXmlMessageFormat() {
		return xmlMessageFormat;
	}



	public void setXmlMessageFormat(boolean xmlMessageFormat) {
		this.xmlMessageFormat = xmlMessageFormat;
	}
*/

	/*
	 * Retrieve the useComponentReference flag.
	 */

	public boolean isUseComponentReference() {
		return useComponentReference;
	}

	/*
	 * Set the useComponentReference flag. 
	 */

	public void setUseComponentReference(boolean useComponentReference) {
		this.useComponentReference = useComponentReference;
	}



	public boolean isCreateClassInstance() {
		return createClassInstance;
	}



	public void setCreateClassInstance(boolean createClassInstance) {
		this.createClassInstance = createClassInstance;
	}



	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}

	// a better mechanism may be needed

	private String generateUniqueId (Object obj) {
		String str;
		Date date = new Date ();

		if (obj == null)
			return null;

		str = obj.getClass().getName() + "@" + obj.hashCode();
		str += date.getTime();

		return (str);

	}

	private Object componentLookup (Object id) {
		JtMessage msg = new JtMessage (JtRegistry.JtREAD);
		JtRegistry registry;
		JtFactory factory = new JtFactory ();

		if (id == null)
			return null;

		registry = factory.getRegistry();

		if (registry == null) {
			//this.handleError("Registry component not found");
			return (null);
		}

		msg.setMsgData(id);
		return (registry.processMessage(msg));
	}

	private Object retrieveHandle (Object id) {
		Object handle;

		if (id == null)
			return (null);
		
		if (useComponentReference) 
			return (id);
		
		handle = componentTable.get (id);

		if (handle == null)
			handle = componentLookup (id);

		return (handle);					

	}

	/*
	private String MessageToXML (Object message) {
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_ENCODE);
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtFactory factory = new JtFactory ();
		String xmlMessage;

		if (message == null)
			return (null);

		msg.setMsgContent(message);
		xmlMessage = (String) factory.sendMessage(xmlHelper, msg);
		
		if (propagateException (xmlHelper) != null)
			return (null);

		if (xmlMessage == null) 
			handleError ("unable to convert message into XML");
		
		
		return (xmlMessage);
	}
	*/
	
	Object XmlToMessage (String xmlMessage) {
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		Object message;
		JtFactory factory = new JtFactory ();

		if (xmlMessage == null)
			return (null);

		msg.setMsgContent(xmlMessage);
		message = factory.sendMessage(xmlHelper, msg);

		if (propagateException (xmlHelper) != null)
			return (null);
		
		//if (message == null)
		//	handleError ("unable to convert XML into object.");
		
		return (message);

	}
	
	private String stackTrace (Exception ex ) {
	      ByteArrayOutputStream bstream;


	      if (ex == null)
	          return (null);

	      bstream = new ByteArrayOutputStream ();
	      

	      ex.printStackTrace (new PrintWriter (bstream, true));


	      return (bstream.toString ());


	  }
	
	JtRemoteException generateRemoteException (Exception ex) {
		JtRemoteException jre;
		
		if (ex == null)
			return (null);
		
		jre = new JtRemoteException (ex.getMessage());
		jre.setTrace (stackTrace (ex));
		
		return (jre);
	}
 
	/*
	String processXmlMessage (String xmlMessage) {
		Object message;
		Object reply;
		String xmlReply;
		
		if (xmlMessage == null)
			return (null);
		
		message = XmlToMessage (xmlMessage);

		if (message == null) {
			// Error has been detected
			return (MessageToXML (generateRemoteException ((Exception) this.getObjException ()))); 
		}
		
		reply = processMsg (message);
		
		if (this.getObjException () == null)
			xmlReply = MessageToXML (reply);
		else
			xmlReply 
			   = MessageToXML (generateRemoteException ((Exception) this.getObjException ()));
		
		return (xmlReply);
	}
	*/
	
	JtEncryptedMessage encryptMessage (JtMessageCipher messageCipher, Object message) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		JtEncryptedMessage encryptedMessage;
		
		if (messageCipher == null || message == null)
			return (null);		
		
		//messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);

		encryptedMessage = (JtEncryptedMessage) messageCipher.processMessage(message);
		
		if (encryptedMessage == null) {
			handleError ("Unable to encrypt reply message.");
			return (null);
		}
		return (encryptedMessage);
		
	}
	
	Object decryptMessage (JtMessageCipher messageCipher, JtEncryptedMessage encryptedMessage) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		Object message;
		
		if (messageCipher == null || encryptedMessage == null)
			return (null);		
		
		//messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);

		message =  messageCipher.processMessage(encryptedMessage);
		
		if (message == null) {
			handleError ("Unable to decrypt message.");
			return (null);
		}
		return (message);
		
	}

	// shallow copy
	
	JtMessage copyMessage (JtMessage message) {

		JtMessage copy = new JtMessage ();
		
		if (message == null)
			return (null);
		
		
		copy.setMsgTo(message.getMsgTo());
		copy.setMsgContent(message.getMsgContent());
		copy.setMsgData(message.getMsgData());
		copy.setMsgId(message.getMsgId());
		copy.setAsynchronous(message.isAsynchronous());
		

		return (copy);
		
	}
	

   // Create the delegate class
    
    private Object createDelegate (String classname) {
        JtMessage msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
        JtFactory factory = new JtFactory ();
        Object instance;
        
        if (classname == null) {
        	handleError ("invalid classname (null");
            return (null);
        }
        
        
        // Attempt to create an instance of the delegate class
    
        msg.setMsgContent(classname);
        
        instance = factory.processMessage(msg);
        
        if (propagateException (factory) != null)
        	return (null);
        return (instance);
        
    }


	
	// Interpret message


	private Object processMsg (Object event) {

		String msgid;
		JtMessage msg = (JtMessage) event;
		Object result = null;
		String ctype;
		//JtMessage msg1 = new JtMessage (JtAccessManager.JtCHECK_SERVICE_ACCESS);
		JtMessage msg1;
		Object handle;
		Object componentId; // check
		JtFactory factory = new JtFactory ();
		Object reply;


		if (msg == null)
			return (null);

		msgid = (String) msg.getMsgId ();

		if (msgid == null)
			return (null);

		factory.setObjException(null);


		if (msgid.equals (JtFactory.JtSET_VALUE) || msgid.equals(JtFactory.JtGET_VALUE)) {
			
			handle = retrieveHandle (msg.getMsgTo());
		
			
			if (handle == null) {
				handleError ("unable to get component handle:" + msg.getMsgTo());
				return (null);
			}

			msg1 = copyMessage (msg);
			msg1.setMsgTo (handle);
			result = factory.processMessage(msg1);
			propagateException (factory);
			return (result);
		}

		if (msgid.equals (JtFactory.JtCREATE_OBJECT)) {
			ctype = (String) msg.getMsgContent();


			msg1 = copyMessage (msg);
			msg1.setMsgTo(null);
			result = factory.processMessage(msg1);          

			if (result == null)
				reply = null;               
			else {
				reply = generateUniqueId (result); // Object ID is returned
				componentTable.put(reply, result);              
			}
			handleTrace ("JtCREATE_OBJECT:" + reply); 
					//JtLogger.JtMIN_LOG_LEVEL);

			propagateException (factory);


			return (reply);

		}


		if (msgid.equals (JtFactory.JtLOOKUP)) {

			//componentId = msg.getMsgTo();
			componentId = msg.getMsgContent();
			
			if (componentId == null) {
				handleError ("Invalid component Id (null).");
				return (null);
			}
			

			msg1 = new JtMessage (JtObject.JtLOOKUP);
			//msg1.setMsgTo (componentId);
			msg1.setMsgContent (componentId);

			result = factory.processMessage (msg1);


			if (result == null) {
				reply = null;
				factory.handleError ("Remote component not found: " + componentId);     	 
			} else {
				reply = componentId; // component Id is returned    
				//componentTable.put(reply, result);
			}

			handleTrace ("JtLOOKUP:" + reply, 
					JtLogger.JtMIN_LOG_LEVEL);

			propagateException (factory);


			return (reply);


		}


		if (msgid.equals (JtFactory.JtREMOVE_OBJECT)) {
			
			handle = retrieveHandle (msg.getMsgTo());
			
			
			// remove from the internal component table
			// Registry components cannot be removed from a
			// remote application.
			if (handle == null) {
				handleError ("unable to get component handle:" + msg.getMsgTo());
				return (null);
			}
			factory.sendMessage(handle, new JtMessage (JtObject.JtREMOVE));

			
			if (useComponentReference)
				return (new Boolean (true));				
			
			result = componentTable.remove (msg.getMsgTo ());

			//factory.removeObject (handle);
			//propagateException (factory);
			if (result == null)
				return (null);
			else
				return (new Boolean (true));
		}


		if (msgid.equals (JtFactory.JtSEND_MESSAGE)) {

			//if (useComponentReference)
			//	handle = msg.getMsgTo();
			//else	
			
			if (msg.getMsgTo() == null ) {

				if (msg.getMsgRecipientClassname() == null) {
					handleError ("Invalid classname (null)." + msg.getMsgRecipientClassname());
					return (null);					
				}

				handle = createDelegate ((String) msg.getMsgRecipientClassname());


			} else

				handle = retrieveHandle (msg.getMsgTo());
			
			
			handleTrace ("JtRemoteMessage.handle:" + handle);
			
			if (handle == null) {
				handleError ("unable to get component handle:" + msg.getMsgTo());
				return (null);
			}
			
			msg1 = copyMessage (msg);
			msg1.setMsgTo (handle);
			result = factory.processMessage(msg1);
			
			propagateException (handle);

			return (result);

		}



		handleError ("invalid msg ID:" + msg.getMsgId ());
		return (null);
	}



	
	private boolean initialize () {
		
		
		accessManager = (JtAccessManager) factory.createObject(JtAccessManager.JtCLASS_NAME);
		
		return (true);
	}
	

	private boolean authenticateMessage (JtEnvelope envelope) {

        Boolean Bool;
        Object msgId;
        JtMessage msg1;

        
        if (envelope == null)
        	return (false);

		//if (msg == null)
		//	return (false);
		
		if (envelope.getContext() == null)
			return (false);
		
		synchronized (this) {
			if (messageAuthenticator == null)
				messageAuthenticator = (JtMessageAuthenticator) factory.createObject(JtMessageAuthenticator.JtCLASS_NAME);		
		}
        //msgId = msg.getMsgId();
        
		//if (!(msgId.equals (JtFactory.JtSET_VALUE) || msgId.equals(JtFactory.JtGET_VALUE) ||
		//		 msgId.equals(JtFactory.JtSEND_MESSAGE)))
        //	return (true);
        
		msg1 = new JtMessage ();
		msg1.setMsgContext(envelope.getContext());
		
		//Bool = (Boolean) messageAuthenticator.processMessage(msg.getMsgContent());
		Bool = (Boolean) messageAuthenticator.processMessage(msg1);

		if (Bool == null)
			return (false);
		
		return (Bool.booleanValue());

	}

	
	private JtComponentAccessEntry verifyAccess (JtMessage msg) {
        String msgId;
        JtMessage msg1;
        JtClassAccessEntry classAccessEntry = new JtClassAccessEntry ();
		JtComponentAccessEntry componentAccessEntry = new JtComponentAccessEntry ();
		Object handle;
        
        
		if (msg == null)
			return (null);
		
		msgId = (String) msg.getMsgId();
		
		
		
		if (msgId.equals(JtFactory.JtCREATE_OBJECT)) {
			
			msg1 = new JtMessage (JtAccessManager.JtGET_CLASS_ACCESS);
			msg1.setMsgContent(msg.getMsgContent());
			classAccessEntry = (JtClassAccessEntry) factory.sendMessage(accessManager, msg1);
			
			if (classAccessEntry == null || !classAccessEntry.isEnabled()) {
				handleError ("Security violation: unable to create a remote instance of " +
						msg1.getMsgContent());
				return (null);
			}
						
			
			componentAccessEntry.setEnabled(classAccessEntry.isEnabled());
			componentAccessEntry.setEncrypted(classAccessEntry.isEncrypted());
			
			return (componentAccessEntry);
							
		}
		
		if (msgId.equals (JtFactory.JtLOOKUP)) {			

			
		
			handle = componentLookup (msg.getMsgContent());
			
			
			if (handle == null) {
				handleError ("Invalid handle:" + msg.getMsgContent());
				return (null);
			} else  {
				
				msg1 = new JtMessage (JtAccessManager.JtGET_COMPONENT_ACCESS);
				msg1.setMsgContent(msg.getMsgContent());
				componentAccessEntry = (JtComponentAccessEntry) factory.sendMessage(accessManager, msg1);

				if (componentAccessEntry == null || !componentAccessEntry.isEnabled()) {
					handleError ("Security violation: unable to access remote component " + msg.getMsgContent());
					return (null);
				}
				
				return (componentAccessEntry);
				
			}



		}
		
		if (msgId.equals (JtFactory.JtSET_VALUE) || msgId.equals(JtFactory.JtGET_VALUE) ||
				 msgId.equals(JtFactory.JtSEND_MESSAGE) ||
				msgId.equals(JtFactory.JtREMOVE_OBJECT)) {
			

			
			if ((msg.getMsgTo () == null) && msgId.equals(JtFactory.JtSEND_MESSAGE)) {
				msg1 = new JtMessage (JtAccessManager.JtGET_CLASS_ACCESS);
				msg1.setMsgContent(msg.getMsgRecipientClassname());
				
				
				classAccessEntry = (JtClassAccessEntry) factory.sendMessage(accessManager, msg1);
				
				if (classAccessEntry == null || !classAccessEntry.isEnabled()) {
					handleError ("Security violation: unable to create a remote instance of " +
							msg1.getMsgContent());
					return (null);
				}
				
				componentAccessEntry.setEnabled(classAccessEntry.isEnabled());
				componentAccessEntry.setEncrypted(classAccessEntry.isEncrypted());
				componentAccessEntry.setAuthenticated(classAccessEntry.isAuthenticated());
				
				return (componentAccessEntry);
				
			}
			
			/*
			if (useComponentReference) {
				handle = msg.getMsgTo();
				
				if (handle == null) {
					handleError ("Invalid component reference:" + msg.getMsgTo());
					return (null);
				}
				
				msg1 = new JtMessage (JtAccessManager.JtGET_CLASS_ACCESS);
				msg1.setMsgContent(handle.getClass().getName());
				classAccessEntry = (JtClassAccessEntry) factory.sendMessage(accessManager, msg1);
				
				if (classAccessEntry == null || !classAccessEntry.isEnabled()) {
					handleError ("Security violation: unable to create a remote instance of " +
							msg1.getMsgContent());
					return (null);
				}
				
				componentAccessEntry.setEnabled(classAccessEntry.isEnabled());
				componentAccessEntry.setEncryptedMessaging(classAccessEntry.isEncryptedMessaging());
				
				return (componentAccessEntry);
			}
			*/
			
			handle = componentLookup (msg.getMsgTo());
			
			if (handle != null) {
				
				msg1 = new JtMessage (JtAccessManager.JtGET_COMPONENT_ACCESS);
				msg1.setMsgContent(msg.getMsgTo());
				componentAccessEntry = (JtComponentAccessEntry) factory.sendMessage(accessManager, msg1);
 
				if (componentAccessEntry == null || !componentAccessEntry.isEnabled()) {
					handleError ("Security violation: unable to access remote component " + msg.getMsgTo());
					return (null);
				}
				
				return (componentAccessEntry);
				
			}

			handle = componentTable.get (msg.getMsgTo());
			
			if (handle == null) {
				handleError ("Invalid handle:" + msg.getMsgTo());
				return (null);
			}
			
			msg1 = new JtMessage (JtAccessManager.JtGET_CLASS_ACCESS);
			msg1.setMsgContent(handle.getClass().getName());
			classAccessEntry = (JtClassAccessEntry) factory.sendMessage(accessManager, msg1);
			
			if (classAccessEntry == null || !classAccessEntry.isEnabled()) {
				handleError ("Security violation: unable to create a remote instance of " +
						msg1.getMsgContent());
				return (null);
			}
			
			componentAccessEntry.setEnabled(classAccessEntry.isEnabled());
			componentAccessEntry.setEncrypted(classAccessEntry.isEncrypted());
			componentAccessEntry.setAuthenticated(classAccessEntry.isAuthenticated());
			
			return (componentAccessEntry);
		}
		

					
		handleError ("Invalid message Id:" + msgId);
		return (null);
	}
	
	// Process object messages. 

	public Object processMessage (Object message) {
        Object msg;
        Object reply;
        Object encryptedReply;
        //JtClassAccessEntry  classEntry;
        JtComponentAccessEntry accessEntry;
        JtMessage jMsg;
        boolean encryptedMessage = false;
        //JtMessageCipher messageCipher = null;
        JtEnvelope envelope;
        
		if (message == null) {
			handleError ("Invalid message: null");
			return generateRemoteException ((Exception) getObjException());
		}

		this.setObjException(null);
		
		synchronized (this) {
			if (!initialized) {
				initialize ();
				initialized = true;
			}
		}
		//if (xmlMessageFormat)
		//	return(processXmlMessage ((String) message));
		//else
		//	return(processMsg (message));

		msg = message;
		if (message instanceof JtEncryptedMessage) {
			
			encryptedMessage = true;
			
			synchronized (this) {
				//if (messageCipher == null)
				messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
			}
			msg = decryptMessage (messageCipher, (JtEncryptedMessage) message);
			
			if (msg == null)
				return generateRemoteException ((Exception) getObjException());
			

		} 
		
		if (!(msg instanceof JtEnvelope)) {
			handleError ("Invalid message type(JtEnvelope expected):" + msg.getClass().getName());
			return generateRemoteException ((Exception) getObjException());
		}

		
		envelope = (JtEnvelope) msg;
        msg = envelope.getMessage();
		
				
		if (!(msg instanceof JtMessage)) {
			handleError ("Invalid message type:" + msg.getClass().getName());
			return generateRemoteException ((Exception) getObjException());
		}
		
		jMsg = (JtMessage) msg;
		
		// Remove message (local message)
		if (jMsg.getMsgId() != null && jMsg.getMsgId().equals (JtObject.JtREMOVE))
			return (null);
		
		accessEntry = verifyAccess (jMsg);
				
		if (accessEntry == null)
			return generateRemoteException ((Exception) getObjException());
		
		if (!encryptedMessage && accessEntry.isEncrypted()) {
			handleError ("Security violation: encrypted messages are expected.");
			return generateRemoteException ((Exception) getObjException());		
		}
		
		if (accessEntry.isAuthenticated()) {
			if (!authenticateMessage (envelope)) {
				handleError ("Security violation: unable to authenticate message.");
				return generateRemoteException ((Exception) getObjException());					
			}				
		}
		
		reply = processMsg (msg);
		
		if (accessEntry.isEncrypted()) {
			messageCipher.setExcludeEncryptedSessionKey(true);
			encryptedReply = encryptMessage (messageCipher, reply);
			reply = encryptedReply;
		}
		
		if (getObjException() != null)
			return generateRemoteException ((Exception) getObjException());
			
		return (reply);


		//return(processMsg (msg));
	}



	/**
	 * Demonstrates all the messages processed by JtScriptInterpreter. 
	 */

	public static void main(String[] args) {

		JtFactory factory = new JtFactory ();
		JtRemoteFacade messenger;
		JtMessage msg = new JtMessage ();
		//JtMessage msg2 = new JtMessage (JtXMLHelper.JtXML_ENCODE);		
		Object reply;
		JtMessage msg1 = new JtMessage (HelloWorld.JtHELLO);
		JtEnvelope envelope = new JtEnvelope ();
		//JtXMLHelper helper = new JtXMLHelper ();
		//String xmlMessage;
		//HelloWorld helloWorld = new HelloWorld ();

		

		// Create messenger

		messenger = (JtRemoteFacade) factory.createObject (JtRemoteFacade.JtCLASS_NAME);

		msg.setMsgId(JtFactory.JtCREATE_OBJECT);
		msg.setMsgContent(HelloWorld.JtCLASS_NAME);
		envelope.setMessage(msg);

		//reply = factory.sendMessage (messenger, msg);
		reply = messenger.processMessage(envelope);

		System.out.println("reply:" + reply);
		
		msg.setMsgId(JtFactory.JtSEND_MESSAGE);
		msg.setMsgTo(reply);
		msg.setMsgContent(msg1);
		envelope.setMessage(msg);
		
		//reply = factory.sendMessage (messenger, msg);
		reply = messenger.processMessage(envelope);

		System.out.println("reply:" + reply);
		
		/*
		messenger.setUseComponentReference(true);
		msg.setMsgId(JtFactory.JtSEND_MESSAGE);
		msg.setMsgTo(helloWorld);
		msg.setMsgContent(msg1);		
		
		reply = messenger.processMessage(msg);

		System.out.println("reply:" + reply);
		*/

	}

}


