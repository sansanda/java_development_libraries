package Jt.jndi;

//import javax.ejb.*;
import javax.naming.*;

import java.util.Properties;
import Jt.*;


/**
 * Jt JNDI Adapter  
 */

public class JtJNDIAdapter extends JtAdapter {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtJNDIAdapter.class.getName(); 
    public static final String JtLOOKUP = "JtLOOKUP"; 
    private String url = "t3://localhost:7001"; // Default value (Weblogic)
    private String user;
    private String password;
    private String factory = "weblogic.jndi.WLInitialContextFactory"; // Default value (Weblogic)
    private boolean initted = false;
    private transient Context ctx = null;

    /**
     * Specifies the URL (initial context).
     * @param url url
     */

    public void setUrl (String url) {
        this.url = url; 

    }

    /**
     * Returns the url. 
     */

    public String getUrl () {
        return (url);
    }


    /**
     * Specifies the user (initial context).
     * @param user user
     */

    public void setUser (String user) {
        this.user = user; 
    }

    /**
     * Returns the user. 
     */

    public String getUser () {
        return (user);
    }


    /**
     * Specifies the password (initial context).
     * @param password password
     */

    public void setPassword (String password) {
        this.password = password; 
    }


    /**
     * Returns the password. 
     */

    public String getPassword () {
        return (password);
    }

    /**
     * Specifies the context factory (initial context).
     * @param factory factory
     */

    public void setFactory (String factory) {
        this.factory = factory; 
    }


    /**
     * Returns the context factory. 
     */


    public String getFactory () {
        return (factory);
    }



    // lookup 

    private Object lookup (String jndiName) {

        Object objref = null;


        try {

            if (!initted) {
                initted = true;
                ctx = getInitialContext();
            }
            if (ctx == null) {
                handleError ("JtJNDIAdapter: unable to get initial context");
                return (null);
            }

            objref = ctx.lookup (jndiName);


        } catch (Exception e) {
            handleException (e);
        }
        return (objref);

    }


    private Object test () {

        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP);

        msg.setMsgContent ("JtSessionFacade");

        return (processMessage (msg));

    }

    /**
     * Process object messages.
     * <ul>
     * <li> JtLOOKUP - retrieves the named object specified by msgContent.
     * </ul>
     * @param event message
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object content;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();

        // Locate the service (JtACTIVATE)

        if (msgid.equals (JtJNDIAdapter.JtLOOKUP)) {

            return (lookup ((String) content));

        }


        if (msgid.equals (JtObject.JtTEST)) {             
            return (test ());
        }


        if (msgid.equals (JtObject.JtREMOVE)) {             
            return (null);
        }

        return (super.processMessage (event));
        //handleError ("processMessage: invalid message id:" + msgid);
        //return (null);

    }

    /**
     * Gets an initial context.
     *
     */

    private Context getInitialContext() throws Exception {

        Properties p = new Properties();

        if (factory == null || url == null) {
            handleWarning ("getInitialContext(): invalid factory and/or url");
            return (null);
        }    

        p.put(Context.INITIAL_CONTEXT_FACTORY,
                factory);

        p.put(Context.PROVIDER_URL, url);


        if (user != null) {
            //System.out.println ("user: " + user);
            p.put(Context.SECURITY_PRINCIPAL, user);
            if (password == null) 
                password = "";
            p.put(Context.SECURITY_CREDENTIALS, password);
        } 
        return new InitialContext(p);
    }



    /**
     * Demonstrates all the messages processed by JtJNDIAdapter. 
     */

    public static void main (String[] args) {
        JtFactory factory = new JtFactory ();
        JtJNDIAdapter adapter;
        Object entry;
        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP);
        
       
        // Create an instance of JtJNDIAdapter

        adapter = (JtJNDIAdapter) factory.createObject (JtJNDIAdapter.JtCLASS_NAME);

        // Send a JtLOOKUP message to the adapter

        msg.setMsgContent ("JtSessionFacade");
        
        entry = (Object) factory.sendMessage (adapter, msg);
               
        if (entry != null)
            System.out.println  ("JtJNDIAdapter: GO");  
        else
            System.out.println  ("JtJNDIAdapter: FAIL");  

        // Remove the JtJNDIAdapter instance

        factory.removeObject (adapter);


    }
}
