package Jt.DAO;


import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.*;

import Jt.JtFactory;
import Jt.JtInterface;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.wizard.struts.ActionMapping;

public class DAODefinitionForm extends ActionForm implements JtInterface {

    private static final long serialVersionUID = 1L;
    private String table;
    private String path;
    private String name;
    //private String className;
    private String dbkeys[];
    private DAOMapping dbmappings[];
    private String fileName;
    public static final String RESET = "RESET";
    JtFactory factory = new JtFactory ();
    

    public DAODefinitionForm() {        
        super();
        
        
        dbmappings = new DAOMapping[DAODefinition.MAX_ENTRIES];
        for (int i=0; i<DAODefinition.MAX_ENTRIES ; i++) {
            dbmappings[i] = new DAOMapping ();
            dbmappings[i].setEnabled (false);
            dbmappings[i].setKeyAttribute (false);
        }

    }
    
    
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /*
    public Collection getAttributes() {
        return attributes;
    }

    public void setAttributes(Collection attributes) {
        this.attributes = attributes;
    }
*/
    
    public DAOMapping[] getDbmappings() {
        return dbmappings;
    }

    public void setDbmappings(DAOMapping[] dbmappings) {
        this.dbmappings = dbmappings;
    }
/*
    public String getClassName() {
        return className;
    }
*/
    public String[] getDbkeys() {
        return dbkeys;
    }

    public void setDbkeys(String[] dbkeys) {
        this.dbkeys = dbkeys;
    }
/*
    public void setClassName(String className) {
        this.className = className;
    }
*/
    public String getTable() {
      return (table);
    }

    public void setTable(String type) {
      this.table=type;
    }

    public String getPath() {
      return (path);
    }

    public void setPath(String path) {
      this.path=path;
    }

    public String getName() {
      return (name);
    }

    public void setName(String name) {
      this.name=name;
    }
    
    public void reset (ActionMapping mapping, HttpServletRequest request) {
        int i;

        
        factory.handleTrace ("DAODefinition.reset");
        
        if (dbmappings == null) {
            
            dbmappings = new DAOMapping[DAODefinition.MAX_ENTRIES];
            return;
        }    
        //for (i=0; i<dbmappings.length ; i++) {
        //    dbmappings[i].setEnabled (false);
        //}


    }
    
    public void initialize () {
        int i;


        factory.handleTrace ("DAODefinition.initialize");

        if (dbmappings == null) {

            dbmappings = new DAOMapping[DAODefinition.MAX_ENTRIES];
            for (i=0; i<DAODefinition.MAX_ENTRIES ; i++) {
                dbmappings[i] = new DAOMapping ();
            }
            
            return;
        }    
        for (i=0; i<dbmappings.length ; i++) {
            if (dbmappings[i] != null) {
                dbmappings[i].setEnabled (false);
                dbmappings[i].setKeyAttribute (false);
            }
        }


    }


    public Object processMessage(Object msg) {
        JtMessage e = (JtMessage) msg;
        String msgid;
        

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();
 
        /*
        if (msgid.equals(DAODefinitionForm.RESET)) {
            this.reset ((ActionMapping) null, null);
            //reset (null, null);
            return null;
        }
        */
        
        if (msgid.equals(JtObject.JtINITIALIZE)) {
            initialize ();
            return null;
        }
        
        factory.handleError ("Invalid meesage ID:" + msgid);
        return null;
    }



}
