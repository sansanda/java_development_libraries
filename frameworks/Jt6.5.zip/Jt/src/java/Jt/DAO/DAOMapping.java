
package Jt.DAO;

/**
 * Database mapping (internal JtWizard class).
 */

public class DAOMapping  {    

    private static final long serialVersionUID = 1L;
    private String attribute;
    private String column;
    private boolean enabled;
    private boolean keyAttribute;
    private boolean notNull;
    private String sql_type;
    private boolean unique;
    
    
    public boolean isUnique() {
        return unique;
    }
    public void setUnique(boolean unique) {
        this.unique = unique;
    }
    public String getSql_type() {
        return sql_type;
    }
    public void setSql_type(String sql_type) {
        this.sql_type = sql_type;
    }
    public boolean isNotNull() {
        return notNull;
    }
    public void setNotNull(boolean notNull) {
        this.notNull = notNull;
    }
    public boolean isKeyAttribute() {
        return keyAttribute;
    }
    public void setKeyAttribute(boolean keyAttribute) {
        this.keyAttribute = keyAttribute;
    }
    public String getAttribute() {
        return attribute;
    }
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }
    public String getColumn() {
        return column;
    }
    public void setColumn(String column) {
        this.column = column;
    }

    public boolean isEnabled() {
        return enabled;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }   

}
