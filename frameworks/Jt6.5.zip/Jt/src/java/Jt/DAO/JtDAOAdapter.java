package Jt.DAO;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.InputStream;
//import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.text.DateFormat;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.jdom.Element;
import Jt.JtAdapter;
import Jt.JtCollection;
import Jt.JtFactory;
import Jt.JtJDBCAdapter;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.xml.JDOMAdapter;


/**
 * Implements the Data Access Object design pattern (DAO).
 * This is a Jt native implementation. Additional DAO implemetations (strategies)
 * are supported as well. For instance, one is provided for Hibernate DAO integration.
 * Please refer to the JtDAOStrategy class.
 */


public class JtDAOAdapter extends JtAdapter {
    

    private static final long serialVersionUID = 1L;
    public static final String JtINSERT = "JtINSERT";
    public static final String JtCREATE = "JtCREATE";
    public static final String JtFIND = "JtFIND";
    public static final String JtREAD = "JtREAD";  
    public static final String JtREAD_CHILDREN = "JtREAD_CHILDREN";  
    public static final String JtUPDATE = "JtUPDATE"; 
    public static final String JtDELETE = "JtDELETE";
    public static final String JtBEGIN_TRANSACTION = "JtBEGIN_TRANSACTION";
    public static final String JtCOMMIT = "JtCOMMIT";
    public static final String JtROLLBACK = "JtROLLBACK";
    public static final String JtEXECUTE_QUERY = "JtEXECUTE_QUERY";  
    public static final String JtEXECUTE_JOIN = "JtEXECUTE_JOIN";  
    public static final String JtMAP_ATTRIBUTE = "JtMAP_ATTRIBUTE";
    public static final String JtCALCULATE_KEY = "JtCALCULATE_KEY";
    public static final String JtCLOSE_CONNECTION = "JtCLOSE_CONNECTION";
    public static final String JtFIND_RECORDS = "JtFIND_RECORDS";
    public static final String JtREAD_MAPPING_STREAM = "JtREAD_MAPPING_STREAM";
    public static final String JtCLEAR = "JtCLEAR";
    public static final String JtCHECK_ACCESS = "JtCHECK_ACCESS";
    public static final String JtCLASS_NAME = JtDAOAdapter.class.getName(); 
    public static final String GET_DAODESCRIPTOR = "GET_DAODESCRIPTOR";
    public static final String JtNEXT = "JtNEXT"; 
    public static final String JtSEARCH_BY_ATTRIBUTES = "JtSEARCH_BY_ATTRIBUTES";   
    public static final String JtSEARCH_FOR_KEYWORDS = "JtSEARCH_FOR_KEYWORDS";   
    
    private boolean autocommit = true;
    private JtObject db = null;         // JDBC adapter
    private Hashtable attr;
    private String configFile = "hibernate.cfg.xml"; // default configuration file
    Hashtable classTable = new Hashtable ();
    private String datasource;
    private String user;
    private String password;
    private String url;  
    private String driver;
    private JtFactory factory = new JtFactory ();
    private boolean initted = false;
    private boolean returnCursor = false;
    
    private boolean executeJoin = false;
    private List classList = null;
    

    /**
     * Returns the value of the autocommit attribute.
     */
    
    public boolean getAutocommit() {
        return autocommit;
    }

    
    /**
     * Specifies if the transaction should be automatically commited
     * after each operation.
     * @param autocommit boolean property
     */
    
    public void setAutocommit(boolean autocommit) {
        this.autocommit = autocommit;
    }
    
    /**
     * Returns the value of the returnCursor attribute.
     */
    
    public boolean isReturnCursor() {
        return returnCursor;
    }

    
    /**
     * Specifies whether or not a JtDAOCursor should be returned
     * as the reply for the EXECUTE_QUERY message.
     * @param returnCursor 
     */

    public void setReturnCursor(boolean returnCursor) {
        this.returnCursor = returnCursor;
    }


    /**
     * Returns the Datasource logical name (JNDI).
     */
    
    public String getDatasource() {
        return datasource;
    }

    /**
     * Specifies the Datasource logical name (if any).
     * @param datasource Datasource logical name
     */

    public void setDatasource(String datasource) {
        this.datasource = datasource;
    }


    /**
     * Returns the database user.
     */
    
    public String getUser() {
        return user;
    }

    /**
     * Specifies the database user.
     * @param user user
     */


    public void setUser(String user) {
        this.user = user;
    }

    /**
     * Returns the database driver.
     */

    public String getDriver() {
        return driver;
    }
    
    /**
     * Specifies the database driver.
     * @param driver driver
     */

    public void setDriver(String driver) {
        this.driver = driver;
    }


    /**
     * Returns the URL of the database.
     */
    public String getUrl() {
        return url;
    }

    /**
     * Specifies the URL of the database.
     * @param url url
     */


    public void setUrl(String url) {
        this.url = url;
    }

    
    /**
     * Returns the database password.
     */
    
    
    public String getPassword() {
        return password;
    }

    /**
     * Specifies the database password.
     * @param password password
     */
    
    public void setPassword(String password) {
        this.password = password;
    }


    /**
     * Specifies the name of the configuration file.
     */

    public void setConfigFile (String configFile) {
        this.configFile = configFile;
    }

    /**
     * Returns the name of the configuration file.
     */

    public String getConfigFile () {
        return (configFile);
    }
    
    
    private boolean isKeyAttribute (List keys, String att) {
        Iterator it;
        DAOMapping mapping;
        
        if (keys == null || keys.isEmpty() || att == null)
            return false;
        
        
        it = keys.iterator();
        
        while (it.hasNext()) {
            mapping = (DAOMapping) it.next();
            if (att.equals(mapping.getAttribute()))
                return true;        
        }
        return false;
        
        
    }
    
    private int setParameters (PreparedStatement pst, Hashtable map_table, List keys)
    {

        Enumeration attrs; 
        String att;
        //String value;
        Object tmp;
        int i = 1;
        java.sql.Timestamp tmp1;

        if (pst == null)
            return i;

        if (map_table == null)
            return i;

        if (attr == null)
            return i;

//      keys = attr.keys ();
        attrs = map_table.keys ();

        //i = 1;
        while (attrs.hasMoreElements ()) {
            att = (String) attrs.nextElement ();

            // check the list of keys to skip
            
            if (keys != null) {
                if (isKeyAttribute (keys, att))
                    continue;
            }
            
            tmp = (Object) attr.get (att);

            if (tmp instanceof java.util.Date) {

                tmp1 = new 
                java.sql.Timestamp (((java.util.Date)tmp).getTime ());
                try {
                    pst.setTimestamp (i, tmp1);
                } catch (Exception ex) {
                    handleException (ex);
                }
                i++;
                //System.out.println ("setParametes: " + tmp1);
            } 

        }    
        return i;

    }
    
    
    private boolean setKeyword (PreparedStatement pst, int pos, String keyword) {
        if (pst == null || (pos <= 0) || keyword == null)
            return false;  
        
        
        
        
        try {
            pst.setString (pos, "%" + massageString (keyword) + "%");
        } catch (Exception ex) {
            handleException (ex);
            return false;
        }
        
        
        return (true);
    }
    
    
    private boolean setKeyValue (PreparedStatement pst, int pos, Object keyValue) {
        
        java.sql.Timestamp tmp1;
        
        if (pst == null || (pos <= 0) || keyValue == null)
            return false;
        
        if (keyValue instanceof java.util.Date) {

            tmp1 = new 
            java.sql.Timestamp (((java.util.Date)keyValue).getTime ());
            try {
                pst.setTimestamp (pos, tmp1);
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;

        } else if (keyValue instanceof String) {
            
            try {
                pst.setString (pos, (String) keyValue);
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
            
        } else if (keyValue instanceof Boolean) {
            
            try {
                pst.setBoolean (pos, ((Boolean) keyValue).booleanValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } else if (keyValue instanceof Integer) {
            
            try {
                pst.setInt (pos, ((Integer) keyValue).intValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } else if (keyValue instanceof Byte) {
            
            try {
                pst.setByte (pos, ((Byte) keyValue).byteValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } if (keyValue instanceof Double) {
            
            try {
                pst.setDouble (pos, ((Double) keyValue).doubleValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } if (keyValue instanceof Long) {
            
            try {
                pst.setLong (pos, ((Long) keyValue).longValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } if (keyValue instanceof Short) {
            
            try {
                pst.setShort (pos, ((Short) keyValue).shortValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        } if (keyValue instanceof Float) {
            
            try {
                pst.setFloat (pos, ((Float) keyValue).floatValue());
            } catch (Exception ex) {
                handleException (ex);
                return false;
            }
            return true;
        }
        
        handleError ("unknown type");
        return false;
        
    }
    
    
    
    
    private boolean setKeyParameters (PreparedStatement pst, List keys, Object key, 
            int index, boolean simple)
    {

        //String att;
        //String value;
        //Object tmp;
        int i;
        //java.sql.Date tmp1;
        int cnt;
        String keyAttr;
        Object keyValue;


        if (pst == null)
            return false;

        if (keys == null)
            return false;

        if (key == null)
            return false;
        
        if (index < 1)
            return false;

//      keys = attr.keys ();
        
        
        if (simple)
            if (setKeyValue (pst, index, key))
                return true;
            else
                return false;
        

        cnt = keys.size();

        for (i = 1; i <= cnt; i++) {
            keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();


            //if (cnt == 1) {
            //    if (!setKeyValue (pst, i, key))
            //        return false;
            //} else {
            keyValue = factory.getValue(key, keyAttr);
            if (keyValue == null)
                return false;
            if (!setKeyValue (pst, index++, keyValue))
                return false;

            //}    

        }    
        return true;

    }
  
    
    private boolean setStatementKeywords (PreparedStatement pst, String keywords)
    {

        int i = 1;
        //int cnt;
        //String keyAttr;
        //Object keyValue;
        Iterator iterator;
        String keyword;
        List keywordList;


        if (pst == null || keywords == null)
            return false;

                       
        keywordList = retrieveKeywordList (keywords);

        if (keywordList == null)
            return (false);
        
        iterator = keywordList.iterator();
        
        

        while (iterator.hasNext()) {
        //for (i = 1; i <= cnt; i++) {
            keyword = (String) iterator.next(); 

  
            if (!setKeyword (pst, i++, keyword)) {
                if (this.getObjException() == null) {
                    handleError ("unable to set attribute value:" + keyword);
                }
                return false;
            }

        }    
        return true;

    }
    
    private boolean setStatementParameters (PreparedStatement pst, List attrNames, Object key, 
            int index)
    {

        int i;
        int cnt;
        String keyAttr;
        Object keyValue;


        if (pst == null)
            return false;

        if (attrNames == null)
            return false;

        if (key == null)
            return false;
        
        if (index < 1)
            return false;

                       
        cnt = attrNames.size();
        
        //factory.sendMessage(key, new JtMessage (JtObject.JtPRINT));

        for (i = 1; i <= cnt; i++) {
            keyAttr = (String) attrNames.get(i - 1);

            keyValue = factory.getValue(key, keyAttr);
            if (keyValue == null) {
                handleError ("Attribute value is null: " + keyAttr);
                return false;
            }    
            if (!setKeyValue (pst, index++, keyValue)) {
                if (this.getObjException() == null) {
                    handleError ("unable to set attribute value:" + keyValue);
                }
                return false;
            }

        }    
        return true;

    }
    
    /**
     * Insert DAO
     */
    
    
    private Object insert (Object obj) {
        JtMessage msg;
        String query;
        //Object conn;
        PreparedStatement pst;
        Object out = null;

        msg = new JtMessage ();
        
        if (obj == null) {
            handleError ("insert: invalid parameter obj (null)");
            return (null);
        }

        //if (db == null)
        //    realize ();

        attr = getAttributes (obj);
        query = buildInsertQuery (obj);

        if (query == null || db == null)
            return (null);

        
        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);
        
        if (propagateException (db) != null) { 
            return null;
        }    

        if (pst == null)
            return (null);  // check

        setParameters (pst, retrieveMappingTable (obj.getClass().getName()), null);

        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_UPDATE);
        msg.setMsgContent (pst);
        out = factory.sendMessage (db, msg);

        if (propagateException (db) != null) { 
            return null;
        }   
        
        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        //propagateException (db);

        if (out == null)
            return (null);

        if (out instanceof Integer) {
            if (((Integer) out).intValue () != 1)
                return (null);
            else
                return (out);
        } else
            return (null);

    }
    
    

    
    /**
     * Update DAO
     */
    
    private Object update (Object obj) {
        JtMessage msg;
        String query;
        //Object conn;
        Object out;
        List keys;
        int index;

        msg = new JtMessage ();
        PreparedStatement pst = null;
        
        
        if (obj == null) {
            handleError ("update: invalid parameter obj (null)");
            return (null);
        }  

        //if (db == null)
        //    realize ();

        attr = getAttributes (obj);
        query = buildUpdateQuery (obj);

        if (query == null || db == null)
            return (null);


        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);

        if (propagateException (db) != null)
            return (null);

        if (pst == null)
            return (null);  // check
        
        keys = retrieveKeys (obj.getClass().getName());
        
        if (keys == null || keys.isEmpty())
            return null;
            

        index = setParameters (pst, retrieveMappingTable (obj.getClass().getName()),
                keys);        
            
        if (!setKeyParameters (pst, keys, obj, index, false))
            return null; 

        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_UPDATE);
        msg.setMsgContent (pst);
        out = factory.sendMessage (db, msg);

        if (propagateException (db) != null)
            return (null);
        
        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        if (out instanceof Integer) {
            if (((Integer) out).intValue () != 1)
                return (null);
            else
                return (out);
        } else
            return (null);

    }
    
    /**
     * Find DAO
     */
 /*   
    private Object find (Object obj, Object key) {
        //Session session;
        Object output = null;

        if (obj == null) {
            handleError ("find: invalid parameter obj (null)");
            return (null);
        }    
        
        if (key == null) {
            handleError ("find: invalid parameter key (null)");           
            return (null);
        }    


        
        return (output);
    }
*/ 
   
   private JtDAOContext retrieveContext () {
       
       JtDAOContext context;

       /*
       if (JtDAOContext.getInstance() == null) {
           factory.createObject(JtDAOContext.JtCLASS_NAME);    // Create JtDAOContext singleton       
       }
       
       context = (JtDAOContext) JtDAOContext.getInstance();
       */
       
       // The first attempt will create JtDAOContext singleton. 
       // Further attempts will return the singleton instance.
       
       context = (JtDAOContext) factory.createObject(JtDAOContext.JtCLASS_NAME);    
       
       if (context == null) {
           handleError ("Unable to create DAO context.");
           return (null);
       }
       return (context);
   }
    
    
   private boolean retrieveConfiguration (JtDAOContext context) {

       Hashtable configTable;
       JtDAOAdapter adapter = null;
   
       if (context == null)
           return (false);

       configTable = context.getConfigTable();

       if (configTable == null)
           return (false);
       

       adapter = (JtDAOAdapter) configTable.get(configFile);
       if (adapter == null)
           return (false);
       
       
       // Copy
       if (adapter != null) {
           this.setDriver(adapter.getDriver());
           this.setUrl(adapter.getUrl());
           this.setPassword(adapter.getPassword());
           this.setUser(adapter.getUser());  
           this.classTable = adapter.classTable;  // careful           
       }
       
       return (true);
       
   }
   
   private void saveConfiguration (JtDAOContext context) {

       Hashtable configTable;
       JtDAOAdapter adapter = new JtDAOAdapter ();
       

       if (context == null)
           return;
       

       adapter.setDriver(this.getDriver());
       adapter.setUrl(this.getUrl());
       adapter.setPassword(this.getPassword());
       adapter.setUser(this.getUser());  
       adapter.classTable = this.classTable;  // careful        
       
       configTable = context.getConfigTable();

       if (configTable != null) {
           configTable.put(configFile, adapter);
       }           
       
   }
    
   private void initialize () {
       JtJDBCAdapter jdbcAdapter;
       Connection conn;
       JtDAOContext context;

       
       handleTrace ("JtDAOAdapter:initialize ...");
       
       
       context = retrieveContext ();
       
       if (context == null) {
           return;   
       }

       // Todo - check driver, etc
       if (!retrieveConfiguration (context)) {
           if (readConfigFile ())
               saveConfiguration (context);
           else {
               if (this.getObjException() == null)
                   handleError ("Unable to read configuration file:" + configFile);
               return;    
           }    
       }    
       
       if (db != null)
           return;

       db = (JtObject) factory.createObject (JtJDBCAdapter.JtCLASS_NAME);
       
       jdbcAdapter = (JtJDBCAdapter) db;
       
       
       if (datasource != null) {
           jdbcAdapter.setDatasource(datasource);
       } else {

           if (driver != null) {
               //handleError ("datasource or driver attribute needs to be set.");
               //return;           
               // Take these atrributes from the configuration file
               if (user == null) {
                   handleError ("datasource or user attribute needs to be set in the configuration file.");
                   return;           
               }   

               if (url == null) {
                   handleError ("datasource or url attribute needs to be set in the configuration file.");
                   return;           
               }   

               if (password == null) {
                   handleError ("datasource or password attribute needs to be set in the configuration file.");
                   return;           
               }  

               jdbcAdapter.setDriver(driver) ;
               jdbcAdapter.setUser(user);       
               jdbcAdapter.setUrl(url);  
               jdbcAdapter.setPassword(password);
           }
       }       

       // Connect to the data source

       factory.sendMessage (jdbcAdapter, new JtMessage (JtJDBCAdapter.JtCONNECT));
       
       if (propagateException (jdbcAdapter) != null)
           return;


       if (autocommit == false) { // check
           conn = jdbcAdapter.getConnection();


           try {
               conn.setAutoCommit(autocommit);
           } catch (SQLException e) {
               handleException (e);
           }
       }
       
       
   }
    
    
    /**
     * Delete DAO
     */
   
    private Object delete (Object obj) {
        JtMessage msg;
        String query;
        //Object conn;
        //ResultSet res;
        Object out;
        PreparedStatement pst;

        msg = new JtMessage ();

        //if (db == null)
        //    realize ();
        
        if (obj == null) {
            handleError ("delete: invalid parameter obj (null)");
            return (null);
        }

        attr = getAttributes (obj); // check

        query = buildDeleteQuery (obj);

        if (query == null || db == null)
            return (null);

        
        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);
        

        if (propagateException (db) != null)
            return (null);

        if (pst == null)
            return (null);  // check

        if (!setKeyParameters (pst, retrieveKeys (obj.getClass().getName()), obj, 1, false))
            return null; 


        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_UPDATE);
        msg.setMsgContent (pst);
        out = factory.sendMessage (db, msg); //check



        if (propagateException (db) != null)
            return (null);
        

        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }
    
        
        //msg.setMsgId (JtJDBCAdapter.JtUPDATE);
        //msg.setMsgContent (query);

        //out = factory.sendMessage (db, msg);
        //propagateException (db);

        if (out instanceof Integer) {
            if (((Integer) out).intValue () != 1)
                return (null);
            else
                return (out); // check
        } else
            return (null);

    }
    
    /**
     * Begin transaction
     */
    private void beginTransaction () {
        //Session session = null;

        //this.setObjException(null);  // reset the exception - check redundant
        
        if (db == null)
            return;
        
        factory.sendMessage (db, new JtMessage (JtJDBCAdapter.JtBEGIN_TRANSACTION));
        
        propagateException (db);
       
        /*
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();
            if (session != null)
                session.beginTransaction();
        } catch (Exception ex) {
            handleException (ex);
        }
        */
    }
    
    
    /**
     *  Rollback transaction
     */
    
    private void rollbackTransaction () {
        //Session session = null;
        
        if (db == null)
            return;
        
        factory.sendMessage (db, new JtMessage (JtJDBCAdapter.JtROLLBACK));
        
        propagateException (db);

        /*
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.getTransaction().rollback();
        } catch (Exception ex) {
            handleException (ex);
        }
        */
    }
    
    /**
     *  Commit transaction
     */
    
    private void commitTransaction () {
        //Session session = null;
        
        if (db == null)
            return;
        
        factory.sendMessage (db, new JtMessage (JtJDBCAdapter.JtCOMMIT));
        
        propagateException (db);
/*
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.getTransaction().commit();
        } catch (Exception ex) {
            handleException (ex);
        }
*/
    }
    
    private Object mapRow (Object obj, ResultSet rs, boolean checkColumn) {

        //Object args[];
        PropertyDescriptor[] prop;
        int i;
        Class p;
        BeanInfo info = null;
        String value; // check
        String column;
        java.util.Date dateValue;
        
        if (obj == null || rs == null)
            return (null);

        try {

            info = Introspector.getBeanInfo(
                    obj.getClass (), obj.getClass ().getSuperclass());
        } catch(Exception e) {
            handleException (e);
            return (null);
        }

        prop = info.getPropertyDescriptors();
        for(i = 0; i < prop.length; i++) {
            //System.out.print ("Attribute:" + 
            //prop[i].getName());
            p = prop[i].getPropertyType();
       
            if (executeJoin) {
                column = getJoinMapping (classList, prop[i].getName());
            } else
                column = getMapping (obj.getClass().getName(), prop[i].getName());

            if (column == null) {
                continue;
            }
            
            
            // Chech if the column exists
            if (checkColumn)
                try {
                    rs.findColumn(column);
                } catch (SQLException e) {
                    continue;
                }

            if (p.getName().equals ("java.util.Date") ){
                dateValue = getDateValue (rs, column);
                factory.setValue (obj, prop[i].getName(), dateValue); 
                continue;
                //value = getRSDateValue (rs, column);
            } else if (p.getName().equals ("boolean") ){         
                value = getRSBooleanValue (rs, column);
            } else // check
                value = getRSValue (rs, column);

            //handleTrace ("factory.setValue:" + prop[i].getName() + ":" + value, 0);
            factory.setValue (obj, prop[i].getName(), value);     

        }
        return (obj);
    }
    
    
    // find: find records based on a query

    private Object findRecords (String query, Object obj1) {
        JtMessage msg;
        ResultSet res;
        Object obj;
        List col = new LinkedList ();
        JtDAOCursor cursor;

        msg = new JtMessage ();

        
        if (obj1 == null)
            return null;
            

        attr = getAttributes (obj1); // check

        //query = build_select_query ();

        if (query == null || db == null)
            return (null);

        
        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent (query);


        res = (ResultSet) factory.sendMessage (db, msg);

        if (propagateException (db) != null)
            return (null);

        if (returnCursor) {
            cursor = new JtDAOCursor ();
            if (classTable != null)
                cursor.setDaoDef((DAODefinition) classTable.get (obj1.getClass().getName()));
            cursor.setResultSet(res);      
            return (cursor);
        }
        
        if (res == null)
            return (null);

        msg.setMsgId (JtCollection.JtADD);

        try {

            while (res.next()) {
                obj = obj1.getClass().newInstance ();

                //((JtDAO) obj).setKey (key);
                //((JtDAO) obj).setTable (table);

                obj = mapRow (obj, res, true);
                if (obj == null)
                    continue; // check

                //msg.setMsgContent (obj);
                //sendMessage (col, msg);
                col.add(obj);

            }

        } catch (Exception e) {
            handleException (e);
            return (null);
        } 

        try {
            res.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        return (col);
    }
    
    
    /*
     * Execute a Query (returns a List o JtDAOCursor)
     */
    
    
    private Object executeQuery (String query, Object obj) {
        Object result = null;

        if (query == null || obj == null)
            return (null);

        
        result = findRecords (query, obj); 
        return result;

    }
    
/*    
    private String retrieveResourceName (String className) {
        StringBuffer buffer = new StringBuffer ();
        int i;
        char c;
        
        if (className == null)
            return (null);
        
        
        for (i = 0; i < className.length(); i++) {
            c = className.charAt(i);
            if (c == '.')
                buffer.append('/');
            else
                buffer.append(c);
        }
        
        buffer.append(".hbm.xml");
       
        return (buffer.toString());
        
        
    }
  */
    
    private boolean readConfigFile () {
        JDOMAdapter adapter = new JDOMAdapter ();
        JtMessage msg = new JtMessage (JDOMAdapter.READ_STREAM);
        JtMessage msg1 = new JtMessage (JDOMAdapter.FIND_ELEMENTS);
        List list;
        Iterator it;
        Element elem;
        String res;
        
        InputStream resStream;
        
        
        if (configFile == null) {
            handleError ("configFile attribute needs to be set.");
            return (false);   
        }   
        
        resStream = this.getClass().getClassLoader().getResourceAsStream (configFile);
                
        if (resStream == null) {
            handleError ("Unable to retrieve stream:" + configFile);
            return (false);
        }
        
        adapter.setInputStream(resStream);
        

        factory.sendMessage(adapter, msg);
        
        
        
        msg1.setMsgContent("mapping");
        list = (List) factory.sendMessage(adapter, msg1);
        
        if (list == null || list.isEmpty())
            return (false);
        it = list.iterator();
        
        while (it.hasNext()) {
            elem = (Element) it.next();
            res = elem.getAttributeValue ("resource");
            readMappingStream (res);
            //resourceTable.put(res, res);
        }
        
        msg1.setMsgContent("property");
        list = (List) factory.sendMessage(adapter, msg1);
        
        if (list == null || list.isEmpty())
            return (true);
        it = list.iterator();
        
        while (it.hasNext()) {
            elem = (Element) it.next();
            res = elem.getAttributeValue ("name");
            if ("connection.driver_class".equals(res))
                this.setDriver(elem.getText());

            if ("connection.url".equals(res))
                this.setUrl(elem.getText());
            
            if ("connection.username".equals(res))
                this.setUser(elem.getText());
            
            if ("connection.password".equals(res))
                this.setPassword(elem.getText());

        }
        
        return (true);
        
    }
    
    private boolean readMappingStream (String configFile) {

        DAODefinition daoDef = new DAODefinition ();
        JtMessage msg = new JtMessage (DAODefinition.READ_MAPPING_STREAM);
        InputStream resStream;
        JtFactory factory = new JtFactory ();
                

        if (configFile == null)
            return (false);
                     
        resStream = this.getClass().getClassLoader().getResourceAsStream (configFile);
        
        if (resStream == null)
            return (false);
        
        msg.setMsgData(resStream);
        factory.sendMessage(daoDef, msg);

        
        if (daoDef.getClassName() != null) {
            classTable.put(daoDef.getClassName(), daoDef);
            return (true);
        }    
        
        return (false);
        
    }
  
    /*
    private String retrieveKeyValue (Object value) {
        if (value == null)
            return null;

        if (value instanceof String) {
          return (String) "'" + value + "'";
        }

        if (value instanceof Integer ||
                value instanceof Long || 
                value instanceof Float ||
                value instanceof Byte ||
                value instanceof Boolean ||
                value instanceof Short ||
                value instanceof Double ||
                value instanceof Character) {
                return (value.toString());
        }   
        return (value.toString());       

    }
    */
    
    private String massageString (String str) {
        StringBuffer sBuffer = new StringBuffer ();
        int i;
        char c;
        
        if (str == null)
            return (null);
        
        if (str.equals(""))
            return ("");
        
        for (i = 0; i < str.length(); i++) {
            c = str.charAt(i);
            if (c != '\'')
                sBuffer.append(c);
            else {
                sBuffer.append(c);
                sBuffer.append(c);
            }    
        }
        return (sBuffer.toString());
        
    }
    
    private Hashtable getAttributes (Object obj) {

        //Object args[];
        PropertyDescriptor[] prop;
        int i;
        //Class p;
        Method m;
        BeanInfo info = null;
        Object value;
        Hashtable attr;

        attr = new Hashtable ();
        
        if (obj == null)
            return (null);

        /*
        if (map_table == null) {
            handleError 
            ("JtDAO.getAttributes: attributes/database mapping is missing");
            return (null);
        }
        */
        
        try {
            info = Introspector.getBeanInfo(
                    obj.getClass (), obj.getClass ().getSuperclass());
        } catch(Exception e) {
            handleException (e);
            return (null);
        }

        prop = info.getPropertyDescriptors();
        for(i = 0; i < prop.length; i++) {
//          System.out.print ("Attribute:" + 
//          prop[i].getName());
            //p = prop[i].getPropertyType();

            try {
                m = prop[i].getReadMethod ();
                if (m == null) {
                    handleError 
                    ("JtDAO: getReadMethod returned null");
                    return (null);
                }

                if (getMapping (obj.getClass().getName(), prop[i].getName()) == null)
                    continue;

                value = m.invoke (obj, null);
                if (value == null) {
//                  attr.put (prop[i].getName(), value); 
                    continue;
                }

                if (value instanceof String) {
                    //attr.put (prop[i].getName(), "'" + value + "'"); 
                    attr.put (prop[i].getName(), "'" + massageString ((String) value) + "'"); 
                    continue;
                }

                if (value instanceof Integer ||
                        value instanceof Long || 
                        value instanceof Float ||
                        value instanceof Byte ||
                        value instanceof Boolean ||
                        value instanceof Short ||
                        value instanceof Double ||
                        value instanceof Character) {
                    attr.put (prop[i].getName(), value.toString () ); 
                    //System.out.println ("=" + value);
                    continue;
                }

                if (value instanceof java.util.Date) {
                    attr.put (prop[i].getName(), value); 
                    continue;
                }

            } catch (Exception e) {
                handleException(e);
                return (null);
            }
        }

        return (attr);
    }
    
    private Hashtable retrieveMappingTable (String className) {
        DAODefinition daoDef;
        if (className == null)
            return null;
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(className);
        
        if (daoDef == null)
            return null;
        
        return (daoDef.getMappingTable());    
    }
    
    private List retrieveKeys (String className) {
        DAODefinition daoDef;
        if (className == null)
            return null;
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(className);
        
        if (daoDef == null)
            return null;
        
        return (daoDef.getKeys());    
    }
    
    private String getJoinMapping (List classList, String at) {
        Iterator iterator;
        String cName;
        String col;
        
        if (classList == null || at == null)
            return (null);
        
        
        iterator = classList.iterator();
        
        while (iterator.hasNext()) {
            
            cName = (String) iterator.next();
            col = getMapping (cName, at);
            
            if (col != null)
                return (col);
        }
        
        return (null);
    }
    
    private String getMapping (String className, String at) {
        DAODefinition daoDef;
        Hashtable mappingTable;
        DAOMapping daoMapping;
        
        if (className == null || at == null)
            return (null);

        if (classTable.isEmpty())
            return (null);

        
        daoDef = (DAODefinition) classTable.get(className);
        
        if (daoDef == null)
            return null;
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        daoMapping = (DAOMapping) mappingTable.get(at);
        
        
        return ((daoMapping==null)?null:daoMapping.getColumn());
    }
    
    
    // buildSelectQuery: build select query

    private String buildSelectQuery (Object obj, Object key) {
        StringBuffer query = new StringBuffer ();
        Enumeration attrs; 
        String att, tmp;
        String key_column;
        Hashtable mappingTable;
        DAODefinition daoDef;
        String keyAttr;
        List keys;
        int cnt;
        int i;
        String table;

        //if (map_table == null || obj == null)
        if (obj == null || key == null)
            return (null);
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null)
            return null;
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
                
        //keyAttr = ((DAOMapping) daoDef.getKeys().get(0)).getAttribute();

        keys = daoDef.getKeys();
        
        if (keys == null || (keys.size() < 1) ||  table == null)
            return (null);

        if (attr == null)
            return (null);

        
        attrs = mappingTable.keys ();
        if (!attrs.hasMoreElements ())
            return (null);
        
        
        query.append ("Select ");

        while (attrs.hasMoreElements ()) {
            att = (String) attrs.nextElement ();
            tmp = getMapping (obj.getClass().getName(), att);

            if (tmp == null) {
                handleError ("buildSelectQuery: invalid mapping for "
                        + att);
                return (null);
            }

            query.append (tmp);        

            if (attrs.hasMoreElements ())
                query.append (",");   

        }
        
                
        query.append (" from " + table + " where ");

        cnt = keys.size();
        for (i = 1; i <= cnt; i++) {
                        
            
            keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();
            key_column = getMapping (obj.getClass().getName(), (String) keyAttr);

            if (key_column == null) {
                handleError ("buildSelectQuery: invalid mapping for "
                        + key);
                return (null);      
            }

            query.append (key_column);
            query.append ("= ?");
            //query.append (value);
 

            
            if (i < cnt) {
                query.append(" AND ");
            }
        }

        handleTrace ("query:" + query);

        return (query.toString ());

    }
    
    private String buildInsertQuery (Object obj) {
        StringBuffer query = new StringBuffer ();
        Enumeration attrs; 
        String key;
        String value;
        Object tmp;
        String attn;
        Hashtable mappingTable;
        DAODefinition daoDef;
        String table;
                       

        if (obj == null)
            return null;
        
        if (attr == null)
            return (null);        
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null) {
            handleError ("Invalid DAO definition (null) for class " +
                    obj.getClass().getName());
            return null;
        }
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
        if (table == null)
            return null;

        //if (map_table == null)
        //    return (null);

        attrs = mappingTable.keys ();

        if (!attrs.hasMoreElements ())
            return (null);

        query.append ("Insert into " + table + " (");

        while (attrs.hasMoreElements ()) {
            key = (String) attrs.nextElement ();

            //attn = (String) map_table.get (key);
            attn = getMapping (obj.getClass().getName(), key);

            if (attn == null) {
                handleError ("buildInsertQuery: invalid mapping for " +
                        attn);
                return (null);
            }  

            query.append (attn);

            if (attrs.hasMoreElements ())
                query.append (","); 
            //value = (String) attr.get (key);

        }
        query.append (") values (");

        attrs = mappingTable.keys ();

        while (attrs.hasMoreElements ()) {

            key = (String) attrs.nextElement ();

            tmp = attr.get (key);

            if (tmp == null) {
                query.append ("null");
            } else if (tmp instanceof String) {
                value = (String) attr.get (key); // check
                query.append (value);
            } else if (tmp instanceof java.util.Date) {
                query.append ("?");
            } 

            //value = (String) attr.get (key);

            //query.append (value);

            if (attrs.hasMoreElements ())
                query.append (","); 

        }
        query.append (")");

        handleTrace ("query:" + query);

        return (query.toString ());

    }
    
    // buildUpdateQuery: build update query

    private String buildUpdateQuery (Object obj) {
        StringBuffer query = new StringBuffer ();
        Enumeration attrs; 
        String att;
        String keyAttr, value;
        Object tmp;
        String column;
        String key_column;
        boolean first = true;
        Hashtable mappingTable;
        DAODefinition daoDef;
        List keys;
        int cnt, i;
        String table;
        

        if (obj == null)
            return (null);
        
        if (attr == null)
            return (null);
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null)
            return null;
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
        //key = ((DAOMapping) daoDef.getKeys().get(0)).getAttribute();
        
        keys = daoDef.getKeys();
        
        if (keys == null || (keys.size() < 1) || table == null)
            return (null);

        //if (map_table == null)
        //    return (null);

        attrs = mappingTable.keys ();

        if (!attrs.hasMoreElements ())
            return (null);

        query.append ("Update " + table + " Set ");

        while (attrs.hasMoreElements ()) {
            att = (String) attrs.nextElement ();

            if (isKeyAttribute (keys, att))
                continue; // check

            tmp = (Object) attr.get (att);

            if (!((tmp == null) || tmp instanceof String || 
                    tmp instanceof java.util.Date)) {
                handleError ("buildUpdateQuery:invalid type for "
                        + att);
                return (null);
            }

            column = getMapping (obj.getClass().getName(), att);

            if (column == null) {
                handleError ("buildUpdateQuery: invalid mapping for " +
                        att);
                return (null);
            }      

            if (first) {
                first = false;
            } else 
                query.append (", ");

            query.append (column);

            if (tmp == null) {
                query.append ("="+null);
            } else if (tmp instanceof String) {
                value = (String) attr.get (att);
                query.append ("="+value);
            } else if (tmp instanceof java.util.Date) {
                query.append ("= ?");
            } 


        }

        query.append (" where ");
        
        cnt = keys.size();
        for (i = 1; i <= cnt; i++) {
            keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();

            //value = (String) attr.get (keyAttr);

            //if (value == null) {
            //    handleError ("buildUpdateQuery: invalid key (null)");
            //    return (null);
            //}

            key_column = getMapping (obj.getClass().getName(), (String) keyAttr);

            if (key_column == null) {
                handleError ("buildUpdateQuery: invalid mapping for "
                        + keyAttr);
                return (null);      
            }

            //query.append (key_column + "=" + value);
            query.append (key_column + "= ?");

            if (i < cnt) {
                query.append(" AND ");
            }
        }

        handleTrace ("query:" + query);

        return (query.toString ());

    }
 
    // buildDeleteQuery: build delete query

    private String buildDeleteQuery (Object obj) {
        StringBuffer query = new StringBuffer ();
        Object value;
        String key_column;
        DAODefinition daoDef;
        Hashtable mappingTable;
        String keyAttr;
        List keys;
        int cnt, i;
        String table;
        

        if (attr == null || obj == null)
            return (null);

        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null)
            return null;
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
        //keyAttr = ((DAOMapping) daoDef.getKeys().get(0)).getAttribute();
        keys = daoDef.getKeys();
        
        
        if (keys == null || (keys.size() < 1) ||  table == null)
            return (null);
              

        //if (map_table == null)
        //    return (null);


        
        query.append ("Delete from "
                + table + " where "); //check
        
        
        cnt = keys.size();
        for (i = 1; i <= cnt; i++) {
            keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();

            key_column = getMapping (obj.getClass().getName(), (String) keyAttr);

            if (key_column == null) {
                handleError ("buildDeleteQuery: invalid mapping for "
                        + keyAttr);
                return (null);      
            }
            
            query.append (key_column);
            
            value = attr.get (keyAttr);
            //value = (Object) getValue (this, key);

            if (value == null) {
                handleError ("buildDeleteQuery: invalid key (null)");
                return (null);
            }
            //query.append (key);
            query.append ("= ?");
            //query.append (value);

            if (i < cnt) {
                query.append(" AND ");
            }
        }

        handleTrace ("query:" + query);

        return (query.toString ());

    }  
    
    
    private String buildSearchByAttributeQuery (Object obj, Collection attributeNames) {
        StringBuffer query = new StringBuffer ();
        Enumeration attrs; 
        String att, tmp;
        String key_column;
        Hashtable mappingTable;
        DAODefinition daoDef;
        String keyAttr;
        //List keys;
        int cnt;
        int i;
        String table;
        Iterator iterator;


        if (obj == null || attributeNames == null) {
            handleError ("buildSearchQuery: invalid parameters." );
            return (null);
        }    
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null) {
            handleError ("DAO definition not found for " + obj.getClass().getName());
            return null;
        }    
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
        if (table == null) {
            handleError ("Invalid DAO definition object. Table name is null.");
            return null;
        }
                

        /*
        keys = daoDef.getKeys();
        
        if (keys == null || (keys.size() < 1) ||  table == null)
            return (null);
        */
        
        attrs = mappingTable.keys ();
        if (!attrs.hasMoreElements ())
            return (null);
        
        
        query.append ("Select ");

        while (attrs.hasMoreElements ()) {
            att = (String) attrs.nextElement ();
            tmp = getMapping (obj.getClass().getName(), att);

            if (tmp == null) {
                handleError ("buildSelectQuery: invalid mapping for "
                        + att);
                return (null);
            }

            query.append (tmp);        

            if (attrs.hasMoreElements ())
                query.append (",");   

        }
        
                
        query.append (" from " + table + " where ");

        if (attributeNames.isEmpty()) {
            handleError ("Invalid paramenters. attributeNames names is empty.");
            return (null);
        }
        
        iterator = attributeNames.iterator();
        
        //cnt = keys.size();
        cnt = attributeNames.size();
        
        for (i = 1; i <= cnt; i++) {
                        
            
            //keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();
            keyAttr = (String) iterator.next();
            key_column = getMapping (obj.getClass().getName(), keyAttr);

            if (key_column == null) {
                handleError ("buildSearchQuery: invalid mapping for "
                        + keyAttr);
                return (null);      
            }

            query.append (key_column);
            query.append ("= ?");
            //query.append (value);
 

            
            if (i < cnt) {
                query.append(" AND ");
            }
        }

        handleTrace ("query:" + query);

        return (query.toString ());

    }
    
    
    private List retrieveKeywordList (String keywords) {
        String keywordArray[];
        int i;
        LinkedList list = new LinkedList ();
        
        
        if (keywords == null)
            return (null);
        
        keywordArray = keywords.split(" ");
        
        for (i = 0; i < keywordArray.length; i++) {
            
            list.add(keywordArray[i]);
            handleTrace ("retrieveKeywordList:" + keywordArray[i]);

        }  
        
        return (list);
    }
    
    private String buildSearchForKeywordsQuery (Object obj, String attributeName,
            String keywords) {
        StringBuffer query = new StringBuffer ();
        Enumeration attrs; 
        String att, tmp;
        String key_column;
        Hashtable mappingTable;
        DAODefinition daoDef;
        String keyAttr;
        //List keys;
        //int cnt;
        //int i;
        String table;
        Iterator iterator;
        String keyword;
        List keywordList;
        

        if (obj == null || attributeName == null || keywords == null) {
            handleError ("Invalid parameters." );
            return (null);
        }    
        
        if (classTable.isEmpty())
            return (null);
        
        daoDef = (DAODefinition) classTable.get(obj.getClass().getName());
        
        if (daoDef == null) {
            handleError ("DAO definition not found for " + obj.getClass().getName());
            return null;
        }    
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        table = daoDef.getTable();
        
        if (table == null) {
            handleError ("Invalid DAO definition object. Table name is null.");
            return null;
        }
                

        /*
        keys = daoDef.getKeys();
        
        if (keys == null || (keys.size() < 1) ||  table == null)
            return (null);
        */
        
        attrs = mappingTable.keys ();
        if (!attrs.hasMoreElements ())
            return (null);
        
        
        query.append ("Select ");

        while (attrs.hasMoreElements ()) {
            att = (String) attrs.nextElement ();
            tmp = getMapping (obj.getClass().getName(), att);

            if (tmp == null) {
                handleError ("Invalid mapping for "
                        + att);
                return (null);
            }

            query.append (tmp);        

            if (attrs.hasMoreElements ())
                query.append (",");   

        }
        
                
        query.append (" from " + table + " where ");


        keywordList = retrieveKeywordList (keywords);

        if (keywordList == null)
            return (null);
        
        iterator = keywordList.iterator();
        
        keyAttr = (String) attributeName;
        key_column = getMapping (obj.getClass().getName(), keyAttr);

        if (key_column == null) {
            handleError ("Invalid mapping for "
                    + keyAttr);
            return (null);      
        }
        
        //for (i = 1; i <= cnt; i++) {
        while (iterator.hasNext()) {
            keyword = (String) iterator.next();
            
            //keyAttr = ((DAOMapping) keys.get(i - 1)).getAttribute();


            query.append (key_column);
            query.append (" like ?");
            //query.append ("=" + "'" + massageString (keyword) + "'" );
            //query.append (value);
 

            
            //if (i < cnt) {
            if (iterator.hasNext()) {
                query.append(" AND ");
            }
        }

        handleTrace ("query:" + query);

        return (query.toString ());

    }
    
    private String getRSValue (ResultSet rs, String column)
    {
        String value = null;

        if (rs == null || column == null)
            return (null);

        try {
            value = rs.getString (column);
        } catch (Exception e) {
            handleException (e);
        }
        return (value);
    }  

    // getRSDateValue 
/*
    private String getRSDateValue (ResultSet rs, String column)
    {
        String value = null;
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);

        if (rs == null || column == null)
            return (null);

        try {
            java.sql.Date date = rs.getDate (column);
            if (date == null)
                return (null); // check
            value = df.format (date); // check
            //value = rs.getString (column);
        } catch (Exception e) {
            handleException (e);
        }
        return (value);
    }  
*/    
    
    private java.util.Date getDateValue (ResultSet rs, String column) {
        if (rs == null || column == null)
            return (null);
        
        try {
            java.sql.Timestamp tstamp = rs.getTimestamp (column);
            if (tstamp == null)
                return (null); // check
            return (new java.util.Date (tstamp.getTime()));

        } catch (Exception e) {
            handleException (e);
            return null;
        }
        
    }

    private String getRSBooleanValue (ResultSet rs, String column)
    {
        String value = null;

        if (rs == null || column == null)
            return (null);

        try {
            boolean b = rs.getBoolean (column);
            //if (b == null)
            //  return (null); // check

            if (b)
                return ("true");
            else
                return ("false");

            //value = b.toString ();
        } catch (Exception e) {
            handleException (e);
        }
        return (value);
    } 

    /*
    private Object map (Object obj, ResultSet rs) {

        //Object args[];
        PropertyDescriptor[] prop;
        int i;
        Class p;
        BeanInfo info = null;
        String value; // check
        String column;
        Object jtout = null;
        java.util.Date dateValue;
        
        if (obj == null || rs == null)
            return null;
        
        
        try {
            jtout = obj.getClass().newInstance();
        } catch (Exception e) {
            handleException (e);
            return (null);
        }
        

        try {

            info = Introspector.getBeanInfo(
                    obj.getClass (), obj.getClass ().getSuperclass());
        } catch(Exception e) {
            handleException (e);
            return (null);
        }

        prop = info.getPropertyDescriptors();
        for(i = 0; i < prop.length; i++) {
            //System.out.print ("Attribute:" + 
            //prop[i].getName());
            p = prop[i].getPropertyType();

            column = getMapping (obj.getClass().getName(), prop[i].getName());

            if (column == null) {
                continue;
            }

            if (p.getName().equals ("java.util.Date") ){
                dateValue = getDateValue (rs, column);
                setValue (jtout, prop[i].getName(), dateValue); 
                continue;
                //value = getRSDateValue (rs, column);
            } else if (p.getName().equals ("boolean") ){         
                value = getRSBooleanValue (rs, column);
            } else // check
                value = getRSValue (rs, column);

            setValue (jtout, prop[i].getName(), value);     

        }
        return (jtout);
    }
    */
    
    // find: find record

    private Object find (Object obj, Object key) {
        JtMessage msg;
        String query;
        ResultSet res;
        Object jout;
        PreparedStatement pst;
        List keys;

        msg = new JtMessage ();
        
        if (obj == null) {
            handleError ("find: invalid parameter obj (null)");
            return (null);
        }    
        
        if (key == null) {
            handleError ("find: invalid parameter key (null)");           
            return (null);
        }    

        //if (db == null)
        //    realize ();

        attr = getAttributes (obj); // check

        query = buildSelectQuery (obj, key);

        if (query == null || db == null)
            return (null);

       
        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);
        

        if (propagateException (db) != null)
            return (null);

        if (pst == null)
            return (null);  // check

        keys = retrieveKeys (obj.getClass().getName());
        
        if (keys == null || keys.isEmpty())
            return null;
            
        if (!setKeyParameters (pst, keys, key, 1, keys.size() == 1))
            return null;

        //if (propagateException (db) != null)
        //    return (null);

        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_QUERY);
        msg.setMsgContent (pst);
        res = (ResultSet) factory.sendMessage (db, msg);


        if (propagateException (db) != null)
            return (null);

        
        // Execute the database query
/*        
        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_QUERY);
        msg.setMsgContent (query);


        res = (ResultSet) factory.sendMessage (db, msg);

        if (propagateException (db) != null)
            return (null);

*/
        
        if (res == null)
            return (null);

        try {
            if (!res.next()) // check
                return (null);
        } catch (Exception e){
            handleException (e);
            return (null);
        } 

        jout = mapRow (obj, res, true);

        try {
            res.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }
        
        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        return (jout);
    }

    // propagateException: 

    private Exception propagateException (JtObject obj)
    {
        Exception ex;

        if (obj == null)
            return null;

        //ex = (Exception) 
        //getValue (obj, "objException");
        
        ex = (Exception) obj.getObjException();

        if (ex != null)
            //setValue (this, "objException", ex);
            this.setObjException(ex);

        return (ex);
    }
    
    
    // Reset the object exceptions
    
    private void resetException ()
    {
        if (this.db != null)
            db.setObjException(null);

        this.setObjException(null);
        

    }
    
    /*
    private boolean  readMappingResource (String className) {
        String resourceName;
        
        if (className == null)
            return false;
        
        resourceName = retrieveResourceName (className);
        
        if (resourceName == null)
            return (false);
        
        if (resourceTable.get(resourceName) == null) {
            handleError (configFile + ":no resource found in the configuration file for " + resourceName);
            return false;
        }    
        return (readMappingStream ((String) resourceTable.get(resourceName)));
        
    }
   */
    

    
     
    
    private Object searchByAttribute (Object obj, List attributeNames) {


        JtMessage msg;
        String query;
        ResultSet res;
        //Object jout;
        PreparedStatement pst;
        //List keys;
        JtDAOCursor cursor;
        LinkedList col = new LinkedList ();
        Object obj1;
       

        msg = new JtMessage ();
        
        if (obj == null) {
            handleError ("Invalid parameter obj (null).");
            return (null);
        }    
        
        if (attributeNames == null || attributeNames.isEmpty ()) {
            handleError ("Invalid parameter attributeNames (null or empty).");           
            return (null);
        }    


        //attr = getAttributes (obj); // check

        //factory.sendMessage(obj, new JtMessage (JtObject.JtPRINT));
        
        query = buildSearchByAttributeQuery (obj, attributeNames);

        if (query == null) {
            if (this.getObjException() == null)
                handleError ("Unable to build search query.");
            return (null);
        }
        
        if (db == null)
            return (null);

       
        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);
        

        if (propagateException (db) != null)
            return (null);

        if (pst == null) {
            handleError ("Unable to build prepared statement.");
            return (null); 
        }    

        //keys = retrieveKeys (obj.getClass().getName());
        
        //if (keys == null || keys.isEmpty())
        //    return null;
            
        if (!setStatementParameters (pst, attributeNames, obj, 1)) {
            if (this.getObjException() == null)
                handleError ("Unable to set Statement parameters");
            return null;
        }    

        //if (propagateException (db) != null)
        //    return (null);

        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_QUERY);
        msg.setMsgContent (pst);
        res = (ResultSet) factory.sendMessage (db, msg);


        if (propagateException (db) != null)
            return (null);

        
        if (res == null)
            return (col);  // Check


        
        if (returnCursor) {
            cursor = new JtDAOCursor ();
            if (classTable != null)
                cursor.setDaoDef((DAODefinition) classTable.get (obj.getClass().getName()));
            cursor.setResultSet(res);      
            
            try {
                pst.close ();
            }
            catch (Exception ex) {
                handleException (ex);
            }
            return (cursor);
        }
        
        msg.setMsgId (JtCollection.JtADD);

        try {

            while (res.next()) {
                obj1 = obj.getClass().newInstance ();


                obj1 = mapRow (obj1, res, true);
                if (obj1 == null) {
                    handleError ("Unable to map object.");
                    return (null); // check
                }    

                col.add(obj1);

            }

        } catch (Exception e) {
            handleException (e);
            return (null);
        } 

        try {
            res.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }
        
        return (col);        
            
        
    }
    
    
    
    private Object searchForKeyword (Object obj, String attributeName,
            String keywords) {


        JtMessage msg;
        String query;
        ResultSet res;
        PreparedStatement pst;
        JtDAOCursor cursor;
        LinkedList col = new LinkedList ();
        Object obj1;
       

        msg = new JtMessage ();
        
        if (obj == null || attributeName == null || keywords == null) {
            handleError ("Invalid parameters (null).");
            return (null);
        }    

        
        query = buildSearchForKeywordsQuery (obj, attributeName, keywords);

        if (query == null) {
            if (this.getObjException() == null)
                handleError ("Unable to build search query.");
            return (null);
        }
        
        if (db == null)
            return (null);

        
        msg.setMsgId (JtJDBCAdapter.JtPREPARE_STATEMENT);
        msg.setMsgContent (query);

        pst = (PreparedStatement) factory.sendMessage (db, msg);
        

        if (propagateException (db) != null)
            return (null);

        if (pst == null) {
            handleError ("Unable to build prepared statement.");
            return (null); 
        }    

            
        /*
        if (!setStatementParameters (pst, attributeNames, obj, 1)) {
            if (this.getObjException() == null)
                handleError ("Unable to set Statement parameters");
            return null;
        }    
        */
        
        if (!setStatementKeywords (pst, keywords)) {
            if (this.getObjException() == null)
                handleError ("Unable to set Statement parameters");
            return null;
        }
        
        //if (propagateException (db) != null)
        //    return (null);

        msg.setMsgId (JtJDBCAdapter.JtEXECUTE_PREPARED_QUERY);
        //msg.setMsgContent (query);
        msg.setMsgContent (pst);
        res = (ResultSet) factory.sendMessage (db, msg);


        if (propagateException (db) != null)
            return (null);

        
        if (res == null)
            return (col);  // Check

        
        if (returnCursor) {
            cursor = new JtDAOCursor ();
            if (classTable != null)
                cursor.setDaoDef((DAODefinition) classTable.get (obj.getClass().getName()));
            cursor.setResultSet(res);      
/*            
            try {
                pst.close ();
            }
            catch (Exception ex) {
                handleException (ex);
            }
*/
            
            return (cursor);
        }
        
        msg.setMsgId (JtCollection.JtADD);

        try {

            while (res.next()) {
                obj1 = obj.getClass().newInstance ();


                obj1 = mapRow (obj1, res, true);
                if (obj1 == null) {
                    handleError ("Unable to map object.");
                    return (null); // check
                }    

                col.add(obj1);

            }

        } catch (Exception e) {
            handleException (e);
            return (null);
        } 

        try {
            res.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }

        /*
        try {
            pst.close ();
        }
        catch (Exception ex) {
            handleException (ex);
        }
        */
        
        return (col);        
            
        
    }
    

    /**
     * Process object messages.
     * <ul>
     * <li> JtINSERT/JtCREATE - Inserts an object. msgContent specifies the object
     * to be inserted.
     * <li> JtFIND/JtREAD - Finds an object. Returns the object or null. msgData 
     * specifies the identifier (key). msgContent specifies an instance of the 
     * persistent class. This instance is only used to determine the persistent class.
     * msgContent can be any instance of the class.
     * <li> JtUPDATE - Updates an object. msgContent specifies the object
     * to be updated.
     * <li> JtDELETE - Deletes an object. msgContent specifies the object
     * to be deleted.
     * <li> JtREMOVE - Releases resources and closes the session.
     * <li> JtEXECUTE_QUERY - Execute an SQL query. msgContent specifies
     * the query to be executed.
     * <li> JtBEGIN_TRANSACTION - Starts a transaction. 
     * <li> JtCOMMIT - Commits the transaction. 
     * <li> JtROLLBACK - Rollbacks the transaction. 
     * </ul>
     */
    
    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object obj;
        Object key;
        String query;
        Object reply;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        obj = e.getMsgContent();
        
        executeJoin = false;
        
        if (msgid.equals (JtDAOAdapter.JtREAD_MAPPING_STREAM)) {
            readMappingStream ((String) e.getMsgContent());
            return (null);
        }
        
        if (!initted) {
            initialize ();
            //if (this.getObjException() != null)
            //    return (null);
            //else    
            initted = true;
            if (this.getObjException() != null)
                return (null);
        }

        // Reset exceptions
        
        resetException ();

        if (msgid.equals (JtDAOAdapter.JtINSERT) ||
                msgid.equals (JtDAOAdapter.JtCREATE)) {
            
            //if (autocommit)
            //   beginTransaction ();
            
            //if (!checkMappingResource (obj))
            //  return (null);
            
            reply = insert (obj);

            /*
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction ();
            */
            
            return (null);
        }

        if (msgid.equals (JtDAOAdapter.JtFIND) ||
                msgid.equals (JtDAOAdapter.JtREAD)) {
            //if (autocommit)
            //    beginTransaction ();
            
            key = e.getMsgData ();
            
            //if (!checkMappingResource (obj))
            //    return (null);
            
            reply = find (obj, key);
            
            /*
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            */
            
            return (reply);
        }

        if (msgid.equals (JtDAOAdapter.JtUPDATE)) {
            //if (autocommit)
            //    beginTransaction ();
            
            

            //checkResource
            
            //if (!checkMappingResource (obj))
            //    return (null);
            
            reply = update (obj);

            /*
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            */
            return (null);
        }
        
        
        if (msgid.equals (JtDAOAdapter.JtDELETE)) {
            
            //if (autocommit)
            //    beginTransaction ();           
            
            //key = e.getMsgData ();
            //if (!checkMappingResource (obj))
            //    return (null);
            
            reply = delete (obj);
 
            /*
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction ();
            */         
            return (null);
        }
 
        if (msgid.equals (JtDAOAdapter.JtBEGIN_TRANSACTION)) {
            beginTransaction ();
            return (null);
        }
        
        if (msgid.equals (JtDAOAdapter.JtCOMMIT)) {
            commitTransaction ();
            return (null);
        }
        

 
        if (msgid.equals (JtDAOAdapter.JtROLLBACK)) {
            rollbackTransaction ();
            return (null);
        }
 
        if (msgid.equals (JtDAOAdapter.JtEXECUTE_QUERY)) {
            
            //if (autocommit)
            //    beginTransaction ();

            
            query = (String) e.getMsgContent();
            obj = e.getMsgData();
            
            //if (!checkMappingResource (obj))
            //    return (null);
            
            reply = executeQuery (query, obj);
            
            /*
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            */
            return (reply);
        }
        
        if (msgid.equals (JtDAOAdapter.JtEXECUTE_JOIN)) {
            
            
            query = (String) e.getMsgContent();
            obj = e.getMsgData();
            executeJoin = true;
            classList = (List) e.getMsgAttachment();
            
            reply = executeQuery (query, obj);
            

            return (reply);
        }
        
        if (msgid.equals (JtObject.JtREMOVE)) {
            //closeSession ();
            if (this.db != null)
                factory.sendMessage(this.db, new JtMessage (JtJDBCAdapter.JtCLOSE));

            return (null);
        }
        
        if (msgid.equals (JtDAOAdapter.JtSEARCH_BY_ATTRIBUTES)) {
            reply = searchByAttribute (obj, (List) e.getMsgData());
            return (reply);
        }
        
        // Check - Hibernate Adapter needs to implement this
        
        if (msgid.equals (JtDAOAdapter.JtSEARCH_FOR_KEYWORDS)) {
            reply = searchForKeyword (obj, (String) e.getMsgData(), 
                    (String) e.getMsgAttachment());
            return (reply);
        }
        
        if (msgid.equals (JtDAOAdapter.GET_DAODESCRIPTOR)) {

            if (classTable == null)
                return (null);

            return (classTable.get(e.getMsgContent()));
        }
        
        return (super.processMessage(event));



    } 
}
