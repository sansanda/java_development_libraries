package Jt.DAO;


import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
import org.jdom.DocType;
import org.jdom.Element;

import Jt.*;
import Jt.util.BeanProperty;
import Jt.util.JtJavaParser;
//import Jt.wizard.struts.DAODefinitionForm;
//import Jt.wizard.struts.FileForm;
import Jt.xml.JDOMAdapter;


/**
 * DAO Definition. This class helps define a Data Access Object (JtWizard internal class).
 */

public class DAODefinition extends JtObject {
    public static final String JtCLASS_NAME = DAODefinition.class.getName(); 
    public static final String GENERATE_DESCRIPTOR = "GENERATE_DESCRIPTOR"; 
    public static final String GENERATE_FORM = "GENERATE_FORM"; 
    public static final String INITIALIZE = "INITIALIZE";   
    public static final String READ = "READ"; 
    public static final String READ_STREAM = "READ_STREAM"; 
    public static final String READ_MAPPING_STREAM = "READ_MAPPING_STREAM"; 
    public static final String UPDATE = "UPDATE"; 
    public static final String PARSE_FILE = "PARSE_FILE"; 
    public static final int MAX_ENTRIES = 12;

    private static final long serialVersionUID = 1L;

    private String className;
    private String table;
    //private JtList keys; 
    private List keys;   // DB Keys
    private String fileName;
    private JDOMAdapter adapter = new JDOMAdapter ();
    private JtFactory factory = new JtFactory ();
    private DAODefinitionForm daoForm;
    //JtHashTable attributes;
    private transient LinkedList attributeList = new LinkedList (); 
    private Hashtable mappingTable = new Hashtable ();
    
    

    public DAODefinition() {
    }

    // Attributes


    public void setClassName (String className) {
        this.className = className; 

    }

    public String getClassName () {
        return (className);
    }
   
    public List getKeys() {
        return keys;
    }

    public void setKeys(List keys) {
        this.keys = keys;
    }

    public Hashtable getMappingTable() {
        return mappingTable;
    }

    public void setMappingTable(Hashtable mappingTable) {
        this.mappingTable = mappingTable;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    
    public String getTable() {
        return table;
    }


    public void setTable(String table) {
        this.table = table;
    }

    /*
    public JtList getKeys() {
        return keys;
    }

    public void setKeys(JtList keys) {
        this.keys = keys;
    }
*/    
    
    private void handleUIError (String error) {
        Collection col;

        if (error == null)
            return;
        col = (Collection) this.getObjErrors();

        if (col == null) {
            col = new LinkedList ();
            setObjErrors (col);
        }
        col.add(error);

    }
    
    private void propagateException (JtObject obj) {
        if (obj == null)
            return;
        
        if (obj.getObjException() != null) {
            this.setObjException(obj.getObjException());
        }
        
    }
    
    private void addElement (JDOMAdapter adapter, String parentPath, Element element) {
        JtMessage msg = new JtMessage (JDOMAdapter.ADD_ELEMENT);

        if (adapter == null || element == null)
            return;
        
        msg.setMsgContent(element);
        msg.setMsgData(parentPath);
        adapter.processMessage(msg);
    }
 
    
    private DAOMapping getMapping (DAODefinitionForm daoForm, String attrName){
        DAOMapping arr[];
        int i;

        if (daoForm == null || attrName == null)
            return null;

        arr = (DAOMapping[]) daoForm.getDbmappings();
        
        if (arr == null)
            return null;
        for (i = 0; i < arr.length; i++) {
            if (attrName.equals (arr[i].getAttribute()))
                return (arr[i]);
        }
        
        return (null);
        
    }    

    
    private List retrieveKeys (DAODefinitionForm daoForm) {
        DAOMapping arr[];
        int i;
        LinkedList list = new LinkedList ();
        
        if (daoForm == null)
            return null;

        arr = (DAOMapping[]) daoForm.getDbmappings();
        
        for (i = 0; i < arr.length; i++) {
            
            if (arr[i].isKeyAttribute())
                list.add(arr[i]);
           
        }
        return (list);
        
    }
    
    private boolean ngenerateIds () {
        //JtIterator iterator;
        int cnt;
        Element element = new Element ("id");
        String idName;
        //String[] dbKeys;
        int i;
        DAOMapping attrMapping;  
        String columnName;
        //List keys;
        Element columnElement; 
        
        if (daoForm == null || keys == null)
            return (true);
        /*
        dbKeys = (String[]) daoForm.getDbkeys();
                        
        if (dbKeys == null)
            return (true); // check
        
        cnt = dbKeys.length;
        */
        
        //keys = retrieveKeys (daoForm);
        cnt = keys.size();
        
        if (cnt == 1) {
            
            //idName = dbKeys[0];
            attrMapping = (DAOMapping) keys.get(0);
            
            idName = attrMapping.getAttribute();
            element.setAttribute("name", idName);
            
            
            attrMapping = getMapping (daoForm, idName);
            
   
            
            if (attrMapping == null) {
                handleWarning ("DAODefinition.ngenerateIds: unable to retrieve mapping for key:" +
                        idName); 
            } else {
                
                columnElement =  addColumnSubElement (attrMapping);  
                columnName = attrMapping.getColumn();
                
                if (columnElement != null)
                    element.addContent(columnElement);
                else if (columnName != null && !columnName.equals("")) // check white spaces
                    if (!columnName.equals (attrMapping.getAttribute()))
                        element.setAttribute("column", columnName);            
/*                
                if (columnName != null && !columnName.equals("")) // check for white spaces
                    if (!columnName.equals (attrMapping.getAttribute()))  
                        element.setAttribute("column", columnName);
*/
            }
            addElement (adapter, "hibernate-mapping/class", element);
            return (true);
        }
        
        element = new Element ("composite-id");
        addElement (adapter, "hibernate-mapping/class", element);
        for (i = 0; i < cnt; i++) {
            
            attrMapping = (DAOMapping) keys.get(i);
            
            idName = attrMapping.getAttribute();

            //idName = dbKeys[i];
            if (idName == null)
                break;     
            element = new Element ("key-property");
            element.setAttribute("name", idName);  
            
            attrMapping = getMapping (daoForm, idName);
            
            if (attrMapping == null) {
                handleWarning ("DAODefinition.ngenerateIds: unable to retrieve mapping for key:" +
                        idName); 

            } else {

                columnName = attrMapping.getColumn();
                columnElement =  addColumnSubElement (attrMapping);                
                
                if (columnElement != null)
                    element.addContent(columnElement);
                else if (columnName != null && !columnName.equals("")) // check white spaces
                    if (!columnName.equals (attrMapping.getAttribute()))
                        element.setAttribute("column", columnName);    
                
/*
                if (columnName != null && !columnName.equals("")) // check for white spaces
                    if (!columnName.equals (attrMapping.getAttribute()))  
                        element.setAttribute("column", columnName);
*/
            }
            
            addElement (adapter, "hibernate-mapping/class/composite-id", element);
        }
        return (true);
        
    }
    
 /*    
    private JtIterator getAttributes () {
        
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        //JtFactory factory = new JtFactory ();
        Object obj;     
        JtHashTable attributes;
        JtIterator iterator;
      
        if (className == null)
            return (null);
              
        obj = factory.createObject(className);           
        
        msg.setMsgContent(obj);
        
        attributes = (JtHashTable) factory.processMessage(msg);
        
        if (attributes  == null)
            return (null);
        
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        return (iterator);
        
    }
*/   
    
    
    private String[] getIDs () {
        Element elem;
        LinkedList list = new LinkedList ();
        String id;
        JtMessage msg = new JtMessage (JDOMAdapter.FIND_ELEMENT);
        String ids[];
        List children;
        int i;
        
        if (adapter == null)
            return null;
        
        msg.setMsgContent("hibernate-mapping/class/id");
        elem = (Element) factory.sendMessage (adapter, msg);
        
        if (elem != null) {
            id = elem.getAttributeValue("name");
            if (id != null)
                list.add(id);
            ids = (String[]) list.toArray(new String[0]);
            
            return ids;
        }
        
        msg = new JtMessage (JDOMAdapter.GET_CHILDREN);
        msg.setMsgContent("hibernate-mapping/class/composite-id");
        children = (List) factory.sendMessage (adapter, msg);      

        if (children == null) {
            return (null);
        }
        
        for (i = 0; i < children.size(); i++) {
            elem = (Element) children.get(i);
            
            if (!("key-property".equals(elem.getName())))
                    continue;
            
            id = elem.getAttributeValue("name");

            list.add(id);
        }  
        
        ids = (String[]) list.toArray(new String[0]);
        
        return ids;
        
    }
    
    // Updates the list (using the IDs)
    
    private void addIds (List list) {
        Element elem;
        String id;
        JtMessage msg = new JtMessage (JDOMAdapter.FIND_ELEMENT);
        List children;
        int i;
        DAOMapping attrMapping;
        String column;
        
        if (adapter == null)
            return;
        
        msg.setMsgContent("hibernate-mapping/class/id");
        elem = (Element) factory.sendMessage (adapter, msg);
        
        if (elem != null) {
            id = elem.getAttributeValue("name");
            
            attrMapping = new DAOMapping ();
            attrMapping.setAttribute(id);

            column = elem.getAttributeValue("column");
            attrMapping.setEnabled(true);
            attrMapping.setKeyAttribute(true);
           
            if (column == null || column.equals(""))
                attrMapping.setColumn(id); //check
            else
                attrMapping.setColumn(column);
            
            handleColumnSubElement (elem, attrMapping);
            
            list.add(attrMapping);
            
            return;
            

        }
        
        msg = new JtMessage (JDOMAdapter.GET_CHILDREN);
        msg.setMsgContent("hibernate-mapping/class/composite-id");
        children = (List) factory.sendMessage (adapter, msg);      

        if (children == null) {
            return;
        }
        
        for (i = 0; i < children.size(); i++) {
            elem = (Element) children.get(i);
            
            if (!("key-property".equals(elem.getName())))
                    continue;
            
            id = elem.getAttributeValue("name");
            
            attrMapping = new DAOMapping ();
            attrMapping.setAttribute(id);

            column = elem.getAttributeValue("column");
            attrMapping.setEnabled(true);
            attrMapping.setKeyAttribute(true);
           
            if (column == null || column.equals(""))
                attrMapping.setColumn(id); //check
            else
                attrMapping.setColumn(column);
            
            handleColumnSubElement (elem, attrMapping);
            
            list.add(attrMapping);
        }                 
        
    }
 
    private void initializeFormMapping (DAODefinitionForm form) {

        Iterator iterator;
        LinkedList list = new LinkedList();
        String st;
        DAOMapping arr[];
        DAOMapping entry;
        BeanProperty prop;
        
/*        
        if (attributes == null) {
            return;
        }  
*/        
        //iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        iterator = attributeList.iterator();
        
        if (iterator == null)
            return;
        
        for (;;) {
            //st = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (!iterator.hasNext())
                break;
        
            prop = (BeanProperty) iterator.next();
            st = prop.getName();
            //if (st == null)
            //    break;

            entry = new DAOMapping ();
            entry.setAttribute(st);
            entry.setColumn(st);  
            entry.setEnabled (true);
            list.add(entry);
        }    
        
        while (list.size() < DAODefinition.MAX_ENTRIES) {
            entry = new DAOMapping ();
            list.add(entry);
        }
        //arr = (LabelValueBean[]) keyList.toArray(new LabelValueBean[0]);
        arr = (DAOMapping[]) list.toArray(new DAOMapping[0]);
        //this.mapping = arr;
        form.setDbmappings(arr);
    }
    
    private void initializeForm (DAODefinitionForm form) {
        
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        //JtFactory factory = new JtFactory ();
        //Object obj;     
        String[] ids;
        JtIterator iterator;
        int i;
        //String st;
        //LabelValueBean lvBean;
        //LinkedList keyList = new LinkedList();

        
        if (className == null || form == null)
            return;
 
        /*
        obj = factory.createObject(className);
        
        if (obj == null) {
            if (factory.getObjException() != null)
                this.setObjException(factory.getObjException());
            return; // check
        }    
        
        msg.setMsgContent(obj);
        */
        
        //attributes = (JtHashTable) factory.processMessage(msg);
        
        //if (attributes  == null)
        //    return;
        
        //iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        iterator = ngetAttributes ();
        
        if (iterator == null) 
            return;
        
        /*
        for (;;) {
            st = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (st == null)
                break;
            lvBean = new  LabelValueBean (st, st);
            keyList.add(lvBean);
        }          
        
        form.setAttributes(keyList);
        */
        
        ids = getIDs ();
        if (ids != null) {
            form.setDbkeys(ids);
            for (i=0; i < ids.length; i++) {
                handleTrace ("InititializeForm (key[" + i + "]):" + ids[i]);
            }
        }
    }    

    private String getQualifiedClassName (String pckg, String cname) {


        if (pckg == null)
            pckg = "";
        
        if (cname == null)
            cname = "";       

        if (pckg.equals(""))
            return (cname);
        
        return (pckg + "." + cname);
            
    }
    
    private void initializeFormFromFile (DAODefinitionForm form, InputStream inputStream) {
        
        //JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        //JtFactory factory = new JtFactory ();    
        //String[] ids;
        JtIterator iterator;
        //String st;
        //LabelValueBean lvBean;
        //LinkedList keyList = new LinkedList();
        JtJavaParser parser = new JtJavaParser ();
        String qname;

        
        //if (className == null || form == null)
        if (form == null || inputStream == null)
            return;
        
                
        //parser.setPath(className);
        

        
        parser.setInputStream(inputStream);
        
        //iStream.setInputStream(inputStream);
        
        //factory.sendMessage (iStream, new JtMessage (JtInputStream.JtREAD_STREAM));
        
        
        //attributes = (JtHashTable) factory.sendMessage(parser, new JtMessage (JtJavaParser.PARSE));
        attributeList = (LinkedList) factory.sendMessage(parser, new JtMessage (JtJavaParser.PARSE1));
        

        if (parser.getObjException() != null) {
            this.setObjException(factory.getObjException());
            return; // check
        }

        qname = getQualifiedClassName (parser.getClassPackage(),
                parser.getClassName());
        
        form.setName(qname);
        
        //attributes = (JtHashTable) factory.processMessage(msg);
        /*
        if (attributes  == null)
            return;
        
        iterator = (JtIterator) attributes.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        
        if (iterator == null) 
            return;
        */    
        /*
        for (;;) {
            st = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (st == null)
                break;
            lvBean = new  LabelValueBean (st, st);
            keyList.add(lvBean);
        }          
        
        form.setAttributes(keyList);
        ids = getIDs ();
        if (ids != null)
          form.setDbkeys(ids);
        */  
    }    
    
 /*   
    String findDBKey (String name) {
        String[] dbKeys;
        int i;
        String key;
        
        if (daoForm == null || name == null)
            return null;
        
        dbKeys =  daoForm.getDbkeys();
        if (dbKeys == null)
            return null;
        
        for (i = 0; i < dbKeys.length; i++) {
            key = dbKeys[i];
            if (key == null)
                continue;
            if (key.equals(name))
                return name;
                
        }
        return null;
    }
*/
    
    // Add Column subelement
    
    private Element addColumnSubElement (DAOMapping attrMapping) {
        Element element;
        String sqlType;
        boolean bool = false;
        String columnName;
                
        if (attrMapping == null)
            return null;        
              
        element = new Element("column");
        
        sqlType = attrMapping.getSql_type();
        
        
        columnName = attrMapping.getColumn();
        
        if (columnName != null && !columnName.equals("")) {// check white spaces
            element.setAttribute("name", columnName);
        } else
            element.setAttribute("name", attrMapping.getAttribute());
                
        
        
        if (sqlType != null && !sqlType.equals("")) {
            element.setAttribute("sql-type", sqlType);
            bool = true;
        }
        
        if (attrMapping.isNotNull()) {
            element.setAttribute("not-null", "true");
            bool = true;
        }
        
        if (attrMapping.isUnique()) {
            element.setAttribute("unique", "true");
            bool = true;
        }
        
        
        if (bool)
            return (element);
        
        return null;
        
        
    }
    
    
    private boolean ngenerateProperties () {

        JtMessage msg = new JtMessage (JDOMAdapter.ADD_ELEMENT);
        String columnName;
        Element element, columnElement;
        DAOMapping attrMapping;
        DAOMapping arr[];
        int i;
        String attrName;
       
        if (daoForm == null)
            return (false);
        
        arr = (DAOMapping[]) daoForm.getDbmappings();
        
        
        if (arr != null ) {
            for (i = 0; i < arr.length; i++) {

                attrMapping = arr[i];
                if (attrMapping == null)
                    continue;
                if (!attrMapping.isEnabled())
                    continue;
                
                attrName = attrMapping.getAttribute();
                //if (findDBKey (attrName) != null) // is this a key ?
                //    continue;
                
                if (attrMapping.isKeyAttribute())
                    continue;
                       
                element = new Element ("property");
                element.setAttribute("name", attrMapping.getAttribute());                
                columnName = attrMapping.getColumn();
                
                columnElement =  addColumnSubElement (attrMapping);           
 
                if (columnElement != null)
                    element.addContent(columnElement);
                else if (columnName != null && !columnName.equals("")) // check white spaces
                    if (!columnName.equals (attrMapping.getAttribute()))
                        element.setAttribute("column", columnName);
                
                msg.setMsgContent(element);
                msg.setMsgData ("hibernate-mapping/class");
                adapter.processMessage(msg);
                
                
            }

        }
        
        return (true);
        
    }
    
    
    private Element findChild (List children, String name) {
        String tmp;
        int i;
        Element elem;
        
        if (children == null || name == null)
            return (null);
        
        
        for (i = 0; i < children.size(); i++) {
            elem = (Element) children.get(i);
            
            if (!("property".equals(elem.getName())))
                    continue;
            
            tmp = elem.getAttributeValue("name");

            if (name.equals(tmp))
                return elem;
 
        }   
        return (null);
    }
    
    private boolean isID (List list, String name) {
        Iterator iterator;
        DAOMapping attrMapping;
        
        if (list == null || name == null)
            return false;
        
        iterator = list.iterator();
        
        while (iterator.hasNext()) {
            attrMapping = (DAOMapping) iterator.next();
            if (attrMapping == null)
                continue;
            if (name.equals(attrMapping.getAttribute())) {
                return true;
            }
        }
        
        return false;
        
    }
    
    
    private JtIterator ngetAttributes () {
        JtMessage msg = new JtMessage (JDOMAdapter.GET_CHILDREN);
        Element elem;
        List children;
        Iterator iterator;
        JtHashTable table = new JtHashTable ();
        JtMessage msg1 = new JtMessage (JtHashTable.JtPUT);
        String name;
        JtIterator jiterator;
        
        if (adapter == null)
            return null;
        
        msg = new JtMessage (JDOMAdapter.GET_CHILDREN);
        msg.setMsgContent("hibernate-mapping/class/composite-id");
        children = (List) factory.sendMessage (adapter, msg);      
        
        if (children != null) {
            iterator = children.iterator();

            while (iterator.hasNext()) {
                elem = (Element) iterator.next();


                if ("key-property".equals(elem.getName())) {
                    name = elem.getAttributeValue("name");

                    if (name == null || name.equals(""))
                        continue;
                    msg1.setMsgData(name);
                    msg1.setMsgContent(name);
                    factory.sendMessage(table, msg1);
                }

            }       
        }
        
        
        msg.setMsgContent("hibernate-mapping/class");
        
        children = (List) factory.sendMessage (adapter, msg);
        
        if (children == null) {
            jiterator = (JtIterator) table.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
            return jiterator;
        }    
        
        iterator = children.iterator();
        
        while (iterator.hasNext()) {
            elem = (Element) iterator.next();
            
            
            if ("property".equals(elem.getName()) || "id".equals(elem.getName())) {
                name = elem.getAttributeValue("name");
                
                if (name == null || name.equals(""))
                    continue;
                msg1.setMsgData(name);
                msg1.setMsgContent(name);
                factory.sendMessage(table, msg1);
            }
            
        }
        jiterator = (JtIterator) table.processMessage(new JtMessage (JtHashTable.JtGET_KEYS));
        return (jiterator);
    }

    private Object readDAODefinition (FileForm dform) {

        //JtMessage msg = new JtMessage (JDOMAdapter.GET_CHILDREN);

        //JtMessage msg2 = new JtMessage (JDOMAdapter.FIND_ELEMENT);

        //Element elem, elem1;
        //DAODefinitionForm daoDefinitionForm = new DAODefinitionForm ();

        InputStream inputStream = null;
        FormFile theFile;
               

        if (dform == null)
            return null;
        
        
        //if (inputStream == null) {
        //    return (null);            
        //}
     
        theFile = dform.getTheFile();
        
        if (theFile == null || !checkXMLExtension (theFile.getFileName())) {
            handleUIError ("File must be an XML file (.xml)");
            return null;
        }
        

        
        //handleTrace ("readDAODefinition:" + theFile.getFileName());
        
        try {
            inputStream = theFile.getInputStream();
        } catch (Exception e) {
            handleException (e);
        }
        
        if (inputStream == null) {
            return null;
        }   

        return (readDAODefinitionStream (inputStream));
        
        /*
        if (form.getFileName() == null) {
            handleUIError ("Please enter a file name.");
            return null; 
        }    
        */
    }
    
    private boolean checkXMLExtension (String name) 
    {
        if (name == null)
            return false;
        
        return (name.endsWith(".xml"));
       
    }
    
    
    private void handleColumnSubElement (Element element, DAOMapping mapping) {
        List list;
        Iterator iterator;
        Element elem;
        String notNull;
        String sqlType;
        String str;
        
        if (element == null || mapping == null)
            return;
        
        list = element.getChildren();
        
        if (list == null || list.isEmpty())
            return;
        
        iterator = list.iterator();
        
        while (iterator.hasNext()) {
            elem = (Element) iterator.next();
            
            if (!"column".equals(elem.getName())) {
                continue;
            }
            
            notNull = elem.getAttributeValue("not-null");
            
            if (notNull != null && notNull.equals("true")) {
                mapping.setNotNull(true);
            }
            
            if (notNull != null && notNull.equals("false")) {
                mapping.setNotNull(false);
            }          
            
            sqlType = elem.getAttributeValue("sql-type");
            
            if (sqlType != null && !sqlType.equals("")) {
                mapping.setSql_type(sqlType);
            }
            
            str = elem.getAttributeValue("unique");
            
            if (str != null && str.equals("true")) {
                mapping.setUnique(true);
            }
            
            if (str != null && str.equals("false")) {
                mapping.setUnique(false);
            }
                    
            
        }
    }
    private Object readDAOMappingStream (InputStream inputStream) {

        JtMessage msg = new JtMessage (JDOMAdapter.GET_CHILDREN);

        JtMessage msg2 = new JtMessage (JDOMAdapter.FIND_ELEMENT);
        //JtFactory factory = new JtFactory ();
        Element elem, elem1;
        //DAODefinitionForm daoDefinitionForm = new DAODefinitionForm ();
        List children;
        String tmp, column;
        DAOMapping attrMapping;
        LinkedList list = new LinkedList ();
        JtIterator iterator;
        
        
        if (inputStream == null) {
            return (null);            
        }
        
        msg2.setMsgContent("hibernate-mapping/class");
        
        adapter.setInputStream(inputStream);        
               
        //factory.sendMessage (adapter, new JtMessage (JDOMAdapter.READ_FILE));
        factory.sendMessage (adapter, new JtMessage (JDOMAdapter.READ_STREAM));
        
        if (adapter.getObjException() != null) {
            propagateException (adapter);
            return (null);
        }    
        
        elem = (Element) factory.sendMessage (adapter, msg2);
        
        
        if (elem == null) {
            handleError ("Invalid XML format.");
            return (null);
        }    
        
        this.setClassName((elem.getAttributeValue("name")));
        this.setTable(elem.getAttributeValue("table"));
        
        
        iterator = ngetAttributes ();
        
        if (iterator == null) {
            
            return (null);// check
        }    
        
        
        msg.setMsgContent("hibernate-mapping/class");
        children = (List) factory.sendMessage (adapter, msg);

        // Add the IDs to the list
        
        addIds (list);
        keys = list;
              
        for (;;) {
            tmp = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (tmp == null) 
                break;
            
            elem1 = findChild (children, tmp);
            
            //if (isID (list, tmp)) 
            //    continue;
                            
            attrMapping = new DAOMapping ();
            attrMapping.setAttribute(tmp);
                       
            handleColumnSubElement (elem1, attrMapping);
            
            column = null;
            if (elem1 != null) {
                column = elem1.getAttributeValue("column");
                attrMapping.setEnabled(true);
            }    
            
            if (column == null || column.equals(""))
                attrMapping.setColumn(tmp); //check
            else
                attrMapping.setColumn(column);
            
            mappingTable.put(tmp, attrMapping);
            //list.add (attrMapping);
            

        }    
        /*
        while (list.size() < DAODefinition.MAX_ENTRIES) {
            attrMapping = new DAOMapping ();
            list.add(attrMapping);
        }
        */
        
        //daoDefinitionForm.setDbmappings((DAOMapping[]) list.toArray(new DAOMapping[0]));
        
        //initializeForm (daoDefinitionForm);
        return (null);
    }   
    private Object readDAODefinitionStream (InputStream inputStream) {

        JtMessage msg = new JtMessage (JDOMAdapter.GET_CHILDREN);

        JtMessage msg2 = new JtMessage (JDOMAdapter.FIND_ELEMENT);
        //JtFactory factory = new JtFactory ();
        Element elem, elem1;
        DAODefinitionForm daoDefinitionForm = new DAODefinitionForm ();
        List children;
        String tmp, column;
        DAOMapping attrMapping;
        LinkedList list = new LinkedList ();
        JtIterator iterator;
        //InputStream inputStream = null;
        //FormFile theFile;
               

        //if (form == null)
        //    return null;
        
        
        if (inputStream == null) {
            return (null);            
        }
/*     
        theFile = dform.getTheFile();
        
        handleTrace ("readDAODefinition:" + theFile.getFileName());
        
        try {
            inputStream = theFile.getInputStream();
        } catch (Exception e) {
            handleException (e);
        }
        
        if (inputStream == null) {
            return null;
        }   
*/
        
        /*
        if (form.getFileName() == null) {
            handleUIError ("Please enter a file name.");
            return null; 
        }    
        */
        
        msg2.setMsgContent("hibernate-mapping/class");
        
        //adapter.setPath(form.getFileName());
        adapter.setInputStream(inputStream);
        
        //daoDefinitionForm.setFileName(form.getFileName());
               
        //factory.sendMessage (adapter, new JtMessage (JDOMAdapter.READ_FILE));
        factory.sendMessage (adapter, new JtMessage (JDOMAdapter.READ_STREAM));
        
        if (adapter.getObjException() != null) {
            propagateException (adapter);
            return (null);
        }    
        
        elem = (Element) factory.sendMessage (adapter, msg2);
        
        
        if (elem == null) {
            handleError ("Invalid XML format.");
            return (null);
        }    
        
        daoDefinitionForm.setName(elem.getAttributeValue("name"));
        daoDefinitionForm.setTable(elem.getAttributeValue("table"));
        
        
        this.setClassName(elem.getAttributeValue("name"));
        
        iterator = ngetAttributes ();
        
        if (iterator == null) {
            
            return (daoDefinitionForm);// check
        }    
        
        
        msg.setMsgContent("hibernate-mapping/class");
        children = (List) factory.sendMessage (adapter, msg);

        // Add the IDs to the list
        
        addIds (list);
              
        for (;;) {
            tmp = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (tmp == null) 
                break;
            
            elem1 = findChild (children, tmp);
            
            if (isID (list, tmp)) 
                continue;
                            
            attrMapping = new DAOMapping ();
            attrMapping.setAttribute(tmp);
                       
            handleColumnSubElement (elem1, attrMapping);
            
            column = null;
            if (elem1 != null) {
                column = elem1.getAttributeValue("column");
                attrMapping.setEnabled(true);
            }    
            
            if (column == null || column.equals(""))
                attrMapping.setColumn(tmp); //check
            else
                attrMapping.setColumn(column);
            
            list.add (attrMapping);
            

        }    
        
        while (list.size() < DAODefinition.MAX_ENTRIES) {
            attrMapping = new DAOMapping ();
            list.add(attrMapping);
        }
        
        daoDefinitionForm.setDbmappings((DAOMapping[]) list.toArray(new DAOMapping[0]));
        
        initializeForm (daoDefinitionForm);
        return (daoDefinitionForm);
    }

    private String generateDescriptor (DAODefinitionForm form) {
 
        //List list;
        if (form == null) {
            return (null);            
        }

        className = (String) form.getName();
        table = (String) form.getTable();


        if (className == null || className.equals ("")) {
            handleUIError ("Please enter a class name.");
            //return (null);
        }    

/*
        if (table == null || table.equals("")) {
            handleUIError ("Please enter a table name");
            return (null);
        } 
*/
        
        daoForm = form;
        
        keys = retrieveKeys (form);
        
        if (keys == null || keys.isEmpty()) {
            handleUIError ("Please select the key attributes (at least one).");     
        }
        
        if (this.getObjErrors() != null)
          return (null);
        
        
        return (generateXMLDescriptor ()); 
        
    }
 
    private String generateXMLDescriptor () {
        //JtFactory factory = new JtFactory ();
        Element element;
        JtMessage msg = new JtMessage (JDOMAdapter.ADD_ELEMENT);
        DocType docType;
        
        if (className == null) {
            handleError ("The className attribute needs to be set.");
            return null;
        }

        /*
        if (table == null) {
            handleError ("The table attribute needs to be set.");
            return null;
        }
        */
        
        
        element = new Element ("hibernate-mapping");
        msg.setMsgContent (element);
        
        factory.sendMessage(adapter, msg);
        
        element = new Element ("class");
        element.setAttribute("name", className);
        
        if (table != null && !table.equals(""))
            element.setAttribute("table", table);       
        
        msg.setMsgContent (element);
        msg.setMsgData ("hibernate-mapping");
        
        factory.sendMessage(adapter, msg);  
        
       
        docType = new DocType ("hibernate-mapping", 
                "-//Hibernate/Hibernate Mapping DTD 3.0//EN",
                "http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd");
        
        adapter.setDocType(docType);
        
        if (!ngenerateIds ())
            return null;
        
        if (!ngenerateProperties ())
            return null;
        return (adapter.getContent());
        
    }
    
    
    private  void updateDAODefinition (DAODefinitionForm form) {
        String xmlString;
        JtMessage msg = new JtMessage (JtFile.JtSAVE_STRING);
        JtFile file = new JtFile ();
        
        if (form == null)
            return;
 
        daoForm = form; 
        table = form.getTable();

        
        if (table == null || table.equals ("")) {
            handleUIError ("Please enter a table name.");
        }  
        
       
        className = form.getName();
        
        if (className == null || className.equals ("")) {
            handleUIError ("Please enter a class name.");
        }  
        
        
        if (getObjErrors() != null) {
            return;
        }
       
        fileName = form.getFileName();
        
        if (fileName == null || className.equals("")) {
            handleError ("Invalid filename");
            return;
        }
        
        xmlString = generateXMLDescriptor ();
        
        if (xmlString == null)
            return;
        
        file.setName(fileName);
        msg.setMsgContent (xmlString);
        factory.sendMessage (file, msg);
        
        if (file.getObjException() != null)
            propagateException (file);
        
        
    }
    
/*    
    private DAODefinitionForm generateForm (DynaActionForm dform) {
        DAODefinitionForm form = new DAODefinitionForm ();
        
        if (dform == null) {
            return (null);            
        }
        className = (String) dform.get ("className");

        if (className == null || className.equals ("")) {
            handleUIError ("Please enter a class name");
            return (null);
        }  
    
        form.setName(className);
        initializeForm (form);
        initializeFormMapping (form);
        
        return (form);
        
    }
*/
    
    private boolean checkExtension (String name) 
    {
        if (name == null)
            return false;
        
        return (name.endsWith(".java"));
       
    }
    
    
    private DAODefinitionForm parseJavaFile (FileForm dform) {
        DAODefinitionForm form = new DAODefinitionForm ();
        FormFile theFile;
        InputStream inputStream = null;
        //JtInputStream iStream = new JtInputStream ();
        
        
        if (dform == null) {
            return (null);            
        }
     
        theFile = dform.getTheFile();
        
        handleTrace ("parseJavaFile:" + theFile.getFileName());
        
        if (theFile == null || !checkExtension (theFile.getFileName())) {
            handleUIError ("File must be a java class file (.java)");
            return null;
        }
        
        try {
            inputStream = theFile.getInputStream();
        } catch (Exception e) {
            handleException (e);
        }
        
        if (inputStream == null) {
            return null;
        }    
 
/*        
        iStream.setInputStream(inputStream);
        
        factory.sendMessage (iStream, new JtMessage (JtInputStream.JtREAD_STREAM));
        
*/        
 /*       
        className = (String) dform.get ("className");

        if (className == null || className.equals ("")) {
            handleUIError ("Please enter a class name");
            return (null);
        }  
*/    
        //form.setName(className);
        initializeFormFromFile (form, inputStream);
        initializeFormMapping (form);
        
        return (form);
        
    }
    
 /*   
    private void updateSessionForm (HttpServletRequest request, ActionForm form) {
        HttpSession session;
        
        if (request == null || form == null)
            return;
        
        session = request.getSession();
        
        if (session != null) {
            session.setAttribute ("daoForm", form);
        }
        
    }
*/
    
    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        Object data;
        HttpServletRequest request;
        String xmlString;
        JtContext context;
        ActionForm form = null;
        


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;


        factory.setStopClass(JtObject.class);
        
        context = (JtContext) msg.getMsgContext();
        if (context != null)
            form = (ActionForm) context.getActionForm();  
        
        // Generate descriptor

        if (msgid.equals(DAODefinition.GENERATE_DESCRIPTOR)) {

            // pass the form information   
            //data = msg.getMsgData ();           
                        
            xmlString = generateDescriptor ((DAODefinitionForm) form);

            return (xmlString);
        }
        

        if (msgid.equals(DAODefinition.READ)) {
            //data = msg.getMsgData ();           
            return ( readDAODefinition ((FileForm) form));
        }
        
        if (msgid.equals(DAODefinition.READ_STREAM)) {
            data = msg.getMsgData ();           
            return ( readDAODefinitionStream ((InputStream) data));
        }
        
        if (msgid.equals(DAODefinition.READ_MAPPING_STREAM)) {
            data = msg.getMsgData ();           
            return ( readDAOMappingStream ((InputStream) data));
        }
        
        if (msgid.equals(DAODefinition.UPDATE)) {
            
            //content = (String) e.getMsgContent ();
            //data = msg.getMsgData ();
            updateDAODefinition ((DAODefinitionForm) form);
            return (null);
        }
 
        /*
        if (msgid.equals (DAODefinition.GENERATE_FORM)) {
            data = msg.getMsgData ();
            return ( generateForm ((DynaActionForm) data));
        }
        */
        
        if (msgid.equals (DAODefinition.PARSE_FILE)) {
            //data = msg.getMsgData ();
            return ( parseJavaFile ((FileForm) form));
        }

        // Let the superclass handle all other messages
        return (super.processMessage (message));

        
    }


    /**
     * Demonstrates the messages processed by this class.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        String reply;
        DAODefinition daoDef;
        DAODefinitionForm daoForm = new DAODefinitionForm ();
        JtMessage msg = new JtMessage (DAODefinition.READ_STREAM);
        InputStream istream = null;
        
        
        try {
            istream = 
                new FileInputStream ("/home/projects/Jt1/src/java/Jt/examples/hibernate/History.hbm.xml");
        } catch (Exception e) {
            e.printStackTrace ();
            System.exit (1);
        }
        
        msg.setMsgData(istream);
        
        daoDef = (DAODefinition) factory.createObject (DAODefinition.JtCLASS_NAME);
        factory.sendMessage (daoDef, msg);
             
        //factory.setLogging(true);
        
        /*

        
        daoDef.processMessage(new JtMessage (DAODefinition.READ));
        
        if (args.length < 1) {
            System.err.println ("Usage: java Jt.DAO.DAODefinition classname");
            return;
        }

        daoForm.setName(args[0]);
        daoForm.setTable("TOBJECT");
        
             
        msg = new JtMessage (DAODefinition.GENERATE_DESCRIPTOR);
        msg.setMsgData(daoForm);
        

        reply = (String) factory.sendMessage (daoDef, msg);       
        
        System.out.println (reply);    
                
        factory.removeObject (daoDef);
        */
        
        
    }

}



