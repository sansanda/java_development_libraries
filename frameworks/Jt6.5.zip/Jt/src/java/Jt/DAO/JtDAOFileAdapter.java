package Jt.DAO;


//import java.io.Serializable;
import Jt.JtFactory;
import Jt.JtFile;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
//import Jt.wizard.WizardConfig;
import Jt.xml.JtXMLHelper;

/**
 * DAO adapter implementation that uses an XML file.
 */


public class JtDAOFileAdapter extends JtDAOAdapter {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtDAOFileAdapter.class.getName();
    private JtFactory factory = new JtFactory ();
    private String path;
    private JtXMLHelper helper;


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
    
    
    

    /**
     * Create DAO
     */
    
    private void create (Object obj) {
        saveObject (obj);
    }

    private void saveObject (Object obj) {

        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
        JtFile jfile = new JtFile ();
        String content;
        JtMessage msg1 = new JtMessage (JtFile.JtSAVE_STRING);
        

        if (obj == null) {
            handleError ("insert: invalid parameter obj (null)");
            return;
        }
        
        if (path == null) {
            handleError ("Attribute path needs to be set.");
            return;
        }

        msg.setMsgContent(obj);
        helper = (JtXMLHelper) factory.createObject (JtXMLHelper.JtCLASS_NAME);
        
        content = (String) factory.sendMessage(helper, msg);
        
        if (content == null)
            return;
        
        jfile.setName(path);
        msg1.setMsgContent(content);
        
        factory.sendMessage (jfile, msg1);
                        

    }

    /**
     * Update DAO
     */

    private void update (Object obj) {

       saveObject (obj);

    }  

    /**
     * Read DAO
     */

    private Object read (Object obj, Object key) {

        Object output = null;
        JtFile jfile = new JtFile ();
        String xmlContent;
        JtMessage msg = new JtMessage (JtObject.JtXML_DECODE);        
 
        /*
        if (obj == null) {
            handleError ("read: invalid parameter obj (null)");
            return (null);
        }  
        */
        
        if (path == null) {
            handleError ("Attribute path needs to be set.");
            return (null);
        }        
        
        jfile.setCreatedir(true);
        jfile.setName(path);
        
        xmlContent = (String) factory.sendMessage(jfile, 
                new JtMessage (JtFile.JtCONVERT_TO_STRING));
        
        if (xmlContent == null)
            return null;
        
        helper = (JtXMLHelper) factory.createObject (JtXMLHelper.JtCLASS_NAME);
        msg.setMsgContent(xmlContent);
        
        output = factory.sendMessage(helper, msg);
        

        return (output);
    }


    /**
     * Delete DAO
     */

    private Object delete (Object obj) {
        //Session session;


        if (obj == null) {
            handleError ("delete: invalid parameter obj (null)");
            return (null);
        }

        try {
            //session = HibernateUtil.getSessionFactory().getCurrentSession();

            //session.delete(obj);
        } catch (Exception ex) {
            handleException (ex);
        }

        return (null);
    }


    /**
     * Process object messages.
     * <ul>
     * <li> JtCREATE - Inserts an object. msgContent specifies the object
     * to be inserted.
     * <li> JtREAD - Finds an object. Returns the object or null. msgData 
     * specifies the identifier (key). msgContent specifies an instance of the 
     * persistent class. This instance is only used to determine the persistent class.
     * msgContent can be any instance of the class.
     * <li> JtUPDATE - Updates an object. msgContent specifies the object
     * to be updated.
     * <li> JtDELETE - Deletes an object. msgContent specifies the object
     * to be deleted.
     * </ul>
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object obj;
        Object key;
        String query;
        Object reply;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        obj = e.getMsgContent();


        if (msgid.equals (JtDAOAdapter.JtCREATE)) {

            create (obj);
            return (null);
        }

        if (msgid.equals (JtDAOFileAdapter.JtREAD)) {

            key = e.getMsgData ();

            reply = read (obj, key);

            return (reply);
        }

        if (msgid.equals (JtDAOAdapter.JtUPDATE)) {
            update (obj);
            return (null);
        }


        if (msgid.equals (JtDAOFileAdapter.JtDELETE)) {

            return (null);
        }



        return (super.processMessage(event));


    }
    
    public static void main(String[] args) {

        /*
        JtObject factory = new JtFactory ();
        JtDAOFileAdapter dao;
        JtMessage msg = new JtMessage (JtDAOAdapter.JtCREATE);
        WizardConfig config;
        Object obj;
        


        msg = new JtMessage (JtDAOAdapter.JtCREATE);

        
        
        dao = (JtDAOFileAdapter) factory.createObject(JtDAOFileAdapter.JtCLASS_NAME);
        
        dao.setPath("/tmp/config.xml");
        
        config = (WizardConfig) factory.createObject(WizardConfig.JtCLASS_NAME);
        
        msg.setMsgContent(config);
        factory.sendMessage(dao, msg);
        
        
        config = (WizardConfig) factory.sendMessage(dao, new JtMessage (JtDAOAdapter.JtREAD));
        
        factory.sendMessage(config, new JtMessage (JtObject.JtPRINT));
        System.out.println("AppName:" + config.getAppName());
        System.out.println("ConfigPath:" + config.getConfigPath());
        */
        
        //crud.setClassname("Jt.examples.hibernate.Member");
        //crud.setKey("email");


        //msg = new JtMessage (CRUDHelper.CREATE);

        //msg.setMsgData(form);
        //obj = (JtObject) factory.sendMessage(crud, msg);
    }

}
