package Jt.DAO;

import java.util.Iterator;
import java.util.List;

import Jt.JtContext;
import Jt.JtFactory;
//import Jt.JtHashTable;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.security.Role;
import Jt.security.RolePermissions;
import Jt.security.UserRole;

/**
 * Implements a DAO Access Manager based on roles and role permissions.
 */

public class JtDAOAccessManager extends JtObject {
    

    private static final long serialVersionUID = 1L;
    private transient JtFactory factory = new JtFactory ();
    private transient JtContext jtContext = null;
    private transient String userName = null;
    private transient List permissionList = null;
    private transient String userRole = null;
    public static final String JtCLASS_NAME = JtDAOAccessManager.class.getName(); 
    public static final String OWNER_ATTRIBUTE = "username";
    public static final String ADMIN_USER = "admin";
    public static final String SECURITY_PACKAGE = "Jt.security";
    
    
    
    // For now until security capabilities are built
    
    private boolean checkProtectedAccess (Object obj, Object key, Object msgId ) {
        //String msgId;
        String tmp;
        //String username;
        
        if (msgId == null || userName == null)
            return (false);
        
        
        //msgId = (String) msg.getMsgId ();
        
        
        if ((msgId.equals(JtObject.JtREAD))) {
            if (userName.equals(key))
                return (true);
            else
                return (false);         
        }
        
        if ((msgId.equals(JtObject.JtUPDATE))) {
            tmp = (String) factory.getValue(obj, JtDAOAccessManager.OWNER_ATTRIBUTE);
            if (userName.equals(tmp))
                return (true);
            else
                return (false);            
            
        }
        
        return (false);
        
        
    }
    /*
    private boolean checkOwnerAccess (Object obj, Object msgId ) {
        //String msgId;
        String tmp;
        RolePermissions ownerPermissions;
        
        if (obj == null || msgId == null || userName == null)
            return (false);
        
        ownerPermissions = retrieveOwnerPermissions (permissionList);        
       
        if (ownerPermissions != null) {
            handleTrace ("JtDAOAccessManager.checkOwnerAccess: owner permissions found in the  database");
            return (checkOperationPermissions (msgId, ownerPermissions));
        }
        
        if (msgId.equals(JtObject.JtREAD) || msgId.equals(JtDAOAdapter.JtEXECUTE_QUERY) ||
                msgId.equals(JtDAOAdapter.GET_DAODESCRIPTOR)) {// JtDAOAdapter.GET_DAODESCRIPTOR is not needed

            return (true);

        }
        
        if (msgId.equals(JtObject.JtUPDATE) ||
                msgId.equals(JtObject.JtCREATE) ||
                msgId.equals(JtObject.JtDELETE)) {
            tmp = (String) factory.getValue(obj, JtDAOAccessManager.OWNER_ATTRIBUTE);
            if (userName.equals(tmp))
                return (true);
            else
                return (false);            
            
        }
        
        return (false);
        
        
    }
    */
    
    /*
    private boolean ownerAttributeExists (Object obj) {
        
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtHashTable htable;
        
        msg.setMsgContent(obj);
        
        htable = (JtHashTable) factory.processMessage(msg);
        
        if (htable == null)
            return (false);
        
        msg = new JtMessage (JtHashTable.JtGET);
        msg.setMsgData(JtDAOAccessManager.OWNER_ATTRIBUTE);
        
        if (htable.processMessage(msg) == null)
            return (false);
        return (true);
        
    }
    */
    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    
    private boolean checkOperationPermissions (Object operation, RolePermissions rolePermissions) {
        if (operation == null || rolePermissions == null)
            return (false);
        
        if (operation.equals(JtObject.JtCREATE))
            return (rolePermissions.isCreatePermission());
        
        if (operation.equals(JtObject.JtREAD) || operation.equals(JtDAOAdapter.JtEXECUTE_QUERY))
            return (rolePermissions.isReadPermission());  
        
        if (operation.equals(JtObject.JtUPDATE))
            return (rolePermissions.isUpdatePermission());  
        
        if (operation.equals(JtObject.JtDELETE))
            return (rolePermissions.isDeletePermission());  
        
        return (false);
        
    }
    
    private List retrieveClassPermissions (String classname) {
        List permissionList = null;
        JtMessage msg = new JtMessage ();
        RolePermissions rolePermissions = new RolePermissions ();
        
        if (classname == null)
            return (null);
        
        msg.setMsgId (RolePermissions.RETRIEVE_CLASS_PERMISSIONS);
        msg.setMsgContent(classname);
        
        permissionList = (List) factory.sendMessage(rolePermissions, msg);
        
        if (propagateException (rolePermissions) != null)
            return (null);
        
        return (permissionList);
        
    }
    
    /*
    private RolePermissions retrieveOwnerPermissions (List permissionList) {
        Iterator iterator;
        RolePermissions rolePermissions;
        String roleId = Role.OWNER;
        
        if (permissionList == null)
            return (null);
        
        iterator = permissionList.iterator();
                
        
        while (iterator.hasNext()) {
            
            rolePermissions = (RolePermissions) iterator.next();
            
            if (roleId.equals(rolePermissions.getRoleId())) {
                return (rolePermissions);
            }
        }
               
        return (null);
        
    }
    */
    
    private String retrieveUserRole (String userId) {
        UserRole userRole = new UserRole ();
        JtMessage msg = new JtMessage ();
        String roleId;

        if (userId == null)
            return (null);
        
        if (userId.equals(JtDAOAccessManager.ADMIN_USER))
            return (Role.ADMINISTRATOR);
        
        msg.setMsgId (UserRole.RETRIEVE_USER_ROLE);
        msg.setMsgContent(userId);

        roleId = (String) factory.sendMessage(userRole, msg);

        if (roleId == null || roleId.equals(""))
            return (Role.USER);
        //if (propagateException (userRole) != null)
        //    return (null);
        
        return (roleId);
    }
    
    
    private boolean checkAccessPermissions (String userId, String classname,
            Object msgId) {

        //List permissionList = null;
        JtMessage msg = new JtMessage ();
        RolePermissions rolePermissions = new RolePermissions ();
        RolePermissions wildPermissions = null;
        //RolePermissions defaultPermissions;
        //UserRole userRole;
        //String roleId;
        Iterator iterator;
        
        
        if (userId == null ||
                classname == null || msgId == null || userRole == null)
            return (false);
        
       
        msg.setMsgId (RolePermissions.RETRIEVE_CLASS_PERMISSIONS);
        msg.setMsgContent(classname);
        
        permissionList = (List) factory.sendMessage(rolePermissions, msg);
        
        if (propagateException (rolePermissions) != null)
            return (false);

        
        if (permissionList == null || permissionList.isEmpty()) {
            // Use default permissions
            return (false);
            //defaultPermissions = (RolePermissions) factory.createObject(RolePermissions.JtCLASS_NAME);
            //return (checkOperationPermissions (msgId, defaultPermissions)); 
        }
        
        /*
        userRole = new UserRole ();
        msg.setMsgId (UserRole.RETRIEVE_USER_ROLE);
        msg.setMsgContent(userName);
        
        roleId = (String) factory.sendMessage(userRole, msg);
        
        if (propagateException (userRole) != null)
            return (false);
        
        handleTrace ("JtDAOAccessManager.checkAccessPermissions:" + roleId);
        
        if (roleId == null || roleId.equals("")) {
            roleId = Role.DEFAULT;
        }
        */
                
        iterator = permissionList.iterator();
                
        
        while (iterator.hasNext()) {
            
            rolePermissions = (RolePermissions) iterator.next();
            
            if (userRole.equals(rolePermissions.getRoleId())) {
                return (checkOperationPermissions (msgId, rolePermissions));
            }
            
            if (Role.WILDCARD.equals(rolePermissions.getRoleId())) {
                wildPermissions = rolePermissions;
            }
        }
        
        if (wildPermissions != null)
            return (checkOperationPermissions (msgId, wildPermissions));
        return (false);
        
    }

    private boolean checkAccess (Object obj, Object key, Object msgId) {
        
        //String userName;
        //JtContext jtContext;
        //String msgId;
        String classname;
        
              
 
        //jtContext = (JtContext) msg.getMsgContext();
        
        if (jtContext == null) {
            handleError ("Invalid Jt Context");
            return false;
        }
        
        userName = jtContext.getUserName();
        handleTrace ("JtDAOAccessManager:" + userName); 
        
        userRole = retrieveUserRole (userName);
        
        
        if (userName != null && userRole.equals(Role.ADMINISTRATOR))
            return (true);
            
        //if (JtDAOAccessManager.ADMIN_USER.equals(userName))
        //    return (true);

        // Classes inside the security package: Role, RolePermissions, etc
        
        if (obj.getClass().getName().startsWith(JtDAOAccessManager.SECURITY_PACKAGE)) {
            return (false);
        }
        
        // for now - fix needed
        if (userName == null && obj != null && 
                obj.getClass().getName().equals("Jt.portal.JtProfile")
                && msgId.equals(JtObject.JtCREATE)) {
            //factory.setValue(obj, "owner", userName);
            return (true);
        }    
        
        if (userName == null) {
            handleError ("Invalid Jt Context. You session may have expired. Please log in.");
            return (false);
        }        
            
        //obj = msg.getMsgContent();
        if (obj == null)
            return (false);
        
        classname = obj.getClass().getName();


        if (obj.getClass().getName().equals("Jt.portal.JtProfile") ||
                obj.getClass().getName().equals("Jt.portal.JtAccount")) {
            return (checkProtectedAccess (obj, key, msgId));           
        }
        
        /*
        permissionList = retrieveClassPermissions (obj.getClass().getName());
        
        if (this.getObjException() != null)
            return (false);
        */
        
        /*
        if (ownerAttributeExists (obj))
            return (checkOwnerAccess (obj, msgId));
        */    
        
        return (checkAccessPermissions (userName, classname,
                msgId));

    }

    
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    
    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        Object reply;
        Object operation;
        Object obj;
        Object key;
        
        

        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();
        //data = e.getMsgData ();
        jtContext = (JtContext) msg.getMsgContext();
        obj = msg.getMsgContent();
        key = msg.getMsgData();
        operation =  msg.getMsgAttachment();

        if (msgid.equals (JtDAOAdapter.JtCHECK_ACCESS)) {
            if (checkAccess (obj, key, operation))
                    return ("true");
            else
                    return ("false");
        }

        // Let the concrete strategy process the message
        
        reply = super.processMessage (message);
        

        return (reply);

    }


}
