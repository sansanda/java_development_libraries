package Jt.DAO;

import javax.servlet.http.HttpServletRequest;
//import org.apache.struts.action.*;
import org.apache.struts.upload.FormFile;
import org.apache.struts.validator.ValidatorForm;

public class FileForm extends ValidatorForm {

    private static final long serialVersionUID = 1L;
    protected FormFile theFile;
    private String formName;



    public FormFile getTheFile() {
        return theFile;
    }


    public void setTheFile(FormFile theFile) {
        this.theFile = theFile;
    }


    public String getFormName() {
        return formName;
    }


    public void setFormName(String formName) {
        this.formName = formName;
    }


}
