package Jt.DAO;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;

/**
 * This class is referenced by JtDAOAdapter. It is used to deal with queries
 * that return a large numbers of entries.
 * JtDAOAdapter implements the Data Access Object design pattern (DAO).
 */

public class JtDAOCursor extends JtObject {

    private static final long serialVersionUID = 1L;

    private JtFactory factory = new JtFactory ();
    
    private ResultSet resultSet = null;
    private DAODefinition daoDef;
    private String classname = null;
    


    public DAODefinition getDaoDef() {
        return daoDef;
    }

    public void setDaoDef(DAODefinition daoDef) {
        this.daoDef = daoDef;
    }



    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public ResultSet getResultSet() {
        return resultSet;
    }

    public void setResultSet(ResultSet resultSet) {
        this.resultSet = resultSet;
    }

    private String getMapping (DAODefinition daoDef, String at) {
        Hashtable mappingTable;
        DAOMapping daoMapping;
        
        if (at == null)
            return (null);

        
        if (daoDef == null)
            return (null);
        
        mappingTable = daoDef.getMappingTable();
        
        if (mappingTable == null)
            return null;
        
        daoMapping = (DAOMapping) mappingTable.get(at);
        
        
        return ((daoMapping==null)?null:daoMapping.getColumn());
    }
    
    private String getRSValue (ResultSet rs, String column)
    {
        String value = null;

        if (rs == null || column == null)
            return (null);

        try {
            value = rs.getString (column);
        } catch (Exception e) {
            handleException (e);
        }
        return (value);
    }  
    
    private java.util.Date getDateValue (ResultSet rs, String column) {
        if (rs == null || column == null)
            return (null);
        
        try {
            java.sql.Timestamp tstamp = rs.getTimestamp (column);
            if (tstamp == null)
                return (null); // check
            return (new java.util.Date (tstamp.getTime()));

        } catch (Exception e) {
            handleException (e);
            return null;
        }
        
    }

    private String getRSBooleanValue (ResultSet rs, String column)
    {
        String value = null;

        if (rs == null || column == null)
            return (null);

        try {
            boolean b = rs.getBoolean (column);
            //if (b == null)
            //  return (null); // check

            if (b)
                return ("true");
            else
                return ("false");

            //value = b.toString ();
        } catch (Exception e) {
            handleException (e);
        }
        return (value);
    } 
    
    private Object mapRow (Object obj, ResultSet rs, boolean checkColumn) {

        //Object args[];
        PropertyDescriptor[] prop;
        int i;
        Class p;
        BeanInfo info = null;
        String value; // check
        String column;
        java.util.Date dateValue;
        
        if (obj == null || rs == null)
            return (null);

        try {

            info = Introspector.getBeanInfo(
                    obj.getClass (), obj.getClass ().getSuperclass());
        } catch(Exception e) {
            handleException (e);
            return (null);
        }

        prop = info.getPropertyDescriptors();
        for(i = 0; i < prop.length; i++) {
            //System.out.print ("Attribute:" + 
            //prop[i].getName());
            p = prop[i].getPropertyType();

            column = getMapping (daoDef, prop[i].getName());

            if (column == null) {
                continue;
            }
            
            
            // Chech if the column exists
            if (checkColumn)
                try {
                    rs.findColumn(column);
                } catch (SQLException e) {
                    continue;
                }

            if (p.getName().equals ("java.util.Date") ){
                dateValue = getDateValue (rs, column);
                factory.setValue (obj, prop[i].getName(), dateValue); 
                continue;
                //value = getRSDateValue (rs, column);
            } else if (p.getName().equals ("boolean") ){         
                value = getRSBooleanValue (rs, column);
            } else // check
                value = getRSValue (rs, column);

            //handleTrace ("factory.setValue:" + prop[i].getName() + ":" + value, 0);
            factory.setValue (obj, prop[i].getName(), value);     

        }
        return (obj);
    }

    
    private Object next () {
        Object obj;
        JtMessage msg;
        
        if (daoDef == null) {
            handleError ("Attribute classname needs to be set.");
            return (null);           
        }
        
        /*
        if (classname == null) {
            handleError ("Attribute classname needs to be set.");
            return (null);
        }
        */

        if (resultSet == null) {
            handleError ("Attribute resultSet needs to be set.");
            return (null);
        }
        
        msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
        msg.setMsgContent(daoDef.getClassName());
        
        obj = factory.processMessage(msg);
        
        try {
            if (!resultSet.next())
                return (null);

            obj = mapRow (obj, resultSet, true);
            if (obj == null)
                return (null); 
        } catch (Exception e) {
            handleException (e);
            return (null);
        } 


        return (obj);
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;



        if (msgid.equals (JtObject.JtREMOVE)) {
            
            if (resultSet == null)
                return (null);
            
            try {
                resultSet.close ();
            }
            catch (Exception ex) {
                handleException (ex);
            }
            return (null); // check    
        }

        if (msgid.equals (JtDAOAdapter.JtNEXT)) {
    
            return (next ()); // check    
        }


        return (super.processMessage (message));

    }
    
}
