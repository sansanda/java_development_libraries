

package Jt.DAO;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtStrategy;


/**
 * DAO Strategy. This class is based on the Strategy design pattern.
 * Several DAO strategies are available: a) a native DAO implementation
 * based on the JDBC adapter. b) a Hibernate strategy.
 * Additional DAO strategies can be used in conjuntion with this class.
 *  
 */

public class JtDAOStrategy extends JtStrategy {


  public static final String JtCLASS_NAME = JtDAOStrategy.class.getName(); 
  private static final long serialVersionUID = 1L; 
  private String concreteStrategyClassName = JtDAOAdapter.JtCLASS_NAME;
  private boolean initted = false;
  private JtFactory factory = new JtFactory (); 
  private boolean checkAccess = false;

  public JtDAOStrategy () {
  }



  public String getConcreteStrategyClassName() {
      return concreteStrategyClassName;
  }



  public void setConcreteStrategyClassName(String concreteStrategyClassName) {
      this.concreteStrategyClassName = concreteStrategyClassName;
  }
  
  

  public boolean isCheckAccess() {
      return checkAccess;
  }



  public void setCheckAccess(boolean checkAccess) {
      this.checkAccess = checkAccess;
  }

  // Propagate Exceptions
  
  private Exception propagateException (Object obj)
  {
      Exception ex;

      if (obj == null)
          return null;

     
      ex = (Exception) factory.getValue(obj, "objException");

      if (ex != null)
          //setValue (this, "objException", ex);
          this.setObjException(ex);

      return (ex);
  }
  
  private void initialize () {

      JtFactory factory = new JtFactory ();

      if (concreteStrategy == null) {
          //    handleError ("processMessage: concreteStrategy attribute must be set");
          //    return (null);
          if (concreteStrategyClassName == null) {
              handleError ("processMessage: concreteStrategyClassName attribute must be set");   
              return;
          }
          concreteStrategy = factory.createObject(concreteStrategyClassName);
      }     
      
  }
  


  // For now until security capabilities are built
  
  private boolean checkProtectedAccess (String username, JtMessage msg) {
      String msgId;
      String tmp;
      
      if (username == null || msg == null)
          return (false);
      
      
      msgId = (String) msg.getMsgId ();
      
      
      if ((msgId.equals(JtObject.JtREAD))) {
          if (username.equals(msg.getMsgData ()))
              return (true);
          else
              return (false);         
      }
      
      if ((msgId.equals(JtObject.JtUPDATE))) {
          tmp = (String) factory.getValue(msg.getMsgContent(), "username");
          if (username.equals(tmp))
              return (true);
          else
              return (false);            
          
      }
      
      return (false);
      
      
  }
  
  /*
  private boolean checkAccess (JtMessage msg) {
      
      Object obj;
      String userName;
      JtContext jtContext;
      String msgId;
      String classname;
      
            
      if (msg == null)
          return (false);
      
      msgId = (String) msg.getMsgId ();
      
    
      if ((msgId.equals(JtObject.JtREAD) ||
              msgId.equals(JtObject.JtUPDATE) ||
              msgId.equals(JtObject.JtCREATE) ||
              msgId.equals(JtObject.JtDELETE)))
          obj = msg.getMsgContent();
      else
          if (msgId.equals(JtDAOAdapter.JtEXECUTE_QUERY))
              obj = msg.getMsgData();
          else
              return (true);

      
      jtContext = (JtContext) msg.getMsgContext();
      
      if (jtContext == null) {
          handleError ("Invalid Jt Context");
          return false;
      }
      
      userName = jtContext.getUserName();
      handleTrace ("JtDAOStrategy:" + userName); 
      if ("admin".equals(userName))
          return (true);

      // for now - fix needed
      if (userName == null && obj != null && 
              obj.getClass().getName().equals("Jt.portal.JtProfile")
              && msgId.equals(JtObject.JtCREATE)) {
          //factory.setValue(obj, "owner", userName);
          return (true);
      }    
      
      if (userName == null) {
          handleError ("Invalid Jt Context: username is null");
          return (false);
      }
      

          
      //obj = msg.getMsgContent();
      if (obj == null)
          return (false);
      
      classname = obj.getClass().getName();
      
      if (classname.equals("Jt.portal.Product")) {
          factory.setValue(obj, "owner", userName);         
      }
      
      
      if (obj.getClass().getName().equals("Jt.portal.JtProfile") ||
              obj.getClass().getName().equals("Jt.portal.JtAccount")) {// check
          return (checkProtectedAccess (userName, msg));           
      }

      return (true);
  }
  */
  
  private boolean checkAccess (JtMessage msg) {
      
      Object obj;
      String userName;
      JtContext jtContext;
      String msgId;
      String classname;
      JtDAOAccessManager accessManager;
      //JtMessage msg;
      String result;
      JtMessage msg1;
            
      if (msg == null)
          return (false);
      
      msgId = (String) msg.getMsgId ();
      
      if (msgId == null)
          return (false);
      
      
      accessManager = (JtDAOAccessManager) factory.createObject(JtDAOAccessManager.JtCLASS_NAME);
      msg1 = new JtMessage (JtDAOAdapter.JtCHECK_ACCESS);
    
      if (msgId.equals(JtObject.JtREAD) ||
              msgId.equals(JtObject.JtUPDATE) ||
              msgId.equals(JtObject.JtCREATE) ||
              msgId.equals(JtObject.JtDELETE))
          obj = msg.getMsgContent();
      else
          if (msgId.equals(JtDAOAdapter.JtEXECUTE_QUERY))
              obj = msg.getMsgData();
          else
              if (msgId.equals(JtDAOAdapter.JtSEARCH_BY_ATTRIBUTES) ||
                      msgId.equals(JtDAOAdapter.JtSEARCH_FOR_KEYWORDS)) {
                  obj = msg.getMsgContent();
                  msgId = JtDAOAdapter.JtEXECUTE_QUERY;
              } else
                  return (true);
      
      
      if (msgId.equals(JtObject.JtREAD))
          msg1.setMsgData(msg.getMsgData());
      msg1.setMsgContent(obj);
      msg1.setMsgAttachment(msgId);
      msg1.setMsgContext(msg.getMsgContext());
      
      result = (String) factory.sendMessage(accessManager, msg1);
      if ("true".equals(result))
          return (true);
      else
          return (false);
  }
  
  /**
   * Process object messages.
   * <ul>
   * </ul>
   */

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage e = (JtMessage) message;
      //JtFactory factory = new JtFactory ();
      Object reply;
      JtMessage msg;
      Object obj;
      //Boolean Bool;
      JtContext jtContext;
      String userName;
      

      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;

      //content = e.getMsgContent();
      //data = e.getMsgData ();
      if (!initted) {
          initialize ();     
          initted = true;
      }
      
      if (msgid.equals (JtObject.JtINITIALIZE)) {
          if (!initted) {
              initialize ();     
              initted = true;
              if (concreteStrategy != null) {
                  propagateException (concreteStrategy);  
              }
          }

          
          return null;     
      }
       
      
      if (checkAccess) {
          if (!checkAccess (e)) {
              handleError ("Access denied");
              return (null);
          }    

      }
     
      if (msgid.equals (JtDAOAdapter.JtREAD_MAPPING_STREAM)) {
          
          // Ignore JtDAOAdapter.JtREAD_MAPPING_STREAM unless the concrete
          // strategy is the default strategy (JtDAOAdapter)
          if (!JtDAOAdapter.JtCLASS_NAME.equals(concreteStrategyClassName))
              return (null);    
      }

      // Let the concrete strategy process the message
      
      reply = super.processMessage (message);
      
      if (concreteStrategy != null) {
          propagateException (concreteStrategy);  
      }
      
      return (reply);

  }



  
}


