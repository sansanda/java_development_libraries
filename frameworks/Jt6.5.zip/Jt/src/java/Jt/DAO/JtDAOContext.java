

package Jt.DAO;
import java.util.Hashtable;

import Jt.JtSingleton;

/**
 *  Jt DAO Context (singleton).
 */

public class JtDAOContext extends JtSingleton {

    public static final String JtCLASS_NAME = JtDAOContext.class.getName(); 
    private static final long serialVersionUID = 1L;
    private Hashtable configTable = new Hashtable ();
    
  
    public Hashtable getConfigTable() {
        return configTable;
    }

    public void setConfigTable(Hashtable configTable) {
        this.configTable = configTable;
    }


}
