
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;


/**
 * Jt Implementation of the Adapter pattern.
 */


abstract public class JtAdapter extends JtObject {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtAdapter.class.getName(); 
  private Object adaptee;

  public JtAdapter() {
  }

/**
  * Specifies the adaptee.
  *
  * @param adaptee adaptee
  */

  public void setAdaptee (Object adaptee) {
     this.adaptee = adaptee; 

  }

/**
  * Returns the adaptee.
  */

  public Object getAdaptee () {
     return (adaptee);
  }




  /**
    * Demonstrates the messages processed by JtAdapter.   
    */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtAdapter adapter;


    // Create an instance of JtAdapter

    adapter = (JtAdapter)
    factory.createObject (JtAdapter.JtCLASS_NAME, "adapter");   

  }

}
