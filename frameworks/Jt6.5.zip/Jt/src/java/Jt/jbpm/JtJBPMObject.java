package Jt.jbpm;


//import java.io.*;

import org.jbpm.graph.def.ActionHandler;
//import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ExecutionContext;
//import org.jbpm.graph.exe.ProcessInstance;
import Jt.*;

/**
 * JtJBPMObject top class. Subclasses of this class can be included in BPM diagrams.
 */

public class JtJBPMObject extends JtEnhancedObject implements ActionHandler {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtJBPMObject.class.getName(); 
	public static final String JtJBPM_EXECUTE = "JtJBPM_EXECUTE "; 
	public JtFactory factory = new JtFactory ();




	public JtJBPMObject() {
	      JtMessage msg = new JtMessage (JtFactory.JtLOAD_PROPERTIES);
        // Load object properties

        msg.setMsgContent(this);
        factory.processMessage (msg);

	}



    /*
     * Jt hook for the JBPM api. Defines a jBPM variable that points to the Jt object.
     * It uses the name of the action (jBPM process diagram) as the name of the variable. 
     * @see org.jbpm.graph.def.ActionHandler#execute(org.jbpm.graph.exe.ExecutionContext)
     */

    public void execute(ExecutionContext context) throws Exception {
        //String reply;
        //JtMessage msg;
        String name, nodeName;
        JtMessage msg = new JtMessage (JtFactory.JtLOAD_PROPERTIES);
        
        try {
            nodeName = context.getContextInstance().getProcessInstance().getRootToken().getNode().getName();
            handleTrace ("JtObject.execute:entering node ... " + nodeName);

            name = context.getAction().getName ();
            handleTrace ("JtObject.execute:creating a Jbpm variable " + name);
            context.getContextInstance().setVariable (name, this);	
        } catch (Exception ex) {
            handleException (ex);
            return;
        } 	
        
        // Load object properties
        //msg.setMsgContent(this);
        //factory.processMessage (msg);
        //loadObjectResources (this);
    }

    private void invokeExecute(Object obj, ExecutionContext context) throws Exception {
        //String reply;
        //JtMessage msg;
        String name, nodeName;

        try {
            nodeName = context.getContextInstance().getProcessInstance().getRootToken().getNode().getName();
            handleTrace ("JtObject.execute:entering node ... " + nodeName);

            name = context.getAction().getName ();
            handleTrace ("JtObject.execute:creating a Jbpm variable " + name);
            context.getContextInstance().setVariable (name, obj);	
        } catch (Exception ex) {
            handleException (ex);
            return;
        } 	
        //loadObjectResources (this);
    }

	/**
	 * Process object messages based on the msgID.
	 * <ul>
	 * <li>JtACTIVATE -  Executes a jBPM process according to its process definition.
	 * <li>JtPASS_VARIABLE -  Passes a variable to the child process. msgContent specifies
	 * the process variable to be passed.
	 * </ul>
	 */

	public Object processMessage (Object event) {

		String msgid = null;
		JtMessage e = (JtMessage) event;
		Object content;
		Object data;


		if (e == null)
			return null;

		msgid = (String) e.getMsgId ();

		if (msgid == null)
			return null;

		content = e.getMsgContent();
		data = e.getMsgData ();

		// Remove this object

		if (msgid.equals (JtObject.JtREMOVE)) {
			return (null);     
		}

		if (msgid.equals (JtJBPMObject.JtJBPM_EXECUTE)) {
			
			try {
				invokeExecute (content, (ExecutionContext) data);
			} catch (Exception ex) {

				handleException (ex);
			}
			return (null);     
		}

		handleError ("processMessage: invalid message id:" + msgid);
		return (null);

	}







}

