package Jt.jbpm;

import Jt.*;
import org.jbpm.graph.exe.ExecutionContext;

/**
 *  Handles error. This class can be readily included in the jBPM process definition.  
 */

public class JtErrorHandler extends JtJBPMObject {
  
  private static final long serialVersionUID = 1L;
  private ExecutionContext context = null;
  private String message;



  public JtErrorHandler() {
  }

  /**
   * Returns the message (or part of the message) to be displayed. 
   */
  
  public String getMessage() {
	return message;
  }

  /**
   * Specifies the message or part of the message to be displayed. 
   */
  
  public void setMessage(String message) {
	this.message = message;
  }
  
  //handle exceptions

  public void handleException (Throwable ex) {
      
      JtJBPMAdapter jbpmAdapter = null;
      
      try {           
        if (context != null) {
            jbpmAdapter = (JtJBPMAdapter) context.getContextInstance().getVariable ("JtJBPMAdapter");
        }
        if (jbpmAdapter != null)
            jbpmAdapter.setObjException(ex); // Propagate the exception to the JBPM adapter
            
      } catch (Exception ex1) {
          
      }
      super.handleException(ex);
  }

/*
  public void handleException (Throwable ex) {
      
      JtJBPMAdapter jbpmAdapter = null;
      
      try {           
        if (context != null) {
            jbpmAdapter = (JtJBPMAdapter) context.getContextInstance().getVariable ("JtJBPMAdapter");
        }
        if (jbpmAdapter != null)
            jbpmAdapter.setObjException(ex); // Propagate the exception to the JBPM adapter
            
      } catch (Exception ex1) {
          
      }
      super.handleException(ex);
  }
*/
  
  /**
   * Execute method (JBPM ActionHandler interface). 
   */

  public void execute(ExecutionContext context) throws Exception {
/*      
    this.context = context;
    if (message != null)
        handleError (message);
    else
        handleError ("An error has been detected");
*/
      JtJBPMAdapter jbpmAdapter = null;
      JtFactory factory = new JtFactory ();
      
      try {           
        if (context != null) {
            jbpmAdapter = (JtJBPMAdapter) context.getContextInstance().getVariable ("JtJBPMAdapter");
        }
        if (jbpmAdapter != null)
            factory.setValue(jbpmAdapter, "errorMessage", message);
            
      } catch (Exception ex) {
         handleException (ex);    
      }
  }   
}



