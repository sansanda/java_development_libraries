
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;



/**
 *  Jt Messages used for the implementation of the Jt messaging pattern.
 *  This class is used to pass information to Jt objects.
 */

public class JtMessage extends JtObject  {

   public static final String JtCLASS_NAME = JtMessage.class.getName(); 
   private static final long serialVersionUID = 1L;
   private Object msgId;
   private Object msgTo;
   private Object msgFrom;
   private Object msgSubject;
   private Object msgContent;
   private Object msgData;
   private Object msgReplyTo;
   private Object msgAttachment;
   private Object msgContext;
   private Object msgRecipientClassname;
   private boolean asynchronous = false;
   private boolean encrypt = false;



   public JtMessage () {

   }

   public JtMessage (String msgId) {
     this.msgId = msgId;
   }

   public JtMessage (int msgId) {
	   this.msgId = new Integer (msgId);
   }

/*
   public JtMessage (Object source) {

   }
*/

   /**
    * Returns the message Context. 
    */
   
   public Object getMsgContext() {
       return msgContext;
   }
   
   /**
    * Sets the message context. 
    * @param msgContext message context
    */

   public void setMsgContext(Object msgContext) {
       this.msgContext = msgContext;
   }

  /**
    * Returns the message ID. 
    */

   public Object getMsgId () {
	return msgId;
   }

   /**
    * Sets the message ID. This ID will be used by the recipient object to determine
    * how the message should be processed.
    * @param newMsgId message ID
    */

   public void setMsgId(Object newMsgId) {
    msgId = newMsgId;
   }


   /**
    * Sets the message recipient. This attribute specifies where the message is going to.
    * @param newMsgTo message recipient
    */

   public void setMsgTo (Object newMsgTo) {
    msgTo = newMsgTo;
   }


   /**
    * Returns the message recipient. 
    */

   public Object getMsgTo() {
    return msgTo;
   }

   /**
    * Sets the message sender. This attribute specifies where the message is coming from.
    * @param newMsgFrom message sender
    */

   public void setMsgFrom (Object newMsgFrom) {
    msgFrom = newMsgFrom;
   }


   /**
    * Returns the message sender. 
    */

   public Object getMsgFrom() {
    return msgFrom;
   }

   /**
    * Sets the message subject. This additional message information may be helpful
    * while processing Jt Messages.
    * @param newMsgSubject message subject 
    */

   public void setMsgSubject(Object newMsgSubject) {
    msgSubject = newMsgSubject;
   }


   /**
    * Returns the message subject. 
    */

   public Object getMsgSubject() {
    return msgSubject;
   }


   /**
    * Sets the message content. 
    * @param newMsgContent message content
    */

   public void setMsgContent(Object newMsgContent) {
    msgContent = newMsgContent;
   }

   /**
    * Returns the message content. 
    */

   public Object getMsgContent() {
    return msgContent;
   }


   /**
    * Specifies additional message data. This attribute is seldom used. 
    * @param newMsgData message data
    */

   public void setMsgData(Object newMsgData) {
    msgData = newMsgData;
   }

   /**
    * Returns additional message data. 
    */

   public Object getMsgData() {
    return msgData;
   }

    /**
    * Specifies the message attachment. This attribute is seldom used. 
    * @param newMsgAttachment message attachment
    */

   public void setMsgAttachment(Object newMsgAttachment) {
    msgAttachment = newMsgAttachment;
   }



   /**
    * Returns the message attachment. 
    */

   public Object getMsgAttachment() {
    return msgAttachment;
   }


   /**
    * Specifies the object that should receive the reply message.
    * @param newMsgReplyTo object that should receive the reply.
    */


   public void setMsgReplyTo(Object newMsgReplyTo) {
    msgReplyTo = newMsgReplyTo;
   }




   /**
    * Returns the object that should receive the reply message.
    */
 
   public Object getMsgReplyTo() {
    return msgReplyTo;
   }

   
   /**
    * Returns the recipient class name. 
    */


   public Object getMsgRecipientClassname() {
	   return msgRecipientClassname;
   }

   /**
    * Sets the recipient class name. This attribute specifies the class
    * where the message is going to. It applies to messages sent to
    * remote hosts. It is used when the message doesn't need to be processed
    * by a specific component.
    * 
    * @param msgRecipientClassname recipient class name
    */
   
   public void setMsgRecipientClassname(Object msgRecipientClassname) {
	   this.msgRecipientClassname = msgRecipientClassname;
   }

   /**
    * Returns the value of asynchronous.
    */
   
   public boolean isAsynchronous() {
	   return asynchronous;
   }


   /**
    * Specifies whether or not this message should be processed asynchronously (independent thread).
    */
   
   public void setAsynchronous(boolean asynchronous) {
	   this.asynchronous = asynchronous;
   }

   /**
    * Returns the value of encrypt.
    */
     
   public boolean isEncrypt() {
	   return encrypt;
   }


   /**
    * Specifies whether or not this message should be encrypted.
    */
   
   public void setEncrypt(boolean encrypt) {
	   this.encrypt = encrypt;
   }

}
