
/*
 *
 * Copyright 2001, Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;
import java.util.*;
import java.io.*;

/**
 * Handles files
 */

public class JtFile extends JtObject {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtFile.class.getName(); 
    public static final String JtWRITE = "JtWRITE";
    public static final String JtREAD_BUFFER = "JtREAD_BUFFER";
    public static final String JtOPEN = "JtOPEN";
    public static final String JtCLOSE = "JtCLOSE";
    public static final String JtDELETE = "JtDELETE";   
    public static final String JtSAVE_STRING = "JtSAVE";  
    public static final String JtCONVERT_TO_STRING = "JtCONVERT_TO_STRING";
    public static final String JtREAD_LINES = "JtREAD_LINES";
    public static final String JtCOPY = "JtCOPY";
    public static final String JtRENAME = "JtRENAME";

    private String name;
    protected String path;
    FileOutputStream ostream = null;
    private FileInputStream istream = null;
    boolean createdir = true;
    boolean recursive = false;
    Vector filelist = null;
    String filter = null;
    byte[] buffer = null;
    public final static int BUFFER_SIZE = 1024;      // Buffer size (read_file)
    public final static int MAX_LENGTH = 1024 * 5000;  // Max length(read_file)
    private int buffersize = BUFFER_SIZE;
    private String content;
    private boolean binary = false;
    private boolean initted = false;
    private boolean loadFileIntoMemory = false;        // Load complete file in memory
    private boolean input = false;                     // Input file
    

    public JtFile() {
    }

    /**
     * Specifies the name of the file or directory. This attribute is being deprecated. Use path instead. 
     * @param newName file name
     */

    public void setName (String newName) {
        name = newName;
        path = name;
    }

    /**
     * Returns the name of the file or directory. This attribute is being deprecated. Use path instead.
     */


    public String getName () {
        return (name);
    }


    
    /**
     * Returns the path of the file or directory.
     */
    public String getPath() {
        return path;
    }

    /**
     * Specifies the path of the file or directory
     * @param path file name
     */
    
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Returns the content of the file (Text file).
     */
    
    
    public String getContent() {
        return content;
    }
    
    

    /**
     * Specifies the content of the file (Text file)
     * @param content 
     */
    
    public void setContent(String content) {
        this.content = content; 
    }
    
    
    /**
     * Returns the binary flag (binary file).
     */
    
    public boolean isBinary() {
        return binary;
    }

    
    /**
     * Sets the binary flag (binary file).
     * @param binary flag
     */   
    
    public void setBinary(boolean binary) {
        this.binary = binary;
    }

    /**
     * Sets the createDir flag which determines if necessary but nonexisting parent directories
     * should be created.
     * @param newCreatedir create nonexisting parent directories
     */

    public void setCreatedir (boolean newCreatedir) {
        createdir = newCreatedir;
    }

    /**
     * Returns the createDir flag which determines if necessary but nonexisting parent directories
     * should be created.
     */

    public boolean getCreatedir () {
        return (createdir);
    }


    /**
     * This attribute is being deprecated.
     */

    public Vector getFilelist () {

        return (filelist);
    }


    /**
     * Sets the filter flag which determines what file extension should be considered.
     */


    public void setFilter (String filter) {
        this.filter = filter;
    }

    /**
     * Returns the filter flag which determines what file extension should be considered.
     */

    public String getFilter () {
        return (filter);
    }

    /**
     * Set the recursive flag which determines if the JtCLEANUP message should recursively
     * remove files under the subdirectories.
     * @param recursive
     *
     */

    public void setRecursive (boolean recursive) {
        this.recursive = recursive;
    }

    /**
     * Returns the recursive flag which determines if the JtCLEANUP message should recursively
     * remove files under the subdirectories.
     *
     */
    public boolean getRecursive () {
        return (recursive);
    }

    /**
     * Returns the flag loadFileInMemory. This flag is used in conjunction with
     * the JtREAD_LINES message.
     */

    public boolean isLoadFileInMemory() {
		return loadFileIntoMemory;
	}
    
    /**
     * Set the loadFileInMemory flag which determines if the whole file should be
     * loaded into memory. This is not suitable for very large file.
     * @param loadFileIntoMemory
     */

	public void setLoadFileInMemory(boolean loadFileIntoMemory) {
		this.loadFileIntoMemory = loadFileIntoMemory;
	}


	
    /**
     * Returns the input flag (input file).
     */
	
	public boolean isInput() {
		return input;
	}

    /**
     * Set the input flag (input file). The default is false.
     */
	
	public void setInput(boolean input) {
		this.input = input;
	}

    /**
     * Returns the buffer size (READ_BUFFER message).
     */
	
	public int getBuffersize() {
		return buffersize;
	}
	
    /**
     * Sets the buffer size (READ_BUFFER message).
     */
	
	public void setBuffersize(int buffersize) {
		this.buffersize = buffersize;
	}

	private boolean openInputFile () {

        if (path == null) {
            handleError ("Attribute 'path' needs to be set.");
            return false;
        }        
        
        try {
            istream = new FileInputStream (path);
        } catch (Exception e) {
            handleException (e);
            return false;
        }
        
        return true;		
		
	}
	
	
    // open file
	
	private boolean open () {
		
		
		if (input)
			return (openInputFile ());

        if (path == null) {
            handleError ("Attribute 'path' needs to be set.");
            return false;
        }        
        
        try {
            ostream = new FileOutputStream (path);
        } catch (Exception e) {
            handleException (e);
            return false;
        }
        
        return true;
    }


    // Save

    private void save (String content) {

        if (content == null)
            return;
        if (ostream == null)
            open ();

        if (ostream == null)
            return;
        try {
            ostream.write(content.getBytes());
        } catch (Exception ex) {
            handleException (ex);
        }
        close ();
    }


    private void copyFile (String targetPath) {
        FileInputStream fis  = null;
        FileOutputStream fos = null;
        File srcFile;
        File targetFile;
        String nameFile;
        
        if (path == null) {
            handleError ("Attribute path needs to be set.");            
        }
        
        srcFile = new File (path);
        
        if (srcFile.isDirectory()) {
            handleError ("Source file cannot be a directory:" + path);
            return;
        }
        
        if (targetPath == null) {
            handleError ("Invalid targetPath: null.");    
            return;            
        }
        
        targetFile = new File (targetPath);
        
        if (targetFile.isDirectory()) {
            nameFile = srcFile.getName();
            targetFile = new File (targetPath, nameFile);
        }

        try {
            byte[] buf = new byte[1024];
            fis  = new FileInputStream(path);
            fos = new FileOutputStream(targetFile);
            int i = 0;
            while ((i = fis.read(buf)) != -1) {
                fos.write(buf, 0, i);
            }
        } 
        catch (Exception e) {
            handleException (e);
        }
        finally {
            try {
            if (fis != null) fis.close();
            if (fos != null) fos.close();
            } catch (Exception ex) {
                handleException (ex);
            }
        }
    }
    
    
    // read the whole file into memory (only good for small files)

    private Object readFile ()
    {
        FileInputStream istream;
        File file;
        int len, offset = 0, i;
        long file_size;
        byte buf [] = new byte [buffersize];

        if (path == null)
            return (null);

        file = new File (path);
        if (!file.exists ())
        {
            handleError ("JtFile.readfile: file does not exist:" + path);
            buffer = null;
            return (null); // check
        }

        if (file.length () == 0L)
        {
            handleTrace ("JtFile.readfile: empty file" + path);
            buffer = null;
            return (null);
        }

        // This is to avoid memory problems while handling big files.
        // Huge files should be split.

        file_size = file.length ();

        if (file_size > MAX_LENGTH)
        {
            handleError 
            ("JtFile.readfile: file exceeded maximum length allowed:" + 
                    path + ":" + file_size);
            return (null);
        }

        buffer = new byte[(int) file_size];

        try {
            istream = new FileInputStream (path);
            offset = 0;

            while ((len = istream.read (buf, 0, buffersize)) > 0) 
            {
                for (i = 0; i < len; i++)
                {

                    if (offset + i >= file_size)
                    {
                        handleError ("JtFile.readfile: file size mismatch" + 
                                path);
                        buffer = null;
                        istream.close ();
                        return (null);

                    }
                    buffer[offset + i] = buf[i];
                }
                offset += len;
            }

            if (offset != file_size)
                handleWarning ("JtFile.readfile: file size mismatch" + 
                        path);  // check

            istream.close ();

        } catch (Exception e) {
            buffer = null;
            handleException (e);
        }

        if (buffer == null)
            return (null);


        return (this);
    }



    // write operation

    private boolean write (byte buffer[]) {

        if (ostream == null || buffer == null)
            return false;

        try {
            ostream.write (buffer, 0, buffer.length);
        } catch (Exception e) {
            handleException (e);
            return (false);
        }
        
        return (true);

    }

    // Destroy operation
/*
    private void destroy ()  {
        if (ostream != null) 
            close ();

    }
*/
    

    private boolean closeInputFile () {
    	
        if (istream == null)
            return false;

        try {
            istream.close ();
        } catch (Exception e) {
            handleException (e);
            return false;
        }
        istream = null;
        return true;
    }

    // close operation

    private boolean close () {
    	
    	if (input)
    		return (closeInputFile ());

        if (ostream == null)
            return false;

        try {
            ostream.close ();
        } catch (Exception e) {
            handleException (e);
            return false;
        }
        ostream = null; // check
        return true;
    }


    private byte[] iread (int bsize) {
    	int len;
    	byte buffer[], buf[], rbuffer[];
    	int i, offset = 0, left;
    	
    	if (bsize <= 0)
    		return (null);
    	
    	buffer =  new byte[(int) bsize];
    	buf =  new byte[(int) bsize];
    	
    	left = bsize;
    	try {
			while ((len = istream.read (buf, 0, left)) > 0) {
				
				if (len < 0)
					break;				
								
				for (i = 0; i < len; i++) 
					buffer[offset++] = buf[i];
				
				left -= len;
				
				if (left == 0)
					return buffer; 
				

			}
		} catch (IOException e) {

			handleException (e);
			return (null);
		}
		
		if (offset == 0)
			return (null);
		
    	rbuffer =  new byte[offset];
    	
		for (i = 0; i < offset; i++) 
			rbuffer[i] = buffer[i];
		
		return rbuffer;    	
    }
    
    private byte[] readBuffer () {
    	
    	if (istream == null) {
    		handleError ("Invalid input stream (null).");
    		return (null);
    	}
    	
    	if (buffersize <= 0) {
    		handleError ("Invalid buffersize attribute.");
    		return (null);
    	}	
    	
    	return (iread (buffersize));
    }


    void createParentDir (String path) {
        File file;
        String parentpath; 

        if (path == null)
            return;

        file = new File (path);
        if (file == null) {
            handleError ("JtFile: unable to create File object:" + path);
            return;
        }

        parentpath = file.getParent ();
        if (parentpath == null)
            return;

        //file = file.getParentFile ();
        file = new File (parentpath);
        if (file == null) {
            handleError ("JtFile: unable to get parent File:" + path);
            return;
        }

        handleTrace ("Parent:" + file.getAbsolutePath());
        if (!file.exists ())
            if (!file.mkdirs ())
                handleError ("JtFile: unable to create directories:" +
                        parentpath);
    }




    // read file line by line

    private List readLines (JtMessage ev) { 
        String line;
        JtMessage e;
        LinkedList list = new LinkedList ();
        JtFactory factory = new JtFactory ();

        if (path == null)
            return (null);

        
        try {
            BufferedReader d = new BufferedReader 
            (new FileReader (path));

            while ((line  = d.readLine ()) != null) {
                //System.out.println ("JtFile.read_lines:" + line);
                e = new JtMessage ();
                e.setMsgId("JtMESSAGE");
                e.setMsgSubject (ev.getMsgId ());
                e.setMsgContent (line);
                if (ev.getMsgReplyTo () != null)
                    factory.sendMessage (ev.getMsgReplyTo (), e);
                
                if (loadFileIntoMemory)
                	list.add(line);
            }
            
            d.close();

        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }
        return (list);
    }

    // rename a file
    
    private boolean renameFile (String newName) {
        File newFile;
        File file;
        
        if (path == null) {
            handleError ("Attribute path needs to be set."); 
            return false;
        }
        
        if (newName == null)
            return (false);

        newFile = new File (newName);
        file = new File (path);
        
        return (file.renameTo(newFile));              
        
    }
    
    private boolean init () {
        
        return (open ());
        
        //if (this.getObjException() != null)
        //    return (false);
        
        //return (true);
    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtOPEN - Opens a file. The attribute 'path' specifies the file path. This applies to all 
     * the operations. 
     * <li> JtCOPY - Makes a copy of the file. msgContent specifies the path of the destination file or
     * <li> directory where the file should be copied. 
     * <li> JtRENAME - Renames the file using the new name (msgContent).
     * <li> JtDELETE - Deletes the file or directory. 
     * <li> JtCLOSE - Closes the file. 
     * <li> JtWRITE - Writes a buffer of bytes (msgContent). 
     * <li> JtREAD_BUFFER - Reads a buffer of bytes and returns it. 
     * <li> JtSAVE_STRING - Writes the String specified by msgContent to the file. Opens the file if it 
     * hasn't been opened. Closes the file after saving the string. 
     * <li> JtCONVERT_TO_STRING - Converts the content of the file to String.
     * <li> JtREAD_LINES - Reads input lines from the file, one line at a time. 
     * Each line is sent to the object specified by msgReplyTo. 
     * If the flag loadFileInMemory is set, all the lines are returned (List).
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        byte buffer[];
        JtBuffer buf;
        File file;
        JtMessage e = (JtMessage) message;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;
        
		// Reset exceptions
		this.setObjException(null);

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) 
        	// Close the file
            return (new Boolean (close ()));     

        if (msgid.equals (JtFile.JtOPEN)) {

            // Create the parent directories if needed

            //if (path == null)
            //    return null;

            if (createdir && input)
                createParentDir (path);

            return  (new Boolean (open ()));
        }


        // deprecated (use JtObject.JtUPDATE)
        if (msgid.equals (JtFile.JtSAVE_STRING)) {     
            if (createdir) {
                createParentDir (path);
            }
            save ((String) e.getMsgContent ());
            return null;
        }
        
        if (msgid.equals (JtObject.JtUPDATE)) {     
            if (createdir) {
                createParentDir (path);
            }
            save (content);
            return null;
        }


        if (msgid.equals (JtFile.JtCLOSE))
            return new Boolean (close ());

        // Deprecated
        if (msgid.equals ("JtREAD_FILE")) { //check
            return (readFile ());
        }

        if (msgid.equals (JtFile.JtRENAME))
            return (new Boolean (renameFile ((String) e.getMsgContent ())));
        

        if (msgid.equals (JtFile.JtCONVERT_TO_STRING)) {
            readFile ();
            if (this.buffer == null) 
                return (null);
            return (new String (this.buffer));
        }
        
        if (msgid.equals (JtObject.JtREAD)) {
            readFile ();
            if (binary)
                return (null);
            
            if (this.buffer == null) 
                content = null;
            else            
                content = new String (this.buffer);
            return (content);
        }

        if (msgid.equals (JtFile.JtREAD_LINES)) {           
            return (readLines (e));
        }
        
        // Message being deprecated (use JtFile.JtWRITE)
        
        if (msgid.equals ("JtDATA_BUFFER")) {
            if (e.getMsgContent () == null)
                return null;

            buf = (JtBuffer) e.getMsgContent ();
            buffer = buf.getBuffer ();
            handleTrace ("JtFile: writing " + buffer.length + " bytes");
            write (buffer);
            return null;
        }

        // Message being deprecated (use JtFile.JtWRITE)
        
        if (msgid.equals ("JtWRITEBYTE")) {
            if (e.getMsgContent () == null)
                return null;

            buffer = (byte[]) e.getMsgContent ();
            // buffer = buf.getBuffer ();
            handleTrace ("JtFile: writing " + buffer.length + " bytes");
            write (buffer);
            return null;
        }
        
        // Read a buffer of data from the file
        
        if (msgid.equals (JtFile.JtREAD_BUFFER)) {
            
            if (!initted) {
            	input = true;
                initted = init ();
                if (!initted)  
                    return (null);
            }
            return (readBuffer ());
        }
        
        // Write a buffer
        
        if (msgid.equals (JtFile.JtWRITE)) {
            
            if (!initted) {
                //initted = true;
                
                if (createdir) {
                    createParentDir (path);
                }
                
                initted = init ();
                if (!initted)  // open the file
                    return (new Boolean (false));
            }    
            
            if (e.getMsgContent () == null) {
            	handleError ("Invalid buffer (null).");
                return (new Boolean (false));
            }
            
            buffer = (byte[]) e.getMsgContent ();

            handleTrace ("JtFile: writing " + buffer.length + " bytes");
            return (new Boolean (write (buffer)));

        }

        if (msgid.equals (JtFile.JtDELETE)) {
            if (path == null) {
                handleError ("JtFile: Invalid attribute (path):"
                        + path);
                return null;
            }
            file = new File (path);
            return (new Boolean (file.delete ()));
        }

        
        if (msgid.equals (JtFile.JtCOPY)) {
            copyFile ((String) e.getMsgContent());
            return (null);
        }

        return (super.processMessage (message));
        //handleError ("JtFile.processMessage: invalid message id:" + msgid);
        //return (null);

    }





    /**
     * Demonstrates the messages processed by JtFile.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        //JtMessage msg;
        File tmp;
        JtFile file;
        JtMessage msg = new JtMessage (JtFile.JtSAVE_STRING);


        // Create a JtFile object       
        file = (JtFile) main.createObject (JtFile.JtCLASS_NAME);
        file.setName("test.txt");
        file.setCreatedir(true);
        msg.setMsgContent ("Test");
        
        // JtSAVE
        main.sendMessage(file, msg);    
        
        msg.setMsgId(JtFile.JtCOPY);
        msg.setMsgContent("/tmp/kk.txt");
        
        main.sendMessage(file, msg); 

        // Create a JtFile object

        file = (JtFile) main.createObject (JtFile.JtCLASS_NAME);
        file.setName("JtFile");
        file.setCreatedir(true);
      

        // JtOPEN

        msg = new JtMessage (JtFile.JtOPEN);
        tmp = new File ("JtFile");

        main.sendMessage (file, msg);
        msg = new JtMessage (JtFile.JtCLOSE);
        main.sendMessage (file, msg);        

        if (!tmp.exists ()) 
            System.err.println ("JtFile(JtOPEN): FAILED");
        else
            System.err.println ("JtFile(JtOPEN): GO");

        // JtDELETE

        msg = new JtMessage (JtFile.JtDELETE);
        main.sendMessage (file, msg);

        tmp = new File ("JtFile");
        if (!tmp.exists ())
            System.err.println ("JtFile(JtDELETE): GO");       
        else {
            System.err.println ("JtFile(JtDELETE): FAILED");
        }

        // createdir attribute
        
        file.setName("/tmp/JtFile/JtFile");
        file.setCreatedir(true);
        main.sendMessage (file, new JtMessage (JtFile.JtOPEN));
        main.sendMessage (file, new JtMessage (JtFile.JtCLOSE));
        

        tmp = new File ("/tmp/JtFile/JtFile");
        if (!tmp.exists ()) 
            main.handleError ("JtFile(JtOPEN/createdir=true): FAILED");
        else
            System.err.println ("JtFile(JtOPEN/createdir=true): GO");


        main.sendMessage (file, new JtMessage (JtFile.JtDELETE));        
        if (!tmp.exists ()) 
            System.err.println ("JtFile(JtDELETE): GO");
        else
            main.handleError ("JtFile(JtDELETE): FAILED");


    }

}


