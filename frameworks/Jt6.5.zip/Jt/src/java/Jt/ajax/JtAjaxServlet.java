package Jt.ajax;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Jt.JtContext;
import Jt.JtDirectory;
import Jt.JtFactory;
import Jt.JtFile;
import Jt.JtMessage;
import Jt.JtInterface;
import Jt.JtOSCommand;
import Jt.JtObject;
import Jt.xml.JtXMLHelper;


/**
 * Jt Servlet used for processing Ajax requests.
 * This class is being deprecated. Use JtServlet instead.
 */

public class JtAjaxServlet extends HttpServlet {


    private static final long serialVersionUID = 1L;
    //JtFactory main = new JtFactory ();
    //private boolean convertToXML = true;   // Convert output to the XML format

      

    public JtAjaxServlet() {
     }

    /**
     * Returns boolean attribute convertToXML
     */

    
    //public boolean getConvertToXML() {
    //    return convertToXML;
    //}

    
    /**
     * Specifies if the output should be converted 
     * to the XML format. The default is true. 
     * @param convertToXML boolean attribute
     */
    //public void setConvertToXML(boolean convertToXML) {
    //    this.convertToXML = convertToXML;
    //}

    
    // Create the delegate class using the class name
    
    private Object createDelegate (JtFactory main, String className) {
        JtMessage msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
        
        if (className == null)
            return (null);
  
        if (JtOSCommand.JtCLASS_NAME.equals (className) || JtFile.JtCLASS_NAME.equals (className) ||
                JtDirectory.JtCLASS_NAME.equals (className)) {
            main.handleError ("Security violation: unable to create a remote instance of " +
                    className);
            return (null);
        }

        
        // Attemp to create an instance of the delegate
    
        msg.setMsgContent(className);
        
        return (main.processMessage(msg));
        
    }
    
    
    // Convert object to XML format (use JtXMLHelper to do the conversion)
    
    private String convertToXML (JtFactory main, Object obj) {
        JtMessage msg = new JtMessage (JtXMLHelper.JtXML_ENCODE);
        JtXMLHelper xmlHelper = new JtXMLHelper ();
        
        //if (obj == null)
        //    return (null);
        
        msg.setMsgContent(obj);
        return ((String) main.sendMessage(xmlHelper, msg));
    }
    
    
    // Process the HTTP Get Request
    
    public void doGet (HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {
        doPost (req, res);
        
    }
    
    
    
    // Process the HTTP Get Request
    
    public void doPost (HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {
       String jtMsgContent = req.getParameter("jtMsgContent");
       String jtClassName = req.getParameter("jtClassname");
       String jtMsgId = req.getParameter("jtMsgId");
       JtMessage msg = new JtMessage ();
       Object jtReply;
       Exception ex;
       JtContext context;

       JtFactory main = new JtFactory ();     
       res.setContentType("text/html");
       res.setHeader("Cache-Control", "no-cache");
       
       if (jtMsgContent == null)
           jtMsgContent = req.getParameter("msgContent"); 

       if (jtClassName == null)
           jtClassName = req.getParameter("classname"); 

       if (jtMsgId == null)
           jtMsgId = req.getParameter("msgId");
       
       msg.setMsgData(req.getParameter("msgData"));
       msg.setMsgAttachment(req.getParameter("msgAttachment"));
       
       
       if (jtClassName == null) {
           ex = errorDetected (main, "JtAjaxServlet: request parameter className needs to be set.");

           //if (convertToXML) {
             res.getWriter().write (convertToXML (main, null));
             return;
           //}  
           //res.getWriter().write ((ex != null)? ex.getMessage():"");            
           //return;
       }    
 
       if (jtMsgId == null) {
           ex = errorDetected (main, "JtAjaxServlet: request parameter msgId needs to be set.");

           //if (convertToXML) {
              res.getWriter().write (convertToXML (main, null));
              return;
           //}   
           //res.getWriter().write ((ex != null)? ex.getMessage():"");             
           //return;
       }    
       
    
       JtInterface delegate = (JtInterface) createDelegate (main, jtClassName);
       
       
       // Check for exceptions during creation of the delegate class
       
       ex = (Exception) main.getObjException();
       if (ex != null) {
           //if (convertToXML) {
           res.getWriter().write (convertToXML (main, null));
            //} else    
            //    res.getWriter().write (ex.getMessage());  
           return;
       }
       
       // Pass context information. This includes the action form
       context = new JtContext ();
       
       context.setServletContext(this.getServletContext());
       //context.setActionForm(form);      
       context.setRequest(req);
       context.setResponse(res);   
       context.setUserName(retrieveUserName (req));
       msg.setMsgContext(context);
       
       
       msg.setMsgId(jtMsgId);
       msg.setMsgContent(jtMsgContent);       
       jtReply = main.sendMessage(delegate, msg);      
 


       // Check for exceptions
       
       //ex = (Exception) main.getValue(delegate, "objException"); // check 
       
       /*
       if (ex != null) {
           if (convertToXML) {
             res.getWriter().write (convertToXML (main, ex));
           } else
             res.getWriter().write (ex.getMessage());          
           return;
       }    
       */
       
       if (jtReply instanceof String) {
           res.getWriter().write ((String) jtReply);
           return;
       }
       
       //if (jtReply == null && !convertToXML) {
       //    res.getWriter().write ("");  //check
       //    return;
       //}    
       
       //if (!convertToXML) {          
       //    res.getWriter().write (jtReply.toString());
       //    return;
       //}    
       // Convert reply to XML format
       
       res.getWriter().write (convertToXML (main, jtReply));
           
    }

   // error detected
    
    private Exception errorDetected (JtObject main, String error) {        
              
        main.handleError(error); // forces an exception to be generated
        return ((Exception) main.getObjException());          
        
    }
    

    private String retrieveUserName (HttpServletRequest request) {
        HttpSession session;
        JtContext ctx;
        JtFactory factory = new JtFactory ();
        
        
        if (request == null)
            return null;
        
        session = request.getSession();
        
        factory.handleTrace ("retrieveUserName(session):" + session);
        if (session == null)
            return null;
        
        ctx = (JtContext) session.getAttribute("jtContext");
        
        factory.handleTrace ("retrieveUserName(ctx):" + ctx);
        if (ctx == null)
            return null;
        
        factory.handleTrace ("retrieveUserName:" + ctx.getUserName());
        return (ctx.getUserName());
    }
    

}
