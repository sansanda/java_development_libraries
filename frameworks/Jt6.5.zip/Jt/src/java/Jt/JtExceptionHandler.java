
package Jt;

import java.io.*;



/**
 * Exception handler. A custom exception handler can be provided. 
 */


public class JtExceptionHandler extends JtObject {



	private static final long serialVersionUID = 1L;


	public JtExceptionHandler () {


	} 
	
    private String stackTrace (Exception ex ) {
        ByteArrayOutputStream bstream;

        if (ex == null)
            return (null);

        bstream = new ByteArrayOutputStream ();       

        ex.printStackTrace (new PrintWriter (bstream, true));

        return (bstream.toString ());

    }

    private void logException (JtInterface logger, Throwable e) {

        String trace;
        
        if (logger == null || e == null)
        	return;

        // An exception has occurred. Update the objException attribute

        trace = stackTrace ((Exception) e);
        

        logger.processMessage(new JtLogEntry (trace, JtLogger.JtMAX_LOG_LEVEL));
        

    }

	/**
	 * Process an exception. 
	 * @param message  exception
	 */


	public Object processMessage (Object message) {


		JtLogger logger;
		JtFactory factory = new JtFactory ();
		
		logger = factory.getLogger();


		if (message == null)
			return (null);
		
		if (message instanceof Throwable) {
            logException (logger, (Throwable) message);
			return (null);
		}

		handleError ("processMessage: invalid message format (Throwable expected).");
		return (null);
	}
	
	/**
	 * Demonstrates the messages processed by this component.
	 */

	public static void main(String[] args) {

		JtExceptionHandler exceptionHandler = new JtExceptionHandler (); 


		// Send a message to the chain

		exceptionHandler.processMessage (new Exception ("my exception"));


	}

}
