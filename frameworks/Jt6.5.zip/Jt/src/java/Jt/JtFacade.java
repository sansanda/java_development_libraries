package Jt;



/**
 * Jt Implementation of the Facade design pattern.
 */

public class JtFacade extends JtComponent {


  public static final String JtCLASS_NAME = JtFacade.class.getName(); 
  private static final long serialVersionUID = 1L;


  public JtFacade () {
  }



  /**
    * Process object messages. Subclasses should override this method.
    * <ul>
    * </ul>
    */

  public Object processMessage (Object message) {



	  return (super.processMessage (message));


  }

 
  /**
   * Demonstrates the messages processed by JtFacade.
   */


  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtFacade facade;
    JtEcho echo1;
    JtEcho echo2; 
    JtMessage msg;

    // Create an instance of JtFacade

    facade = (JtFacade) factory.createObject (JtFacade.JtCLASS_NAME);


    echo1 = (JtEcho) factory.createObject (JtEcho.JtCLASS_NAME);
    echo2 = (JtEcho) factory.createObject (JtEcho.JtCLASS_NAME);


    System.out.println ("JtFacade(JtADD_CHILD): adding a subsystem ...");

    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(echo1);


    factory.sendMessage (facade, msg);


    System.out.println ("JtFacade(JtADD_CHILD): adding a subsystem ...");

    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(echo2);



  }


}


