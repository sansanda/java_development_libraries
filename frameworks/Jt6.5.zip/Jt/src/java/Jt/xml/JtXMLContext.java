package Jt.xml;

/**
 * Internal class used by JtXMLHelper.
 */

class JtXMLContext {
    
	String classname;
    Object properties;
    Object child;
    String element;
    Object children;
    Object object;
    StringBuffer buffer;
    
    
    public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public StringBuffer getBuffer() {
        return buffer;
    }
    public void setBuffer(StringBuffer buffer) {
        this.buffer = buffer;
    }
    public Object getObject() {
        return object;
    }
    public void setObject(Object object) {
        this.object = object;
    }
    public Object getChildren() {
        return children;
    }
    public void setChildren(Object children) {
        this.children = children;
    }
    public Object getChild() {
        return child;
    }
    public void setChild(Object child) {
        this.child = child;
    }
    public String getElement() {
        return element;
    }
    public void setElement(String element) {
        this.element = element;
    }
    public Object getProperties() {
        return properties;
    }
    public void setProperties(Object properties) {
        this.properties = properties;
    }

}
