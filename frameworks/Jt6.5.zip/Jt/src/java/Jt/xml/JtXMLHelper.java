

package Jt.xml;

import Jt.*;
import Jt.examples.Test;
import Jt.security.JtEncryptedMessage;
import Jt.util.Base64Helper;

import java.util.*;
import java.lang.reflect.*;
import java.beans.*;
import java.io.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Convert components from/to the XML format.
 */

public class JtXMLHelper extends JtObject implements ContentHandler {


    private static final long serialVersionUID = 1L;
    private transient XMLReader reader = null;
    protected static final String DEFAULT_PARSER_NAME = "org.apache.xerces.parsers.SAXParser";
    protected static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    private transient Object currentObject = null;         // current object
    private String parserName = DEFAULT_PARSER_NAME;
    private transient Stack contextStack = new Stack ();
    private boolean excludeXMLHeader;
    public static final String JtCLASS_NAME = JtXMLHelper.class.getName(); 
    private static final int LINE_LENGTH = 72; 
    private transient JtFactory factory = new JtFactory ();
	private InputStream inputStream = null;
    public final static String JtREAD_STREAM = "JtREAD_STREAM";
    private boolean forceJtEncoding = false;
    private boolean nullObject = true;

    public JtXMLHelper() {
    }

    /**
     * Specifies the parser.
     * @param parserName parse
     */


    void setParserName (String parserName) {
        this.parserName = parserName;

    }


    /**
     * Returns the parser. 
     */

    String getParserName () {
        return (parserName);  
    }

    /**
     * Returns the excludeXMLHeader attribute 
     */

    public boolean getExcludeXMLHeader() {
        return excludeXMLHeader;
    }


    /**
     * Specifies if the XML header should be excluded from the output
     */

    public void setExcludeXMLHeader(boolean excludeXMLHeader) {
        this.excludeXMLHeader = excludeXMLHeader;
    }

    
    /**
     * Specifies the input stream (refer to READ_STREAM).
     * @param inputStream input stream
     */

    public void setInputStream(Object inputStream) {
        this.inputStream  = (InputStream) inputStream;
    }

    /**
     * Returns the input stream.
     */

    public Object getInputStream() {
        return inputStream;
    }
    
    /**
     * Returns the flag forceJtEncoding.
     */

    public boolean isForceJtEncoding() {
		return forceJtEncoding;
	}

    /**
     * Sets forceJtEncoding (force Jt encoding). 
     */
       
	public void setForceJtEncoding(boolean forceJtEncoding) {
		this.forceJtEncoding = forceJtEncoding;
	}

	/** 
     * Start element (SAX API). 
     */
    public void startElement(String uri, String local, String raw,
            Attributes attrs) throws SAXException {

        JtXMLContext ctx;
        HashMap map;

        handleTrace ("Start element: " + raw, JtLogger.JtMIN_LOG_LEVEL);

        if ("java".equals (raw))     
            throw (new SAXException ("XMLEncoded"));


        ctx = new JtXMLContext ();
        ctx.setElement(raw);
        contextStack.push(ctx);

        if ("Object".equals (raw)) { 
            map = new HashMap ();
            ctx.setProperties(map);
            
            ctx.setClassname(attrs.getValue("", "classname"));
            handleTrace ("classname:" + attrs.getValue("", "classname"));
            return;    
        }

    } 

    
    private boolean verifyAttributeList (Object obj, HashMap map) throws SAXException {
    	JtFactory factory = new JtFactory ();
    	Hashtable table;
    	JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTE_TABLE);
    	Set set;
    	Iterator iterator;
    	String attrName;
    	
    	if (obj == null)
    		return (false);
    	
    	if (map == null)
    		return (false);
    	
    	msg.setMsgContent(obj);
    	table = (Hashtable) factory.processMessage(msg);
    	
    	if (table == null)
    		return (true);
    	
    	set = map.keySet();
    	
    	iterator = set.iterator();
    	
    	while (iterator.hasNext()) {
    		attrName = (String) iterator.next();
    		
    		if (table.get(attrName) == null)
    			throw (new SAXException ("Unable to read XML file (invalid class attribute):" + attrName));

    	}

    	
    	return (true);
    }

    Object setResources (Object obj) throws SAXException {
        PropertyDescriptor[] prop;
        int i;
        BeanInfo info = null;
        Object tval; 
        JtXMLContext ctx;
        HashMap map;
        JtFactory factory = new JtFactory ();

        //handleTrace ("setResources:" + obj, JtLogger.JtMIN_LOG_LEVEL);
        ctx = (JtXMLContext) contextStack.peek ();

        if (ctx == null)
            return (null);

        map = (HashMap) ctx.getProperties();

        if (obj == null || map == null)
            return (null);

        
    	if (!verifyAttributeList (obj, map))
            throw (new SAXException ("Invalid attribute"));
    		
        // refactor this piece

        try {
            info = Introspector.getBeanInfo(
            		obj.getClass (), java.lang.Object.class);
        } catch(Exception e) {
            handleException (e);
            return (null); //check
        }

        
        
        prop = info.getPropertyDescriptors();


        for(i = 0; i < prop.length; i++) {

            tval = (Object) map.get (prop[i].getName());


            if (tval != null)
                if (!factory.setValue (obj, prop[i].getName(), tval))  
                    throw (new SAXException ("setValue failed:" + prop[i].getName()));
        
        }

        return (obj); // check
    } 

    private boolean checkModifiers (Class cl, String prop) {

        //Class cl;
        Field field;
        int mod;


        if (cl == null || prop == null)
            return (false);


        field = null;
        try {
            field = cl.getDeclaredField (prop); // property dup property names
            //System.out.println ("class:" + cl.getName ());

        } catch (Exception e) {

            //handleException (e);

            if (cl.getSuperclass () == null) {
                //handleException (e); check
                return (false);
            }
        }

        if (field == null) {
            cl = cl.getSuperclass ();
            return (checkModifiers (cl, prop));
        }

        mod = field.getModifiers ();

        if (Modifier.isTransient (mod)) {
            return (false);
        }
        if (Modifier.isStatic (mod)) {
            return (false);
        } 
        return (true);       
    }

    private boolean isDefaultValue (Object value) {
        if (value instanceof Integer)
        	return (((Integer) value).intValue() == 0);
        
        if (value instanceof Long)
        	return (((Long) value).longValue() == 0); 
        
        if (value instanceof Float)
        	return (((Float) value).floatValue() == 0.0);   
        
        if (value instanceof Byte)
        	return (((Byte) value).byteValue() == 0); 
        
        if (value instanceof Double)
        	return (((Double) value).doubleValue() == 0.0);  
        
        if (value instanceof Short)
        	return (((Short) value).shortValue() == 0);
        
        if (value instanceof Boolean)
        	return (((Boolean) value).booleanValue () == false);
        
        return false;
    }
    
    private Hashtable getAttributes (Object obj) {

        PropertyDescriptor[] prop;
        int i;
        Class cl;
        Method m;
        BeanInfo info = null;
        Object value;
        Hashtable attr;
        String xmlFormat;
        char ch;


        if (obj == null)
            return (null);

        attr = new Hashtable ();


        try {
            info = Introspector.getBeanInfo(
                    obj.getClass (), java.lang.Object.class);
        } catch(Exception e) {
            handleException (e);
            return (null);
        }

        prop = info.getPropertyDescriptors();
        for(i = 0; i < prop.length; i++) {

            try {

                cl = prop[i].getPropertyType();

                if (!checkModifiers (obj.getClass (),prop[i].getName())) {
                    continue;
                }



                m = prop[i].getReadMethod ();
                if (m == null) {
                    handleError 
                    ("getAttributes: getReadMethod returned null");
                    return (null);
                }

                value = m.invoke (obj, null);
                if (value == null) {
                    continue; // check
                }
                
                if (cl.isArray() && !(value instanceof byte[])) {
                    handleWarning ("JtXMLHelper.getAttributes: unable to convert arrays:" + prop[i].getName());

                    return (null);
                }

                if (!(cl.isPrimitive() || value instanceof String)) {
                    //handleWarning ("JtXMLHelper.getAttributes: unable to convert non primitive type:" + 
                    //        prop[i].getName() + " " + cl.getName());

                    xmlFormat = convertToXML (value);
                    if (xmlFormat == null)
                        return (null);

                    attr.put (prop[i].getName(), xmlFormat);
                    continue;

                }

                if (value instanceof String) {
                    attr.put (prop[i].getName(), "<![CDATA[" + value + "]]>"); 

                    continue;
                }

                if (value instanceof Character) {
                    ch = ((Character) value).charValue();
                    int i1 = (int) ch;
                	if (i1 <= 0)
                		continue;   
                    attr.put (prop[i].getName(), "<![CDATA[" + value.toString () + "]]>" ); 

                    continue;
                		
                }
                
                
                
                if (value instanceof Integer ||
                        value instanceof Long || 
                        value instanceof Float ||
                        value instanceof Byte ||
                        value instanceof Boolean ||
                        value instanceof Short ||
                        value instanceof Double) {
                	
                	if (isDefaultValue (value))
                		continue;
                	
                    attr.put (prop[i].getName(), value.toString ()); 

                    continue;
                } else {
                    handleWarning 
                    ("JtXMLHelper.getAttributes: unable to convert attribute type to String:" + prop[i].getName());
                    return (null);

                }

            } catch (Exception e) {
                handleException(e);
                return (null);
            }
        }

        return (attr);
    }

    private long StringToLong (String str) {
        long lpostingId;
        
        if (str == null)
        	return (1);
        try {
            lpostingId = Long.parseLong(str);
        } catch (Exception e) {
            handleException (e);
            return (-1L);
        }
        return (lpostingId);
    }

    private Object createInstance () {
        String classname;
        Class jtclass = null;
        Object obj;
        String value;
        String stmp;
        JtRemoteException jex;
        JtXMLContext ctx;
        HashMap map;
        Exception ex;
        long l;
        Base64Helper helper;
        JtMessage msg;

        ctx = (JtXMLContext) contextStack.peek();    

        map = (HashMap) ctx.getProperties();
        if (map == null)
            return (null); // check
        

        classname = ctx.getClassname();
        handleTrace ("Creating instance:" + classname, JtLogger.JtMIN_LOG_LEVEL);       	

        if (classname == null)
            return (null); // check

        if (!classname.equals ("byte[]")) {
        	try {
        		jtclass = Class.forName ((String) classname);
        	} catch (Exception e) {
        		handleException (e);
        		return (null);
        	}
        }


        if (classname.equals ("Jt.JtRemoteException")) {
            value = (String) map.get ("value");
            stmp = (String) map.get ("trace");


            if (value == null) {
                handleError ("createInstance: invalid value:" +
                        value);

                return (null);   
            }
            jex = new JtRemoteException (value);
            jex.setTrace (stmp);
            return (jex);
        }


        if (classname.equals ("Jt.JtException")) {
            value = (String) map.get ("value");


            if (value == null) {
                handleError ("createInstance: invalid value:" +
                        value);

                return (null);   
            }
            try {
                obj = jtclass.newInstance ();      
            } catch (Exception e) {
                handleException (e);
                return (null);
            }
            ex = new JtException (value);
            return (ex);
        }

        if (classname.equals (Date.class.getName())) {
            value = (String) map.get ("value");
            l = StringToLong (value);
            
            if (l < 0)
            	return (null);
            	          
            try {
                obj = jtclass.newInstance ();
                ((Date) obj).setTime(l);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }
        
        if (classname.equals ("byte[]") ){
            value = (String) map.get ("value");
            helper = new Base64Helper ();

            msg = new JtMessage (Base64Helper.JtBASE64_DECODE);
            msg.setMsgContent(value);
            
            
            try {
                obj = factory.sendMessage(helper, msg);

                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.startsWith ("java.lang")) {

            value = (String) map.get ("value");
        } else {
            try {
                obj = jtclass.newInstance ();
                handleTrace ("newInstance:" +  obj, JtLogger.JtMIN_LOG_LEVEL);
                if (setResources (obj) == null)
                    return null;
                return (obj); // check     
            } catch (Exception e) {
                handleException (e);
                return (null);
            }

        }

        if (value == null) {
            handleError ("createInstance: invalid value:" +
                    value);

            return (null);   
        }

        if (classname.equals ("java.lang.Byte")) {

            try {
                obj = new Byte (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }


        if (classname.equals ("java.lang.Short")) {

            try {
                obj = new Short (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }


        if (classname.equals ("java.lang.Float")) {

            try {
                obj = new Float (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.Double")) {

            try {
                obj = new Double (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.Character")) {

            try {
                obj = new Character (value.charAt(0));
                return (obj);    
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.String")) {

            try {
                obj = new String (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.Integer")) {

            try {
                obj = new Integer (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.Long")) {

            try {
                obj = new Long (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        if (classname.equals ("java.lang.Boolean")) {

            try {
                obj = new Boolean (value);
                return (obj);	   
            } catch (Exception e) {
                handleException (e);
                return (null);
            }             

        }

        handleError ("createInstance: unable to handle class type:" +
                classname);
        return (null); // check
    }


    /** 
     * End element (SAX API). 
     */

    public void endElement(String uri,
            String name,
            String qName)
    throws SAXException {
        JtMessage msg;
        int i;
        JtXMLContext parentCtx = null, currentCtx;
        Vector children;
        HashMap map;
        StringBuffer buffer;
        Object newObject;


        if (qName == null)
            return;  //check


        handleTrace ("End element: " + qName, JtLogger.JtMIN_LOG_LEVEL);

        if ("Object".equals (qName)) { //check



            newObject = createInstance ();
            currentObject = newObject;


            //handleTrace ("End element: "  + newObject.getClass().getName());

            currentCtx = (JtXMLContext) contextStack.pop ();
            currentCtx.setObject(newObject);
            
            if (newObject == null && currentCtx.getClassname() == null) { // Null object
            	nullObject =  true;
            	return;
            }
            
            if (newObject == null) // Invalid class
            	throw (new SAXException ("Unable to create class instance"));

            if (newObject instanceof JtCollection || newObject instanceof JtList) {
                children = (Vector) currentCtx.getChildren();
                //if (children == null)
                //    return;

                if (children != null)
                	for (i = 0; i < children.size (); i++) {
                		msg = new JtMessage (JtCollection.JtADD); // chech message ID
                		msg.setMsgContent (children.elementAt (i));
                		((JtObject) newObject).processMessage (msg);
                		//sendMessage (object, msg);
                	}
                //return;
            }
            
            if (newObject instanceof List) {

                children = (Vector) currentCtx.getChildren();
                //if (children == null)
                //    return;
                if (children != null)
                	for (i = 0; i < children.size (); i++)
                		((List) newObject).add(children.elementAt (i));


            }

            if (contextStack.isEmpty()) {
                return; // check
            }


            parentCtx = (JtXMLContext) contextStack.peek();

            if (!("Object".equals(parentCtx.getElement()))) {
                handleTrace ("End Element: this attribute references an object " +  
                        newObject.getClass().getName(), JtLogger.JtMIN_LOG_LEVEL);
                parentCtx.setChild(newObject);
                return;
            }   

            //handleTrace ("End Element: adding child to parent " +  
            //        newObject.getClass().getName());

            children = (Vector) parentCtx.getChildren ();             
            if (children == null) {
                children = new Vector ();
                parentCtx.setChildren(children);
                children.addElement (newObject);
            } else {
                children.addElement (newObject);                 
            }

            //return;
        } else { 


            currentCtx = (JtXMLContext) contextStack.pop();

            parentCtx = (JtXMLContext) contextStack.peek();
            map = (HashMap) parentCtx.getProperties();


            if (currentCtx.getChild() != null) {
                map.put (qName, currentCtx.getChild());
                handleTrace ("map.put(" + qName + "):" + currentCtx.getChild(),
                		JtLogger.JtMIN_LOG_LEVEL);
                return;
            }    

            buffer = currentCtx.getBuffer();

            handleTrace (qName + ":" + buffer, JtLogger.JtMIN_LOG_LEVEL);

            if (buffer != null)
                map.put (qName, buffer.toString ());

        } 


    }


    /** 
     * Start document (SAX API). 
     */
    public void startDocument() throws SAXException {

    } 

    /** 
     * End document (SAX API). 
     */

    public void endDocument()
    throws SAXException {

    }

    /** 
     * Characters (SAX API). 
     */

    public void characters(char[] ch,
            int start,
            int length)
    throws SAXException {
        //String tmp;
        JtXMLContext ctx;
        StringBuffer buffer;

        ctx = (JtXMLContext) contextStack.peek();

        if (ctx == null)
            return; // check


        //handleTrace ("Characters:    \"");
        if (ctx.getBuffer() == null) {
            buffer = new StringBuffer ();
            ctx.setBuffer(buffer);
        } else
            buffer = ctx.getBuffer();

        for (int i = start; i < start + length; i++) {
            buffer.append (ch[i]);

            /*
      switch (ch[i]) {
        case '\\':
          handleTrace("\\\\");
          break;
	case '"':
	  handleTrace("\\\"");
	  break;
	case '\n':
	  //handleTrace("\\n");
	  break;
	case '\r':
          handleTrace ("\\r");
          break;
        case '\t':
          handleTrace ("\\t");
          break;
        default:
          buffer.append (ch[i]);
          break;
      }
             */
        }

        //handleTrace("\"\n");
        //elemValue = buffer.toString ();
        buffer.toString().trim ();


    }

    /** 
     * endPrefixMapping - SAX API. 
     */
    public void endPrefixMapping(String prefix)
    throws SAXException {

    }

    /** 
     * ignorableWhitespace - SAX API. 
     */
    public void ignorableWhitespace(char[] ch,
            int start,
            int length)
    throws SAXException {

    }

    /** 
     * processingInstruction - SAX API. 
     */
    public void processingInstruction(String target,
            String data)
    throws SAXException {

    }

    /** 
     * setDocumentLocator - SAX API. 
     */

    public void setDocumentLocator(Locator locator) {

    }

    /** 
     * skippedEntity - SAX API. 
     */

    public void skippedEntity(java.lang.String name)
    throws SAXException {

    }


    /** 
     * startPrefixMapping - SAX API. 
     */

    public void startPrefixMapping(String prefix,
            String uri)
    throws SAXException
    {

    }

    // Realize helper

    void realizeHelper() {

        if (reader != null)
            return;

        try{
            reader = XMLReaderFactory.createXMLReader (parserName);

            reader.setContentHandler (this);
            //reader.setErrorHandler (this);
        } catch (Exception ex) {

            handleException (ex);
        }

    }

    private Object convertXMLToObject (String string) {

        ByteArrayInputStream bstream;

        currentObject = null;  // check

        if (string == null)
            return (null);

        if (reader == null)
            realizeHelper();


        try {

            bstream = new ByteArrayInputStream (string.getBytes());     
            reader.parse (new InputSource ((InputStream) bstream));

        } catch (Exception ex) {
            if ("XMLEncoded".equals(ex.getMessage ())) 
                currentObject = decodeObject (string);  // the object has been encoded using XMLEncode
            else  
                handleException (ex);

        }
        return currentObject;
    }  

    // Convert Jt Component

    private String convertJtObjectToXML (Object obj) {

        StringBuffer buf = new StringBuffer ();

        Hashtable tbl;  
        String key;
        Enumeration keys;

        if (obj == null)
            return (null);

        tbl = getAttributes (obj); 

        if (tbl == null)
            return (null);


//      buf.append ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        buf.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

        if (tbl != null) {
            keys = tbl.keys ();    
            while (keys.hasMoreElements()) {

                key = (String) keys.nextElement ();

                buf.append ("<" + key + ">");
                buf.append ((String) tbl.get (key));  //check
                buf.append ("</" + key + ">\n");


            }
        }
        buf.append ("</Object>\n"); 

        handleTrace ("convertJtObjectToXML (XML):" + buf, JtLogger.JtMIN_LOG_LEVEL);
        return (buf.toString ());

    }

    private String convertObjectToXML (Object obj) {
    	
    	if (obj == null)
    		return (null);
    	
    	return (convertJtObjectToXML (obj));
    }

    // Convert Jt Collection

    private String convertJtCollectionToXML (Object obj) {

        StringBuffer buf = new StringBuffer ();
        JtIterator jit;
        Object tmp;
        String tmp1;

        if (obj == null)
            return (null);

//      buf.append ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        buf.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

        jit = (JtIterator) factory.getValue (obj, "iterator");

        if (jit != null)
            for (;;) {

                tmp = jit.processMessage (new JtMessage (JtIterator.JtNEXT));    
                if (tmp == null)
                    break;
                tmp1 = convertToXML (tmp);

                if (tmp1 == null)
                    return (null); // check

                buf.append (tmp1);
            }  

        buf.append ("</Object>\n"); 

        return (buf.toString ());

    }

    private String convertListToXML (List obj) {

        StringBuffer buf = new StringBuffer ();

        Object tmp;
        String tmp1;
        Iterator iterator;

        if (obj == null)
            return (null);

        buf.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

        iterator = obj.iterator();
        
        if (iterator != null)
        	while (iterator.hasNext()) {
        		
        		tmp = iterator.next();
                if (tmp == null)
                    break;
                tmp1 = convertToXML (tmp);

                if (tmp1 == null)
                    return (null); // check

                buf.append (tmp1);
        	}
        

        buf.append ("</Object>\n"); 

        return (buf.toString ());

    }
    
    
    private String stackTrace (JtRemoteException ex ) {
        ByteArrayOutputStream bstream;


        if (ex == null)
            return (null);

        bstream = new ByteArrayOutputStream ();

        if (ex.getTrace() != null)
            return ex.getTrace();

        //ex = (Exception) getValue (this, "objException");

        ex.printStackTrace (new PrintWriter (bstream, true));

        ex.setTrace(bstream.toString ());


        return (bstream.toString ());


    }

    private String encodeObject (Object obj) {
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);

        if (obj == null)
            return (null);
        msg.setMsgContent(obj);
        return ((String) factory.processMessage (msg));

    }

    private Object decodeObject (String xmlObject) {
        JtMessage msg = new JtMessage (JtObject.JtXML_DECODE);

        if (xmlObject == null)
            return (null);
        msg.setMsgContent(xmlObject);
        return (factory.processMessage (msg));

    }


    // Convert object to XML

    private String convertToXML (Object obj) {

        StringBuffer obuffer = new StringBuffer ();
        String output = null;
        Base64Helper helper = new Base64Helper ();
        String str;
        JtMessage msg = new JtMessage (Base64Helper.JtBASE64_ENCODE);

        helper.setLineLength(JtXMLHelper.LINE_LENGTH);
        if (obj == null) {
            obuffer.append ("<Object>\n");
            obuffer.append ("</Object>\n"); 
            return (obuffer.toString ()); 
        }

        // handleTrace ("convertToXML ..." + obj + ":" + obj.getClass().getName());

        if (obj instanceof String ||
                obj instanceof Character) {
            obuffer.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");
            
            obuffer.append ("<value>" + "<![CDATA[" + obj + "]]>" + "</value>\n"); //check

            obuffer.append ("</Object>\n"); 
            return (obuffer.toString ()); 
        }
        
        if (obj instanceof Date) {
            obuffer.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

            obuffer.append ("<value>" +  ((Date) obj).getTime() + "</value>\n");

            obuffer.append ("</Object>\n"); 
            return (obuffer.toString ()); 
        }
        
        if (obj instanceof byte[]) {
            obuffer.append ("<Object classname=\"byte[]\">\n");
            
            msg.setMsgContent(obj);
            str = (String) factory.sendMessage(helper, msg);
            
            if (str == null)
            	return null;
            obuffer.append ("<value>"+ str + "</value>\n"); //check

            obuffer.append ("</Object>\n"); 
            return (obuffer.toString ()); 
        }

        if (obj instanceof Byte ||
                obj instanceof Short ||
                obj instanceof Integer ||
                obj instanceof Long ||
                obj instanceof Boolean ||
                obj instanceof Float ||
                obj instanceof Double ||
                //obj instanceof String ||
                obj instanceof Character) {
//          buffer.append ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            obuffer.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");
            obuffer.append ("<value>" + obj + "</value>\n");
            obuffer.append ("</Object>\n"); 
            return (obuffer.toString ()); 

        } else if (obj instanceof JtCollection || obj instanceof JtList) { 

            output = convertJtCollectionToXML (obj);

            //if (output != null)
            return (output);

        } else if (obj instanceof List) { 
            output = convertListToXML ((List) obj);
            return (output);        	
        } if (obj instanceof JtInterface) {

            output = convertJtObjectToXML (obj);
            //if (output != null)
            return (output);

        } else if (obj instanceof JtRemoteException) { // check this section
            obuffer.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

            // check

            obuffer.append ("<value>" + "<![CDATA[" + ((Exception) obj).getMessage () + "]]>" + "</value>\n");
            obuffer.append ("<trace>" + "<![CDATA[" + stackTrace ((JtRemoteException) obj) + "]]>" + "</trace>\n");
            obuffer.append ("</Object>\n");
            return (obuffer.toString ());              
        } else if (obj instanceof JtException) { // check this section
            obuffer.append ("<Object classname=\"" + obj.getClass().getName() + "\">\n");

            // check
            //obuffer.append ("<classname>" + "Jt.JtRemoteException" + "</classname>\n");

            obuffer.append ("<value>" + ((Exception) obj).getMessage () + "</value>\n");
            //obuffer.append ("<trace>" + stackTrace ((Exception) obj) + "</trace>\n");
            obuffer.append ("</Object>\n");
            return (obuffer.toString ());              
        } else if (obj.getClass().getName().startsWith("Jt."))
        	return (convertObjectToXML (obj));

        // Try to do the conversion

        if (forceJtEncoding) {
        	output = convertObjectToXML (obj);
        	if (output != null)
        		return (output);
        }
        handleWarning ("convertToXML(warning):using JEE XMLEncoder to convert class " + obj.getClass().getName());  


        //handleTrace ("convertToXML:unable to convert object class " + obj.getClass().getName());   
        return (null);

    }

    // Initialize Helper

    private void initializeHelper () {
        currentObject = null;
        contextStack = new Stack ();
    }

    // Cleanup

    private void cleanup () {
        currentObject = null;
        reader = null;
        contextStack.clear();
    }

    /**
     * Process object messages. 
     * <ul>
     * <li> JtXML_ENCODE - Converts the component (msgContent) into XML.
     * <li> JtXML_DECODE - Converts XML to object. msgContent contains the XML representation of the object.
     * </ul>
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object content;
        String output;
        Object obj;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();


        if (msgid.equals (JtObject.JtXML_ENCODE)) {

            output =  convertToXML (content);

            if (output == null)
                return encodeObject (content);

            //        if (output!= null && output.startsWith("<?xml"))
            //            return (output); 
            //        else
            if (excludeXMLHeader)
                return (output);            
            else    
                return (XML_HEADER + output);
        }


        if (msgid.equals (JtObject.JtXML_DECODE)) {

            initializeHelper ();             
            obj = convertXMLToObject ((String) content);
            
            if ((obj == null && this.getObjException() == null) && !nullObject)
            	handleError ("Unable to decode component (XML format).");

            
            return (obj);
        }

        if (msgid.equals (JtObject.JtREMOVE)) {
            cleanup ();     
            return (null);
        }

        handleError ("JtXMLHelper.processMessage: invalid message id:" + msgid);
        return (null);

    }


    /**
     * Demonstrates all the messages processed by JtXMLHelper
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg1, msg2;
        Date date, date1;
        String tmp, tmp1;
        Integer i;
        Double d;
        JtXMLHelper helper;
        JtOSCommand command;
        JtList col, col1;
        Test test = new Test ();
        JtPrinter printer = new JtPrinter ();
        String str = "Hello World ..";
        JtEncryptedMessage encryptedMessage;
        
        

        msg1 = new JtMessage ();
        msg2 = new JtMessage ();
        
        helper = (JtXMLHelper) main.createObject (JtXMLHelper.JtCLASS_NAME);
        
        
        test.setEmail("test@test.com");
        test.setDate(new Date ());
        test.setByteArray(str.getBytes());
        test.setLongField(5L);

        
        msg1.setMsgId (JtObject.JtXML_ENCODE);
        msg1.setMsgContent (test); 
        
        tmp = (String) main.sendMessage (helper, msg1);
        //System.out.println (tmp);
        

        msg2.setMsgId (JtObject.JtXML_DECODE);
        msg2.setMsgContent (tmp);
        test = (Test) main.sendMessage (helper, msg2);
        System.out.println ("Date:" + test.getDate());
        if (test.getByteArray() != null)
        	System.out.println ("Array:" + new String (test.getByteArray()));
        printer.processMessage(test);
        //System.exit (1);        
        msg1.setMsgContent (test); 
        
        tmp1 = (String) main.sendMessage (helper, msg1);
        
        if (tmp != null && tmp1 != null && tmp.equals(tmp1)) {
            System.out.println ("JtXML_ENCODE (Test): PASS");
        } else
            System.out.println ("JtXML_ENCODE (Test): FAIL");
        //System.out.println (test);

        msg1.setMsgId (JtObject.JtXML_ENCODE);

        msg1.setMsgContent (new Integer (2));

        System.out.println ("JtXML_ENCODE: converting Integer (2) to XML ..");


        tmp = (String) main.sendMessage (helper, msg1);
        System.out.println (tmp);


        msg2.setMsgId (JtObject.JtXML_DECODE);
        System.out.print ("JtXML_DECODE: converting XML to object (Integer) .. ");

        msg2.setMsgContent (tmp);
        i = (Integer) main.sendMessage (helper, msg2);

        System.out.println (i);

        if (i != null && i.intValue() == 2) {
            System.out.println ("JtXML_ENCODE (INTEGER): PASS");
            System.out.println ("JtXML_DECODE (INTEGER): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (INTEGER): FAIL");
            System.out.println ("JtXML_DECODE (INTEGER): FAIL");

        }


        msg1.setMsgId (JtObject.JtXML_ENCODE);

        msg1.setMsgContent (new Double (3));

        System.out.println ("JtXML_ENCODE: converting Double (3) to XML ..");



        tmp = (String) main.sendMessage (helper, msg1);
        //System.out.println (tmp);


        msg2.setMsgId (JtObject.JtXML_DECODE);
        System.out.print ("JtXML_DECODE: converting XML to object (Double) .. ");

        msg2.setMsgContent (tmp);
        d = (Double) main.sendMessage (helper, msg2);

        System.out.println (d);

        if (d != null && d.doubleValue() == 3) {
            System.out.println ("JtXML_ENCODE (DOUBLE): PASS");
            System.out.println ("JtXML_DECODE (DOUBLE): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (DOUBLE): FAIL");
            System.out.println ("JtXML_DECODE (DOUBLE): FAIL");

        }


        msg1.setMsgId (JtObject.JtXML_ENCODE);

        msg1.setMsgContent ("My string");

        System.out.println ("JtXML_ENCODE: converting String to XML ..");
        tmp = (String) main.sendMessage (helper, msg1);
        System.out.println (tmp);


        msg2.setMsgId (JtObject.JtXML_DECODE);
        msg2.setMsgContent (tmp);
        tmp = (String) main.sendMessage (helper, msg2);

        System.out.print ("JtXML_DECODE: converting XML to object (String) .. ");

        System.out.println (tmp);


        if (tmp != null && tmp.equals("My string")) {
            System.out.println ("JtXML_ENCODE (String): PASS");
            System.out.println ("JtXML_DECODE (String): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (String): FAIL");
            System.out.println ("JtXML_DECODE (String): FAIL");

        }


        command = (JtOSCommand) main.createObject (JtOSCommand.JtCLASS_NAME, "cmd");
        main.setValue ("cmd", "command", "notepad");

        msg1.setMsgId (JtObject.JtXML_ENCODE);

        msg1.setMsgContent (command);

        tmp = (String) main.sendMessage (helper, msg1);
        System.out.println ("Output =" + tmp);

        msg1.setMsgId (JtObject.JtXML_DECODE);

        msg1.setMsgContent (tmp);

        command = (JtOSCommand) main.sendMessage (helper, msg1);

        msg1.setMsgId (JtOSCommand.JtEXECUTE);
        main.sendMessage (command, msg1);


        col =  (JtList) main.createObject (JtList.JtCLASS_NAME, "col");

        msg1 = new JtMessage (JtList.JtADD);
        msg1.setMsgContent (new Integer (2));

        main.sendMessage (col, msg1);   
        
        //JtAxisProxy proxy = new JtAxisProxy ();
        //proxy.setProxyId("proxy");
        //proxy.setObjException(null);
        
        //msg1.setMsgContent (proxy);

        //main.sendMessage (col, msg1);  

        msg1.setMsgContent ("String");

        main.sendMessage (col, msg1);  

        msg1.setMsgContent (new JtException ("JtException"));

        main.sendMessage (col, msg1); 

        //msg1 = new JtMessage ("JtADD");
        //msg1.setMsgContent (new Date ());

        //main.sendMessage (col, msg1);  
        
        msg2.setMsgId (JtObject.JtXML_ENCODE);
        msg2.setMsgContent (col);
        tmp = (String) main.sendMessage (helper, msg2);

        System.out.println ("JtList=" + tmp);
        

        /*
        col1 =  (JtList) main.createObject (JtList.JtCLASS_NAME, "col1");

        msg1 = new JtMessage (JtList.JtADD);
        msg1.setMsgContent (new Integer (2));


        main.sendMessage (col1, msg1);       

        msg1.setMsgContent ("String");

        main.sendMessage (col1, msg1);  

        //msg1.setMsgContent (new JtRemoteException ("JtRemoteException"));

        //main.sendMessage (col1, msg1); 

        msg1.setMsgContent (col1);

        main.sendMessage (col, msg1);  


        msg2.setMsgId (JtObject.JtXML_ENCODE);
        msg2.setMsgContent (col);
        tmp = (String) main.sendMessage (helper, msg2);

        System.out.println ("JtCollection=" + tmp);
        */
        
        msg1.setMsgId (JtObject.JtXML_DECODE);

        msg1.setMsgContent (tmp);

        col = (JtList) main.sendMessage (helper, msg1);

        //msg1 = new JtMessage ("JtADD");
        //msg1.setMsgContent (new JtException ("JtException"));
        //main.sendMessage (col, msg1); 

        msg2.setMsgId (JtObject.JtXML_ENCODE);
        msg2.setMsgContent (col);
        tmp1 = (String) main.sendMessage (helper, msg2);

        System.out.println ("JtList (1)=" + tmp1);


        if (tmp != null && tmp1 != null && tmp.equals(tmp1)) {
            System.out.println ("JtXML_ENCODE (JtCollection): PASS");
            System.out.println ("JtXML_DECODE (JtCollection): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (JtCollection): FAIL");
            System.out.println ("JtXML_DECODE (JtCollection): FAIL");

        }


        date = new Date ();
        msg2.setMsgId (JtObject.JtXML_ENCODE);
        msg2.setMsgContent (date);
        tmp = (String) main.sendMessage (helper, msg2);

        System.out.println ("Date=" + tmp);

        msg2.setMsgId (JtObject.JtXML_DECODE);
        msg2.setMsgContent (tmp);
        date1 = (Date) main.sendMessage (helper, msg2);
        System.out.println ("Date1=" + date1);


        if (date1 != null && date1.equals(date)) {
            System.out.println ("JtXML_ENCODE (Date): PASS");
            System.out.println ("JtXML_DECODE (Date): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (Date): FAIL");
            System.out.println ("JtXML_DECODE (date): FAIL");

        }

        msg1 = new JtMessage  (JtObject.JtTEST);
        msg1.setMsgContent(new Integer (10));
        msg2.setMsgId (JtObject.JtXML_ENCODE);
        msg2.setMsgContent (msg1);
        tmp = (String) main.sendMessage (helper, msg2);
        System.out.println ("msg=" + tmp);


        msg2.setMsgId (JtObject.JtXML_DECODE);
        msg2.setMsgContent (tmp);
        JtMessage msg = (JtMessage) main.sendMessage (helper, msg2);
        System.out.println ("msgId" + msg.getMsgId());
        System.out.println ("msgContent" + msg.getMsgContent());
        if (msg.getMsgContent() != null)
            System.out.println ("msgContent:class:" + msg.getMsgContent().getClass().getName());  


        encryptedMessage = new JtEncryptedMessage ();
        
        encryptedMessage.setEncryptedSessionKey("key".getBytes());
        encryptedMessage.setMsgContent("content".getBytes());  
        
        msg.setMsgId (JtObject.JtXML_ENCODE);
        msg.setMsgContent (encryptedMessage);
        tmp = (String)  main.sendMessage (helper, msg);
        //System.out.println (tmp);
        
        msg.setMsgId (JtObject.JtXML_DECODE);
        msg.setMsgContent (tmp);
        encryptedMessage = (JtEncryptedMessage)  main.sendMessage (helper, msg);
        
        msg.setMsgId (JtObject.JtXML_ENCODE);
        msg.setMsgContent (encryptedMessage);
        tmp1 = (String)  main.sendMessage (helper, msg);
        
        
        if (tmp != null && tmp1 != null && tmp.equals(tmp1)) {
            System.out.println ("JtXML_ENCODE (JtEncryptedMessage): PASS");
            System.out.println ("JtXML_DECODE (JtEncryptedMessage): PASS");
        } else {
            System.out.println ("JtXML_ENCODE (JtEncryptedMessage): FAIL");
            System.out.println ("JtXML_DECODE (JtEncryptedMessage): FAIL");

        }
        printer.processMessage(encryptedMessage);
      
    }

}


