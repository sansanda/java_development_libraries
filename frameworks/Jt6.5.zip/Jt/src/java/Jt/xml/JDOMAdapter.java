package Jt.xml;


import java.io.*;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import org.jdom.xpath.*;

import Jt.JtAdapter;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtIterator;
import Jt.JtMessage;
import Jt.JtObject;

/**
 * Adapter for the JDOM API.
 */

public class JDOMAdapter extends JtAdapter {


    private static final long serialVersionUID = 1L;
    private SAXBuilder builder = null;
    private String path;
    public static final String JtCLASS_NAME = JDOMAdapter.class.getName(); 

    public final static String READ_FILE = "READ_FILE";   
    public final static String READ_STREAM = "READ_STREAM";
    public final static String FIND_ELEMENT = "FIND_ELEMENT";   
    public final static String REPLACE_ELEMENT = "REPLACE_ELEMENT";
    public final static String ADD_ELEMENT = "ADD_ELEMENT";
    public final static String INSERT_ELEMENT = "INSERT_ELEMENT";
    public final static String CLONE_ELEMENT = "CLONE_ELEMENT";
    public final static String STRING_TO_XML = "STRING_TO_XML";
    public final static String SAVE_FILE = "SAVE_FILE"; 
    public final static String XML_TO_STRING = "XML_TO_STRING"; //check 
    public final static String GET_CHILDREN = "GET_CHILDREN"; 
    public final static String ELEMENT_TO_BEAN = "ELEMENT_TO_BEAN"; 
    public final static String FIND_ELEMENTS = "FIND_ELEMENTS"; 
    public final static String ADD_CHILD = "ADD_CHILD"; 

    private Document doc = null;
    private String content = null;
    XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
    private boolean initialized = false;
    private InputStream inputStream;
    private List elementList = new LinkedList ();
    private boolean retry = true;
        
    

    /**
     * Initialize the adapter
     */

    private void initializeAdapter () {
        try {
            builder = new SAXBuilder();

        } catch (Exception ex) {

            handleException (ex);

        }
    }

    private void saveFile () {
        File file;
        PrintWriter out;

        if (path == null) {
            handleError ("attribute path needs to be set.");
            return;
        }    

        file = new File (path);
        try {
            out = new PrintWriter (new FileWriter (file));
            getContent ();
            out.print(content);
            out.close();
        } catch (Exception e) {
            handleException (e);
        }    

    }

    /**
     * Reads the XML file specified by path.
     * @return string representation of the XML file.
     */

    public String readFile () {

        if (path == null) {
            handleError ("attribute path needs to be set.");
            return (null);	
        }    

        handleTrace ("JDOMAdapter.readFile:" + path);
        
        try {  
            doc = builder.build(path);
        } catch (Exception ex) {
            if (!retry) {
                handleException (ex);
                return (null);
                
            }
            try {  
                doc = builder.build(path);
            } catch (Exception ex1) {

                handleException (ex1);
                return (null);
                                
            }              
            
        }	
        
        

        if (doc == null)
            return (null);

        outputter = new XMLOutputter(Format.getPrettyFormat());

        return (outputter.outputString (doc));
    }
    
    
    private String readStream () {

        if (inputStream == null) {
            handleError ("attribute inputStream needs to be set.");
            return (null);  
        }    

        try {  
            doc = builder.build(inputStream);
            inputStream.close();
        } catch (Exception ex) {
            
            if (!retry) {
                handleException (ex);

                try {
                    inputStream.close();
                } catch (Exception ex1) {

                }
                return (null);
            }
            
            try {  
                doc = builder.build(inputStream);
                inputStream.close();
            } catch (Exception ex1) {
                handleException (ex1);
                return (null);
                
            }    

            
        } 

        if (doc == null)
            return (null);

        outputter = new XMLOutputter(Format.getPrettyFormat());

        return (outputter.outputString (doc));
    }
    
    
    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    /**
     * Returns the DocType declaration.
     * @return DocType
     */
    public DocType getDocType() {
        if (doc != null)
            return doc.getDocType();
        else
            return null;
    }
    
    /**
     * Sets the DocType declaration.
     */
    
    public void setDocType(DocType docType) {
        if (doc != null)
            doc.setDocType(docType);
    }

    private Document stringToXML (String str) {
        doc = null;
        if (str == null)
            return null;	  
        try {  
            doc = builder.build(new StringReader (str));
        } catch (Exception ex) {
            handleException (ex);
        }		  
        return doc;
    }

    /**
     * Returns the string representing the XML document
     * @return string representing the XML document
     */

    public String getContent() {
        if (doc == null) {
            content = null;
            return (null);
        }    

        outputter = new XMLOutputter(Format.getPrettyFormat());
        content = outputter.outputString (doc);

        return content;
    }




    /**
     * Element lookup
     * @param elementPath
     * @return element or null
     */

    private Element findElement (String elementPath) {
        XPath path;  
        Element elem = null;
        if (elementPath == null)
            return (null);

        if (doc == null)
            return (null);

        try {
            path = XPath.newInstance (elementPath);
            elem = (Element) path.selectSingleNode (doc);

        } catch (JDOMException e) {
            handleException (e);
            return (null);
        }

        return (elem);
    }
    
    private List getChildren (String elementPath) {
        Element elem;
        if (elementPath == null)
            return (null);
        elem = findElement (elementPath);
        if (elem == null)
            return (null);
        return (elem.getChildren());
        
    }
    
    private List findRElements (Element rootElem, String elementName) {
        String name;

                
        elementList.clear ();
        
        if (rootElem == null)
            return (elementList);
                
        name = rootElem.getName();  
        
        if (elementName.equals (name)) {
            elementList.add(rootElem);
            return (elementList);
        }
        
        findElements (rootElem, elementName);
        
        return (elementList);
    }     
    
    
    //private void findElements (List children, String elementName) {
    private void findElements (Element rootElem, String elementName) {
        String name;
        Iterator iterator;
        Element elem;
        List children;
                
        
        if (rootElem == null)
            return;
        
        children =  rootElem.getChildren();
        
        if (children == null || elementName == null)
            return;
        
        iterator = children.iterator();
        
        while (iterator.hasNext()) {
            elem = (Element) iterator.next();
            
            name = elem.getName();  
            //System.out.println("XML ........................" + name);
            if (elementName.equals (name)) {
                elementList.add(elem);
            } else
                findElements (elem, elementName);
        }               
                
    }
    
    private List findElements (String elementName) {
        Element elem;
        List children;
        
        if (elementName == null)
            return (null);
        
        if (doc == null)
            return null;
        
        try {
            elem = doc.getRootElement();
        } catch (Exception ex) {
            handleException (ex);
            return null;
        }
        
        if (elem == null)
            return (null);
        
        elementList.clear();
        
        //children = elem.getChildren();
        
        findElements (elem, elementName);
        
        return (elementList);
        
    }

    /**
     * Sets the content of an element to be the text given.
     * @param elementPath element path
     * @param elementValue new text Value
     * @return element or null
     */

    private Element replaceElement (String elementPath, String elementValue) {
        Element elem;

        if (elementPath == null) {
            return null;    	
        }
        elem = findElement (elementPath);

        if (elem == null) {
            handleError ("replaceElement: element not found: " + elementPath);
            return (elem);
        }

        elem.setText (elementValue);

        return (elem);
    }

    private Element cloneElement (String elementPath) {
        Element elem, parent, tmp;

        if (elementPath == null) {
            return null;    	
        }
        elem = findElement (elementPath);

        if (elem == null) {
            handleError ("cloneElement: element not found: " + elementPath);
            return (elem);
        }

        parent = elem.getParentElement();
        if (parent == null)
            return (null);

        tmp = (Element) elem.clone();

        parent.addContent(tmp);

        return (tmp);
    }

    private void addChild (Element parent, Element child) {
        if (parent == null || child == null)
            return;
        
        parent.addContent(child);
        
    }

    private Element addElement (String parentPath, Element element) {
        Element parent;

        if (parentPath == null) {
            if (doc == null)
                doc = new Document ();
            doc.setRootElement(element); // check
            return (element);
        }

        if (element == null) {
            handleError ("addElement: invalid element (null)");
            return null;        
        }
        parent = findElement (parentPath);

        if (parent == null) {
            handleError ("addElement: parent not found: " + parentPath);
            return (null);
        }

        //parent = elem.getParentElement();
        //if (parent == null)
        //    return (null);

        //tmp = (Element) elem.clone();

        //parent.addContent(element);
        parent.addContent(element);

        return (element);
    }   

    
    
    private Element insertElement (String parentPath, Element element, Integer Index) {
        Element parent;

        if (parentPath == null) {

            return (null);
        }
        
        if (Index == null)
            return null;

        if (element == null) {
            handleError ("insertElement: invalid element (null)");
            return null;        
        }
        parent = findElement (parentPath);

        if (parent == null) {
            handleError ("insertElement: parent not found: " + parentPath);
            return (null);
        }

        parent.addContent(Index.intValue(), element);

        return (element);
    }      
    
    
    private Object elementToBean (Element elem, Object obj) {
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
        JtMessage msg1 = new JtMessage (JtFactory.JtCREATE_OBJECT);     
        JtFactory factory = new JtFactory ();
        JtHashTable attributes;
        JtIterator iterator;
        String attName;
        String attValue;
        Object instance;
        
        if (elem == null || obj == null)
            return (null);
              
        msg1.setMsgContent(obj.getClass().getName());
        
        instance = factory.processMessage(msg1);
        
        if (instance == null)
            return (null);
        
        factory.setStopClass(JtObject.class);
        msg.setMsgContent(instance);
        attributes =  (JtHashTable) factory.processMessage(msg);
        
        if (attributes == null)
            return (null);
        
        iterator = (JtIterator) attributes.processMessage 
        (new JtMessage (JtHashTable.JtGET_KEYS));
        
        if (iterator == null)
            return (null);
        
        for (;;) {
            attName = (String) iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
            if (attName == null)
                break;
            attValue = elem.getAttributeValue(attName);
            if (attValue != null) {
                factory.setValue (instance, attName, attValue);
            }
        }
        
        return (instance);
    }
    
    void attToString (List atts, StringBuffer buffer) {
        Iterator iterator;
        Attribute attr;

        if (buffer == null || atts == null)
            return;
        iterator = atts.iterator();

        if (iterator == null)
            return;

        for (;;) {
            if (!iterator.hasNext())
                break;
            attr = (Attribute) iterator.next();

            buffer.append(" " + attr.getName() + "=\"" + attr.getValue() + "\"");
        }    

    }

    /*
    void elementToString (Element element, StringBuffer buffer, int level) {
        List atts;
        List children;
        int size;
        Namespace nspace;
        String eName;
        String text;

        if (element == null)
            return;

        nspace = element.getNamespace();


        if (nspace == null || nspace.getPrefix() == null || "".equals (nspace.getPrefix()))
            eName = element.getName();
        else
            eName = nspace.getPrefix() + ":" + element.getName(); 

        for (int i = 0; i < level; i++)
            buffer.append("  ");

        buffer.append("<" + eName);

        atts = element.getAttributes();

        if (atts != null)
            attToString (atts, buffer);

        text = element.getTextTrim(); 
        children = element.getChildren();

        if ((children.size() == 0) && (text == null || text.equals("")))
            buffer.append(" />\n");
        else {
            buffer.append(">");
            
            
            if (text != null && !text.equals(""))
                buffer.append(text);

            //if (!"td".equals (eName))
            
            if (children.size() != 0)
                buffer.append("\n");
        }

        //text = element.getTextTrim();
        //if (text != null && !text.equals(""))
        //    buffer.append(text);


        children = element.getChildren();

        if (children.size() != 0) {


            size = children.size ();

            for (int i = 0; i < size; i++) {
                element = (Element) children.get(i);
                //if ("td".equals (eName))
                //    elementToString (element, buffer, 0);    
                //else
                    elementToString (element, buffer, level + 1);  

            }
        }
        if (!((children.size() == 0) && (text == null || text.equals("")))) {
            //if (!"td".equals (eName))
            
            if (children.size() != 0)
                for (int i = 0; i < level; i++)
                    buffer.append("  ");
            buffer.append("</" + eName + ">\n");
        }    

    }
    */
    String xmlToString () {
        //StringBuffer buffer = new StringBuffer ();

        //Element element;

        if (doc == null)
            return (null);

        //element = doc.getRootElement ();
        //if (element == null)
        //    return (null);
        
        return (outputter.outputString (doc));

        //elementToString (element, buffer, 0);

        //return (buffer.toString ());
    }
    
    
    private String read () {
        
        if (path == null && inputStream == null) {
            handleError ("Either path or inputStream should be set.");
            return null;
        }    
        
        if (path != null && inputStream != null) {
            handleError ("Either path or inputStream should be set (not both).");
            return null;
        }         
        
        if (path != null)
            return (readFile ());
        

        return (readStream ());
                
    }

    /**
     * Process object messages.
     * <ul>
     * <li>JtREAD - Reads a XML file or input stream. path or inputStream specify the file to be read. 
     * <li>READ_FILE - Reads a XML file. The attribute path specifies the file to be read. This message
     * is being deprecated (use JtREAD).
     * <li>FIND_ELEMENT - Finds the element specified by msgContent. msgContent specifies the XML path.
     * For instance "jsp:root/html:html/html:form/fieldset".
     * <li>FIND_ELEMENTS - Returns a list of elements of the type specified by msgContent. 
     * For instance "form". 
     * <li>REPLACE_ELEMENT - Replaces the text associated with element specified by msgContent.
     * msgData contains the new text.
     * <li>CLONE_ELEMENT - Clones the element specified by msgContent.
     * <li>SAVE_FILE - Saves XML content to the file specified by the path attribute.
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        Object content;
        Object data;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        if (msg == null || msg.getMsgId () == null) {
            handleError ("Invalid message");	
            return null;
        }  


        if (!initialized) {
            initializeAdapter (); // check
            initialized = true;
        }  

        content = msg.getMsgContent();
        data = msg.getMsgData ();
        
        
        if (msgid.equals (JtObject.JtREAD))
            return (read());

        // Message being deprecate (use JtREAD)
        if (msgid.equals (JDOMAdapter.READ_FILE))
            return readFile ();

        // Message being deprecate (use JtREAD)
        if (msgid.equals (JDOMAdapter.READ_STREAM))
            return readStream ();

        if (msgid.equals (JDOMAdapter.FIND_ELEMENT))
            return findElement ((String) msg.getMsgContent());
        
        if (msgid.equals (JDOMAdapter.FIND_ELEMENTS))
            
            if (msg.getMsgData() != null)
                return (findRElements ((Element) msg.getMsgData(),
                        (String) msg.getMsgContent()));
            else
                return findElements ((String) msg.getMsgContent());

        // This message ID is being deprecated. Use the JDOM API instead (addContent)
        if (msgid.equals(JDOMAdapter.ADD_ELEMENT)) {
            addElement ((String) data, (Element) content);
            return (null);     
        }
        // This message ID is being deprecated. Use the JDOM API instead (addContent)       
        if (msgid.equals(JDOMAdapter.ADD_CHILD)) {
            addChild ((Element) content, (Element) data);
            return (null);     
        }
        
        // This message ID is being deprecated. Use the JDOM API instead (addContent)
        if (msgid.equals(JDOMAdapter.INSERT_ELEMENT)) {
            insertElement ((String) data, (Element) content,
                    (Integer) msg.getMsgAttachment());
            return (null);     
        }

        if (msgid.equals (JDOMAdapter.REPLACE_ELEMENT))
            return replaceElement ((String) msg.getMsgContent(),
                    (String) msg.getMsgData());

        // This message ID is being deprecated. Use the JDOM API instead (getChildren)
        if (msgid.equals (JDOMAdapter.GET_CHILDREN))
            return getChildren ((String) msg.getMsgContent());

        if (msgid.equals (JDOMAdapter.CLONE_ELEMENT))
            return cloneElement ((String) msg.getMsgContent()); 
               
        if (msgid.equals (JDOMAdapter.ELEMENT_TO_BEAN)) {
            return elementToBean ((Element) msg.getMsgContent(),
                    (Object) msg.getMsgData ()); 
        }    

        if (msgid.equals(JDOMAdapter.STRING_TO_XML))
            return (stringToXML ((String) msg.getMsgContent())); 

        if (msgid.equals(JDOMAdapter.XML_TO_STRING))
            return (xmlToString ()); 

        if (msgid.equals(JDOMAdapter.SAVE_FILE)) {
            saveFile ();
            return (null);     
        }
        return (super.processMessage (message));

    }

    /**
     * Returns the path to the XML file.
     */  

    public String getPath() {
        return path;
    }

    /**
     * Specifies the path to the XML file.
     */  

    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Returns the retry attribute.
     */  

    public boolean isRetry() {
        return retry;
    }
    
    /**
     * Specifies the retry attribute. Specifies whether or not the adapter should 
     * retry to open the file/stream. The default is true. 
     */  

    public void setRetry(boolean retry) {
        this.retry = retry;
    }

    /**
     * Demonstrates the messages processed by this class.
     */

    public static void main(String[] args) {

        JtMessage msg = new JtMessage ();
        JtFactory factory = new JtFactory ();
        JDOMAdapter adapter;
        Element element = new Element ("Root");
        DocType docType;

        adapter = (JDOMAdapter) factory.createObject(JDOMAdapter.JtCLASS_NAME);

        // Add elements
        
        msg.setMsgId(JDOMAdapter.ADD_ELEMENT);
        msg.setMsgContent (element);
        factory.sendMessage(adapter, msg);

        element = new Element ("class");
        element.setAttribute("name", "Jt.Object");
        msg.setMsgContent (element);
        msg.setMsgData ("Root");
        factory.sendMessage(adapter, msg);  

        element = new Element ("id");
        element.setAttribute("name", "email");
        msg.setMsgContent (element);
        msg.setMsgData ("Root/class");
        factory.sendMessage(adapter, msg);  

        element = new Element ("property");
        element.setAttribute("name", "firstname");
        msg.setMsgContent (element);
        msg.setMsgData ("Root/class");
        factory.sendMessage(adapter, msg);  
        
        docType = new DocType ("hibernate-mapping", 
                "-//Hibernate/Hibernate Mapping DTD 3.0//EN",
        "http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd");

        adapter.setDocType(docType);

        //msg.setMsgId(new Integer (JdomAdapter.READ_FILE));
        //output = (String) adapter.processMessage(msg);
        System.out.println (adapter.getContent()); 

        //msg = new JtMessage (JdomAdapter.SAVE_FILE);

        //adapter.processMessage(msg); // Save the file 


    }




}
