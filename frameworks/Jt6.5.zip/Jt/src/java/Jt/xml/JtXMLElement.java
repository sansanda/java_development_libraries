package Jt.xml;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import Jt.JtComposite;
import Jt.JtMessage;

/**
 * XML Element. Internal class used by JtSAXAdapter.
 */

public class JtXMLElement extends JtComposite {


	private static final long serialVersionUID = 1L;


	public static final String JtCLASS_NAME = JtXMLElement.class.getName(); 
	public static final String JtGET_ATTRIBUTE = "JtGET_ATTRIBUTE"; 
	public static final String JtGET_SUBELEMENT = "JtGET_SUBELEMENT"; 


	private String qname;
	private HashMap attributes = null;
	private String text;


	/**
	 * Returns the element attributes
	 */
	
	public HashMap getAttributes() {
		return attributes;
	}
	
	/**
	 * Specifies the element attributes
	 */
	
	public void setAttributes(HashMap attributes) {
		this.attributes = attributes;
	}

	/**
	 * Returns the qualified name.
	 */
	
	public String getQname() {
		return qname;
	}
	
	/**
	 * Specifies the qualified name.
	 */
	
	public void setQname(String qname) {
		this.qname = qname;
	}

	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}

	private JtXMLElement getSubElement (String qName) {
		List list;
		Iterator iterator;
		JtXMLElement elem;

		if (qName == null) 
			return (null);

		list = this.getList();

		if (list == null)
			return (null);

		iterator = list.iterator();

		while (iterator.hasNext()) {
			elem = (JtXMLElement) iterator.next();

			if (qName.equals(elem.getQname()))
				return (elem);
		}

		return (null);
	}

	
	private void printAttributes () {
		Iterator iterator;
		String name;
		String value;
		
		if (attributes == null)
			return;
		
		iterator = attributes.keySet().iterator();
		
		while (iterator.hasNext()) {
			name = (String) iterator.next();
			
			value = (String) attributes.get(name);
			
			System.out.print(" " + name + "=\"" + value + "\"");
			

		}
		System.out.print("\n");		
	}

	public Object processMessage (Object message) {

		String msgid = null;
		JtMessage msg = (JtMessage) message;

		msgid = (String) msg.getMsgId ();

		if (msgid.equals(JtXMLElement.JtGET_ATTRIBUTE)) {
			if (attributes == null)
				return (null);

			if (msg.getMsgContent() == null) { 
				handleError ("Invalid message attribute (msgContent): null");
				return (null);
			}    

			return (attributes.get(msg.getMsgContent()));
		}

		if (msgid.equals(JtXMLElement.JtGET_SUBELEMENT)) {


			if (msg.getMsgContent() == null) { 
				handleError ("Invalid element name: null");
				return (null);
			}    

			return (getSubElement ((String) msg.getMsgContent()));
		}
		
		if (msgid.equals(JtXMLElement.JtPRINT)) {
			
			System.out.print("<" + qname + ">");
 
			printAttributes ();
			System.out.println("</" + qname + ">");
			return (null);
		}

		return (super.processMessage (message));


	}

}
