
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */
package Jt.xml;

import Jt.*;
//import Jt.examples.Test;
//import Jt.security.JtEncryptedMessage;
//import Jt.util.Base64Helper;

import java.util.*;
//import java.lang.reflect.*;
//import java.beans.*;
import java.io.*;

import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 * Jt SAX Adapter.
 */

public class JtSAXAdapter extends JtObject implements ContentHandler {


    private static final long serialVersionUID = 1L;
    private transient XMLReader reader = null;
    private String path;
    protected static final String DEFAULT_PARSER_NAME = "org.apache.xerces.parsers.SAXParser";
    protected static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    private transient Object currentObject = null;         // current object
    private String parserName = DEFAULT_PARSER_NAME;
    private transient Stack contextStack = new Stack ();
    public static final String JtCLASS_NAME = JtSAXAdapter.class.getName(); 
    //private static final int LINE_LENGTH = 72; 
    private transient JtFactory factory = new JtFactory ();
	//private InputStream inputStream = null;
    private boolean initialize = false;
    private Object delegateComponent = null;


	public JtSAXAdapter() {
    }

    /**
     * Returns the path to the XML file.
     */  

    public String getPath() {
        return path;
    }

    /**
     * Specifies the path to the XML file.
     */  

    public void setPath(String path) {
        this.path = path;
    }
    
    /**
     * Specifies the parser.
     * @param parserName parse
     */


    void setParserName (String parserName) {
        this.parserName = parserName;

    }


    /**
     * Returns the parser. 
     */

    String getParserName () {
        return (parserName);  
    }

    /**
     * Returns the input stream.
     */

    public Object getDelegateComponent() {
		return delegateComponent;
	}

    /**
     * Specifies the delegate components that will process the XML elements.
     */
    
	public void setDelegateComponent(Object delegateComponent) {
		this.delegateComponent = delegateComponent;
	}

	
	
	private HashMap retrieveAttributes (Attributes attrs) {
		HashMap map;
		int i;
		
		if (attrs == null)
			return (null);
		
		map = new HashMap ();
		
		for (i = 0; i < attrs.getLength(); i++) {
			handleTrace ("attribute:" + attrs.getQName(i), JtLogger.JtMIN_LOG_LEVEL);
			handleTrace ("attribute (value):" + attrs.getValue(i), JtLogger.JtMIN_LOG_LEVEL);
			
			map.put(attrs.getQName(i), attrs.getValue(i));
			//attrs.getQName(i);
		}
		
		return (map);
		
	}
	
	/** 
     * Start element (SAX API). 
     */
    public void startElement(String uri, String local, String raw,
            Attributes attrs) throws SAXException {

        JtXMLContext ctx;
        HashMap map;
        JtXMLElement element = new JtXMLElement ();

        handleTrace ("Start element: " + raw, JtLogger.JtMIN_LOG_LEVEL);
        //handleTrace ("Start element: " + raw);

        //if ("java".equals (raw))     
        //    throw (new SAXException ("XMLEncoded"));


        ctx = new JtXMLContext ();
        ctx.setElement(raw);
        
        element.setQname(raw);
        //contextStack.push(ctx);
        contextStack.push(element);
        

        map = retrieveAttributes (attrs);
        element.setAttributes(map);

        //if ("Object".equals (raw)) { 
            //map = new HashMap ();
            //ctx.setProperties(map);
            
            //ctx.setClassname(attrs.getValue("", "classname"));
            //handleTrace ("classname:" + attrs.getValue("", "classname"));
            return;    
        //}

    } 

    
 
 
     
 
    private long StringToLong (String str) {
        long lpostingId;
        
        if (str == null)
        	return (1);
        try {
            lpostingId = Long.parseLong(str);
        } catch (Exception e) {
            handleException (e);
            return (-1L);
        }
        return (lpostingId);
    }




    /** 
     * End element (SAX API). 
     */

    public void endElement(String uri,
            String name,
            String qName)
    throws SAXException {
        JtMessage msg;
        int i;
        //JtXMLContext parentCtx = null, currentCtx;
        //Vector children;
        //HashMap map;
        //StringBuffer buffer;
        //Object newObject = null;
        JtXMLElement currentElement, parentElement;
        


        if (qName == null)
            return;  //check


        handleTrace ("End element: " + qName, JtLogger.JtMIN_LOG_LEVEL);

        currentElement = (JtXMLElement) contextStack.pop ();
        
        
        if (delegateComponent != null) {
        	
        	factory.sendMessage(delegateComponent, currentElement);
        	
        }
        
        if (contextStack.isEmpty()) {
            return; // check
        }
        
        parentElement = (JtXMLElement) contextStack.peek();
        msg = new JtMessage (JtComposite.JtADD_CHILD);
        msg.setMsgContent(currentElement);

        parentElement.processMessage(msg);
        
        /*
        if ("Object".equals (qName)) { //check



            //newObject = createInstance ();
            currentObject = newObject;


            //handleTrace ("End element: "  + newObject.getClass().getName());

            currentCtx = (JtXMLContext) contextStack.pop ();
            currentCtx.setObject(newObject);
            
            if (newObject == null && currentCtx.getClassname() == null) // Null object
            	return;
            
            if (newObject == null) // Invalid class
            	throw (new SAXException ("Unable to create class instance"));

            if (newObject instanceof JtCollection || newObject instanceof JtList) {
                children = (Vector) currentCtx.getChildren();
                //if (children == null)
                //    return;

                if (children != null)
                	for (i = 0; i < children.size (); i++) {
                		msg = new JtMessage (JtCollection.JtADD); // chech message ID
                		msg.setMsgContent (children.elementAt (i));
                		((JtObject) newObject).processMessage (msg);
                		//sendMessage (object, msg);
                	}
                //return;
            }
            
            if (newObject instanceof List) {

                children = (Vector) currentCtx.getChildren();
                //if (children == null)
                //    return;
                if (children != null)
                	for (i = 0; i < children.size (); i++)
                		((List) newObject).add(children.elementAt (i));


            }

            if (contextStack.isEmpty()) {
                return; // check
            }


            parentCtx = (JtXMLContext) contextStack.peek();

            if (!("Object".equals(parentCtx.getElement()))) {
                handleTrace ("End Element: this attribute references an object " +  
                        newObject.getClass().getName(), JtLogger.JtMIN_LOG_LEVEL);
                parentCtx.setChild(newObject);
                return;
            }   

            //handleTrace ("End Element: adding child to parent " +  
            //        newObject.getClass().getName());

            children = (Vector) parentCtx.getChildren ();             
            if (children == null) {
                children = new Vector ();
                parentCtx.setChildren(children);
                children.addElement (newObject);
            } else {
                children.addElement (newObject);                 
            }

            //return;
        } else { 


            currentCtx = (JtXMLContext) contextStack.pop();

            parentCtx = (JtXMLContext) contextStack.peek();
            map = (HashMap) parentCtx.getProperties();


            if (currentCtx.getChild() != null) {
                map.put (qName, currentCtx.getChild());
                handleTrace ("map.put(" + qName + "):" + currentCtx.getChild(),
                		JtLogger.JtMIN_LOG_LEVEL);
                return;
            }    

            buffer = currentCtx.getBuffer();

            handleTrace (qName + ":" + buffer);

            if (buffer != null && buffer.toString () != null && map != null)
                map.put (qName, buffer.toString ());

        } 
   */

    }


    /** 
     * Start document (SAX API). 
     */
    public void startDocument() throws SAXException {

    } 

    /** 
     * End document (SAX API). 
     */

    public void endDocument()
    throws SAXException {

    }

    /** 
     * Characters (SAX API). 
     */

    public void characters(char[] ch,
            int start,
            int length)
    throws SAXException {
        String tmp;

        StringBuffer buffer = new StringBuffer ();
        JtXMLElement element;
        
        element = (JtXMLElement )contextStack.peek();
        
        if (element == null)
        	return;
        
        if (element.getText() == null) {
            buffer = new StringBuffer ();

        } else 
            buffer = new StringBuffer (element.getText());
        	
        
/*
        ctx = (JtXMLContext) contextStack.peek();

        if (ctx == null)
            return; // check



        if (ctx.getBuffer() == null) {
            buffer = new StringBuffer ();
            ctx.setBuffer(buffer);
        } else
            buffer = ctx.getBuffer();



        //handleTrace("\"\n");
        //elemValue = buffer.toString ();
        //
*/
        for (int i = start; i < start + length; i++)
            buffer.append (ch[i]);
   
        
        tmp = buffer.toString().trim ();
        
        element.setText(tmp);
        
        if (tmp == null || tmp.equals(""))
        	return;
        
        handleTrace ("Characters:\"" + tmp + "\"", JtLogger.JtMIN_LOG_LEVEL);

    }

    /** 
     * endPrefixMapping - SAX API. 
     */
    public void endPrefixMapping(String prefix)
    throws SAXException {

    }

    /** 
     * ignorableWhitespace - SAX API. 
     */
    public void ignorableWhitespace(char[] ch,
            int start,
            int length)
    throws SAXException {

    }

    /** 
     * processingInstruction - SAX API. 
     */
    public void processingInstruction(String target,
            String data)
    throws SAXException {

    }

    /** 
     * setDocumentLocator - SAX API. 
     */

    public void setDocumentLocator(Locator locator) {

    }

    /** 
     * skippedEntity - SAX API. 
     */

    public void skippedEntity(java.lang.String name)
    throws SAXException {

    }


    /** 
     * startPrefixMapping - SAX API. 
     */

    public void startPrefixMapping(String prefix,
            String uri)
    throws SAXException
    {

    }


    private boolean initialize() {
    	
        currentObject = null;
        contextStack = new Stack ();

        try{
            reader = XMLReaderFactory.createXMLReader (parserName);

            reader.setContentHandler (this);
            //reader.setErrorHandler (this);
        } catch (Exception ex) {

            handleException (ex);
            return (false);
        }

        return (true);
    }

 

    
    // Cleanup

    private void cleanup () {
        currentObject = null;
        reader = null;
        contextStack.clear();
    }

    
    private void readFile () {
    	InputStream istream;
    	
    	if (path == null) { 
    		handleError ("Path attribute needs to be set");
    	    return;
        }
    	
        try {
            istream = new FileInputStream (path);
            reader.parse (new InputSource (istream));
            
            if (istream != null)
            	istream.close();
        } catch (Exception e) {
            handleException (e);
            return;
        }
    	
    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtACTIVATE - Parse the XML file.
     * </ul>
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        //Object content;
        //String output;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();


        // reset exception
        this.setObjException(null);

        
        if (msgid.equals (JtComponent.JtACTIVATE)) {

            if (!initialize ())
            	return (null); 
            readFile ();
            cleanup ();
            return (new Boolean (true));

        }
        
        if (msgid.equals (JtComponent.JtREMOVE)) {
            cleanup ();     
            return (new Boolean (true));
        }

        handleError ("Invalid message id:" + msgid);
        return (null);

    }


    /**
     * Demonstrates all the messages processed by JtSAXAdapter
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtMessage msg;

        JtSAXAdapter saxAdapter;

                

        msg = new JtMessage ();
        
        if (args.length < 1) {
        	System.err.println ("Usage: java Jt.xml.JtSAXAdapter processdefinition.xml");
        	return;
        }
        
        saxAdapter = (JtSAXAdapter) factory.createObject (JtSAXAdapter.JtCLASS_NAME);

        
        msg.setMsgId (JtComponent.JtACTIVATE);
        saxAdapter.setPath(args[0]);
        
        factory.sendMessage (saxAdapter, msg);        

      
    }

}


