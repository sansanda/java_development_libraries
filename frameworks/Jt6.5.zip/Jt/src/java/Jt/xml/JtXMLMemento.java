

package Jt.xml;

import Jt.JtFactory;
import Jt.JtMemento;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.examples.HelloWorld;



/**
 * Subclass of JtMemento (memento design pattern). This class captures
 * the internal state of an object using XML format.
 */

public class JtXMLMemento extends JtMemento {

    public static final String JtCLASS_NAME = JtXMLMemento.class.getName(); 
    private static final long serialVersionUID = 1L;
    private String xmlState = null;
    private String name;
    

    /**
     * Specifies (saves) the originator's internal state.
     * @param xmlState state (XML)
     */
    public void setXmlState(String xmlState) {
        this.xmlState = xmlState;
    }




    /**
     * Returns the originator's internal state.
     */
    
    public String getXmlState() {
        return xmlState;
    }



    public String getName() {
        return name;
    }




    public void setName(String name) {
        this.name = name;
    }




    public JtXMLMemento () {
    }




    /**
     * Process object messages.
     * <ul>

     * </ul>
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object reply;



        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtMemento.JtSAVE)) {
            reply = super.processMessage(event);
            xmlState = (String) state;
            return (reply);
        }
        
        if (msgid.equals (JtMemento.JtRESTORE)) {
            state = (String) xmlState;
            return (super.processMessage(event));

        }
   
        return (super.processMessage(event));

    }


    /**
     * Demonstrates the messages processed by JtXMLMemento.
     */


    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtXMLMemento memento;
        JtMessage msg;
        HelloWorld hello = new HelloWorld ();
        JtPrinter printer = new JtPrinter ();

        hello.setGreetingMessage("Hello World");

        // Create an instance of JtMemento

        memento = (JtXMLMemento) factory.createObject (JtXMLMemento.JtCLASS_NAME, "memento");


        // Save the state of hello using Memento

        msg = new JtMessage (JtXMLMemento.JtSAVE);    
        msg.setMsgContent(hello);   
        factory.sendMessage (memento, msg);   

        System.out.println ("Saved object:");
        //factory.sendMessage (hello, new JtMessage (JtObject.JtPRINT)); 
        printer.processMessage(hello);

        hello.setGreetingMessage("new message");

        System.out.println ("Object after changed:");
        //factory.sendMessage (hello, new JtMessage (JtObject.JtPRINT));
        printer.processMessage(hello);
        
        // Restore the object

        msg = new JtMessage (JtXMLMemento.JtRESTORE);    
        msg.setMsgContent(hello);     
        factory.sendMessage (memento, msg);

        System.out.println ("Restored Object:");   
        //factory.sendMessage (hello, new JtMessage (JtObject.JtPRINT));
        printer.processMessage(hello);


        //factory.removeObject (memento);


    }




}


