

package Jt.xml;

import java.util.Date;
import java.util.Hashtable;

import Jt.*;
import Jt.security.JtAccessManager;


/**
  * Jt Script interpreter 
  */


public class JtScriptInterpreter extends JtInterpreter  {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtScriptInterpreter.class.getName(); 
  public static final String JtSCRIPT = "JtSCRIPT"; 
  public static final String JtPARSE = "JtPARSE"; 
  private String filename;
  private String content;
  private boolean remoteInvocation = false;
  private transient JtXMLHelper xmlHelper = null;
  private transient Object scriptOutput = null; // script output
  private transient JtFactory factory = new JtFactory (); 
  private transient boolean enableAccessManager = false;
  private Hashtable componentTable = new Hashtable ();

  

  public JtScriptInterpreter () {
  }


 /**
  * Specifies the script filename.
  * @param filename script filename
  */

  public void setFilename (String filename) {
     this.filename = filename; 
  }


 /**
   * Returns the script filename. 
   */

  public String getFilename () {
     return (filename);
  }

 /**
  * Specifies the script content.
  * @param content script content
  */

  public void setContent (String content) {
     this.content = content; 
  }


 /**
   * Returns the script content. 
   */
  public String getContent () {
     return (content);
  }




  public void setRemoteInvocation (boolean remoteInvocation) {
     this.remoteInvocation = remoteInvocation; 
  }


  public boolean getRemoteInvocation () {
     return (remoteInvocation);
  }


  /**
   * Returns the value of the enableAccessManager flag.
   */

  public boolean isEnableAccessManager() {
	  return enableAccessManager;
  }

  /**
   * Specifies whether or not the framework access manager should be used.
   * This limits the access granted to remote programs.
   * The framework resource file is used to specify what classes/packages
   * can be accessed.
   */

  public void setEnableAccessManager(boolean enableAccessManager) {
	  this.enableAccessManager = enableAccessManager;
  }


  private Exception propagateException (Object obj)
  {
	  Exception ex;

	  if (obj == null)
		  return null;

	  ex = (Exception) factory.getValue (obj, "objException");


	  if (ex != null)
		  //factory.setValue (this, "objException", ex);
		  this.setObjException(ex);

	  return (ex);
  }
 
   // a better mechanism may be needed
  
   private String generateUniqueId (Object obj) {
	   String str;
	   Date date = new Date ();
	   
	   if (obj == null)
		   return null;
	   
	   str = obj.getClass().getName() + "@" + (obj.hashCode() + (date.getTime()));

	   return (str);
	   
   }

	private Object componentLookup (String id) {
		JtMessage msg = new JtMessage (JtRegistry.JtREAD);
		JtRegistry registry;
        
        if (id == null)
        	return null;
        
 	    registry = factory.getRegistry();
 	    
 	    if (registry == null) {
 	        this.handleError("Registry component not found");
 	    	return (null);
 	    }
 	    
		msg.setMsgData(id);
		return (registry.processMessage(msg));
	}
	
	private Object retrieveHandle (String id) {
		Object handle;
		
		handle = componentTable.get (id);
		
		if (handle == null)
			handle = componentLookup (id);
		
		return (handle);					
				
	}
   
   // Interpret Jt Message: update scriptOutput for JtCREATE_OBJECT, JtSET_VALUE
   //                       and JtSEND_MESSAGE, etc.
 
   private Object interpretMsg (Object event) {

     String msgid;
     JtMessage msg = (JtMessage) event;
     Object result = null;
     String ctype;
     JtAccessManager accessManager;
     JtMessage msg1 = new JtMessage (JtAccessManager.JtCHECK_SERVICE_ACCESS);
     String aReply;
     Object handle;
     Boolean Bool;
     Object componentId; // check

     
     if (msg == null)
       return (null);

     msgid = (String) msg.getMsgId ();

     if (msgid == null)
       return (null);

     factory.setObjException(null);
     
     if (msgid.equals (JtFactory.JtSET_VALUE)) {
       //handle = componentTable.get (msg.getMsgSubject ());

       handle = retrieveHandle ((String) msg.getMsgSubject ());	 
       factory.setValue (handle,
                 msg.getMsgContent (),
                 msg.getMsgData());

       propagateException (factory);
       return (null);
     }

     if (msgid.equals (JtFactory.JtCREATE_OBJECT)) {
       //System.out.println ("JtScriptIterpreter(JtCREATE_OBJECT):" + msg.getMsgContent()
       //    + "," + msg.getMsgData());
 
       ctype = (String) msg.getMsgContent();

       if (remoteInvocation) {
    	   if (enableAccessManager) {
    		   accessManager = (JtAccessManager) factory.createObject(JtAccessManager.JtCLASS_NAME);
    		   msg1.setMsgContent(ctype);

    		   aReply = (String) factory.sendMessage(accessManager, msg1);

    		   if (!"true".equals(aReply)) {
    			   factory.handleError ("Security violation: unable to create a remote instance of " +
    					   ctype);
        		   propagateException (factory);
    			   return (null);
    		   }
    	   } else if (JtOSCommand.JtCLASS_NAME.equals (ctype) || JtFile.JtCLASS_NAME.equals (ctype) ||
    			   JtDirectory.JtCLASS_NAME.equals (ctype)) {
    		   factory.handleError ("Security violation: unable to create a remote instance of " +
    				   ctype); 
    		   propagateException (factory);
    		   return (null);
    	   }

       }                                  
       result = factory.createObject (msg.getMsgContent (),
                 msg.getMsgData());

       if (remoteInvocation) {

           if (result == null)
               scriptOutput = null;               
           else {
               scriptOutput = generateUniqueId (result); // Object ID is returned
               componentTable.put(scriptOutput, result);              
           }
           handleTrace ("JtScriptInterpreter.interpretMsg(JtCREATE_OBJECT):proxy:" + scriptOutput, 
                   JtLogger.JtMIN_LOG_LEVEL);
           
           propagateException (factory);


           return (scriptOutput);
           //return (null);
       }  

       propagateException (factory);
       
       scriptOutput = result;
       return (result);
     }

     
     if (msgid.equals (JtFactory.JtLOOKUP)) {

         componentId = msg.getMsgContent(); //check
    	 accessManager = (JtAccessManager) factory.createObject(JtAccessManager.JtCLASS_NAME);
    	 
    	 msg1 = new JtMessage (JtAccessManager.JtCHECK_COMPONENT_ACCESS);
    	 msg1.setMsgContent(componentId);

    	 Bool = (Boolean) factory.sendMessage(accessManager, msg1);

    	 if (!Bool.booleanValue()) {
    		 factory.handleError ("Security violation: unable to access remote component " +
    				 msg.getMsgContent());
    		 propagateException (factory);
    		 return (null);
    	 }

    	 msg1 = new JtMessage (JtObject.JtLOOKUP);
    	 msg1.setMsgContent (componentId);
    	 
         result = factory.processMessage (msg1);


         if (result == null) {
        	 scriptOutput = null;
       		 factory.handleError ("Remote component not found: " + componentId);     	 
         } else {
        	 scriptOutput = componentId; // component Id is returned    
             //componentTable.put(scriptOutput, result);
         }
         
         handleTrace ("JtScriptInterpreter.interpretMsg(JtLOOKUP):" + scriptOutput, 
        		 JtLogger.JtMIN_LOG_LEVEL);

         propagateException (factory);


         return (scriptOutput);


       }
     
     if (msgid.equals (JtFactory.JtGET_VALUE)) {
    	 //handle = componentTable.get (msg.getMsgContent ());
         handle = retrieveHandle ((String) msg.getMsgContent ());

    	 result = factory.getValue (handle,
    			 msg.getMsgData());

    	 propagateException (factory);
    	 scriptOutput = result;   
    	 handleTrace ("JtScriptInterpreter.interpretMsg(JtGET_VALUE):" + scriptOutput, 
    			 JtLogger.JtMIN_LOG_LEVEL);
    	 return (result);
     }

     if (msgid.equals (JtFactory.JtREMOVE_OBJECT)) {
       handle = componentTable.get (msg.getMsgContent ());  
       
       
       // remove from the internal component table
       // Registry components cannot be removed from a
       // remote application.
       if (handle == null) {
    	   handleError ("Component not found:" + msg.getMsgContent ());
    	   return (null);
       }
       factory.sendMessage(handle, new JtMessage (JtObject.JtREMOVE));
       componentTable.remove (msg.getMsgContent ());
   
       //factory.removeObject (handle);
       //propagateException (factory);
       return (null);
     }


     if (msgid.equals (JtFactory.JtSEND_MESSAGE)) {
       //handle = componentTable.get (msg.getMsgContent ());
       handle = retrieveHandle ((String) msg.getMsgContent ());

       result = factory.sendMessage (handle,
                    msg.getMsgData ());

       propagateException (handle);

       scriptOutput = result;
       return (result);

     }

     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);
     }

     handleError ("JtScriptInterpreter.interpretMessage: invalid msg ID:"
     + msg.getMsgId ());
     return (null);
   }


  private Object parse () {
    

    JtMessage msg;
    JtList col;
    JtMessage msg1;
    JtIterator iterator;
    String str;
    JtFile file;
    //Object result = null;
    Exception ex;

    if (filename != null && content != null) {
      handleError ("JtScriptInterpreter.parse: set uri or string (only one)");
      return null;
    } 

    if (filename == null && content == null) {
      handleError ("JtScriptInterpreter.parse: both uri and string are null");
      return null;
    }    

    scriptOutput = null;

    if (filename != null) {

      file = new JtFile ();

      factory.setValue (file, "name", filename);

      str = (String) factory.sendMessage (file, new JtMessage (JtFile.JtCONVERT_TO_STRING));
    

    } else
      str = content;


    if (str == null)
      return (null);

    if (xmlHelper == null)
      xmlHelper = new JtXMLHelper ();  
      //xmlHelper = (JtXMLHelper) createObject (JtXMLHelper.JtCLASS_NAME, "xmlHelper");


    msg = new JtMessage (JtObject.JtXML_DECODE);

    msg.setMsgContent (str);

    col = (JtList) factory.sendMessage (xmlHelper, msg);

    //destroyObject ("xmlHelper");

    if (col == null)
      return (null);

    msg = new JtMessage (JtIterator.JtNEXT);

    //iterator = (JtIterator) getValue (col, "iterator");
    iterator = (JtIterator) col.getIterator();

    if (iterator == null)
      return (null);

    for (;;) {
      msg1 = (JtMessage) iterator.processMessage (new JtMessage (JtIterator.JtNEXT));

      if (msg1 == null)
        break;    

      interpretMsg (msg1);  

      //ex = (Exception) 
      // getValue (this, "objException");
      ex = (Exception) this.getObjException();

      if (ex != null)
        break;   // stop processing the script
                 // if an exception is detected   
    }

    return (scriptOutput);
  }


  // Process object messages

  public Object processMessage (Object event) {

   String msgid = null;
   JtMessage e = (JtMessage) event;
   //Object content;

     if (e == null)
	return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	return null;

//   content = e.getMsgContent();

     if (msgid.equals (JtScriptInterpreter.JtPARSE) || msgid.equals (JtInterpreter.JtINTERPRET)) {
        return (parse ());
     }

     if (msgid.equals (JtObject.JtREMOVE)) {
         return (null);
     }
     
     return (super.processMessage(event));
     //handleError ("JtScriptInterpreter.processMessage: invalid message id:" + msgid);
     //return (null);

  }



 /**
   * Demonstrates all the messages processed by JtScriptInterpreter. 
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();


    if (args.length < 1) {
      System.err.println ("Usage: java JtScriptInterpreter uri");
      System.exit (1);
    }

    // Create message reader

    factory.createObject (JtScriptInterpreter.JtCLASS_NAME, "reader");

    factory.setValue ("reader", "filename", args[0]);


    factory.sendMessage ("reader", new JtMessage (JtInterpreter.JtINTERPRET));


  }

}


