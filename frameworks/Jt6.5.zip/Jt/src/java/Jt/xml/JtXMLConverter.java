
package Jt.xml;
import Jt.*;

/**
 *  Converts Jt API calls into XML messages. These messages can be sent
 *  to remote objects. This class is being deprecated. Please use XMLHelper instead.
 */

public class JtXMLConverter extends JtObject {

    public static final String JtCLASS_NAME = JtXMLConverter.class.getName(); 
    public static final String JtCONVERT = "JtCONVERT";
    private static final long serialVersionUID = 1L;
    private JtList list = new JtList ();


    public JtXMLConverter() {
    }


    public Object createObject (Object class_name, Object id) {

        JtMessage msg1 = new JtMessage (JtFactory.JtCREATE_OBJECT);   
        JtMessage msg2 = new JtMessage (JtList.JtADD); 

        //if (class_name == null || id == null) // check
        if (class_name == null) // check    
            return (null);

        msg1.setMsgContent(class_name);
        msg1.setMsgData(id);
        msg2.setMsgContent (msg1);

        list.processMessage(msg2);    

        return (null);
    }

    public Object objectLookup (Object id) {

        JtMessage msg1 = new JtMessage (JtFactory.JtLOOKUP);   
        JtMessage msg2 = new JtMessage (JtList.JtADD); 

        if (id == null)
            return (null);

        msg1.setMsgContent(id);
        msg2.setMsgContent (msg1);

        list.processMessage(msg2);    

        return (null);
    }
    
    public Object sendMessage (Object id, Object msg) {

        JtMessage msg1 = new JtMessage (JtFactory.JtSEND_MESSAGE);
        JtMessage msg2 = new JtMessage (JtList.JtADD);     
        
        if (id == null || msg == null)
            return (null);


        msg1.setMsgContent(id);
        msg1.setMsgData(msg);
        msg2.setMsgContent (msg1);


        list.processMessage(msg2);

   
        return (null);


    } 



    public void removeObject (Object id) {
        JtMessage msg1 = new JtMessage (JtFactory.JtREMOVE_OBJECT);   
        JtMessage msg2 = new JtMessage (JtList.JtADD); 

        if (id == null)
            return;

        msg1.setMsgContent(id);
        msg2.setMsgContent (msg1);


        list.processMessage(msg2);    

    } 

    public void setValue (Object id, Object att, 
            Object value) {
        JtMessage msg1 = new JtMessage (JtFactory.JtSET_VALUE);
        JtMessage msg2 = new JtMessage (JtList.JtADD);   

        //if (id == null || att == null || value == null)
        if (id == null || att == null)
            return;

        msg1.setMsgSubject(id);
        msg1.setMsgContent (att);
        msg1.setMsgData(value);
        msg2.setMsgContent (msg1);
        
        
        list.processMessage(msg2);  

    }


    public Object getValue (Object id, Object att) {
        JtMessage msg1 = new JtMessage (JtFactory.JtGET_VALUE);
        JtMessage msg2 = new JtMessage (JtList.JtADD); 

        if (id == null || att == null)
            return (null);


        msg1.setMsgContent(id);
        msg1.setMsgData(att);
        msg2.setMsgContent (msg1);


        list.processMessage(msg2);  

        return (null);

    }

    String convertToXML () {

        JtXMLHelper helper;
        String xmlObj;
        JtMessage msg2 = new JtMessage (JtObject.JtXML_ENCODE);  

        helper = new JtXMLHelper ();

        msg2.setMsgContent (list);

        xmlObj = (String) helper.processMessage (msg2); 

        if (xmlObj == null) {
            handleError ("Fatal error: unable to convert to XML");
            return (null);
        }

        return (xmlObj);

    }

    // Process object messages

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        //Object content;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();

        if (msgid.equals (JtXMLConverter.JtCONVERT)) { 
            return (convertToXML ());
        }  

        // Let the parent class process the message

        return (super.processMessage (event));     


    }


    /**
     * Demonstrates all the message processed by JtXMLConverter. 
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg1;
        JtMessage msg = new JtMessage ("JtHELLO");
        JtXMLConverter converter;
        String str;

        //main.setLogFile ("log.txt");

        msg1 = new JtMessage ();

        msg1.setMsgId (JtXMLConverter.JtCONVERT);


        converter = (JtXMLConverter) main.createObject (JtXMLConverter.JtCLASS_NAME, 
        "adapter");

        converter.createObject (JtOSCommand.JtCLASS_NAME, "command");
        converter.setValue ("command", "command", "notepad");
        converter.sendMessage ("command", new JtMessage (JtOSCommand.JtEXECUTE));
        converter.getValue ("command", "command");
        converter.sendMessage ("command", msg);

        str = (String) main.sendMessage (converter, msg1);

        System.out.println ("XML =" + str);

    }

}


