

package Jt;
import java.util.*;


/**
 * Handles a list of components. This class is useful when a List component 
 * needs to be added to UML/BPM diagrams or accessed via a remote API.
 */


public class JtList extends JtObject {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtList.class.getName(); 
    private List col = null;
    public static final String JtADD = "JtADD";
    public static final String JtCLEAR = "JtCLEAR";
    public static final String JtFIRST = "JtFIRST";
    public static final String JtLAST = "JtLAST";
    public static final String JtREMOVE_FIRST = "JtREMOVE_FIRST";
    public static final String JtREMOVE_OBJECT = "JtREMOVE_OBJECT";    

    public JtList() {
    }


    /**
     * Returns the List used to implement this class. 
     */
    public List getList () {
        return (col);
    }



    /**
     * Sets the List used to implement this class. 
     */

    public void setList (List col) {
        this.col = col;
    }

    /**
     * Returns a JtIterator.
     */

    public JtIterator getIterator () {
        JtIterator jit;
        //Collection values;

        jit = new JtIterator ();

        if (col == null)
            return (null);
        /*
     values = col.values ();

     if (values == null)
       return (null);
         */
        jit.setIterator(col.iterator ());

        return (jit);
    }
    
    /**
     * void operation. 
     */
    public void setIterator (JtIterator iterator) {

    }

    /**
     * Void operation.
     */

    public void setSize (int size) {
        // this.size = this.size; // void operation
    }

    /**
     * Returns the number of elements in this list.
     */ 

    public int getSize () {
        return (col != null ? col.size (): 0);
    }


    /**
     * Process object messages.
     * <ul>
     * <li> JtADD - Appends the object specified by msgContent to the end of
     * this list
     * <li> JtCLEAR - Removes all the objects from this list
     * <li> JtFIRST - Returns the first element in the list
     * <li> JtLAST - Returns the last element in the list
     * <li> JtREMOVE_FIRST - Removes and returns the first element in the list
     * <li> JtREMOVE_OBJECT - Removes the object specified by msgContent.
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //Object data;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();
        //data = e.getMsgData ();

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtList.JtADD)) {
            // Add object to the list

            if (content == null) {
                handleWarning 
                ("JtList.processMessage(JtADD):invalid content (null)");
                return (this);

            }
            if (col == null)
                col = new LinkedList ();

            col.add (content);        
            return (this);
        }     


        if (msgid.equals (JtList.JtCLEAR)) {

            if (col != null) {
                col.clear ();
            }

            return (this);
        }

        if (msgid.equals (JtList.JtFIRST)) {

            if (col == null)
                return (null);

            if (col.size () < 1) {
                return (null);
            }

            return (col.get (0));
        }


        if (msgid.equals (JtList.JtLAST)) {

            if (col == null)
                return (null);

            if (col.size () < 1) {
                return (null);
            }

            return (col.get (col.size() - 1));
        }


        if (msgid.equals (JtList.JtREMOVE_FIRST)) {

            if (col == null)
                return (null);

            if (col.size () < 1) {
                return (null);
            }

            return (col.remove (0));
        }

        if (msgid.equals (JtList.JtREMOVE_OBJECT)) {
            // Remove an object from the collection

            if (content == null) {
                handleWarning 
                ("JtList.processMessage(JtREMOVE_OBJECT):invalid message content (null)");
                return (null);

            }
            if (!col.contains (content)) {
                handleError ("element not found " + content);
                return (null);
            }    
            
            col.remove (content);        
            return (null);
        } 
        
        return (super.processMessage(message));


    }


    /**
     * Demonstrates the messages processed by JtList.
     * This class is useful when a List component needs to be
     * added to UML/BPM diagrams or accessed via a remote API.
     */ 

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        JtIterator it;
        Integer obj;
        Integer I;
        JtList list;


        // Create a JtList

        list = (JtList) main.createObject (JtList.JtCLASS_NAME, "list");

        msg = new JtMessage (JtList.JtADD);
        msg.setMsgContent(new Integer (1));

        // Add an object to the list

        main.sendMessage (list, msg);

        msg = new JtMessage (JtList.JtADD);
        msg.setMsgContent(I = new Integer (2));

        // Add object to the list

        main.sendMessage (list, msg);

        System.out.println ("Size=" + list.getSize());


        obj = (Integer) main.sendMessage (list, new JtMessage (JtList.JtFIRST));

        System.out.println ("First=" + obj);

        obj = (Integer) main.sendMessage (list, new JtMessage (JtList.JtLAST));

        System.out.println ("Last=" + obj);

        it = (JtIterator) list.getIterator();

        for (;;) {
            obj = (Integer) main.sendMessage (it, new JtMessage (JtIterator.JtNEXT));
            if (obj == null)
                break;
            System.out.println (obj);
        }


        msg = new JtMessage (JtList.JtREMOVE_OBJECT);
        msg.setMsgContent(I);       
        
        main.sendMessage (list, msg);
        
        System.out.println ("Size=" + list.getSize());        
        
        // Clear the list

        msg.setMsgId(JtList.JtCLEAR);
        main.sendMessage (list, msg);

    }

}


