/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;


import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.security.Key;

import javax.crypto.KeyGenerator;

import Jt.axis.JtAxisProxy;
import Jt.examples.HelloWorld;
import Jt.rest.JtRestService;
import Jt.security.JtEncryptedMessage;
import Jt.security.JtMessageCipher;


/**
 * Jt Messenger (early .8 version ). Sends a MDP message to a component. Performs encryption as needed via JtMessageCipher.
 */

public class JtMessenger extends JtObject {


  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtMessenger.class.getName();

	private Key sessionKey = null;
	private String encryptionAlgorithm = "Blowfish";
	private int keySize = 128;
	private JtMessageCipher messageCipher;
	private JtContext context;
	private boolean synchronous = true;                    // Synchronous messaging ?
	protected boolean encrypted = false;                   // Encrypted messaging
	private boolean useEnvelope = false;                  // Use enveloped
	

	  public JtMessenger () {


	  }
	
 
	/**
	 * Returns the session key.
	 */
	
	public Key getSessionKey() {
		return sessionKey;
	}

	/**
	 * Specifies the session key that is to be used for message
	 * encryption. This key session  will be encrypted using the
	 * public key of the recipient. If no key is specified (null value)
	 * a session key is generated using the specified encryption algorithm
	 * and key size.
	 */

	public void setSessionKey(Key sessionKey) {
		this.sessionKey = sessionKey;
	}

	/**
	 * Returns the encryption algorithm.
	 */

	public String getEncryptionAlgorithm() {
		return encryptionAlgorithm;
	}

	/**
	 * Specifies the encryption algorithm to be
	 * used for message encryption (Blowfish
	 * is the default).
	 */
	
	public void setEncryptionAlgorithm(String encryptionAlgorithm) {
		this.encryptionAlgorithm = encryptionAlgorithm;
	}
	
	
	/*
	 * Returns the message context. It contains authentication information (username, password, etc).
	 */

	public JtContext getContext() {
		return context;
	}

	/*
	 * Specifies the message context.  
	 */

	public void setContext(JtContext context) {
		this.context = context;
	}


	/**
	 * Returns the key size.
	 */
	
	public int getKeySize() {
		return keySize;
	}

	/**
	 * Specifies the key size to be
	 * used by the encryption mechanism
	 * (128 is the default).
	 */
	
	public void setKeySize(int keySize) {
		this.keySize = keySize;
	}

    
	   /**
	    * Returns the value of synchronous.
	    */

	    public boolean isSynchronous() {
			return synchronous;
		}

	    /**
	     * Specifies whether or not this message should be processed asynchronously (independent thread).
	     */
	    
		public void setSynchronous(boolean synchronous) {
			this.synchronous = synchronous;
		}

		/**
		 * Returns the value of encrypted.
		 */


		public boolean isEncrypted() {
			return encrypted;
		}
		

		/**
		 * Specifies whether or not this message should be encrypted.
		 */

		public void setEncrypted(boolean encrypted) {
			this.encrypted = encrypted;
		}
	
	
	/*
	 *  Propagate Exceptions
	 */
	
	public boolean isUseEnvelope() {
			return useEnvelope;
		}


		public void setUseEnvelope(boolean useEnvelope) {
			this.useEnvelope = useEnvelope;
		}



	  private Key generateSessionKey () {
		  Key sessionKey;
		  
		  try {
			  KeyGenerator generator = KeyGenerator.getInstance (encryptionAlgorithm);
			  generator.init(keySize);
			  sessionKey = generator.generateKey();
			  
			  return (sessionKey);
		  } catch (Exception ex) {
			  handleException (ex);
			  return (null);
		  }
	  }
	
	private JtEncryptedMessage encryptMessage (Object message, Key key) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		JtEncryptedMessage encryptedMessage;
		
		if (message == null || key == null)
			return (null);		
		
		if (messageCipher == null)
			messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        messageCipher.setSessionKey(key);
		
		encryptedMessage = (JtEncryptedMessage) messageCipher.processMessage(message);
		
		if (encryptedMessage == null) {
			handleError ("Unable to encrypt message");
			return (null);
		}
		return (encryptedMessage);
		
	}
	
	
 	
	private Object decryptMessage (JtEncryptedMessage encryptedMessage, Key key) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		Object message;
		
		if (encryptedMessage == null)
			return (null);		
		
		if (messageCipher == null)
			messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        messageCipher.setSessionKey(key);

		message = (Object) messageCipher.processMessage(encryptedMessage);
		
		if (message == null) {
			handleError ("Unable to decrypt message");
			return (null);
		}
		return (message);
		
	}
	
	private boolean initializeProxy (JtProxy proxy) {
		JtMessage msg = new JtMessage (JtProxy.JtINITIALIZE_PROXY);
		Boolean Bool;

		if (proxy == null)
			return (false);
		
		if (proxy.getSubject() != null)
			return (true);

		msg.setEncrypt(encrypted);
		Bool = (Boolean) ((JtProxy) proxy).processMessage(msg);

		return (Bool.booleanValue());

	}
	
	  private Object buildMessageForProxy (JtProxy id, Object message) {
	      JtMessage msg = new JtMessage (JtFactory.JtSEND_MESSAGE);
		  
		  
	      if (id == null)
	          return (null);
	      
	      if (id instanceof JtRemoteProxy && !initializeProxy (id)) 
	    	  return (null);
	      
	      msg.setMsgTo(((JtProxy)id).getSubject());
	      msg.setMsgContent(message);
	      msg.setEncrypt(encrypted);
	      msg.setAsynchronous(!synchronous);
	      
	      //if (!this.isSynchronous())  {
	      //	  msg.setAsynchronous(true);
	      //}
	      
	      if (id instanceof JtRestService) {
	    	  
				msg.setMsgRecipientClassname(((JtRestService) id).getClassname());
			    msg.setMsgTo(((JtRestService) id).getRemoteComponentId());
	      }

	      return (msg);

	  }
	  
	  /** 
	   * Component lookup.
	   */
	  
	  Object lookupObject (Object id) {
	  	JtMessage msg = new JtMessage (JtFactory.JtLOOKUP);
	  	JtFactory factory = new JtFactory ();

	      if (id == null)
	      	return null;
	      

	      msg.setMsgContent(id);
	      return (factory.processMessage(msg));
	  }   

	  
	  private Object encodeObject (Object obj) {

	      ByteArrayOutputStream stream = new ByteArrayOutputStream ();
	      XMLEncoder e; 
	      Object result = null;


	      if (obj == null)
	          return (null);

	      try {

	          e = new XMLEncoder(
	                  new BufferedOutputStream(stream));
	          e.writeObject(obj);
	          e.close();
	          result = stream.toString ();

	      } catch (Exception ex) {
	          handleException (ex);
	          return (null);
	      }    
	      return (result); 

	  }
	  
	  private void handleMessageTrace (Object message) {

	      //String nl = System.getProperty("line.separator");
	      String tmp;
	      String xmlMessage;
	      JtMessage msg;
	            

	      
	      if (logger.getLogLevel() == JtLogger.JtMIN_LOG_LEVEL) {
	    	  xmlMessage = (String) encodeObject (message);
	    	  handleTrace ("Message ...\n" + xmlMessage, JtLogger.JtMIN_LOG_LEVEL);
	    	  return;
	      }
	      if (message instanceof JtMessage) {
	    	  msg = (JtMessage) message;
	    	  tmp = "JtMessage.msgId:" + msg.getMsgId ();
	    	  
	    	  /*
	    	  if (msg.getMsgSubject () != null)
	    		  tmp +=nl+ "JtMessage.MsgSubject:"+ msg.getMsgSubject();
	    	  */	  
	    	  if (msg.getMsgContent () != null)
	    		  tmp += "\nJtMessage.msgContent:"+ msg.getMsgContent();
	  
	          handleTrace (tmp);
	      }
	      
	  }
	  
	  
      private Object forwardMessage (Object obj, Object msg) {
    	  JtEnvelope envelope;
    	  Object reply;
    	  
    	  if (obj == null || msg == null)
    		  return (null);
    	  
    	     // Asynchronous messaging ?

          if (!synchronous) {
        	  if (obj instanceof JtThread) {
        		  
        		  // Discard the envelope if any
        		  
        	      if (msg instanceof JtEnvelope)    	    	  
        	      	  msg = ((JtEnvelope) msg).getMessage();
        	      
                  reply = ((JtThread) obj).enqueueMessage ((Object) msg);
        	      	  
        	  } else {
        		  
        		  /*
        		  if (!(msg instanceof JtEnvelope)) {
        			  
        	   		  // Use a message envelope. Asynchronous message (msg) is
                      // passed inside an instance of JtEnvelope  			  
        			  
        			  envelope = new JtEnvelope ();   	  
        			  envelope.setMessage(msg);
        			  envelope.setAsynchronous(true);
        			  
        			  msg = envelope;
        		  }
        		  */
                  reply = ((JtInterface) obj).processMessage (msg);
        	  }
        	  
          } else {
        	  if (obj instanceof JtThread) {
        		  
        	      if (msg instanceof JtEnvelope)  { // Asynchronous message (msg)
        	    	  
        	    	  envelope = (JtEnvelope) msg;
        	    	  
    	    		  // Discard the envelope
        	   		  msg = ((JtEnvelope) msg).getMessage();
        	    	  
        	    	  if (envelope.isAsynchronous())  	 
        	    		  reply = ((JtThread) obj).enqueueMessage (msg);
        	    	  else
        	    		  reply = ((JtInterface) obj).processMessage (msg);
        	    		  
        	    	  
        	      }	 else 
        	    	  reply = ((JtInterface) obj).processMessage (msg); // Synchronous message 

        	      	  
        	  } else {
        		  
        		  // Asynchronous message (msg) is passed inside an instance of JtEnvelope
        		  // This will probably cause an expected exception since Asynchronous
        		  // messaging requires the component to inherit from JtThread.
        	      
                  reply = ((JtInterface) obj).processMessage (msg);
        	  }
        	  
          }
          

    	  
    	  return (reply);
      }
	 
	  /**
	   * Sends a message to a component (Jt messaging design pattern). 
	   *
	   * @param id    component id
	   * @param msgid message
	   */
	
	public Object sendMessage (Object id, Object msgid) {
		JtEncryptedMessage encryptedMessage;
		Object reply;
		//Key key;
		//JtFactory factory = new JtFactory ();
		//JtMessage msg;
		Object obj;
		JtEnvelope envelope;
		Object message;
		//Object msg;


		if (id == null) {
			handleError ("invalid component (null)");
			return (null);
		}

		
		if (msgid != null)
			handleTrace ("sendMessage:"+ 
					id.toString() + ", "+ msgid.toString() + " ...");    	  
		else    	  
			handleTrace ("sendMessage:"+ 
					id.toString() + ", "+ msgid  + " ...");

		obj = lookupObject (id);

		if (obj == null) {
			handleError ("unable to find object " + id);
			return (null);
		}
		
		//msg = msgid;
	    if (logger.getLogLevel() == JtLogger.JtMIN_LOG_LEVEL)
	     	  handleTrace ("Component ...\n" + (String) encodeObject (obj), JtLogger.JtMIN_LOG_LEVEL);
	      
	    handleMessageTrace (msgid);

		if (obj instanceof JtProxy) {
			
			message = buildMessageForProxy ((JtProxy) obj, msgid);
			
			if (message == null)
				return (null);
			

		} else
			message = msgid;
		
		
		
		if (obj instanceof JtRemoteProxy || useEnvelope) {
			envelope = new JtEnvelope ();
			envelope.setMessage(message);
			message = envelope;
			
			if (context != null)
				envelope.setContext(context);

		}
				

		if (encrypted) {
			
			//key = generateSessionKey ();
		
			
			if (sessionKey == null) {
				
				// Generate the session key to be
				// used for message encryption.
				
				//handleTrace ("Generating a session key ....");
				
				sessionKey = generateSessionKey ();
				if (sessionKey == null)
					return (null);
			}
			

			
			encryptedMessage = encryptMessage (message, sessionKey);
			//encryptedMessage = encryptMessage (message);
			
			if (encryptedMessage == null)
				return (null);
			
			
		    //reply =  (((JtInterface)obj).processMessage(encryptedMessage));
			reply = forwardMessage (obj, encryptedMessage);
						
			//if (propagateException (obj) != null)
			//	return (null);
			
			if (reply instanceof JtEncryptedMessage) {
				
				return (decryptMessage  ((JtEncryptedMessage) reply, sessionKey));
			}
			
			return (reply);
		}
		
				
		reply = forwardMessage (obj, message);

		
		//if (propagateException (obj) != null)
		//	return (null);
			
		return (reply);
	}

   

 
  /**
   * Demonstrates the messages processed by JtMessenger
   */

  public static void main(String[] args) {

    JtMessenger messenger = new JtMessenger ();
	JtFactory factory = new JtFactory ();
	String sReply;
	Object reply;
	JtAxisProxy proxy, proxy1;
	String url = "http://localhost:8080/JtPortal/JtRestService";
	HelloWorld helloWorld;
	String greeting;
	
	url = "http://localhost:8080/axis/services/JtAxisService";

    //JtPrinter printer = new JtPrinter ();
    boolean bool;
       
    
	// Create an instance of the remote Proxy


	proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
	
	// Specify url and classname
	
	proxy.setUrl(url);
	proxy.setClassname ("Jt.examples.Echo");
		
    // Send the message to the remote component/service.
	
	//messenger.setEncrypted(true);
	sReply = (String) messenger.sendMessage (proxy, "Welcome to Jt messaging ...");

	System.out.println ("Reply:" + sReply);
	
	
	// Create an instance of the remote Proxy

	proxy1 = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);	
	proxy1.setUrl(url);
	proxy1.setClassname ("Jt.examples.EchoService");
		
    // Specify that secure/encrypted messaging should be used
	messenger.setEncrypted(true);
	//messenger.setSynchronous(false);
	
    // Send the message to the remote component/service.
	
	reply = messenger.sendMessage (proxy1, new JtMessage (JtComponent.JtACTIVATE));

	System.out.println ("Reply:" + reply);


    // Specify that secure/encrypted messaging should be used				
	factory.setEncrypted(true);
	bool = factory.setValue(proxy1, "greeting", "new message");
	System.out.println ("boolean:" + bool);		

	
	reply = factory.getValue(proxy1, "greeting");
	System.out.println ("greeting attribute:" + reply);	

	bool = factory.removeObject(proxy1);		
	System.out.println ("removeObject:" + bool);		
	
	//bool = factory.removeObject(proxy1);
	//System.out.println ("removeObject:" + bool);		
	
	factory.setEncrypted(false);
	helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME, "helloWorld");

    greeting = (String) factory.sendMessage("helloWorld", new JtMessage (HelloWorld.JtHELLO));
    System.exit(1);


  }

}


