/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;

import Jt.examples.HelloWorld;



/**
 * Jt Implementation of the Proxy pattern.
 */


public class JtProxy extends JtObject {

  public static final String JtCLASS_NAME = JtProxy.class.getName(); 
  public static final String  JtINITIALIZE_PROXY = "JtINITIALIZE_PROXY"; 
  private static final long serialVersionUID = 1L;
  private Object subject;

  public JtProxy() {
  }

/**
  * Specifies the proxy's subject.
  *
  * @param subject subject
  */

  public void setSubject (Object subject) {
     this.subject = subject; 

  }

/**
  * Returns the proxy's subject.
  */

  public Object getSubject () {
     return (subject);
  }




  /**
    * Process object messages by forwarding them to the proxy's subject. 

    * @param event Jt Message    
    */


  public Object processMessage (Object event) {
  
	  JtFactory factory = new JtFactory ();


     // Let the subject process the request

     if (subject == null) {
       handleError ("JtProxy.process: the subject attribute needs to be set");
       return (null);
     }


     //return (factory.sendMessage (subject, event));
     //return (((JtInterface) subject).processMessage(event));
     return (factory.processMessage (event));

  }

  
  /**
    * Demonstrates the messages processed by JtProxy.   
    */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtMessage msg;
    HelloWorld helloWorld;
    JtProxy proxy;
    String str;


    // Create an instance of JtProxy

    proxy = (JtProxy)
      main.createObject (JtProxy.JtCLASS_NAME);
    helloWorld = (HelloWorld) main.createObject (HelloWorld.JtCLASS_NAME);

    proxy.setSubject(helloWorld); // this is the correct way of setting the attribute
                                  // subject
    
    msg = new JtMessage(HelloWorld.JtHELLO);
    
    main.setValue(proxy, "greetingMessage", "Proxy: hello world");

    str = (String)main.getValue(proxy, "greetingMessage");
        
    System.out.println ("greeting:" + str);
    
    // Send a message to the Proxy
    
    System.out.println ("Reply:" + main.sendMessage (proxy, msg));
    
    main.removeObject(proxy);       

  }

}
