/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */
package Jt;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.*;



/**
 * Root class of the Jt component hierarchy; it implements the functionality 
 * required by the messaging design pattern.
 */


public class JtObject implements Serializable, JtInterface {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtObject.class.getName();
    protected static String version = "6.5 - 08/01/10";    // Framework version

    // Core Messages
    
    public static String JtINITIALIZE = "JtINITIALIZE";
    public static final String JtACTIVATE = "JtACTIVATE"; 
    public static final String JtREMOVE = "JtREMOVE"; 
    
    public static final String JtSTART = "JtSTART";          // Component may use an independent thread
    public static final String JtSTOP = "JtSTOP";
          
    public static final String JtBROADCAST = "JtBROADCAST";  // Broadcast a message
    public static final String JtTEST = "JtTEST";  

    public static final String JtPRINT = "JtPRINT"; 
    public static final String JtCLONE = "JtCLONE";         
    public static final String JtCOPY = "JtCOPY"; 


    public static final String JtXML_ENCODE = "JtXML_ENCODE"; 
    public static final String JtXML_DECODE = "JtXML_DECODE";   



    // Messages used for the implementation of the visitor
    // design pattern

    public static final String JtVISIT = "JtVISIT";
    public static final String JtACCEPT = "JtACCEPT";

    // Value Object design pattern

    public static final String JtVALUE_OBJECT = "JtVALUE_OBJECT";  // This message is being moved to the subclasses
                                                                   // Check the documentation

    
    // CRUD Messages
    

    public static String JtCREATE = "JtCREATE";
    public static String JtREAD = "JtREAD";
    public static String JtUPDATE = "JtUPDATE";   
    public static String JtDELETE = "JtDELETE"; 
    public static String JtSEARCH = "JtSEARCH";    
    public static String JtLOOKUP = "JtLOOKUP"; 



    //private String objName = null;			        
    private Object componentId;                         // Component Id
    private Object objException;	                    // Exception
    private transient Object objErrors = null;


    // Context attributes


    private static boolean initialized = false;          // The framework has been initialized?

    protected static JtLogger logger;                    // Logger component 
    protected static JtInterface exceptionHandler;       // Exception handler




    public JtObject () {
        
    	if (!initialized) {
    		initialized = true;
 
    		//JtFactory factory = new JtFactory ();  // Forces Jt initialization

    	}

    } 
    
    /** 
     * Retrieves the logger.
     */

    public static JtLogger getLogger() {
  	  return logger;
    }
    
    /** 
     * Sets the logger.
     */

    public static void setLogger(JtLogger logger) {
  	  JtFactory.logger = logger;
    }

    /** 
     * Retrieves the exception handler.
     */
    
     public static JtInterface getExceptionHandler() {
		return exceptionHandler;
	}

     /** 
      * Sets the exception handler.
      */
     
	public static void setExceptionHandler(JtInterface exceptionHandler) {
		JtObject.exceptionHandler = exceptionHandler;
	}

	 private String encodeObject (Object obj) {

	      ByteArrayOutputStream stream = new ByteArrayOutputStream ();
	      XMLEncoder e; 
	      String result = null;


	      if (obj == null)
	          return (null);

	      try {

	          e = new XMLEncoder(
	                  new BufferedOutputStream(stream));
	          e.writeObject(obj);
	          e.close();
	          result = stream.toString ();

	      } catch (Exception ex) {
	          handleException (ex);
	          return (null);
	      }    
	      return (result); 

	  }

	  private Object decodeObject (String xmlObj) {

	      ByteArrayInputStream stream;
	      Object result = null;
	      XMLDecoder d;


	      if (xmlObj == null)
	          return (null);

	      stream = new ByteArrayInputStream (xmlObj.getBytes ());

	      try {

	          d = new XMLDecoder(
	                  new BufferedInputStream(stream));
	          result = d.readObject();
	          d.close();

	      } catch (Exception ex) {
	          handleException (ex);
	      } 
	      return (result);    

	  }

	  // Clone the object

	  private Object cloneObject () {

	      String aux;

	      
	      aux = encodeObject (this);

	      if (aux == null) {
	          handleError ("cloneObject: Unable to encode the object (XML format"); 
	          return (null);
	      }

	      return (decodeObject (aux));

	 }
	  
	/**
     * Process a Jt Message. This is the only method required by the Jt interface (Jt Interface). 
     * <li>JtCLONE - returns a clone of this object.
     * <li>JtPRINT - prints this object using its XML representation.
     * <li>JtACCEPT - Accept operation. This message contains a reference to
     * the visitor (msgContent). As a result of this operation, a JtVISIT
     * message is sent to the visitor. A reference to this object is passed to the visitor.
     * @param message  message
     */


    public Object processMessage (Object message) {

        String msgid;
        JtMessage msg;
        Object content;
        JtMessage aux;

        // handleTrace ("JtObject.processMessage called");
        if (message== null)
            return (null);
        
        if (!(message instanceof JtMessage)) {
        	handleError ("Invalid message:" + message);
        	return null;
        }	
        
        msg = (JtMessage) message;
        
        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return (null);

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);  // Nothing needs to be done   
        }

        // Clone object
        if (msgid.equals (JtObject.JtCLONE)) {
            return (cloneObject ());     
        } 


        if (msgid.equals (JtObject.JtPRINT)) {
            System.out.println (encodeObject (this));
            return (null);
        }

        // This message is being moved to the subclasses
        // Check the documentation
        
        //if (msgid.equals (JtObject.JtVALUE_OBJECT)) {
        //    return (this);
        //}


        if (msgid.equals (JtObject.JtACCEPT)) {

            content = msg.getMsgContent();

            if (content == null) {
                handleError ("processMessage: invalid ACCEPT message; visitor reference is null");
                return (null);
            }

            // Send a JtVISIT message to the visitor.
            // Include a reference to this object

            aux = new JtMessage (JtVisitor.JtVISIT);
            aux.setMsgContent (this);
            return (new JtFactory().sendMessage (content, aux));   // check
        }

        handleError ("JtObject.processMessage: invalid msg ID:"
                + msg.getMsgId ());
        return (null);
    }
    

    /** 
     * Handles exceptions. Jt provides a consistent way of handling exceptions:
     * the exception is stored and propagated using the objException attribute.
     * The exception message and the stack trace are sent to the screen or a log file.
     * This method should be called each time an exception is detected.
     * Override this method if your application requires special exception handling.
     * You may also provide your custom exception handler. Refer to the 
     * exceptionHandler attribute.
     * @param e exception
     */

    public void handleException (Throwable e) {

        //String trace;

        // An exception has occurred. Update the objException attribute
        objException = e;


        if (exceptionHandler == null)
        	return;
        
        exceptionHandler.processMessage(e);
    }


    /** 
     * Handles trace messages. This method should be called each time a 
     * message needs to be logged. Trace messages are send to the screen or a log file
     * depending on the logFile attribute. The logging attribute is used to enable/disable
     * logging. Override this method if your application requires special logging capabilities.
     * You may also provide your custom logger. Refer to the logger attribute.
     * @param msg trace message
     * @param level logging level
     */

    public void handleTrace (String msg, int level) {
        //Date date;
        //SimpleDateFormat formatter;

        if (logger == null || !logger.getLogging())
        	return;
        
        logger.processMessage(new JtLogEntry (msg, level));


    }
    
    /** 
     * Handles trace messages. This method should be called each time a 
     * message needs to be logged. Trace messages are send to the screen or a log file
     * depending on the logFile attribute. The logging attribute is used to enable/disable
     * logging. Override this method if your application requires special logging capabilities.
     * You may also provide your custom logger. Refer to the attribute logger.
     * @param msg trace message
     */

    public void handleTrace (String msg) {
        handleTrace (msg, JtLogger.JtDEFAULT_LOG_LEVEL);
    }

    /** 
     * Handles warning messages. This method should be called each time a warning
     * message needs to be logged. Trace messages are send to the screen or a log file
     * depending on the logFile attribute. Warning messages are always logged regardless
     * of the value of the objTrace attribute.
     * @param msg trace message
     */

    public void handleWarning (String msg) {
        if (logger == null)
        	return;

        logger.processMessage(new JtLogEntry (msg, JtLogger.JtMAX_LOG_LEVEL));
        

    }



    /** 
     * Handles error messages. This method generates a JtException which 
     * is handled by the handleException method.
     * This causes the error message and the stack trace to be sent to the screen or a log file.
     * This method should be called each time an error is detected.
     * Override this method if your application requires special error handling.
     * @param msg error message
     */

    public void handleError (String msg) {
        try {

            // generate a JtException 
            if (objErrors == null)
                objErrors = new LinkedList ();

            ((LinkedList) objErrors).add(msg);

            throw new JtException (msg);

        } catch (JtException e) {

            handleException (e);
        }

    }



   
    /** 
     * Retrieves the component name.
     */

    //public String getObjName() {
    //    return objName;
    //}


    /** 
     * Sets the component name.
     */

    //public void setObjName(String newObjName) {
    //    objName = newObjName;
    //}


    /** 
     * Retrieves a collection of errors.
     */
    
    public Object getObjErrors() {
        return objErrors;
    }

    /** 
     * Sets objErrors .
     */
    
    public void setObjErrors(Object objErrors) {
        this.objErrors = objErrors;
    }



    /** 
     * Gets the value of objException. This attribute is used to store and propagate exceptions detected
     * while processing messages. The handleException method updates this attribute. 
     * Since handleError invokes handleException, it also updates this attribute.
     */

    public Object getObjException() {
        return objException;
    }

    /** 
     * Sets the value of objException. This attribute is used to store and propagate exceptions detected
     * while processing messages. The handleException method updates this attribute.
     * Since handleError invokes handleException, it also updates this attribute.
     */

    public void setObjException(Object newObjException) {
        objException = newObjException;
    }


    // Session

    /*
   public Object getObjSession() {
    return objSession;
   }
     */

    /*
   public void setObjSession(Object newObjSession) {

    //handleTrace ("JtObject.setObjSession:" + newObjSession);
    objSession = newObjSession;
   }
     */

    /**
     * Returns the component id.
     */
    
    public Object getComponentId() {
		return componentId;
	}
    
    /**
     * Specifies the component id.
     */

	public void setComponentId(Object componentId) {
		this.componentId = componentId;
	}

	public String toString () {


        //if (this.objName != null) {
        	
        //	return (this.objName); // returns the component name
        //}    
    	
        if (this.componentId != null) {
        	if (this.componentId instanceof String) 
        		return ((String) this.componentId);
    	
        	return ((this.componentId).toString());
        } 
    	
        return (super.toString());

    }

    /**
     * Demonstrates the messages processed by JtObject
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        String tmp;

        // Create the object

        msg = (JtMessage) main.createObject (JtMessage.JtCLASS_NAME, "message");



        if (msg != null)
            System.out.println ("Jt.createObject: GO");
        else
            System.out.println ("Jt.createObject: FAILED");

        // Set Value

        main.setValue ("message", "msgId", "JtTestId");

        if (msg.getMsgId () != null)
            if (msg.getMsgId().equals ("JtTestId"))
                System.out.println  ("Jt.setValue: GO");
            else
                System.out.println  ("Jt.setValue: FAILED");
        else
            System.out.println  ("Jt.setValue: FAILED");



        // Get value

        tmp = (String) main.getValue ("message", "msgId");

        if (tmp != null)
            if (tmp.equals ("JtTestId"))
                System.out.println  ("Jt.getValue: GO");
            else
                System.out.println  ("Jt.getValue: FAILED");
        else
            System.out.println  ("Jt.getValue: FAILED");

        main.removeObject ("message");

        /*
        if (main.lookupObject ("message") == null) {
            System.out.println  ("Jt.removeObject: GO"); 
        } else
            System.out.println  ("Jt.removeObject: FAILED"); 

         */


        // handleWarning

        //main.handleError ("JtObject: this is a warning");
        //main.setLogLevel(1);
        //main.handleTrace ("JtObject: this is a trace");
        //main.handleException (new Exception ("JtObject: this is a ex"));



        //JtObject obj = (JtObject) main.createObject (JtObject.JtCLASS_NAME); 


        //System.out.println (main.getValue (obj, "logging"));   


        //main.sendMessage(obj, new JtMessage (JtObject.JtRESET_FRAMEWORK));

    }
}
