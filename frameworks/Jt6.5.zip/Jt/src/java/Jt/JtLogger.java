
package Jt;

import java.io.*;
import java.util.*;
import java.text.*;



/**
 * Provides logging capabilities for a messaging framework.
 */


public class JtLogger extends JtObject {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtLogger.class.getName();
	public static final String DATE_FORMAT = "HH:mm:ss MM/dd/yyyy"; // Date format

	// Messages


	public static String JtENABLE_LOGGING = "JtENABLE_LOGGING";
	public static String JtDISABLE_LOGGING = "JtDISABLE_LOGGING";


	// Logging constants

	public static int JtDEFAULT_LOG_LEVEL = 3;          // Default Logging level
	public static int JtMIN_LOG_LEVEL = 0;              // Minimum Logging level
	public static int JtMAX_LOG_LEVEL = 100;            // this level is always logged



	// Context attributes


	private boolean logging = false;                      // is logging enabled?
	private String logFile = null;                        // Log file  
	private int logLevel = JtLogger.JtDEFAULT_LOG_LEVEL;  // Log level
	private PrintWriter logStream = null;




	public JtLogger () {


	} 



	/**
	 * Process a Message.  
	 * <li>Log a message (if the input message is an instance of JtLogEntry).
	 */


	public Object processMessage (Object message) {

		String msgid;
		JtMessage msg;
		//Object content;
		//JtMessage aux;
		JtLogEntry entry;


		if (message == null)
			return (null);
		
		if (message instanceof JtLogEntry) {
			entry = (JtLogEntry) message;
			log (entry.getMsg(), entry.getLevel());
			return (null);
		}
		msg = (JtMessage) message;

		msgid = (String) msg.getMsgId ();

		if (msgid == null)
			return (null);



		if (msgid.equals (JtLogger.JtENABLE_LOGGING)) {
			enableLogging ((String) msg.getMsgContent());
			return (null);
		}

		if (msgid.equals (JtLogger.JtDISABLE_LOGGING)) {
			disableLogging ();
			return (null);
		}
		
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);  // Nothing needs to be done   
        }

		handleError ("processMessage: invalid msg ID:"
				+ msg.getMsgId ());
		return (null);
	}

	// Enable logging

	private void enableLogging (String newLogFile) {
		if (newLogFile != null)
			logFile = newLogFile;
		else {
			if (logFile == null)
				logFile = "stderr";
		}

		logging = true;


		if (logStream != null)
			logStream.close();

		openLogFile (); // check - old Stream

	}

	// Disable logging

	private void disableLogging () {


		logging = false;


		if (logStream != null) {
			logStream.flush();
			logStream.close();
			logStream = null;
		}

	}

	// Open log file

	private void openLogFile () {  
		FileOutputStream fs;

		if (logFile == null || logFile.equals (""))
			return;

		if (logFile.equals ("stderr")) { // stderr
			logStream = null;
			return;
		}

		try {
			fs = new FileOutputStream (logFile);
			logStream = new PrintWriter (fs); 
		} catch (Exception e) {
			logStream = null;
			handleException (e);
			return;
		}

		handleTrace ("JtObject.openLogFile: opened log file ... " +
				logFile);

	}






	// Log a message

	private void log (String msg, int level) {
		Date date;
		SimpleDateFormat formatter;

		//if (objTrace <= 0)
		//    return;

		if (level != JtLogger.JtMAX_LOG_LEVEL) {
			if (!logging)
				return;

			if (level < logLevel)
				return;
		}

		date = new Date ();
		formatter = new SimpleDateFormat(JtLogger.DATE_FORMAT);

		if (logStream == null) {
			System.err.println (formatter.format(date) + ":" + msg);
			return;
		}

		logStream.println (formatter.format(date) + ":" + msg);
		logStream.flush ();

	}






	/** 
	 * Gets the name of the file used for logging purposes (logFile).
	 */


	public String getLogFile() {
		return logFile;
	}


	/** 
	 * Specifies the file to be used for logging purposes (logFile).
	 * @param newLogFile name of the log file
	 */

	public void setLogFile(String newLogFile) {


		if (newLogFile != null && logFile != null)
			if (newLogFile.equals(logFile))
				return;

		logFile = newLogFile;

		logging = true;

		if (logFile != null)
			openLogFile ();

	}

	/** 
	 * Returns the logging flag.
	 */

	public boolean getLogging() {
		return logging;
	}

	/** 
	 * Specifies whether or not logging is enabled.
	 * @param logging
	 */

	public void setLogging(boolean logging) {
		this.logging = logging;
	}

	/** 
	 * Returns the logging level.
	 */

	public int getLogLevel() {
		return logLevel;
	}

	/** 
	 * Specifies the logging level.
	 * @param logLevel
	 */

	public void setLogLevel(int logLevel) {
		this.logLevel = logLevel;
	}
	
	/**
	 * Demonstrates the messages processed by this component.
	 */

	public static void main(String[] args) {

		JtLogger logger = new JtLogger (); 
		JtLogEntry entry = new JtLogEntry ("log entry", JtLogger.JtDEFAULT_LOG_LEVEL);
		logger.setLogging(true);


		logger.processMessage (entry);


	}

}
