
package Jt;
import java.io.*;


/**
 * Handles input streams (reading, closing, etc). It can read one buffer at a time or all the data
 * in the input stream.
 */


public class JtInputStream extends JtObject {


    private static final long serialVersionUID = 1L;
    private InputStream inputStream = null;
    private byte[] buffer;
    public final static int BUFFER_SIZE = 1024;  // Buffer size (read_file)
    public final static int MAX_LENGTH = 1024 * 3000;  // Max length
    int bufferSize = BUFFER_SIZE;
    public static final String JtCLASS_NAME = JtInputStream.class.getName(); 
    public final static String JtREAD = "JtREAD";   
    public final static String JtCLOSE = "JtCLOSE";  
    public final static String JtOPEN = "JtOPEN";  
    public final static String JtREAD_BUFFER = "JtREAD_BUFFER";  
    public final static String JtREAD_STREAM = "JtREAD_STREAM"; 
    public final static String JtDATA_BUFFER = "JtDATA_BUFFER";
    private boolean readStream = false; 
    private JtFactory factory = new JtFactory ();
    private long maxLength = MAX_LENGTH;
    private long count = 0L;



    public JtInputStream() {
    }

    /**
     * Specifies the input stream.
     * @param inputStream input stream
     */

    public void setInputStream(Object inputStream) {
        this.inputStream = (InputStream) inputStream;
    }

    /**
     * Returns the input stream.
     */

    public Object getInputStream() {
        return inputStream;
    }



    /**
     * Return the buffer size.
     */

    public int getBufferSize () {
        return bufferSize;
    }

    /**
     * Sets the buffer size. The default value for this attribute is 1024.
     * @param bufferSize buffer size
     */

    public void setBufferSize (int bufferSize) {
        this.bufferSize = bufferSize;

    }

    /**
     * Return the max length. Trying to read an input stream bigger than
     * maxLength will fail. An error will be produced (handleError).  
     * maxLength only applies to JtREAD_STREAM.
     */

    public long getMaxLength() {
        return maxLength;
    }

    /**
     * Sets the max length. 
     * @param maxLength Max length
     */

    public void setMaxLength(long maxLength) {
        this.maxLength = maxLength;
    }


    byte [] getBuffer ()
    {
        return (buffer);
    }


    // read from input stream

    private String readStream (Object reply_to)
    {
        InputStream istream;
        int len, i;
        JtMessage msg;
        JtBuffer buff = new JtBuffer ();
        StringBuffer sbuffer = null;
        long count = 0L;


        if (inputStream == null) {
            handleError ("attribute inputStream needs to be set.");
            return null;
        }    

        istream = inputStream;

        byte buf [] = new byte [bufferSize];

        byte[] buffer1;

        try {
            //istream = new FileInputStream (name);

            handleTrace ("readStream:available:" +
                    istream.available ());

            while ((len = istream.read (buf, 0, bufferSize)) > 0) 
            {

                handleTrace ("readStream:" + len);
                buffer1 = new byte [len];

                i = 0;
                while (i < len) {
                    buffer1[i] = buf[i];
                    i++;
                }

               
                buff.setBuffer (buffer1);

                msg = new JtMessage ();
                msg.setMsgId (JtInputStream.JtDATA_BUFFER);
                msg.setMsgContent (buff);

                // send messages to the reply_to object

                if (reply_to != null)
                    factory.sendMessage (reply_to, msg);

                if (readStream) {
                    
                    count += len;
                    
                    if (count > maxLength) {
                        handleError ("maxLenth exceeded:" + maxLength);
                        return (null);
                    }
                        
                    if (sbuffer == null)
                        sbuffer = new StringBuffer ();

                    sbuffer.append(new String (buffer1));
                }
            }

            // istream.close (); check

        } catch (Exception e) {
            handleException (e);
            return (null);
        }


        /*
    handleTrace ("read_file:");
    for (i = 0; i < offset; i++)
      System.out.print (new Character ((char) buffer[i]));
         */
        return (sbuffer!=null?sbuffer.toString():null);
    }



    private byte[] readBuffer ()
    {
        InputStream istream;
        int len, i;


        if (inputStream == null) {
            handleError ("attribute inputStream needs to be set.");
            return null;
        }    

        istream = inputStream;

        byte buf [] = new byte [bufferSize];

        byte[] buffer1 = null;

        try {

            handleTrace ("JtInputStream.readBuffer:available:" +
                    istream.available (), 0);

            if ((len = istream.read (buf, 0, bufferSize)) > 0) 
            {

                handleTrace ("JtInputStream.readBuffer:" + len, 0);
                buffer1 = new byte [len];

                i = 0;
                while (i < len) {
                    buffer1[i] = buf[i];
                    i++;
                }


                if (readStream) {
                    
                    count += len;
                    
                    if (count > maxLength) {
                        handleError ("maxLenth exceeded:" + maxLength);
                        return (null);
                    }
                        
                }
            }


        } catch (Exception e) {
            handleException (e);
            return (null);
        }

        if (len <= 0) {
            handleTrace ("Closing input stream.");
            closeStream ();
        }    

        return (buffer1);
    }

    // close operation

    void closeStream () {

        if (inputStream == null)
            return;

        try {
            inputStream.close ();
            inputStream = null; // check
        } catch (Exception e) {
            handleException (e);
        }
    }


    /**
     * Process object messages.
     * <ul>
     * <li> JtREAD_BUFFER - Reads a buffer of bytes (bytes[]) from the input stream. 
     * bufferSize specifies the size of the buffer. Closes the input stream after
     * all the data (last buffer) has been read from the input stream. 
     * <li> JtCLOSE - Closes the input stream. 
     * <li> JtREAD_STREAM - Reads the input stream. Converts the input (byte[]) to String
     * and closes the stream.  
     * <li> JtREAD - This message is being deprecated (use JtREAD_BUFFER).
     * Reads from the input stream, one buffer of data at a time. 
     * Each buffer is sent to the object specified by msgReplyTo (JtMessage). 
     * </ul>
     * @param message Jt Message
     */
 
    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object reply_to;
        String content = null;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        if (msgid.equals (JtInputStream.JtREAD)) {
            reply_to = (Object) e.getMsgReplyTo ();

            readStream (reply_to);
            return (null);
        }
        
        if (msgid.equals (JtInputStream.JtREAD_BUFFER)) {

            return (readBuffer ());
        }

        if (msgid.equals (JtInputStream.JtREAD_STREAM)) {

            readStream = true;
            content = readStream (null);

            closeStream ();
            return (content);
        }

        if (msgid.equals (JtInputStream.JtCLOSE) || msgid.equals (JtObject.JtREMOVE)) {
            closeStream ();
            return (null);
        }

        return (super.processMessage(message));

    }


    /**
     * Demonstrates the messages processed by JtInputStream.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        FileInputStream istream = null;
        JtObject f;
        byte[] buffer;

        try {
            istream = new FileInputStream ("/tmp/test.txt"); // this file needs to exist.
        } catch (Exception e) {
            e.printStackTrace ();
        }

        //main.setLogFile ("log.txt");

        // Create JtInputStream using test.txt

        main.createObject (JtInputStream.JtCLASS_NAME, "istream");
        main.setValue ("istream", "inputStream", istream);
        main.setValue ("istream", "bufferSize", "1024");
        //main.setValue ("istream", "maxLength", "1001025");


        // Create output file (output)

        f = (JtObject) main.createObject (JtFile.JtCLASS_NAME, "file");
        main.setValue ("file", "name", "/tmp/output");

        main.sendMessage ("file", new JtMessage (JtFile.JtOPEN));

        // Read input stream, one buffer at a time. Send buffers to a file 

        //msg = new JtMessage (JtInputStream.JtREAD);
        msg = new JtMessage (JtInputStream.JtREAD_BUFFER);
        //msg.setMsgReplyTo (f);

        //System.out.println (main.sendMessage ("istream", new JtMessage (JtInputStream.JtREAD_STREAM)));
        
        while ((buffer = (byte[]) main.sendMessage ("istream", new JtMessage (JtInputStream.JtREAD_BUFFER)))
                != null) {

            msg = new JtMessage (JtFile.JtWRITE);
            msg.setMsgContent(buffer);
            main.sendMessage ("file", msg);
        }

        //main.sendMessage ("istream", msg);

        main.sendMessage ("file", new JtMessage (JtFile.JtCLOSE));

        //main.sendMessage ("istream", new JtMessage (JtInputStream.JtCLOSE));
        main.removeObject ("istream");



    }

}


