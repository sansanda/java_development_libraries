package Jt.util;

/**
 * Compares two objects
 */

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.examples.Test;

public class JtComparator extends JtObject {
    private static final long serialVersionUID = 1L;
    public JtHashTable parameters = null;
    
    


     public Object processMessage(Object message) {
        List list ;
        Object obj, obj1;
        Object objVal, objVal1;
        
        //String msgid;
        JtFactory factory = new JtFactory ();
        JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTE_TABLE);
        Hashtable table;
        Set set;
        Iterator it;
        String attrName;
        
        if (message == null) {
        	handleError ("invalid parameter:null");
        	return (new Boolean (false));
        }

        list = (List) message;

        if (list.size() < 2) {
        	handleError ("two objects are expected.");
        	return (new Boolean (false));
        }	
        
        obj = list.get(0);
        obj1 = list.get(1);
        
        if (obj.getClass() != obj1.getClass()) {
        	//handleError ("two objects are expected.");
        	return (new Boolean (false));
        }       	
        
        msg.setMsgContent(obj);
        table = (Hashtable) factory.processMessage(msg);
        if (table == null)
        	return (new Boolean (false));
        
        set = table.keySet();
        
        it = set.iterator();
        
        while (it.hasNext()) {
        	attrName = (String) it.next();
        	objVal = factory.getValue(obj, attrName);
        	objVal1 = factory.getValue(obj1, attrName);
        	
        	if (objVal == null && objVal1 == null)
        		continue;
        	if (objVal != null) 
        		if (!objVal.equals(objVal1)) 
        		{
        			handleTrace ("JtComparator (different):" + attrName, JtLogger.JtMIN_LOG_LEVEL);
                	return (new Boolean (false));
        		}	
        }
        
        return (new Boolean (true));
    }
    /**
     * Demonstrates the messages processed by this class.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        //JtMessage msg;
        //Object obj;
        Test test = new Test ();
        Test test1 = new Test ();      
        JtComparator comparator = new JtComparator ();
        ArrayList list = new ArrayList ();
        Boolean Reply;
        String str = "Hello World ..";
        
        
        //str.setString("action.do?");
        
        list.add(test);
        list.add(test1);   
        
        test.setComments("comments");
        
        test1.setComments("comments");

        
        Reply = (Boolean) factory.sendMessage(comparator, list);
        
        System.out.println("Comparator:" + Reply);

    }
}
