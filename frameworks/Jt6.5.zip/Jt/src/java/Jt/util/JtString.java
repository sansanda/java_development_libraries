/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt.util;


import java.net.URLDecoder;
import java.util.StringTokenizer;

import Jt.JtHashTable;
import Jt.JtMessage;
import Jt.JtObject;


/**
 * Handles Strings.
 */

public class JtString extends JtObject {
    private static final long serialVersionUID = 1L;
    public static final String JtGET_NEXT_TOKEN = "JtGET_NEXT_TOKEN";
    public JtHashTable parameters = null;
    private int index = 0;
    String reservedTokensTable[] = {"+", "-", "/", "*", "%", 
    		"==", "!=", "<=", ">=", ">", "<", "(", ")", 
    		"&&", "||", "!"};
    
    private String string;
    
	/**
	 * Retrieve the String.
	 */
    
    public String getString() {
        return string;
    }

	/**
	 * Sets the String.
	 */
    
    public void setString(String string) {
        this.string = string;
    }

    private void addToken (String token, String value) {
        JtMessage msg;
        String tmp = null;
        
        if (token == null || token.equals(""))
            return;
        if (value == null || value.equals(""))
            return;
        
        try {
            tmp =  URLDecoder.decode(value, "UTF-8");
        } catch (Exception ex) {
            handleException (ex);
            return;
        }
        //System.out.println("out:" + tmp);
        msg = new JtMessage (JtHashTable.JtPUT);
        msg.setMsgContent(tmp);
        msg.setMsgData(token);       
        
        parameters.processMessage(msg);
    }

    private JtHashTable decode () {
        StringTokenizer tokenizer;
        //StringTokenizer tokenizer1;
        String token;
        String tmp;
        int index;
        String parameter;

        if (string == null)
            return (null);
        
        parameters = new JtHashTable ();
        
        index = string.indexOf('?');
        
        if (index > 0) {
            tmp = string.substring(index+1);
        } else
            tmp = string;
        
        
        //System.out.println("out:" + tmp);
        
        tokenizer = new StringTokenizer (tmp, "&", false);
        
        
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken("&");
            //System.out.println(token);
            
            index = token.indexOf('=');
            
            if (index == -1) {
                handleError ("invalid URL string");
                continue;
            }
            
            parameter = token.substring(0, index); 
            addToken (parameter, token.substring(index+1));
                     
        }
        
        
        return (parameters);
    }
    
    
    private String getNumber (int startIndex) {
    	int i;
    	char c;
    	
    	if (startIndex < 0)
    		return (null);
    	
    	
    	for (i = startIndex + 1; i < string.length(); i++) {
    		
    		c = string.charAt(i);
    		
    		if (Character.isDigit(c) || c == '.')
    			continue;
    		return (string.substring(startIndex, i));    		
    			    			
    	}
    	
    	return (string.substring(startIndex));
    }
    
    
    private String getString (int startIndex) {
    	int i;
    	char c;
    	
    	if (startIndex < 0)
    		return (null);
    	
    	
    	for (i = startIndex + 1; i < string.length(); i++) {
    		
    		c = string.charAt(i);
    		
    		if (c == '"')
    			break;  		
    			    			
    	}
    	
    	if (i < string.length())
    		return (string.substring(startIndex, i + 1));
    	
    	handleError ("Invalid String:" + string.substring(startIndex));
    	
    	return (null);
    }
    
    private String getCharacter (int startIndex) {
    	int i;
    	char c;
    	
    	if (startIndex < 0)
    		return (null);
    	
    	
    	for (i = startIndex + 1; i < string.length(); i++) {
    		
    		c = string.charAt(i);
    		
    		if (c == '\'')
    			break;  		
    			    			
    	}
    	
    	if (i < string.length())
    		return (string.substring(startIndex, i + 1));
    	
    	handleError ("Invalid character format:" + string.substring(startIndex));
    	
    	return (null);
    }
    
    
    private String getIdentifier (int startIndex) {
    	int i;
    	char c;
    	
    	if (startIndex < 0)
    		return (null);
    	
    	
    	for (i = startIndex + 1; i < string.length(); i++) {
    		
    		c = string.charAt(i);
    		
    		if (Character.isJavaIdentifierPart(c) || c == '.')
    			continue;
    		return (string.substring(startIndex, i));    		
    			    			
    	}
    	
    	return (string.substring(startIndex));
    }
    
    
    private boolean compareRToken (String rToken) {
    
    	int i;
    	
    	if (string == null || rToken == null || index < 0)
    		return (false);
    	
    	if (string.length () - index < rToken.length())
    		return (false);
    	
    	for (i = 0; i < rToken.length (); i++) {
    		if (rToken.charAt(i) == string.charAt(index + i))
    			continue;
    		else
    			return (false);
    	}
    	return (true);
    }
    
    private String checkReservedTokens () {
    	int i;
    	
    	for (i = 0; i < reservedTokensTable.length; i++ ) {
    		
    		
    		if (compareRToken (reservedTokensTable[i]))
    				return (reservedTokensTable[i]);
    			
    	}
    	return (null);
    }
    
    private String getNextToken () {
    	char c;
    	int startIndex;
    	String token;
    	
    	if (string == null)
    		return (null);
    	
    	if (index >= string.length())
    		return (null);
    	
    	c = string.charAt(index);
    	
    	   	
    	while (Character.isWhitespace(c)) {
    	
    		index++;
    		
        	c = string.charAt(index);
    	}	
    	
    	startIndex = index;
    	
    	if (c == '"') {
    		token = getString (startIndex);
    		index = index + token.length();
    		return (token);    		
    	}
    	
    	
    	if (c == '\'') {
    		token = getCharacter (startIndex);
    		index = index + token.length();
    		return (token);    		
    	}
    	
    	if (Character.isDigit(c) || c == '.') {
    		token = getNumber (startIndex);
    		index = index + token.length();
    		return (token);
    	}
    	
    	if (Character.isJavaIdentifierPart(c)) {
    		token = getIdentifier (startIndex);
    		index = index + token.length();
    		return (token);   		
    	}
    	
    	token = checkReservedTokens ();
    	if (token != null)
    		index = index + token.length();  	
    	return (token);    	
    	
    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtGET_NEXT_TOKEN - Returns the next token found in the String.
     * </ul>
     */   
    public Object processMessage(Object event) {
        JtMessage e = (JtMessage) event;
        String msgid;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;



        if (msgid.equals (JtString.JtGET_NEXT_TOKEN))
            return (getNextToken ());
        
        return (super.processMessage(event));
    }
    
    /**
     * Demonstrates the messages processed by JtString.
     */

    public static void main(String[] args) {

        //JtObject factory = new JtFactory ();
        JtMessage msg;
        //List list
        JtString str = new JtString ();
        String token;
        
        str.setString("   ((-122.0 + 564) > 20) || ($obj.color > 20)");
        //str.setString("action.do?");
        
        token = (String) str.processMessage(new JtMessage (JtString.JtGET_NEXT_TOKEN));
        
        while (token != null) {
        	System.out.println("token:" + token);
            token = (String) str.processMessage(new JtMessage (JtString.JtGET_NEXT_TOKEN));

        }
  

    }
}
