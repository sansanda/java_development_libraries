package Jt.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.beans.PropertyDescriptor;

import Jt.*;

/**
 * Parse Java files
 */

public class JtJavaParser extends JtObject {
    public static final String JtCLASS_NAME = JtJavaParser.class.getName(); 
    public static final String PARSE = "PARSE";
    public static final String PARSE1 = "PARSE1";
    JtFactory factory = new JtFactory ();
    private String path;
    private String classPackage;
    private String className;
    
    
    int level = 0;
    List getters = new LinkedList ();
    //List properties;
    int index = 0;
    JtHashTable properties;
    LinkedList propertyList = new LinkedList ();
    //private boolean initted = false;
    private InputStream inputStream;
    private boolean commented = false; //
    private boolean commented1 = false;   
    


    private static final long serialVersionUID = 1L;


    public JtJavaParser() {
    }


    // Attributes

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public InputStream getInputStream() {
        return inputStream;
    }


    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }


    public String getClassName() {
        return className;
    }


    public void setClassName(String className) {
        this.className = className;
    }


    public String getClassPackage() {
        return classPackage;
    }


    public void setClassPackage(String classPackage) {
        this.classPackage = classPackage;
    }


    private String lowerFirstLetter (String str) {
        if (str == null)
            return (null);

        if (str.equals(""))
            return (str);

        if (str.length() == 1)
            return str.toLowerCase();

        return (str.substring(0, 1).toLowerCase() + str.substring(1));
    }



    private String getPropertyName (String getter) {
        String str;

        if (getter == null)
            return null;

        if (!getter.startsWith ("get") &&
                !getter.startsWith ("is"))
            return (null);

        if (getter.startsWith ("get"))
            str = getter.substring(3);
        else
            str = getter.substring(2);           

        return lowerFirstLetter (str);

    }

    private boolean isPrimitive (String token) {

        if (token == null)
            return (false);

        if (    token.equals ("byte") || 
                token.equals ("short")|| token.equals ("int")
                || token.equals ("long") || token.equals ("float")
                || token.equals ("double") || token.equals ("boolean") || 
                token.equals ("char"))
            return (true);

        return (false);
    }


    boolean checkType (String token) {
        //handleTrace ("checkType:" + token);
        if (token == null)
            return (false);

        if (token.equals ("java.lang.String") || 
                token.equals ("byte") || 
                token.equals ("short")|| token.equals ("int")
                || token.equals ("long") || token.equals ("float")
                || token.equals ("double") || token.equals ("boolean") || 
                token.equals ("char") || token.equals ("java.util.Date") || 
                token.equals("String") || token.equals ("Date"))
            return (true);

        return (false);
    }

    private int findPropertyDeclaration (List tokens, String propertyName) {
        int i = 0;
        String token;

        //handleTrace ("findPropertyDeclaration:" + propertyName);

        if (tokens == null || propertyName == null)
            return (-1);

        for (i = 0; i < tokens.size(); i++) {
            token = (String) tokens.get(i);
            if (!propertyName.equals(token))
                continue;

            if (i > 0 && checkType ((String) tokens.get(i - 1)))
                return (i);

        }

        return (-1);
    }

    void getSubTokens (List list, String token) {
        StringTokenizer tokenizer;
        String token1, token2;
        JtMessage msg = new JtMessage (JtHashTable.JtPUT);
        String propertyName;
        int i;
        //JtHashTable properties = new JtHashTable ();
        BeanProperty descriptor;

        if (token == null || list == null)
            return;

        tokenizer = new StringTokenizer (token, "(){},;\n", true);


        while (tokenizer.hasMoreTokens()) {
            token1 = (String) tokenizer.nextElement();            
            
            if (commented) {
                if (token1.equals("\n"))
                    commented = false;
                continue;
            } else if (commented1) {
                i = token1.indexOf("*/");

                if (i < 0)
                    continue;
                commented1 = false;
                token1 = token1.substring(i+2);   


            } 

            i = containComment (token1);

            if (i >= 0) {
                // ignore stuff after the comment 
                token1 = token.substring(0, i);             

            }

            if (token1.equals("{"))
                level++;

            if (token1.equals("}"))
                level--;
            
            if (token1.equals("\n") || token1.equals("")) 
                continue;
            

            list.add (token1);
            index++;

            if (level > 1) {
                continue;
            }
            
            //handleTrace ("adding token:" + token1);

            if (token1.startsWith("get") || token1.startsWith("is")) {

                if (index < 2)
                    continue;

                token2 = (String) list.get(index - 2);

                if (!checkType (token2))
                    continue;


                propertyName = getPropertyName (token1);

                if (findPropertyDeclaration (list, propertyName) < 0)
                    continue;

                msg.setMsgData (propertyName);
                
                descriptor = new BeanProperty ();
                //msg.setMsgContent (token2);
                //System.out.println (token2 + " " + propertyName);

                descriptor.setType(token2);
                descriptor.setPrimitive(isPrimitive (token2));
                descriptor.setName(propertyName);
                msg.setMsgContent (descriptor);
                factory.sendMessage(properties, msg);
                
                propertyList.add(descriptor);
            }

        }    



    }
    
    private void retrieveBeanInfo (List tokens) {
        int i;
        String token;

        classPackage = "";
        className = "";
        
        if (tokens == null)
            return;
        
        for (i = 0; i < tokens.size(); i++) {
            token = (String) tokens.get(i);
 /*           
            if ("{".equals(token)) {
                handleError ("invalid Java class format");
                return;
            }
*/            
            if ("package".equals(token)) {
                if (i < tokens.size() - 1)
                    classPackage = (String) tokens.get(i+1);
                
            }
            

            
            
            if ("class".equals(token)) {
                if (i < tokens.size() - 1)
                    className = (String) tokens.get(i+1);
                return;
            }          
                
        }
        
    }

    private int containComment (String token) {
        int index;
        char c;
        
        commented = false;
        commented1 = false;
        
        if (token == null || token.equals(""))
            return -1;
        index = token.indexOf('/');
        
        if (index < 0)
            return index;
        
        if (index == token.length() - 1)
            return -1;
        
        c = token.charAt(index + 1);
        
        if (c == '/') {
            commented = true;
            return (index);
        }    
        
        if (c == '*') {
            commented1 = true;
            return (index);
        }    
        
        return (containComment (token.substring(index + 1)));
        
    }
    
    String removeComments (String content) {
        
        StringBuffer sbuffer = new StringBuffer ();
        int index = 0;
        int i;
        
        if (content == null)
            return (null);
        
        while ( index < content.length()) {
            
            i = content.indexOf('/', index);
            
            if (i < 0) {
                sbuffer.append(content.substring(index));
                break;
            }
            
            if (i == content.length() - 1) {
                sbuffer.append(content.substring(index));
                break;
            }

            
        }
        return sbuffer.toString();
        
    }
    
    private LinkedList newParseJavaFile () {
        String content;
        StringTokenizer tokenizer;
        List tokens = new LinkedList ();
        String token;
        JtInputStream jStream = new JtInputStream ();

        if (inputStream == null) {
            handleError ("attribute inputStream needs to be set");
            return null;           
        }
        properties = new JtHashTable ();   
        
        jStream.setInputStream(inputStream);
        
        content = (String) factory.sendMessage (jStream, new JtMessage (JtInputStream.JtREAD_STREAM));
        

        if (content == null)
            return null;

        tokenizer = new StringTokenizer (content, " \t\r\f");

        if (tokenizer == null)
            return null;

        while (tokenizer.hasMoreTokens()) {
            token = (String) tokenizer.nextElement();
            getSubTokens (tokens, token);

        }    
        
        retrieveBeanInfo (tokens);
        

        return (propertyList);                    

    }
    
    private JtHashTable parseJavaFile () {
        JtFile file = new JtFile ();
        String content;
        StringTokenizer tokenizer;
        List tokens = new LinkedList ();
        String token;
        String token1;
        //int level;
        JtMessage msg = new JtMessage (JtHashTable.JtPUT);
        JtInputStream jStream = new JtInputStream ();
        int index;

        if (inputStream == null) {
            handleError ("attribute inputStream needs to be set");
            return null;           
        }
        properties = new JtHashTable ();   
        
        jStream.setInputStream(inputStream);
        
        content = (String) factory.sendMessage (jStream, new JtMessage (JtInputStream.JtREAD_STREAM));
        
/*        
        if (path == null) {
            handleError ("attribute path needs to be set");
            return null;
        }    

        properties = new JtHashTable ();

        file.setName (path);

        content = (String) factory.sendMessage(file, new JtMessage (JtFile.JtCONVERT_TO_STRING));
*/
        if (content == null)
            return null;

        tokenizer = new StringTokenizer (content, " \t\r\f");

        if (tokenizer == null)
            return null;

        while (tokenizer.hasMoreTokens()) {
            token = (String) tokenizer.nextElement();
            getSubTokens (tokens, token);

            /*
            if ((index = containComment (token)) < 0) {
                getSubTokens (tokens, token);
                continue;
            } else
                getSubTokens (tokens, token.substring(0, index));               
            
            if (token.charAt(index+1) == '/') {
                if (tokenizer.hasMoreTokens())
                    token = (String) tokenizer.nextToken("\n");
            }
            */

        }    
        
        retrieveBeanInfo (tokens);
        

        return (properties);                    

    }

    // Process object messages

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;


        if (msg == null)
            return null;

        msgid = (String) msg.getMsgId ();

        if (msgid == null)
            return null;

        if (msgid.equals (JtJavaParser.PARSE1)) {
            //initted = true;
            return (newParseJavaFile ());

        }
        
        
        // This message is being deprecated (a list should be returned)
        if (msgid.equals (JtJavaParser.PARSE)) {
            //initted = true;
            return (parseJavaFile ());

        }

        // Let the superclass handle all other messages
        return (super.processMessage (message));

    }



    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();  // Jt Factory
        JtJavaParser parser = new JtJavaParser (); 
        File file = new File ("/projects/contract/DAOMember.java");
        


        JtMessage msg = new JtMessage (JtJavaParser.PARSE);

        // Send the Message

        //parser.setPath("/projects/contract/DAOMember.java");
        try {
            parser.setInputStream(new FileInputStream (file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        factory.handleTrace ("main:sending a message (JtHello) to the helloWorld object ...");
        factory.sendMessage (parser, msg);
        
        System.out.println ("classname:" + parser.getClassName());
        System.out.println ("package:" + parser.getClassPackage());

    }

}



