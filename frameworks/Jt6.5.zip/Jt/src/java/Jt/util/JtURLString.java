package Jt.util;


import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.StringTokenizer;

import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtMessage;
import Jt.JtObject;

public class JtURLString extends JtObject {
    private static final long serialVersionUID = 1L;
    public static final String JtURL_DECODE = "JtURL_DECODE";
    public JtHashTable parameters = null;
    
    private String string;
    

    public String getString() {
        return string;
    }


    public void setString(String string) {
        this.string = string;
    }

    private void addToken (String token, String value) {
        JtMessage msg;
        String tmp = null;
        
        if (token == null || token.equals(""))
            return;
        if (value == null || value.equals(""))
            return;
        
        try {
            tmp =  URLDecoder.decode(value, "UTF-8");
        } catch (Exception ex) {
            handleException (ex);
            return;
        }
        //System.out.println("out:" + tmp);
        msg = new JtMessage (JtHashTable.JtPUT);
        msg.setMsgContent(tmp);
        msg.setMsgData(token);       
        
        parameters.processMessage(msg);
    }

    private JtHashTable decode () {
        StringTokenizer tokenizer;
        //StringTokenizer tokenizer1;
        String token;
        String tmp;
        int index;
        String parameter;

        if (string == null)
            return (null);
        
        parameters = new JtHashTable ();
        
        index = string.indexOf('?');
        
        if (index > 0) {
            tmp = string.substring(index+1);
        } else
            tmp = string;
        
        
        //System.out.println("out:" + tmp);
        
        tokenizer = new StringTokenizer (tmp, "&", false);
        
        
        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken("&");
            System.out.println(token);
            
            index = token.indexOf('=');
            
            if (index == -1) {
                handleError ("invalid URL string");
                continue;
            }
            
            parameter = token.substring(0, index); 
            addToken (parameter, token.substring(index+1));
                     
        }
        
        
        return (parameters);
    }
    public Object processMessage(Object event) {
        JtMessage e = (JtMessage) event;
        Object obj;
        String msgid;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;



        if (msgid.equals (JtURLString.JtURL_DECODE))
            return (decode ());
        
        return (super.processMessage(event));
    }
    /**
     * Demonstrates the messages processed by this class.
     */

    public static void main(String[] args) {

        JtObject factory = new JtFactory ();
        JtMessage msg;
        //List list;
        Object obj;
        JtURLString str = new JtURLString ();
        
        str.setString("Jt.examples.struts.CRUD?classname=Jt.examples.hibernate.Member&key=email&query=select+*+from+roster");
        //str.setString("action.do?");
        
        str.processMessage(new JtMessage (JtURLString.JtURL_DECODE));
        

    }
}
