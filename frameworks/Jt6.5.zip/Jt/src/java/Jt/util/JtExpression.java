/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.util;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Stack;

import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.examples.HelloWorldMessage;
import Jt.examples.Test;

/**
 * Handles and evaluates expressions. Implements the Shunting yard algorithm.
 * Early version 0.5. Issue around Unary -.
 */

public class JtExpression extends JtObject {
    private static final long serialVersionUID = 1L;
    public static final String POSTFIX = "POSTFIX";
    public static final String EVALUATE = "EVALUATE";
    public static final String ADD_VARIABLE = "ADD_VARIABLE";
    public static final String RETRIEVE_VARIABLES = "RETRIEVE_VARIABLES";
    
    public static final String ADDITION = "+";
    public static final String SUBSTRACTION = "-";    
    public static final String MULTIPLICATION = "*";  
    public static final String DIVISION = "/";   
    public static final String MODULUS = "%";
    
    public HashMap variableTable = new HashMap ();
    
    public JtHashTable parameters = null;

    private String reservedTokensTable[][] = {
    		{"&&", "3"}, {"||", "2"},    	
    		{"==", "4"}, {"!=", "4"},
    		{"<", "5"}, {">", "5"}, {"<=", "5"}, {">=", "5"}, 
    		{"+", "6"}, {"-", "6"}, 
    		{"*", "7"},{"/", "7"}, {"%", "7"},
    		{"!", "9"}       		
    
    };
    
    private Stack operatorStack = new Stack ();
    private Hashtable precedenceTable;
    private boolean initialized = false;    
    private String string;
    private String postfix;
    
	/**
	 * Returns the String representation.
	 */
    public String getString() {
        return string;
    }

	/**
	 * Sets the String representation of the expression.
	 */
    
    public void setString(String string) {
        this.string = string;
    }



	private int stringToInt (String sPriority) {

		if (sPriority == null)
			return (0);

		try {
			return (Integer.parseInt(sPriority));
		}catch (Exception ex) {
			return (-1);
		}


	}

   private boolean initialize () {
	   int i;
	   String operator;
	   int precedence;
	   
	   precedenceTable = new Hashtable ();
	   	   
	   for (i = 0; i < reservedTokensTable.length; i++ ) {

		   operator = reservedTokensTable[i][0];

		   //System.out.println("priority:" + reservedTokensTable[i][1]);
		   precedence = stringToInt (reservedTokensTable[i][1]);

		   if (precedence > 0)
			   precedenceTable.put(operator, new Integer (precedence));

	   }	
	   
	   return (true);
   }
   
   private int retrieveOperatorPriority (String token) {

	   Integer tmp;
	   
	   if (token == null)
		   return (-1);

	   tmp = (Integer) precedenceTable.get(token);
	   return (tmp != null ? tmp.intValue(): -1);

   }

   private boolean isOperand (String token) {
	   
	   if (token == null)
		   return (false);
	   
	   if (token.equals("(") || token.equals(")")) 
		   return false;		  	   
	   
	   if (precedenceTable.get (token) != null)
		   return (false);
		   
	   return (true);
   }
   
   private Boolean evaluateLogicalOperation (String operation, 
   Object operand1, Object operand2) {
	   boolean bool1;
	   boolean bool2;
	   
	   if (operation == null || operand1 == null || 
			   operand2 == null)
		   return (null);	
	   
	   
	   if (!(operand1 instanceof Boolean)) {
		   handleError ("Invalid type (boolean expected):" + operand1);
		   return (null);
	   }
	   
	   if (!(operand2 instanceof Boolean)) {
		   handleError ("Invalid type (boolean expected):" + operand2);
		   return (null);
	   }
	   
	   bool1 = ((Boolean) operand1).booleanValue();
	   bool2 = ((Boolean) operand1).booleanValue();
	   
	   if (operation.equals("&&"))
		   return (new Boolean (bool1 && bool2));		   

	   
	   if (operation.equals("||"))
		   return (new Boolean (bool1 || bool2));	
	   
	   handleError ("Invalid operation:" + operation);
	   
	   return (null);
   }
   
   private Boolean evaluateUnaryLogicalOperation (String operation, 
		   Object operand1) {
	   boolean bool1;

	   if (operation == null || operand1 == null)
		   return (null);	


	   if (!(operand1 instanceof Boolean)) {
		   handleError ("Invalid type (boolean expected):" + operand1);
		   return (null);
	   }

	   bool1 = ((Boolean) operand1).booleanValue();

	   if (operation.equals("!"))
		   return (new Boolean (!bool1));		   

	   handleError ("Invalid operation:" + operation);
	   return (null);
   }
   
   private Object evaluateUnaryMinus (String operation, 
		   Object operand) {
	   boolean bool1;

	   if (operation == null || operand == null)
		   return (null);	


	   if ((operand instanceof Integer)) {
		   
		   
		   return (new Integer (-((Integer) operand).intValue()));
	   }
	   

	   handleError ("Invalid operand:" + operand);
	   return (null);
   }


   private Boolean lessOrEqualThan (Object op1, Object op2) {
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() <= ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return ( new Boolean ( ((String) op1).compareTo((String) op2) <= 0 ) );		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() <= ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() <= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() <= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() <= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() <= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() <= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() <= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() <= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() <= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() <= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() <= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() <= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() <= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() <= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() <= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() <= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() <= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() <= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() <= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() <= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() <= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() <= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() <= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() <= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() <= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
	   
   }
   
   
   
   private Boolean lessThan (Object op1, Object op2) {
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() < ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return ( new Boolean ( ((String) op1).compareTo((String) op2) < 0 ) );		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() < ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() < ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() < ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() < ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() < ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() < ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() < ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() < ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() < ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() < ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() < ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() < ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() < ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() < ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() < ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() < ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() < ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() < ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() < ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() < ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() < ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() < ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() < ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() < ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() < ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
	   
   }
   
   
   private Boolean greaterOrEqualThan (Object op1, Object op2) {
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return ( new Boolean ( ((String) op1).compareTo((String) op2) >= 0 ) );		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() >= ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() >= ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() >= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() >= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() >= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() >= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() >= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() >= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() >= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() >= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() >= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() >= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() >= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() >= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() >= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() >= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() >= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() >= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() >= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() >= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() >= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() >= ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() >= ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() >= ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() >= ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() >= ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
	   
   }   
   
   
   private Boolean greaterThan (Object op1, Object op2) {
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() > ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return ( new Boolean ( ((String) op1).compareTo((String) op2) > 0 ) );		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() > ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() > ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() > ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() > ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() > ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() > ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() > ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() > ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() > ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() > ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() > ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() > ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() > ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() > ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() > ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() > ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() > ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() > ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() > ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() > ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() > ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() > ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() > ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() > ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() > ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
	   
   }  
   
   
   private Boolean equal (Object op1, Object op2) {
	   
	   
	   if (op1 instanceof String && op1.equals("null")) 
		   op1 = null;
	   
	   if (op2 instanceof String && op2.equals("null")) 
		   op2 = null;	   

	   
	   if (op1 == null || op2 == null) {
		   return (new Boolean (op1 == op2));
	   }
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() == ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return (new Boolean (op1.equals(op2)));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() == ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() == ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() == ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() == ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() == ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() == ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() == ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() == ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() == ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() == ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() == ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() == ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() == ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() == ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() == ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() == ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() == ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() == ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() == ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() == ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() == ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() == ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() == ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() == ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() == ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   //handleError ("Invalid operand:" + op1.getClass().getName());
	   return (new Boolean (op1 == op2));
	   //return (null);
	   
   }  
   
   
   private Boolean distint (Object op1, Object op2) {
	   //if (op1 == null || op2 == null)
	   //	   return (null);
	   
	   if (op1 instanceof String && op1.equals("null")) 
		   op1 = null;
	   
	   if (op2 instanceof String && op2.equals("null")) 
		   op2 = null;	   

	   
	   if (op1 == null || op2 == null) {
		   return (new Boolean (op1 != op2));
	   }
	   
	   
	   if (op1 instanceof Character) { 
		   if (op2 instanceof Character) 
			   return (new Boolean (((Character) op1).charValue() != ((Character) op2).charValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof String) { 
		   if (op2 instanceof String) 
			   return (new Boolean (!op1.equals(op2)));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean ((((Short) op1).shortValue() != ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Short) op1).shortValue() != ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Short) op1).shortValue() != ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Short) op1).shortValue() != ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Short) op1).shortValue() != ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Long) op1).longValue() != ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Long) op1).longValue() != ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Long) op1).longValue() != ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Long) op1).longValue() != ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Long) op1).longValue() != ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Integer) op1).intValue() != ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Integer) op1).intValue() != ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Integer) op1).intValue() != ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Integer) op1).intValue() != ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Integer) op1).intValue() != ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Float) op1).floatValue() != ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Float) op1).floatValue() != ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Float) op1).floatValue() != ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Float) op1).floatValue() != ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Float) op1).floatValue() != ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Boolean (((Double) op1).doubleValue() != ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Boolean (((Double) op1).doubleValue() != ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Boolean (((Double) op1).doubleValue() != ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Boolean (((Double) op1).doubleValue() != ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Boolean (((Double) op1).doubleValue() != ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   //handleError ("Invalid operand:" + op1.getClass().getName());
	   return (new Boolean (op1 != op2));
	   
   }  

   
   private Boolean evaluateRelationalOperation (String operation, 
		   Object operand1, Object operand2) {
	   //if (operation == null || operand1 == null || 
	   //		   operand2 == null)
	   if (operation == null)
		   return (null);	   

	   if (operation.equals("<"))
		   return (lessThan (operand1, operand2));
	   
	   if (operation.equals("<="))		   
		   return (lessOrEqualThan (operand1, operand2));
	   
	   if (operation.equals(">"))
		   return (greaterThan (operand1, operand2));
	   
	   if (operation.equals(">="))		   
		   return (greaterOrEqualThan (operand1, operand2));
		   
	   if (operation.equals("=="))
		   return (equal (operand1, operand2));		   	
	   
	   if (operation.equals("!=")) 
		   return (distint (operand1, operand2));	
	   
	   handleError ("Invalid operation:" + operation);
	   return (null);
   }
   
 
   

   
   private Object addition (Object op1, Object op2) {
	   
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   
	   if (op1 instanceof String || op2 instanceof String) { 

		   if (op1 instanceof String)
			   return ((String) op1 + op2);
		   
		   if (op2 instanceof String)
			   return (op1 + (String) op2);		   
	   }
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Short ((short) (((Short) op1).shortValue() + ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Short) op1).shortValue() + ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Short) op1).shortValue() + ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Short) op1).shortValue() + ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Short) op1).shortValue() + ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Long (((Long) op1).longValue() + ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Long (((Long) op1).longValue() + ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Long) op1).longValue() + ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Long) op1).longValue() + ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Long) op1).longValue() + ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Integer (((Integer) op1).intValue() + ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Integer) op1).intValue() + ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Integer) op1).intValue() + ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Integer) op1).intValue() + ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Integer) op1).intValue() + ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Float (((Float) op1).floatValue() + ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Float (((Float) op1).floatValue() + ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Float (((Float) op1).floatValue() + ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Float) op1).floatValue() + ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Float) op1).floatValue() + ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Double (((Double) op1).doubleValue() + ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Double (((Double) op1).doubleValue() + ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Double (((Double) op1).doubleValue() + ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Double (((Double) op1).doubleValue() + ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Double) op1).doubleValue() + ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
   }
   
   
   private Object substraction (Object op1, Object op2) {
	   
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Short ((short) (((Short) op1).shortValue() - ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Short) op1).shortValue() - ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Short) op1).shortValue() - ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Short) op1).shortValue() - ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Short) op1).shortValue() - ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Integer (((Integer) op1).intValue() - ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Integer) op1).intValue() - ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Integer) op1).intValue() - ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Integer) op1).intValue() - ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Integer) op1).intValue() - ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Long (((Long) op1).intValue() - ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Long (((Long) op1).intValue() - ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Long) op1).intValue() - ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Long) op1).intValue() - ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Long) op1).intValue() - ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Float (((Float) op1).floatValue() - ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Float (((Float) op1).floatValue() - ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Float (((Float) op1).floatValue() - ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Float) op1).floatValue() - ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Float) op1).floatValue() - ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Double (((Double) op1).doubleValue() - ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Double (((Double) op1).doubleValue() - ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Double (((Double) op1).doubleValue() - ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Double (((Double) op1).doubleValue() - ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Double) op1).doubleValue() - ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
   }

   private Object multiplication (Object op1, Object op2) {
	   
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Short ((short) (((Short) op1).shortValue() * ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Short) op1).shortValue() * ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Short) op1).shortValue() * ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Short) op1).shortValue() * ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Short) op1).shortValue() * ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Integer (((Integer) op1).intValue() * ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Integer) op1).intValue() * ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Integer) op1).intValue() * ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Integer) op1).intValue() * ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Integer) op1).intValue() * ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Long (((Long) op1).longValue() * ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Long (((Long) op1).longValue() * ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Long) op1).longValue() * ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Long) op1).longValue() * ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Long) op1).longValue() * ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Float (((Float) op1).floatValue() * ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Float (((Float) op1).floatValue() * ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Float (((Float) op1).floatValue() * ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Float) op1).floatValue() * ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Float) op1).floatValue() * ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Double (((Double) op1).doubleValue() * ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Double (((Double) op1).doubleValue() * ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Double (((Double) op1).doubleValue() * ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Double (((Double) op1).doubleValue() * ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Double) op1).doubleValue() * ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
   }
 
   
   private Object division (Object op1, Object op2) {
	   
	   if (op1 == null || op2 == null)
		   return (null);
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Short ((short) (((Short) op1).shortValue() / ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Short) op1).shortValue() / ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Short) op1).shortValue() / ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Short) op1).shortValue() / ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Short) op1).shortValue() / ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Integer (((Integer) op1).intValue() / ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Integer) op1).intValue() / ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Integer) op1).intValue() / ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Integer) op1).intValue() / ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Integer) op1).intValue() / ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Long (((Long) op1).longValue() / ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Long (((Long) op1).longValue() / ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Long) op1).longValue() / ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Long) op1).longValue() / ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Long) op1).longValue() / ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Float (((Float) op1).floatValue() / ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Float (((Float) op1).floatValue() / ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Float (((Float) op1).floatValue() / ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Float) op1).floatValue() / ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Float) op1).floatValue() / ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Double (((Double) op1).doubleValue() / ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Double (((Double) op1).doubleValue() / ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Double (((Double) op1).doubleValue() / ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Double (((Double) op1).doubleValue() / ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Double) op1).doubleValue() / ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
   }

  private Object modulus (Object op1, Object op2) {

	   if (op1 == null || op2 == null)
		   return (null);
	   
	   
	   if (op1 instanceof Short) {
		   
		   if (op2 instanceof Short) 
			   return (new Short ((short) (((Short) op1).shortValue() % ((Short) op2).shortValue())));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Short) op1).shortValue() % ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Short) op1).shortValue() % ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Short) op1).shortValue() % ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Short) op1).shortValue() % ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   
	   if (op1 instanceof Integer) {
		   
		   if (op2 instanceof Short) 
			   return (new Integer (((Integer) op1).intValue() % ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Integer (((Integer) op1).intValue() % ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Integer) op1).intValue() % ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Integer) op1).intValue() % ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Integer) op1).intValue() % ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Long) {
		   
		   if (op2 instanceof Short) 
			   return (new Long (((Long) op1).longValue() % ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Long (((Long) op1).longValue() % ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Long (((Long) op1).longValue() % ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Long) op1).longValue() % ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Long) op1).longValue() % ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Float) {
		   
		   if (op2 instanceof Short) 
			   return (new Float (((Float) op1).floatValue() % ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Float (((Float) op1).floatValue() % ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Float (((Float) op1).floatValue() % ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Float (((Float) op1).floatValue() % ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Float) op1).floatValue() % ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   if (op1 instanceof Double) {
		   
		   if (op2 instanceof Short) 
			   return (new Double (((Double) op1).doubleValue() % ((Short) op2).shortValue()));
		   
		   if (op2 instanceof Integer) 
			   return (new Double (((Double) op1).doubleValue() % ((Integer) op2).intValue()));
		   
		   if (op2 instanceof Long) 
			   return (new Double (((Double) op1).doubleValue() % ((Long) op2).longValue()));
		   
		   if (op2 instanceof Float) 
			   return (new Double (((Double) op1).doubleValue() % ((Float) op2).floatValue()));	
		   
		   if (op2 instanceof Double) 
			   return (new Double (((Double) op1).doubleValue() % ((Double) op2).doubleValue()));		
		   
		   handleError ("Invalid operand:" + op2.getClass().getName());
		   return (null);
	   }
	   
	   handleError ("Invalid operand:" + op1.getClass().getName());
	   return (null);
   }
   
   private Object evaluateBinaryOperation (String operation, 
		   Object operand1, Object operand2) {
	   
	   if (operation == null || operand1 == null || 
			   operand2 == null)
		   return (null);
	   
	   handleTrace ("evaluateBinaryOperation:" + operand1 + operation + operand2, JtLogger.JtMIN_LOG_LEVEL);

	   if (operation.equals(JtExpression.ADDITION))
		   return (addition (operand1, operand2));
	   
	   if (operation.equals(JtExpression.SUBSTRACTION))
		   return (substraction (operand1, operand2));
	   
	   if (operation.equals(JtExpression.MULTIPLICATION))		   
		   return (multiplication (operand1, operand2));

	   
	   if (operation.equals(JtExpression.DIVISION))		   
		   return (division (operand1, operand2));
	   
	   if (operation.equals(JtExpression.MODULUS))		   
		   return (modulus (operand1, operand2));

	   handleError ("Invalid operation:" + operation);
	   return (null);
	   
   }
   
   
   private boolean isInteger (String token) {
	   int i;
	   char c; 
	   
	   if (token == null)
		   return (false);
	   
	   for (i = 0; i < token.length(); i++) {
		   c = token.charAt(i);
		   
		   if (!Character.isDigit(c))
			   return (false);
		 
	   }
		   
	   return (true);	   
	   
   }
   
   private boolean isRational (String token) {
	   int i;
	   char c; 
	   int count = 0;
	   int digitCount = 0;
	   
	   if (token == null)
		   return (false);
	   
	   for (i = 0; i < token.length(); i++) {
		   c = token.charAt(i);
		   
		   if (c == '.') {
			   
			   count++;
			   if (count != 1)
				   return (false);
			   continue;
		   }
		   
		   if (!Character.isDigit(c))
			   return (false);
		 
		   digitCount++;
	   }
		   
	   return (digitCount > 0 && count == 1);	   
	   
   }
   
   private Object convertTokenToDouble (String token) {
	   double d;
	   //if (token.indexOf(".") < 0)
	   //	   return (null);
		   
	   try {
		   d = Double.parseDouble(token);
		   return (new Double (d));
	   }catch (Exception ex) {
		   handleException (ex);
		   return (null);
	   }		   
	  
	   
   }
   
   
   private String convertTokenToString (String token) {
	   
	   if (token == null)
		   return null;
	   return (token.substring(1, token.length() - 1));   
   }
   
   private Character convertTokenToCharacter (String token) {
	   
	   if (token == null)
		   return null;
	   
	   if (token.length() == 3) 
		   return (new Character (token.charAt(1)));
		   
		   
	   return (null);   
   }
   
   private boolean isString (String token) {
	   int len;
	   if (token == null || token.length() == 0)
		   return (false);

	   len = token.length();
	   
	   if (token.charAt(0) == '"' && token.charAt(len - 1) == '"')
		   return (true);
	   
	   return (false);
   }
   
   private boolean isCharacter (String token) {
	   int len;
	   if (token == null || token.length() == 0)
		   return (false);

	   len = token.length();
	   
	   if (token.charAt(0) == '\'' && token.charAt(len - 1) == '\'')
		   return (true);
	   
	   return (false);
   }
   
   private boolean isReserved (String token) {
	   if (token == null)
		   return (false);
	   
	   if (token.equals("true"))
		   return (true);
	   
	   if (token.equals("false"))
		   return (true);
	   
	   if (token.equals("null"))
		   return (true);
	   
	   return (false);
   }
   
   
   private boolean isVariableName (String name) {
	   
	   int i;
	   
	   if (name == null)
		   return (false);
	   
	   if (!Character.isJavaIdentifierStart(name.charAt(0)))
		   return (false);
		   
	   
	   	   
	   if (isReserved (name))
		   return (false);
	   
	   for (i = 1; i < name.length(); i++) {
		   if (!Character.isJavaIdentifierPart(name.charAt(i)))
			   return (false);		   
	   }
	   
	   
	   return (true);
	   
   }
   private List retrieveVariableNames () {
	   
	   String token;
	   JtString jString = new JtString ();
	   ArrayList lst = new ArrayList ();
	   int index;
	   String componentName = null;
	   
	   
	   if (string == null)
		   return (lst);
	   
	   jString.setString(string);
	   
	   JtMessage msg = new JtMessage (JtString.JtGET_NEXT_TOKEN);

	   
	
	   
	   for (;;) {
		   token = (String)jString.processMessage(msg);
				   		   
		   if (token == null)
			   break;
		   
		   index = token.indexOf (".");
		   if (index < 0)
			   componentName = token;
		   else
			   componentName = token.substring(0, index);
		   
		   if (isVariableName (componentName))
			   lst.add(componentName);
	   }
	   
	   
	   return (lst);
	   
   }
   
   private Object convertTokenToObject (String token) {
	   int i;
	   int index;
	   String componentName;
	   String attrName;
	   Object attrValue;
	   Object component;
	   JtFactory factory = new JtFactory ();
	   
	   if (token == null || token.equals(""))
		   return (null);
	   
	   if (token.equals("true"))
		   return (new Boolean (true));
	   
	   if (token.equals("false"))
		   return (new Boolean (false));
	   
	   if (isInteger (token)) {
		   
		   try {
			   i = Integer.parseInt(token);
			   return (new Integer (i));
		   }catch (Exception ex) {
			   handleException (ex);
			   return (null);
		   }
	   }
	   if (isRational (token)) 
		   return (convertTokenToDouble (token));

	   if (isString (token))
		   return (convertTokenToString (token));	
	   
	   if (isCharacter (token))
		   return (convertTokenToCharacter (token));	
	   
	   if (Character.isJavaIdentifierStart(token.charAt(0))) {
		
		   if (token.equals("null"))
			   return (token);
		   
		   index = token.indexOf (".");
		   if (index < 0)
			   componentName = token;
		   else
			   componentName = token.substring(0, index);
		   
		   component =  variableTable.get(componentName);
		   
		   if (!variableTable.containsKey(componentName)) {
			   handleError ("Invalid variable name:" + componentName);
			   return (null);
		   }
		   
		   if (index < 0)
			   return (component);
		   
		   if (component == null) {
			   handleError ("Invalid attribute (variable points to null):" + token);
			   return (null);			   
		   }
		   
		   attrName = token.substring(index + 1);
		   
		   if (attrName == null || attrName.equals("")) {
			   handleError ("Invalid attribute");
			   return (null);			   
		   }		   
		   
		   attrValue = factory.getValue(component, attrName);
		   
		   //if (factory.getObjException() == null && attrValue == null )
		   //	   return ("null");
		   
		   return (attrValue);
	   }
	   
	   handleError ("Invalid token:" + token);
	   return (null);
	   
	   
   }
   
   private boolean relationalOperator (String token) {
	   if (token == null)
		   return (false);
	   
	   if (token.equals(">") || token.equals(">=") ||
			   token.equals("<=") || token.equals("<") ||
			   token.equals("==") || token.equals("!=")) {
		   
		   return (true);
	   }
	   
	   return (false);
   }
   
   private boolean logicalOperator (String token) {
	   if (token == null)
		   return (false);
	   
	   if (token.equals("&&") || token.equals("||"))		   
		   return (true);
	   
	   return (false);
   }
   
   private Object evaluate() {
	   Stack stack = new Stack ();
	   JtString jString = new JtString ();
	   JtMessage msg = new JtMessage (JtString.JtGET_NEXT_TOKEN);
	   String token = null;
	   Object obj;
	   Object operand1;
	   Object operand2;
	   Object result = null;
	   

	   postfix = postfix ();

	   if (postfix == null)
		   return (null);
	   
	   
	   handleTrace ("postfix:" + postfix);
 
	   jString.setString(postfix);
	   
	   for (;;) {
		   
		   token = (String)jString.processMessage(msg);
		   if (token == null)
			   break;
		   
		   if (isOperand (token)) {
			   obj = convertTokenToObject (token);
			   
			   if (this.getObjException() != null) {
			   	   //handleError ("Unable to convert operand:" + token);
			   	   return (null);
			   }
			   stack.push (obj);
			   result = obj;
			   continue;
		   }		  
		   
		   
		   if (stack.size() == 1) {
			   operand1 = stack.pop();

			   if (token.equals("!"))
				   result = evaluateUnaryLogicalOperation (token, operand1);
			   else if (token.equals("-")) {
				   result = evaluateUnaryMinus (token, operand1);
			   } else {

				   handleError ("Invalid operation:" + token);
				   return (null);
			   }
			   stack.push(result);

		   }
		   
		   if (stack.size() >= 2) {
			   
			   operand2 = stack.pop();
			   operand1 = stack.pop();

			   if (relationalOperator (token)) {

				   result = evaluateRelationalOperation (token, operand1, operand2);
			   } else if (logicalOperator (token)){
				   result = evaluateLogicalOperation (token, operand1, operand2);
			   } else {
				   //operand2 = stack.pop();
				   //operand1 = stack.pop();
				   result = evaluateBinaryOperation (token, operand1, operand2);				   
			   }
			   if (result == null) {
				   handleError ("Invalid operation:" + token);
				   return (null);
			   }
			   stack.push(result);
		   }
		   


	   }   
	   
	   return (result);
	   
   }
   
   private String postfix () {
	   JtString jString = new JtString ();
	   JtMessage msg = new JtMessage (JtString.JtGET_NEXT_TOKEN);
	   String token;
	   StringBuffer output = new StringBuffer ();
	   int priority;
	   String stackElement;
	   
	   if (string == null)
		   return (null);
	   
	   jString.setString(string);
	   
	   for (;;) {
		  
		   token = (String)jString.processMessage(msg);
		   
		   //System.out.println("token:" + token);
		   
		   if (token == null)
			   break;
		   
		   if (isOperand (token)) {
			   output.append(token + " ");
			   continue;
		   }
		   
		   //if (operatorStack.isEmpty())		   
		   //	   operatorStack.push(token);
		   
		   if (token.equals("(")) {
			   operatorStack.push(token);
			   continue;
		   }

		   if (token.equals(")")) {
			   for (;;) {
				   if (operatorStack.isEmpty()) {
					   handleError ("missing (");
					   return (null);
				   }
				   stackElement = (String) operatorStack.pop();
				   if ("(".equals(stackElement))
					   break;
				   output.append(stackElement + " ");
			   }
			   continue;

		   }
		   
		   priority = retrieveOperatorPriority (token); 		   
		   
		   for (;;) {

			   if (operatorStack.isEmpty())
				   break;
			   
			   stackElement = (String) operatorStack.peek();
			   
			   if ("(".equals(stackElement))
				   break;

			   
			   if (priority > retrieveOperatorPriority ((String) operatorStack.peek()))
				   break;
			   
			   output.append(operatorStack.pop() + " ");
		   }
		   
		   operatorStack.push(token);
	   }
	   
	   while (!operatorStack.isEmpty())
		   output.append(operatorStack.pop () + " ");
	   
	   return (output.toString().trim());
   }

     
   public void addVariable (String name, Object value) {
	   
	   if (name == null)
		   return;
	   
	   variableTable.put(name, value);
	   
   }
   /**
    * Process object messages.
    * <ul>
    * <li> EVALUATE - Evaluates the expression and returns the result.
    * <li> ADD_VARIABLE - Adds a variable (msgContent) and its value (msgData) to 
    * be used for the expression evaluation.  
    * <li> POSTFIX - Bulds and returns the postfix representation of the expression 
    * using the Shunting yard algorithm.
    * </ul>
    */
   
    public Object processMessage(Object msg) {
        JtMessage e = (JtMessage) msg;
        String msgid;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        this.setObjException(null);
        
        if (!initialized) 
        	initialized = initialize ();

        if (msgid.equals (JtExpression.POSTFIX))
            return (postfix ());
        
        if (msgid.equals (JtExpression.EVALUATE))
            return (evaluate ());
        
        if (msgid.equals (JtExpression.ADD_VARIABLE)) {
        	addVariable ((String) e.getMsgContent(), e.getMsgData());
            return (null);
        }
        
        if (msgid.equals (JtExpression.RETRIEVE_VARIABLES)) {
        	return (retrieveVariableNames ());
        }
        
        return (super.processMessage(msg));
    }
    /**
     * Demonstrates the messages processed by this class.
     */

    public static void main(String[] args) {

        //JtObject factory = new JtFactory ();
        JtMessage msg; 
        //List list
        JtExpression exp = new JtExpression ();
        Object result;
        Integer I1 = new Integer (2);
        Double I = new Double (4.0);
        String S = "string1";
        Character C = new Character ('a');
        HelloWorldMessage helloWorld = new HelloWorldMessage ();
        Test test = new Test ();
        Boolean done = new Boolean (false);
        JtPrinter printer = new JtPrinter ();

        
        //str.setString("   ((-122.0 + 564) > 20) || ($obj.color > 20)");
        //exp.setString("(-$kk*(1+2))*3 > (5 < 4)");
        //exp.setString("1+(2*3-4)== 3 && 1+2==2");
        exp.setString("(i + 1 * 4) / 2");

        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("i");
        msg.setMsgData(I);
        exp.processMessage(msg);
        System.out.println ("Add variable (i):" + I);
        
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));
        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        exp.setString("1 * 4 % 2");
        
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));
        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        exp.setString("1 < 2");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);

        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("I1");
        msg.setMsgData(I1);
        exp.processMessage(msg);
        System.out.println ("Add variable (I1):" + I1);
        
        exp.setString("I1 == 2 * 1");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        
        exp.setString("2.1 * 2 + 1");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);

        
        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("S");
        msg.setMsgData(S);
        exp.processMessage(msg);
        System.out.println ("Add variable (S):" + S);
        
        exp.setString("S + \"string\" + 8");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        
        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("C");
        msg.setMsgData(C);
        exp.processMessage(msg);
        System.out.println ("Add variable (C):" + C);
        
        exp.setString("C>='a'");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        if (result.equals(new Boolean (true)))
        	System.out.println("Character: GO");
        else
        	System.out.println("Character: FAIL");   
        
        exp.setString("!(2 == 3)");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        
        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("helloWorld");
        msg.setMsgData(helloWorld);
        exp.processMessage(msg);
        System.out.println ("Add variable (helloWorld)");
        
        exp.setString("helloWorld.greetingMessage>\"Hello\"");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
 
        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("test");
        msg.setMsgData(test);
        exp.processMessage(msg);

        test.setStatus(10);
        exp.setString("test.status*2==20");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);

        exp.setString("test.email!=null");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);

        exp.setString("\"hi\"");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        exp.setString("jtReply==null");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        exp.setString("null");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);

        exp.setString("-(5*4)");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        exp.setString("-5+4");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        exp.setString("-5*4");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        
        msg = new JtMessage (JtExpression.ADD_VARIABLE);
        msg.setMsgContent ("done");
        msg.setMsgData(done);
        exp.processMessage(msg);
        
        exp.setString("!done");       
        result = exp.processMessage(new JtMessage (JtExpression.EVALUATE));        
        System.out.println("Result(" + exp.getString() + "): " + result);
        
        result = exp.processMessage(new JtMessage (JtExpression.RETRIEVE_VARIABLES));        
        printer.processMessage(result);

  
    }
}
