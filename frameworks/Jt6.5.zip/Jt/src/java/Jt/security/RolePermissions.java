package Jt.security;

import java.util.LinkedList;
import java.util.List;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;

/**
 * Role permissions. Create, Read, Update, Delete, execute permissions (CRUD) are associated
 * to a specific object class for the specified role. For instance, the role "guest" can be granted permissions
 * to "read" DAO objects of the class "Jt.portal.product". JtDAOAccessManager relies on this
 * class in order to grant access to specific framework objects.
 */

public class RolePermissions extends JtObject {
    

    private static final long serialVersionUID = 1L;

    // Messages
    
    public static final String RETRIEVE_ROLE_PERMISSIONS = "RETRIEVE_ROLE_PERMISSIONS";
    public static final String RETRIEVE_CLASS_PERMISSIONS = "RETRIEVE_CLASS_PERMISSIONS";
    
    public static final String JtCLASS_NAME = RolePermissions.class.getName(); 
    
    private JtFactory factory = new JtFactory ();
    private transient JtDAOStrategy daoAdapter;
    private transient boolean init = false;
    
    private String roleId;
    private String classname;
    
    private boolean createPermission;
    private boolean readPermission;
    private boolean updatePermission;
    private boolean deletePermission;
    private boolean executePermission;

    /**
     * Returns the role Id.
     */
    
    public String getRoleId() {
        return roleId;
    }
    
    /**
     * Sets the role Id.
     */

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
     * Returns the classname.
     */
    
    public String getClassname() {
        return classname;
    }

    /**
     * Sets the classname.
     */
    
    public void setClassname(String classname) {
        this.classname = classname;
    }
    
    
    /**
     * Returns create permissions.
     */

    public boolean isCreatePermission() {
        return createPermission;
    }
    
    /**
     * Sets create permissions.
     */

    public void setCreatePermission(boolean createPermission) {
        this.createPermission = createPermission;
    }

    /**
     * Returns read permissions.
     */
    
    public boolean isReadPermission() {
        return readPermission;
    }

    /**
     * Sets read permissions.
     */
    
    public void setReadPermission(boolean readPermission) {
        this.readPermission = readPermission;
    }  
    
    /**
     * Returns update permissions.
     */
    
    public boolean isUpdatePermission() {
        return updatePermission;
    }

    /**
     * Sets update permissions.
     */
    
    public void setUpdatePermission(boolean updatePermission) {
        this.updatePermission = updatePermission;
    }

    /**
     * Returns delete permissions.
     */
    
    public boolean isDeletePermission() {
        return deletePermission;
    }

    /**
     * Sets delete permissions.
     */
    
    public void setDeletePermission(boolean deletePermission) {
        this.deletePermission = deletePermission;
    }
    
    /**
     * Returns execute permissions.
     */
    public boolean isExecutePermission() {
        return executePermission;
    }

    /**
     * Sets execute permissions.
     */
    
    public void setExecutePermission(boolean executePermission) {
        this.executePermission = executePermission;
    }

    private void initialize () {
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(true);        
    }
    
    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }

    private RolePermissions retrieveRolePermissions (String roleId, String classname) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        RolePermissions rolePermissions = new RolePermissions ();
        
        
        if (roleId == null ||
            classname == null)
            return (null);
        
        rolePermissions.setRoleId(roleId);        
        rolePermissions.setClassname(classname);
        
        msg.setMsgContent(new RolePermissions ());
        msg.setMsgData (rolePermissions);
        
        rolePermissions = (RolePermissions) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return (null);
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (rolePermissions);
    }
    
    private List retrieveClassPermissions (String classname) {
        JtMessage msg = new JtMessage (JtDAOAdapter.JtSEARCH_BY_ATTRIBUTES);
        RolePermissions rolePermissions = new RolePermissions ();
        LinkedList attributeList = new LinkedList ();
        List classPermissions;
        
        
        if (classname == null)
            return (null);
             
        rolePermissions.setClassname(classname);
        
        msg.setMsgContent(rolePermissions);
        
        attributeList.add("classname");
        msg.setMsgData (attributeList);
        
        classPermissions = (List) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return (null);
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        return (classPermissions);
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        
        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        if (!init) {
            initialize ();
            init = true;
        }      

        if (e.getMsgId().equals(RolePermissions.RETRIEVE_ROLE_PERMISSIONS)) {
                        
            return (retrieveRolePermissions ((String) e.getMsgContent(),
                    (String) e.getMsgData()));
        }
        
        if (e.getMsgId().equals(RolePermissions.RETRIEVE_CLASS_PERMISSIONS)) {
            
            return (retrieveClassPermissions ((String) e.getMsgContent()));
        }
        
        return (super.processMessage(message));

    }   
}
