/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt.security;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;

import javax.crypto.Cipher;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;



/**
 * Jt Asymmetric Cipher for message encryption.
 */



public final class JtAsymmetricCipher extends JtObject {
	

    private static final long serialVersionUID = 1L;
    private PublicKey publicKey = null;
    private String certificatePath;
    private String certificateName = "Jt";
    private String transformation = "RSA/ECB/PKCS1Padding";
    public static final String JtCLASS_NAME = JtAsymmetricCipher.class.getName();  
    private boolean encryptMode = true;
    //private String keyStoreResource = "Jt.ks";
    
    private JtFactory factory = new JtFactory ();
    
	/**
	  * Returns the certificate path.
	  */

	public String getCertificatePath() {
		return certificatePath;
	}

	/**
	  * Specifies the certificate path.
	  */
	
	public void setCertificatePath(String certificatePath) {
		this.certificatePath = certificatePath;
	}

	/**
	  * Returns the transformation.
	  */
	
	public String getTransformation() {
		return transformation;
	}

	/**
	  * Specifies the transformation.
	  */
	
	public void setTransformation(String transformation) {
		this.transformation = transformation;
	}

	/**
	  * Returns the value of encryptMode. 
	  */
	
	public boolean isEncryptMode() {
		return encryptMode;
	}

	/**
	  * Specifies whether or not the mode is encryption (ENCRYPT_MODE). The default is true. 
	  */
	
	public void setEncryptMode(boolean encryptMode) {
		this.encryptMode = encryptMode;
	}
	
	
	/**
	  * Returns the KeyStore resource. 
	  */
	
	//public String getKeyStoreResource() {
	//	return keyStoreResource;
	//}
	
	/**
	  * Specifies the KeyStore resource.  
	  */

	//public void setKeyStoreResource(String keyStoreResource) {
	//	this.keyStoreResource = keyStoreResource;
	//}

	/**
	  * Returns the name of the certificate stored in the KeyStore. 
	  */
	public String getCertificateName() {
		return certificateName;
	}

	/**
	  * Specifies the name of the certificate to be retrieved from the KeyStore. 
	  */
	
	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}

	private PublicKey retrievePublicKey (String certFilename) {

		JtCertificate cert;
		PublicKey key;

		if (certFilename == null)
			return (null);
		
		cert = (JtCertificate) factory.createObject(JtCertificate.JtCLASS_NAME);
		cert.setPath(certFilename);

		key = cert.getPublicKey();
		
		if (propagateException (cert) != null)
			return (null);
			
		return (key);
	}
	
	
	private PublicKey retrievePublicKeyFromKeyStore (String certificateName) {

		JtCertificate cert;
		Certificate certificate;
		PublicKey key;
		JtKeyStore keyStore = null;
    	JtMessage msg = new JtMessage (JtKeyStore.JtGET_CERTIFICATE);

		if (certificateName == null) {
			handleError ("Invalid certificate name (null).");
			return (null);
		}
		
    	keyStore = (JtKeyStore) factory.createObject (JtKeyStore.JtCLASS_NAME);
		
		msg.setMsgContent(certificateName);
		
		certificate = (Certificate) factory.sendMessage(keyStore, msg);
		
		if (propagateException (keyStore) != null)
			return (null);
			
		if (certificate == null) {
			handleError ("Unable to retrieve certificate from KeyStore:" + certificateName);
			return (null);
		}
		
		key = certificate.getPublicKey();
		
			
		return (key);
	}

    private byte[] encrypt(byte[] buffer)
    {
    	Cipher asymmetricCipher;
    	
    	//if (certificatePath == null) {
    	//	handleError ("certificatePath attribute needs to be set.");
    	//	return (null);
    	//}

    	if (transformation == null) {
    		handleError ("transformation attribute needs to be set.");
    		return (null);
    	}
    	
    	//if (publicKey == null)
    	//	publicKey = retrievePublicKey (certificatePath); 
    	publicKey = retrievePublicKeyFromKeyStore (certificateName);
    	
    	if (publicKey == null)
    		return null; 
    	
    	try {
    		asymmetricCipher = Cipher.getInstance(transformation);
    		asymmetricCipher.init(Cipher.ENCRYPT_MODE, publicKey);
    		return (asymmetricCipher.doFinal(buffer));
    		
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);
    	}
    
    		
    }
    
    
    private byte[] decrypt(byte[] encoded, PrivateKey key)
    {
    	Cipher asymmetricCipher;
    	   	

    	if (key == null) {
    		handleError ("invalid key (null).");
    		return null;  //check
    	}
    	
    	try {
    		asymmetricCipher = Cipher.getInstance(transformation);
    		asymmetricCipher.init(Cipher.DECRYPT_MODE, key);
    		return (asymmetricCipher.doFinal(encoded));
    		
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);
    	}    
    		
    }
    
    

	/*
	 *  Propagate Exceptions
	 */
	
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}
    
    private PrivateKey retrievePrivateKey () {

    	JtKeyStore keyStore;
    	PrivateKey key;

    	keyStore = (JtKeyStore) factory.createObject(JtKeyStore.JtCLASS_NAME);
    	
    	key = keyStore.getPrivateKey();
    	
    	if (propagateException (keyStore) != null)
    		return (null);   		

    	return (key);
    	
    }
    
    /**
     * Process object messages.
     */

    public Object processMessage (Object message) {

        
    	if (message == null) {
    		handleError ("Invalid message: null");
    		return (null);
    	}
    	
    	if (message instanceof JtMessage)
            return (super.processMessage(message));
    	
    	if (!(message instanceof byte[])) {
    		handleError ("Invalid message format: byte[] expected." );
    		return (null);
    	}

    	if (encryptMode)
    		return (encrypt((byte []) message));
    	else {
        	PrivateKey key = retrievePrivateKey ();
        	
        	if (key == null)
        		return (null);

    		return (decrypt((byte []) message, key));    		
    	}	

    }

    
    /*
     * Demonstrate the messages handled by this component.
     */
    
    public static void main (String args[]) {
        JtFactory factory = new JtFactory ();
        JtAsymmetricCipher crypto;
        byte bArray[];
        String sMessage = "Hello .. Welcome to Jt messaging";
        String decrytedMessage;


        crypto = (JtAsymmetricCipher) factory.createObject (JtAsymmetricCipher.JtCLASS_NAME);
        
        bArray = (byte []) factory.sendMessage (crypto, sMessage.getBytes());       
        

        crypto.setEncryptMode(false);
        bArray = (byte []) factory.sendMessage (crypto, bArray);
        
        if (bArray != null) {
        	decrytedMessage = new String (bArray);
        	System.err.println (decrytedMessage);
        	if (sMessage.equals(decrytedMessage)) {
        		System.err.println ("JtCipher:PASS");
        		System.exit(0);
        	}	
        }
		System.err.println ("JtCipher:FAILED");
		System.exit(1);    
        
    }
    
}
