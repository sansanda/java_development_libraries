/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.security;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import Jt.JtComponent;
import Jt.JtFactory;
import Jt.JtMessage;



/**
 * Jt Symmetric Cipher for message encryption.
 */


public final class JtSymmetricCipher extends JtComponent {
	

    private static final long serialVersionUID = 1L;

    public static final String JtCLASS_NAME = JtSymmetricCipher.class.getName();  
    public static final String JtGENERATE_KEY = "JtGENERATE_KEY";  
    public static final String Blowfish = "Blowfish";  
    
    private Key key = null;
    private String algorithm = "Blowfish";
    private String transformation = "Blowfish/ECB/PKCS5Padding";
    private int keySize = 128;
    private boolean encryptMode = true;
    
    

	/**
	  * Returns the key.
	  */
    
    public Key getKey() {
		return key;
	}

	/**
	  * Specifies the key to be used.
	  */
    
	public void setKey(Key key) {
		this.key = key;
	}

    
	/**
	  * Returns the encryption algorithm.
	  */
	
    public String getAlgorithm() {
		return algorithm;
	}

	/**
	  * Specifies the encryption algorithm. The default is Blowfish.
	  */
    
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	/**
	  * Returns the transformation. 
	  */
	
	public String getTransformation() {
		return transformation;
	}

	/**
	  * Specifies the transformation. The default is Blowfish/ECB/PKCS5Padding.
	  */
	
	public void setTransformation(String transformation) {
		this.transformation = transformation;
	}

	/**
	  * Returns the key size. 
	  */
	
	public int getKeySize() {
		return keySize;
	}

	
	/**
	  * Specifies the key size. The default is 128 bits.
	  */
	
	public void setKeySize(int keySize) {
		this.keySize = keySize;
	}

	
	/**
	  * Returns the value of encryptMode. 
	  */
	
	public boolean isEncryptMode() {
		return encryptMode;
	}

	/**
	  * Specifies whether or not the mode is encryption (ENCRYPT_MODE). The default is true. 
	  */
	
	public void setEncryptMode(boolean encryptMode) {
		this.encryptMode = encryptMode;
	}

	private byte[] encrypt(byte[] buffer)
    {
    	Cipher symmetricCipher;
    	
    	if (key == null) {
    		handleError ("Key attribute needs to be set.");
    		return (null);
    	}
    	
    	if (buffer == null) {
    		handleError ("Invalid parameter. Plain data is null.");
    		return (null);
    	}
    	
    	try {
    		symmetricCipher = Cipher.getInstance(transformation);
    		symmetricCipher.init(Cipher.ENCRYPT_MODE, key);
    		return (symmetricCipher.doFinal(buffer));
    		
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);
    	}   
    		
    }
    
    private byte[] decrypt(byte[] encoded)
    {
    	Cipher symmetricCipher;
    	SecretKey symmetricKey;   	

    	if (key == null) {
    		handleError ("Key attribute needs to be set.");
    		return null;
    	}
    	
    	if (encoded == null) {
    		handleError ("Invalid parameter: encrypted data is null.");
    		return (null);
    	}
    	
    	symmetricKey = new SecretKeySpec (key.getEncoded(), algorithm);
    	
    	try {
        	symmetricKey = new SecretKeySpec (key.getEncoded(), algorithm);
    		symmetricCipher = Cipher.getInstance(transformation);
    		symmetricCipher.init(Cipher.DECRYPT_MODE, symmetricKey);
    		return (symmetricCipher.doFinal(encoded));
    		
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);
    	}   
    		
    }
    
    /*
    private PrivateKey retrievePrivateKey () {

    	JtKeyStore keyStore;

    	
    	keyStore = (JtKeyStore) factory.createObject(JtKeyStore.JtCLASS_NAME);
    	keyStore.setPath("/home/projects/Jt/creditCardExample.ks");
    	
    	return (keyStore.getPrivateKey());
    	
    	//return (null);
    }
    */
    
    private Key generateKey () {
    	Key key;
    	
    	if (algorithm == null) {
    		handleError ("Algorithm attribute needs to be set.");
    		return (null);
    	}
    	
    	if (keySize <= 0) {
    		handleError ("keySize needs to be set properly: " + keySize);
    		return (null);
    	}
    	
    	try {
    		KeyGenerator generator = KeyGenerator.getInstance (algorithm);
    		generator.init(keySize);
    		key = generator.generateKey();

    	} catch (Exception ex) {

    		handleException (ex);
    		return (null);
    	}
    	
    	return (key);
    }
    
    /**
     * Process object messages. This component encrypts/decrypts data using symmetric encryption.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgId;
        JtMessage msg;
        
    	if (message == null) {
    		handleError ("Invalid message: null");
    		return (null);
    	}
    	
    	if (message instanceof JtMessage) {
    		
    		msg = (JtMessage) message;
    		msgId = (String) msg.getMsgId();
    		
    		if (msgId.equals(JtSymmetricCipher.JtGENERATE_KEY)) {
    			
    			return (generateKey ());
    		}
    		
    		
            return (super.processMessage(message));
    	}
    	if (!(message instanceof byte[])) {
    		handleError ("Invalid message format: byte[] expected." );
    		return (null);
    	}

    	if (encryptMode)
    		return (encrypt((byte []) message));
    	else
    		return (decrypt((byte []) message));    		

    }
    

    
    public static void main (String args[]) {
        JtFactory factory = new JtFactory ();
        //JtMessage msg;
        JtSymmetricCipher crypto;
        byte bArray[];
        String sMessage = "Hello .. Welcome to Jt messaging";
        String decrytedMessage;
	    Key key = null;

        // Create an instance of the symmetric cipher

        crypto = (JtSymmetricCipher) factory.createObject (JtSymmetricCipher.JtCLASS_NAME);
        
        // Generate a key
        
       
	    key = (Key) factory.sendMessage(crypto, new JtMessage (JtSymmetricCipher.JtGENERATE_KEY));
	    
	    crypto.setKey(key); // Specify the encryption key
	    
	    // Encrypt the message
	    
	    bArray = (byte []) factory.sendMessage (crypto, sMessage.getBytes());
        

        // Decrypt the message
        
        crypto.setEncryptMode(false);
        bArray = (byte []) factory.sendMessage (crypto, bArray);
        
        if (bArray != null) {
        	decrytedMessage = new String (bArray);
        	System.err.println (decrytedMessage);
        	if (sMessage.equals(decrytedMessage)) {
        		System.err.println ("JtCipher:PASS");
        		System.exit(0);
        	}	
        }
		System.err.println ("JtCipher:FAILED");
		System.exit(1);
        
        
    }
    
}
