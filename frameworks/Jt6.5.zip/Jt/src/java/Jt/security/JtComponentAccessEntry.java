package Jt.security;

import java.io.Serializable;



/**
 * Component Access Entry.
 */

public class JtComponentAccessEntry implements Serializable  {
    
    

    private static final long serialVersionUID = 1L;

    private String entryId;
    private boolean encrypted;
    private boolean enabled;
    private boolean authenticated;

    /**
     * Returns the component Id.
     */

	public String getEntryId() {
		return entryId;
	}

    /**
     * Specifies the component Id.
     */
	
	public void setEntryId(String entryId) {
		this.entryId = entryId;
	}
	
    /**
     * Returns the encryptedMessaging flag.
     */

	public boolean isEncrypted() {
		return encrypted;
	}

    /**
     * Specifies whether or not encrypted messaging is required.
     */
	
	public void setEncrypted(boolean encrypted) {
		this.encrypted = encrypted;
	}

    /**
     * Returns the value of the 'enabled' flag.
     */
	
	public boolean isEnabled() {
		return enabled;
	}

    /**
     * Specifies whether or not access to this component is enabled.
     */
	
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
    
	
    /**
     * Returns the value of the authenticated flag.
     */
	
	public boolean isAuthenticated() {
		return authenticated;
	}

    /**
     * Specifies whether or not messaging should be authenticated.
     */
	
	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}
}
