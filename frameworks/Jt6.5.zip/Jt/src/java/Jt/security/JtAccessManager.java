package Jt.security;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import Jt.JtDirectory;
import Jt.JtFactory;
import Jt.JtFile;
import Jt.JtInputStream;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtOSCommand;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.JtSingletonComponent;
import Jt.xml.JtXMLHelper;
//import Jt.security.RolePermissions;

/**
 * Service Access Manager. Internal framework component.
 */

public class JtAccessManager extends JtSingletonComponent {
    

    private static final long serialVersionUID = 1L;
    //private transient JtFactory factory = new JtFactory ();
    public static final String JtCLASS_NAME = JtAccessManager.class.getName(); 
    public static final String JtCHECK_SERVICE_ACCESS = "JtCHECK_SERVICE_ACCESS";
    public static final String JtCHECK_COMPONENT_ACCESS = "JtCHECK_COMPONENT_ACCESS";
    public static final String JtGET_CLASS_ACCESS = "JtGET_CLASS_ACCESS";
    public static final String JtGET_COMPONENT_ACCESS = "JtGET_COMPONENT_ACCESS";    
    //public static final String ADMIN_USER = "admin";
    public static final String SECURITY_PACKAGE = "Jt.security";
    public static final String ADMIN_USER = "admin";
    private String configFile = "JtAccessManager.xml"; 
    private boolean configFileExists = false;
    private boolean initialized = false;
    
    
    // Packages, classes and component that can be accessed
    
    Hashtable classTable = new Hashtable (); 
    Hashtable packageTable = new Hashtable ();
    Hashtable componentTable = new Hashtable ();
    

    
    private String classAccessList = null;
    private String componentAccessList = null;
    
    private List classEntryAccessList = null;
    private List componentEntryAccessList = null;
    

    /**
     * Returns the list of classes that can be accessed remotely.
     */
    
    public String getClassAccessList() {
		return classAccessList;
	}


    /**
     * Specifies the list of classes that can be accessed remotely.
     */
    
	public void setClassAccessList(String classAccessList) {
		this.classAccessList = classAccessList;
	}




    /**
     * Returns the list of components that can be accessed remotely.
     */
	
    public String getComponentAccessList() {
		return componentAccessList;
	}

    /**
     * Specifies the list of components that can be accessed remotely.
     */
    
	public void setComponentAccessList(String componentAccessList) {
		this.componentAccessList = componentAccessList;
	}


    /**
     * Returns the configuration file.
     */
	
	public String getConfigFile() {
		return configFile;
	}

	
    /**
     * Sets the configuration file.
     */

	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}

	

	

    public List getComponentEntryAccessList() {
		return componentEntryAccessList;
	}


	public void setComponentEntryAccessList(List componentEntryAccessList) {
		this.componentEntryAccessList = componentEntryAccessList;
	}


	public List getClassEntryAccessList() {
		return classEntryAccessList;
	}


	public void setClassEntryAccessList(List classEntryAccessList) {
		this.classEntryAccessList = classEntryAccessList;
	}


	/**
     *  Retrieve the package name
     */
	
	private String retrievePackageName (String className) {
        int index;
        
        if (className == null)
            return (null);
        
        index = className.lastIndexOf(".");
        
        if (index < 0)
            return (null);       
        
        return (className.substring(0, index));
                   
    }
    

	private JtClassAccessEntry checkClassAccessTable (String classname) {
		String classPackage;
		JtClassAccessEntry classEntry;
		
		if (classname == null) {
			handleError ("Invalid classname (null).");
			return (null);		
		}

		// Table was loaded from the config file

		classEntry = (JtClassAccessEntry) classTable.get(classname);
		
		handleTrace ("classEntry:" + classEntry, JtLogger.JtMIN_LOG_LEVEL);
		if (classEntry != null)
        	return (classEntry);
        
        classPackage = retrievePackageName (classname);
        
        if (classPackage == null)
        	return (null);
        
        classEntry = (JtClassAccessEntry) packageTable.get(classPackage + ".*");

		handleTrace ("classEntry:" + classEntry, JtLogger.JtMIN_LOG_LEVEL);
        return (classEntry);	
		
	}

	private void initializeClassTableFromProperties () {
    	String classArray [];
    	int i;
    	JtClassAccessEntry classEntry;
    	String tmp;
		
        classArray = classAccessList.split(",");
        
        for (i = 0; i < classArray.length; i++) {
        	tmp = classArray[i];
        	tmp = tmp.trim();
        	
        	classEntry = new JtClassAccessEntry ();
        	
        	classEntry.setEnabled(true);
        	classEntry.setClassname(tmp);
        	
        	if (tmp.endsWith(".*"))
        		packageTable.put(tmp, classEntry);
        	else
        		classTable.put(tmp, classEntry);
        	
        } 
	}
    
    private boolean checkClassAccessList (String className) {
    	String classArray [];
    	int i;
    	String tmp;
    	String classPackage;
    	JtClassAccessEntry classEntry;
    	
    	if (className == null)
    		return (false);
    	
    	if (classAccessList == null)
    		return (false);
    	
        classArray = classAccessList.split(",");
        
        for (i = 0; i < classArray.length; i++) {
        	tmp = classArray[i];
        	tmp = tmp.trim();
        	
        	classEntry = new JtClassAccessEntry ();
        	
        	classEntry.setEnabled(true);
        	classEntry.setClassname(tmp);
        	
        	if (tmp.endsWith(".*"))
        		packageTable.put(tmp, classEntry);
        	else
        		classTable.put(tmp, classEntry);
        	
        } 
        
        if (classTable.get(className) != null)
        	return (true);
        
        classPackage = retrievePackageName (className);
        
        if (classPackage == null)
        	return (false);
        
        if (packageTable.get(classPackage + ".*") != null)
        	return (true);
        	
        return (false);
    }
    
    
    public boolean checkClassAccess (String className) {
    	if (className == null)
    		return (false);
    	
    	className = className.trim();
        if (className.equals(JtObject.JtCLASS_NAME) || 
        		className.equals(JtOSCommand.JtCLASS_NAME) ||
        		className.equals(JtFile.JtCLASS_NAME) ||
        		className.equals(JtDirectory.JtCLASS_NAME)) {
            return (false);           
        }
    	
    	
        if (className.equals("Jt.portal.JtProfile") ||
                className.equals("Jt.portal.JtAccount")) {
            return (false);           
        }
        // Classes inside the security package: Role, RolePermissions, etc
        
        if (className.startsWith(JtAccessManager.SECURITY_PACKAGE)) {
            return (false);
        }
    	

        return (checkClassAccessList (className));

        
    }
    
    
    public JtClassAccessEntry retrieveClassAccessEntry (String className) {
    	if (className == null) {
    		handleError ("Invalid classname:null");
    		return (null);
    	}
    	className = className.trim();
        if (className.equals(JtObject.JtCLASS_NAME) || 
        		className.equals(JtOSCommand.JtCLASS_NAME) ||
        		className.equals(JtFile.JtCLASS_NAME) ||
        		className.equals(JtDirectory.JtCLASS_NAME)) {
            return (null);           
        }
    	
    	
        if (className.equals("Jt.portal.JtProfile") ||
                className.equals("Jt.portal.JtAccount")) {
            return (null);           
        }
        // Classes inside the security package: Role, RolePermissions, etc
        
        if (className.startsWith(JtAccessManager.SECURITY_PACKAGE)) {
            return (null);
        }
    	

        return (checkClassAccessTable (className));

        
    }
    
    public JtComponentAccessEntry retrieveComponentAccessEntry (Object componentId) {
    	if (componentId == null)
    		return (null);
    	
    	
        return ((JtComponentAccessEntry) componentTable.get(componentId));
        
    }
    
    public boolean checkComponentAccess (String componentName) {
       	String classArray [];
    	int i;
    	String tmp;
    	//JtClassAccessEntry componentAccessEntry;
    	
    	if (componentName == null)
    		return (false);
    	
    	if (componentAccessList == null)
    		return (false);
    	
        classArray = componentAccessList.split(",");
        
        for (i = 0; i < classArray.length; i++) {
        	tmp = classArray[i];
        	tmp = tmp.trim();
        	
        	if (componentName.equals(tmp))
        		return (true);
        	
        }         
        	
        return (false);
        
    }
    
    
    private void initializeComponentTableFromProperties () {
       	String classArray [];
    	int i;
    	String tmp;
    	JtComponentAccessEntry componentAccessEntry;
    	
    	
    	if (componentAccessList == null)
    		return;
    	
        classArray = componentAccessList.split(",");
        
        for (i = 0; i < classArray.length; i++) {
        	tmp = classArray[i];
        	tmp = tmp.trim();
        
        	componentAccessEntry = new JtComponentAccessEntry ();

        	componentAccessEntry.setEnabled(true);
        	componentAccessEntry.setEntryId(tmp);
        	
        	componentTable.put (tmp, componentAccessEntry);
        	
        }         
        	
    }
    
    
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}

    private boolean readConfigFile () {
    	InputStream stream;
    	JtInputStream jStream = new JtInputStream ();
    	JtMessage msg = new JtMessage (JtInputStream.JtREAD_STREAM);
    	String xmlFile;
    	JtXMLHelper helper = new JtXMLHelper ();
    	JtAccessManager protoAccessManager = null;
    	JtFactory factory = new JtFactory ();
    	Boolean Bool;
    	
    	if (configFile == null)
    		return (false);
    	
    	stream = Thread.currentThread().getContextClassLoader().getResourceAsStream (configFile);
    	
    	if (stream == null)
    		return (false);
    	
    	jStream.setInputStream(stream);
    	
    	handleTrace ("JtAccessManager: reading config file:" +
    			configFile);
    	
    	xmlFile = (String) jStream.processMessage(msg);
    	
    	if (xmlFile == null) {
    		propagateException (jStream);
    		return (false);
    	}

    	msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
    	msg.setMsgContent(xmlFile);
    	
    	try {
    		protoAccessManager = (JtAccessManager) helper.processMessage(msg);
    	} catch (Exception ex) {
    		handleException (ex);
    		return (false);
    	}
    	
    	if (protoAccessManager == null)
    		return (false);
    	
    	msg = new JtMessage (JtFactory.JtCOPY);
    	msg.setMsgContent(protoAccessManager);
    	msg.setMsgData(this);
    	
    	Bool = (Boolean) factory.processMessage(msg);
    	
    	return (Bool.booleanValue());
    	
    }
    
    private boolean initializeClassAccessTable () {
    	Iterator iterator;
    	JtClassAccessEntry classEntry;
    	String tmp;
    	
    	if (classEntryAccessList == null)
    		return (false);
    	
    	iterator = classEntryAccessList.iterator();
    	

    	while (iterator.hasNext()) {
    		try {
    			// data comes from an input file
    			classEntry = (JtClassAccessEntry) iterator.next();
    		} catch (Exception ex) {
    			handleException (ex);
    			continue;
    		}
    		
    		if (classEntry == null) {
    			handleWarning ("JtAccessManager: classEntry is null.");
    			continue;
    		}
    		tmp = classEntry.getClassname();
    		
    		if (tmp == null) {
    			handleWarning ("JtAccessManager: classname is null.");
    			continue;
    		}
    		
        	if (tmp.endsWith(".*"))
        		packageTable.put(tmp, classEntry);
        	else
        		classTable.put(tmp, classEntry);
    	}
    	
    	return (true);
    }
    
    
    private boolean initializeComponentAccessTable () {
    	Iterator iterator;
    	JtComponentAccessEntry componentEntry;
    	String tmp;
    	
    	if (componentEntryAccessList == null)
    		return (false);
    	
    	iterator = componentEntryAccessList.iterator();
    	

    	while (iterator.hasNext()) {
    		try {
    			// Comes from an input file
    			componentEntry = (JtComponentAccessEntry) iterator.next();
    		} catch (Exception ex) {
    			handleException (ex);
    			continue;
    		}
    		
    		if (componentEntry == null) {
    			handleWarning ("JtAccessManager: componentEntry is null.");
    			continue;
    		}
    		tmp = componentEntry.getEntryId();
    		
    		if (tmp == null) {
    			handleWarning ("JtAccessManager: component Id is null.");
    			continue;
    		}
    		

    		componentTable.put(tmp, componentEntry);

    	}
    	
    	return (true);
    }
    
    private synchronized boolean initialize () {
    	//boolean configFileExist; 
    	
    	if (initialized)
    		return (true);
    	
    	initializeClassTableFromProperties ();
    	initializeComponentTableFromProperties ();
    	
    	configFileExists = readConfigFile ();
    	
    	if (configFileExists) {
    		
    	    classTable = new Hashtable (); 
    	    packageTable = new Hashtable ();
    	    componentTable = new Hashtable ();
    		initializeClassAccessTable ();
    		initializeComponentAccessTable ();
    	}	
    	
    	initialized = true;
    	return (true);
    }
    
    
    
    /**
     * Process object messages.
     */

    
    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage msg = (JtMessage) message;
        //Object reply;
             

        if (msg == null) {
        	handleError ("Invalid message: null.");
            return null;
        }
        msgid = (String) msg.getMsgId ();

        if (msgid == null) {
        	handleError ("Invalid message Id: null.");        	
            return null;
        }
         
        if (!initialized)
        	
        	initialize ();

        
        
        
        this.setObjException(null); // Reset exceptions
        
        
        if (msgid.equals (JtObject.JtINITIALIZE)) {
        	initialized = false;
        	initialize ();
        	return (new Boolean (true));
        }
        // This message Id is being deprecated.
        // Use JtGET_CLASS_ACCESS
        if (msgid.equals (JtAccessManager.JtCHECK_SERVICE_ACCESS)) {
            if (checkClassAccess ((String) msg.getMsgContent()))
                    return ("true");
            else
                    return ("false");
        }
        
        if (msgid.equals (JtAccessManager.JtGET_CLASS_ACCESS))
        	return (retrieveClassAccessEntry ((String) msg.getMsgContent()));

        if (msgid.equals (JtAccessManager.JtGET_COMPONENT_ACCESS))
        	return (retrieveComponentAccessEntry ((String) msg.getMsgContent()));
        
        // This message Id is being deprecated
        // Use JtGET_COMPONENT_ACCESS
        if (msgid.equals (JtAccessManager.JtCHECK_COMPONENT_ACCESS)) {
            if (checkComponentAccess ((String) msg.getMsgContent()))
                    return (new Boolean (true));
            else
                    return (new Boolean (false));
        }
        if (msgid.equals (JtObject.JtREMOVE))
        	return (null);
        
        handleError ("Invalid message Id:" + msgid);
       
        return (null);

    }
    
    
    
    /**
     * Demonstrates the messages processed by JtAccessManager.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtAccessManager accessManager;
        JtMessage msg = new JtMessage (JtAccessManager.JtCHECK_SERVICE_ACCESS);
        JtMessage msg1;
        String reply;
        Boolean bReply;
        JtXMLHelper helper = new JtXMLHelper ();
        JtPrinter printer = new JtPrinter ();
        ArrayList classList = new ArrayList ();
        JtClassAccessEntry classEntry = new JtClassAccessEntry ();
        JtComponentAccessEntry componentEntry = new JtComponentAccessEntry ();

        // Create a JtAccessManager instance       
        accessManager = (JtAccessManager) main.createObject (JtAccessManager.JtCLASS_NAME);
        accessManager.setClassAccessList("Jt.examples.HelloWorld");
        msg.setMsgContent ("Jt.examples.HelloWorld"); 

        reply = (String) main.sendMessage(accessManager, msg);
        
        if (reply.equals("true"))
            System.out.println("JtCHECK_SERVICE_ACCESS:GO");
        else
            System.out.println("JtCHECK_SERVICE_ACCESS:FAIL");       	
        //System.out.println(reply);
        
        msg1 = new JtMessage (JtAccessManager.JtCHECK_COMPONENT_ACCESS);
        msg.setMsgContent ("myComponent"); 
        
        bReply = (Boolean) main.sendMessage(accessManager, msg1);
        System.out.println(bReply);
        
        accessManager.setComponentAccessList("component1,component2");
        msg1 = new JtMessage (JtAccessManager.JtCHECK_COMPONENT_ACCESS);
        msg1.setMsgContent ("component1"); 
        
        bReply = (Boolean) main.sendMessage(accessManager, msg1);
        System.out.println(bReply);       
        
        classEntry.setClassname("Jt.examples.*");
        classEntry.setEnabled(true);
        
        classList.add(classEntry);
        
        accessManager.setClassEntryAccessList(classList);
        
        //helper.setForceJtEncoding(true);
        msg = new JtMessage (JtXMLHelper.JtXML_ENCODE); 
        msg.setMsgContent(accessManager);
        
        System.out.println("xml:\n" + helper.processMessage(msg));
        
        //main.sendMessage(accessManager, new JtMessage (JtObject.JtINITIALIZE));

        printer.processMessage(accessManager);
        
        
        accessManager = (JtAccessManager) main.createObject (JtAccessManager.JtCLASS_NAME);
        
        main.sendMessage(accessManager, new JtMessage (JtObject.JtINITIALIZE));
        
        msg1 = new JtMessage (JtAccessManager.JtGET_CLASS_ACCESS);
        msg1.setMsgContent ("Jt.examples.HelloWorld");
        
        classEntry = (JtClassAccessEntry) main.sendMessage(accessManager, msg1);
        printer.processMessage(classEntry);      
        
        msg1 = new JtMessage (JtAccessManager.JtGET_COMPONENT_ACCESS);
        msg1.setMsgContent ("MyComponent"); 
        
        componentEntry = (JtComponentAccessEntry) main.sendMessage(accessManager, msg1);
        
        printer.processMessage(componentEntry);
    

    }

}
