
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 */

package Jt.security;

import java.io.Serializable;
import java.security.Principal;

/**
 * Jt Principal
 */

public class JtPrincipal implements Principal, Serializable {

	private static final long serialVersionUID = 1L;
	private String name;


    public JtPrincipal(String name) {


    	this.name = name;
    }


    public String getName() {
    	return name;
    }


    public String toString() {
    	return(name);
    }


    public boolean equals(Object o) {
    	if (o == null)
    		return false;

    	if (this == o)
    		return true;

    	if (!(o instanceof JtPrincipal))
    		return false;
    	JtPrincipal that = (JtPrincipal)o;

    	if (this.getName().equals(that.getName()))
    		return true;
    	return false;
    }
 

    public int hashCode() {
    	return name.hashCode();
    }
}
