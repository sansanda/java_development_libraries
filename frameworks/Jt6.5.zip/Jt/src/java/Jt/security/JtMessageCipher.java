
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.security;

import java.security.Key;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.xml.JtXMLHelper;



/**
 * Jt Message Cipher. Encrypt/Decrypt messages using a symmetric session key. The session
 * key is encrypted using the public key of the recipient and included
 * as part of the encrypted message.  
 */


public final class JtMessageCipher extends JtObject {


	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtMessageCipher.class.getName();  
	private JtObject symmetricCipher = null;
	private JtObject asymmetricCipher = null;
	private boolean excludeEncryptedSessionKey = false;

	public JtMessageCipher () {
		JtFactory factory = new JtFactory ();
		
		symmetricCipher = (JtObject) factory.createObject(JtSymmetricCipher.JtCLASS_NAME);
		asymmetricCipher = (JtObject) factory.createObject(JtAsymmetricCipher.JtCLASS_NAME);
	}

	private Key sessionKey;


	/*
	 * Returns the session key.
	 */

	public Key getSessionKey() {
		return sessionKey;
	}


	/*
	 * Specifies the session key to be used for message encryption.
	 * If no session key is provided, one is automatically generated.
	 */
	
	public void setSessionKey(Key sessionKey) {
		this.sessionKey = sessionKey;
	}


	/*
	 * Returns the symmetric cipher.
	 */

	public JtObject getSymmetricCipher() {
		return symmetricCipher;
	}

	/*
	 * Specifies the component responsible for symmetric encryption.
	 * It encrypts messages using the session key. The user
	 * can change the attributes of this component (encryption algorithm,
	 * key size, etc.) or provide his/her own component.
	 */
	
	public void setSymmetricCipher(JtObject symmetricCipher) {
		this.symmetricCipher = symmetricCipher;
	}

	/*
	 * Returns the asymmetric cipher.
	 */

	public JtObject getAsymmetricCipher() {
		return asymmetricCipher;
	}

	/*
	 * Specifies the component responsible for asymmetric encryption.
	 * It encrypts the session key using the recipient's public key. The user
	 * can change the attributes of this component or provide his/her own component.
	 */

	public void setAsymmetricCipher(JtObject asymmetricCipher) {
		this.asymmetricCipher = asymmetricCipher;
	}

	/*
	 * Returns the value of excludeEncryptedSessionKey (default is false).
	 */

	public boolean isExcludeEncryptedSessionKey() {
		return excludeEncryptedSessionKey;
	}

	/*
	 * Specifies that the encrypted session key should
	 * be excluded from the message. This is usually done
	 * for the reply messages. The sender already knows
	 * the session key. No need to send it as part of the 
	 * message.
	 */

	public void setExcludeEncryptedSessionKey(boolean excludeEncryptedSessionKey) {
		this.excludeEncryptedSessionKey = excludeEncryptedSessionKey;
	}


	private Key generateSessionKey () {
		Key sessionKey;

	    sessionKey = (Key) symmetricCipher.processMessage (new JtMessage (JtSymmetricCipher.JtGENERATE_KEY));

	    if (propagateException (symmetricCipher) != null)
	    	return (null);
	    
	    return (sessionKey);

	}
	
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}

	private Object encryptMessage (Object message) {
		JtFactory factory = new JtFactory ();
		JtXMLHelper helper = new JtXMLHelper ();
		String xmlMessage;
		JtMessage msg;
		byte[] buffer;
		JtEncryptedMessage encryptedMessage = new JtEncryptedMessage ();


		if (message == null) {
			handleError ("Invalid message (null)");
			return (null);
		} 

		// Use the session key or generate one if a
		// session key is not provided.
		
		if (sessionKey == null)
			sessionKey = generateSessionKey ();

		if (sessionKey == null) {
			handleError ("Unable to generate session key (null)");
			return (null);
		}


		// Encode the message using XML 
		
		msg = new JtMessage (JtObject.JtXML_ENCODE);
		msg.setMsgContent(message);
		xmlMessage = (String) helper.processMessage(msg);

		if (propagateException (helper) != null)
			return (null);

		// Encrypt the session key using the public key of
		// the recipient.
		
		//AsymmetricCipher.setCertificatePath("/home/projects/Jt/test.cer");
		//factory.setValue(asymmetricCipher, "certificatePath", "/home/projects/Jt/test.cer");
		
		if (!excludeEncryptedSessionKey) {
			factory.setValue(asymmetricCipher, "encryptMode", "true");
			buffer = (byte[]) asymmetricCipher.processMessage(sessionKey.getEncoded());	

			if (propagateException (asymmetricCipher) != null)
				return (null);

			// Include the encrypted session key as part
			// of the encrypted message

			encryptedMessage.setEncryptedSessionKey(buffer);
		}
		
		// Encrypt the message using the session key
		
		//symmetricCipher.setKey(sessionKey);
		factory.setValue(symmetricCipher, "key", sessionKey);

		factory.setValue(symmetricCipher, "encryptMode", "true");
		buffer = (byte[]) symmetricCipher.processMessage(xmlMessage.getBytes());
		
		if (propagateException (symmetricCipher) != null)
			return (null);

		encryptedMessage.setMsgContent(buffer);
		encryptedMessage.setMsgId(JtEncryptedMessage.JtCLASS_NAME);

		return (encryptedMessage);

	}


	private Key decryptSessionKey (byte[] encSessionKey) {

		SecretKey symmetricKey = null;
		byte[] sessionKeyBytes;
		JtFactory factory = new JtFactory ();
		String algorithm = null;

		if (encSessionKey == null) {
			handleError ("Invalid session key (null).");
			return null;
		}
 		
		factory.setValue(asymmetricCipher, "encryptMode", "false");
		sessionKeyBytes = (byte[]) asymmetricCipher.processMessage(encSessionKey);

		if (propagateException (asymmetricCipher) != null)
			return (null);

		if (sessionKeyBytes == null)
			handleError ("Unable to decrypt session key");
		
		if (symmetricCipher == null) {
			handleError ("Invalid symmetric cipher (null).");
			return (null);
		}

		algorithm = (String) factory.getValue(symmetricCipher, "algorithm");
		
		if (algorithm == null) {
			handleError ("Invalid encryption algorithm (null).");
		    return (null);	
		}
		
		try {
			symmetricKey = new SecretKeySpec (sessionKeyBytes, algorithm);
		} catch (Exception ex) {
			handleException (ex);
			return (null);
		}

		return (symmetricKey);
	}

	private Object decryptMessage (JtEncryptedMessage encMessage) {

		JtMessage msg; 
		JtXMLHelper helper = new JtXMLHelper ();
		String xmlMessage;
		byte[] bArray;
		Object message;
		JtFactory factory = new JtFactory ();

		if (encMessage == null) {
			handleError ("Invalid encrypted message (null):");
			return (null);
		}
		
		if (encMessage == null) {
			handleError ("Invalid encrypted message (empty):");
			return (null);
		}


		if (sessionKey == null)
			sessionKey = decryptSessionKey (encMessage.getEncryptedSessionKey());
		
		if (sessionKey == null)
			return (null);
		
		factory.setValue(symmetricCipher, "key", sessionKey);
		
		factory.setValue(symmetricCipher, "encryptMode", "false");		

		
		bArray = (byte []) symmetricCipher.processMessage(encMessage.getMsgContent());

		if (propagateException (symmetricCipher) != null)
			return (null);
		
		if (bArray == null) {
			handleError ("Unable to decrypt message.");
			return (null); 
		}

		xmlMessage = new String (bArray);

		msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		msg.setMsgContent(xmlMessage);
		message = helper.processMessage(msg);
		
		if (propagateException (helper) != null)
			return (null);	
		
		if (bArray == null) {
			handleError ("Unable to decode XML message.");
			return (null); 
		}
		
		return (message);
	}


	/**
	 * Encrypt/Decrypt input messages.
	 * <ul>
	 * </ul>
	 */

	public Object processMessage (Object message) {


		if (message instanceof JtEncryptedMessage) {
			return (decryptMessage((JtEncryptedMessage) message));
		}


		return (encryptMessage (message));
		//handleError ("invalid message Id:" + e.getMsgId());
		//return (super.processMessage(message));

	}
	public static void main (String args[]) {
		JtFactory factory = new JtFactory ();

		JtMessageCipher cipher;
		JtEncryptedMessage encryptedMessage;

		JtPrinter printer = new JtPrinter ();
		Object reply;
		Key sessionKey = null;
		JtObject symmetricCipher;

		
		cipher = (JtMessageCipher) factory.createObject (JtMessageCipher.JtCLASS_NAME);
		
		// Retrieve symmetric cipher and use it to generate
		// a session key.
		
		symmetricCipher = cipher.getSymmetricCipher();
	    sessionKey = (Key) factory.sendMessage(symmetricCipher, new JtMessage (JtSymmetricCipher.JtGENERATE_KEY));
		
		cipher.setSessionKey(sessionKey);


		encryptedMessage = (JtEncryptedMessage) factory.sendMessage (cipher, "Welcome to Jt messaging ...");

		printer.processMessage(encryptedMessage);

		// Uncomment this section in order for
		// the encrypted session key (included in the 
		// encrypted message) to be used.
		
		cipher.setSessionKey(null);
		reply = factory.sendMessage (cipher, encryptedMessage);


		printer.processMessage(reply);
		
		if (reply != null && reply.equals("Welcome to Jt messaging ..."))
			System.err.println ("JtCipher:PASS");
		else
			System.err.println ("JtCipher:FAIL");			

	}

}
