/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt.security;

import java.io.Serializable;


/**
 * Class Access Entry.
 */

public class JtClassAccessEntry implements Serializable  {
    
    

    private static final long serialVersionUID = 1L;

    private String classname;
    private boolean encrypted;
    private boolean enabled;
    private boolean authenticated;

    /**
     * Returns the classname.
     */
    
	public String getClassname() {
		return classname;
	}

    /**
     * Specifies the classname.
     */
	
	public void setClassname(String classname) {
		this.classname = classname;
	}

	
    /**
     * Returns the encryptedMessaging flag.
     */
	
	public boolean isEncrypted() {
		return encrypted;
	}

    /**
     * Specifies whether or not encrypted messaging is required.
     */
	public void setEncrypted(boolean encrypted) {
		this.encrypted = encrypted;
	}

    /**
     * Returns the value of the 'enabled' flag.
     */
	
	public boolean isEnabled() {
		return enabled;
	}

    /**
     * Specifies whether or not access to this class is enabled.
     */
	
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

    /**
     * Returns the value of the authenticated flag.
     */
	
	public boolean isAuthenticated() {
		return authenticated;
	}

    /**
     * Specifies whether or not messaging should be authenticated.
     */
	
	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}
    
}
