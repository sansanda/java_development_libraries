package Jt.security;


import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOStrategy;

/**
 * User role. This class represents the role associated to the user. 
 * JtDAOAccessManager relies on roles in order to grant 
 * access to specific framework objects.
 */

public class UserRole extends JtObject {
    

    private static final long serialVersionUID = 1L;
    
    // Messages
    
    public static final String RETRIEVE_USER_ROLE = "RETRIEVE_USER_ROLE";
    
    private JtFactory factory = new JtFactory ();
    private transient JtDAOStrategy daoAdapter;
    private transient boolean init = false;
    
    private String userId;
    private String roleId;

    /**
     * Returns the user Id.
     */
    
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the user Id.
     */
    
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Returns the role Id.
     */
    
    public String getRoleId() {
        return roleId;
    }
    
    /**
     * Sets the role Id.
     */

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }


    
    private void initialize () {
        daoAdapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME);
        //adapter.setCheckAccess(true);        
    }
    
    
    private Exception propagateException (JtObject obj) {
        Exception ex;
        
        if (obj == null)
            return (null);
        
        ex = (Exception) obj.getObjException();
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    
    private String retrieveUserRole (String userId) {
        JtMessage msg = new JtMessage (JtObject.JtREAD);
        UserRole userRole;
        
        msg.setMsgContent(new UserRole ());
        msg.setMsgData (userId);
        
        userRole = (UserRole) factory.sendMessage(daoAdapter, msg);
        
        if (propagateException (daoAdapter) != null)
            return (null);
        
        factory.sendMessage (daoAdapter, new JtMessage (JtObject.JtREMOVE));
        
        if (userRole == null)
            return (null);
        
        return (userRole.getRoleId());
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {
        
        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        if (!init) {
            initialize ();
            init = true;
        }      

        if (e.getMsgId().equals(UserRole.RETRIEVE_USER_ROLE)) {
                        
            return (retrieveUserRole ((String) e.getMsgContent()));
        }
        

        
        return (super.processMessage(message));

    }    

}
