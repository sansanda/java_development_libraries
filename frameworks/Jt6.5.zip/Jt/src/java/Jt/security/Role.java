package Jt.security;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.DAO.JtDAOAdapter;
import Jt.DAO.JtDAOStrategy;

/**
 * Framework role. The standard roles are "user" and "administrator".
 * 
 */

public class Role extends JtObject implements Comparable {
    
    

    private static final long serialVersionUID = 1L;
    //public static final String DEFAULT = Role.OWNER;
    
    // Standard roles
    
    public static final String USER = "user";
    public static final String ADMINISTRATOR = "administrator";
    public static final String OWNER = "owner";
    
    public static final String WILDCARD = "*";
    
    public static final String JtCLASS_NAME = Role.class.getName(); 
    
    // Messages
    
    public static final String RETRIEVE_ALL_ROLES = "RETRIEVE_ALL_ROLES";

    private transient JtFactory factory = new JtFactory ();
    
    private String roleId;
    private String description;

    /**
     * Returns the role Id.
     */
    
    public String getRoleId() {
        return roleId;
    }

    /**
     * Sets the role Id
     */
    
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
     * Returns the role description.
     */
    
    public String getDescription() {
        return description;
    }

    /**
     * Sets the role description.
     */
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    private Exception propagateException (Object obj) {
        Exception ex;
        JtFactory factory;
        
        if (obj == null)
            return (null);
        
        factory = new JtFactory ();
        
        ex = (Exception) factory.getValue(obj, "objException");
        
        if (ex != null) {
            this.setObjException(ex);
        }  
        return (ex);
    }
    

    private void addStandardRoles (List roleList) {
        Role role = new Role ();
        
        if (roleList == null)
            return;
        
        role.setRoleId(Role.WILDCARD);
        
        roleList.add(role);
        
        /*
        if (!roleList.contains (role))
            roleList.add(0, role);
        
        role = new Role ();
        role.setRoleId(Role.ADMINISTRATOR);
        
        if (!roleList.contains (role))
            roleList.add(0, role);
        */
    }


    
    private List retrieveAllRoles () {
        
        JtMessage msg = new JtMessage ();
        List result;
        String query = "select * from role"; // check - configuration file
        JtDAOStrategy adapter; 

        
        adapter = (JtDAOStrategy) factory.createObject (JtDAOStrategy.JtCLASS_NAME); 
        adapter.setCheckAccess(false); 
        
        msg.setMsgId (JtDAOAdapter.JtEXECUTE_QUERY); // check


        msg.setMsgContent(query);
       
       
        msg.setMsgData(new Role ());
                
        
        result = (List) factory.sendMessage (adapter, msg);
        
        propagateException (adapter);
        
        if (result == null)
            result = new LinkedList ();
            
        Collections.sort(result);
        
        addStandardRoles (result);
        
        factory.sendMessage (adapter, new JtMessage (JtObject.JtREMOVE));
        return (result);
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {

        //ActionForm form = null;
        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
                  
        
        if (e.getMsgId().equals(Role.RETRIEVE_ALL_ROLES)) {
            
            return (retrieveAllRoles ());
        }
           
        

        return (super.processMessage(message));

    }



    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;

        if (roleId == null)
            return (false);
        
        return (roleId.equals(((Role) obj).getRoleId()));

    }

    public int compareTo(Object obj) {
        String str;
        if (this == obj)
            return 0;
        if (obj == null)
            return -1;
        if (getClass() != obj.getClass())
            return -1;
        
            
        str = ((Role) obj).getRoleId();
        
        if (roleId == null)
            return -1;
        return (roleId.compareTo (str));

    }
}
