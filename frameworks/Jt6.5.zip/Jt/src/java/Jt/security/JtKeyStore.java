
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 */

package Jt.security;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;


/**
 * KeyStore component for cryptographic keys and certificates.
 */


public final class JtKeyStore extends JtObject {
	

    private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtKeyStore.class.getName(); 
	public static final String JtGET_CERTIFICATE = "JtGET_CERTIFICATE";
    private String path;
    private String password;
    private String alias = "Jt";
    private String resourcePath = "Jt.ks";
    private KeyStore ks = null;
    private boolean initialized = false;
          
	/**
	  * Returns the keystore path.
	  */
    
    public String getPath() {
		return path;
	}

	/**
	  * Specifies the keystore path.
	  */
    
	public void setPath(String path) {
		this.path = path;
	}

	/**
	  * Retrieves the private key.
	  */
	
	public PrivateKey getPrivateKey() {
		
        if (!initialized) {
        	initialized = initialize ();
        	
        	if (!initialized)
        		return (null);
        }
		
		return retrievePrivateKey ();
	}

	
	// void operation
	
	public void setPrivateKey(PrivateKey privateKey) {
		//this.privateKey = privateKey;
	}

	/**
	  * Returns the keystore password.
	  */
	
    public String getPassword() {
		return password;
	}

	/**
	  * Specifies the keystore password.
	  */
    
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	/**
	  * Returns the keystore alias.
	  */
	
	public String getAlias() {
		return alias;
	}

	/**
	  * Returns the keystore alias.
	  */
	
	public void setAlias(String alias) {
		this.alias = alias;
	}

	/**
	  * Returns the resource path.
	  */
	
	public String getResourcePath() {
		return resourcePath;
	}
	
	
	/**
	  * Specifies the resource path. The KeyStore will be located via the CLASSPATH.
	  */
	
	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	
	private Certificate retrieveCertificate (String alias) {

    	Certificate cert;
		    	
    	
	   	try {
    		    		
    		cert = ks.getCertificate(alias);

    		return (cert);
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);

    	}	
	} 
	
	
	private boolean initialize () {
		InputStream stream = null; 
    	String ksType = KeyStore.getDefaultType();
		
		if (password == null) {
			handleError ("password attribute needs to be set.");
			return (false);			
		}
		
    	if (alias == null) {
    		handleError ("alias attribute needs to be set.");
    		return (false);
    	}
		
    	if (path == null && resourcePath == null) {
    		
    		handleError ("Either resourcePath (or path) needs to be set.");
    		return (false);
    	}
    	
    	if (path != null && resourcePath != null) {
    		
    		handleError ("Either resourcePath (or path) needs to be set (not both).");
    		return (false);
    	}
    	
    	if (resourcePath != null) {
    		stream = Thread.currentThread().getContextClassLoader().getResourceAsStream (resourcePath);
    		
    		if (stream == null) {
    			handleError ("Unable to access resource:" + resourcePath);
    			return (false);				
    		}
    	}
    	
    	if (path != null) {
    		try {
    			stream = new FileInputStream (path);

    		} catch (Exception ex) {
    			handleException (ex);
    			return (false);

    		}
    	}
    	
    	
	   	try {
    		ks = KeyStore.getInstance(ksType);
    		
    		ks.load(stream, password.toCharArray());
    		stream.close();
    		    		
    		return (true);
    	} catch (Exception ex) {
    		handleException (ex);
    		return (false);
    	}
    	
	}
	
	
    public Object processMessage (Object message) {

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        
        if (!initialized) {
        	initialized = initialize ();
        	
        	if (!initialized)
        		return (null);
        }
        
        if (e.getMsgId().equals(JtKeyStore.JtGET_CERTIFICATE))  
        	return (retrieveCertificate ((String) e.getMsgContent()));
        
        handleError ("invalid message Id:" + e.getMsgId());

        return (null);

    }
	
	private PrivateKey retrievePrivateKey () {
    	
    	PrivateKey privateKey;
    	

    	try {
    		privateKey = (PrivateKey) ks.getKey (alias, password.toCharArray());
    	} catch (Exception ex) {
    		handleException (ex);
    		return (null);
    	}
    	return (privateKey);



    }
	
    /*
     * Demonstrate the messages handled by this component.
     */
    
    public static void main (String args[]) {
    	JtFactory factory = new JtFactory ();
    	JtKeyStore keyStore;
    	JtMessage msg = new JtMessage (JtKeyStore.JtGET_CERTIFICATE);
    	Certificate cert;
    	
    	keyStore = (JtKeyStore) factory.createObject (JtKeyStore.JtCLASS_NAME);
    	
    	//keyStore.setResourcePath("Jt.ks");
    	//keyStore.setPassword("password");
    	//keyStore.setAlias ("test");
    	
    	msg.setMsgContent("jt");
    	
    	cert = (Certificate) factory.sendMessage(keyStore, msg);
    	
    	System.out.println(cert);
    	
    	System.out.println(keyStore.getPrivateKey());
    	
    }
    
}
