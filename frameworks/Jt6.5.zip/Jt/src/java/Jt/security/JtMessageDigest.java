package Jt.security;
import java.security.MessageDigest;

import org.apache.struts.action.ActionForm;

import Jt.JtContext;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.portal.JtAccount;

import sun.misc.BASE64Encoder;


/**
 * Message digest
 */


public final class JtMessageDigest extends JtObject {

    private static final long serialVersionUID = 1L;

    public synchronized String encrypt(String plaintext)
    {
        MessageDigest md = null;
        try
        {
            md = MessageDigest.getInstance("SHA"); 
        }
        catch(Exception e)
        {
            handleException (e);
            return (null);
        }
        try
        {
            md.update(plaintext.getBytes("UTF-8")); 
        }
        catch(Exception e)
        {
            handleException (e);
            return (null);
        }
        byte raw[] = md.digest(); 
        String hash = (new BASE64Encoder()).encode(raw); 
        return hash; 
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {

        ActionForm form = null;
        JtContext context;

        

        JtMessage e = (JtMessage) message;

        if (e == null ||  (e.getMsgId() == null))
            return (null);
        


        context = (JtContext) e.getMsgContext();
 

        if (e.getMsgId().equals(JtObject.JtACTIVATE)) {
            
            
            return (encrypt((String) e.getMsgContent()));


        }
        
        return (super.processMessage(message));

    }

    
}
