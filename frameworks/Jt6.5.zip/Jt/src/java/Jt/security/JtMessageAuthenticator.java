/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.security;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JAAS.JtJAASAdapter;



/**
 * Message Authenticator. It relies on the framework JAAS adapter.
 */


public final class JtMessageAuthenticator extends JtObject {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtMessageAuthenticator.class.getName(); 
    private boolean initialized = false;
    private JtJAASAdapter adapter;
    private JtFactory factory = new JtFactory ();

    
    
    private boolean initialize () {
    	
        adapter = (JtJAASAdapter) factory.createObject (JtJAASAdapter.JtCLASS_NAME);
        
        
        return (true);
    }

    // Authenticate the message
    
    private boolean authenticate (JtMessage msg)
    {
    	JtContext context;
    	JtMessage msg1;
    	Boolean Bool;
    	
    	if (msg == null)
    		return false;
    	
    	context = (JtContext) msg.getMsgContext();
    	
    	if (context == null) {
    		handleError ("Invalid context (null)");
    		return false;
    	}
    	
    	if (adapter == null)
    		return false;
    	
    	if (context.getUserName() == null) {
    		handleError ("Invalid username (null)");
    		return false;
    	}
    	
    	if (context.getPassword() == null) {
    		handleError ("Invalid password (null)");
    		return false;
    	}
    	
    	adapter.setUsername(context.getUserName());
    	adapter.setPassword(context.getPassword());

 
    	// Try to log in
    	
    	msg1 = new JtMessage (JtJAASAdapter.JtLOGIN);
    	  	
    	Bool = (Boolean) adapter.processMessage(msg1);
    	
    	adapter.setUsername(null);
    	adapter.setPassword(null); 
    	
    	if (Bool == null || !Bool.booleanValue())
    		return (false);
    	
    	// Log out
    	
    	msg1 = new JtMessage (JtJAASAdapter.JtLOGOUT);
	  	
    	adapter.processMessage(msg1);
    	
    	return (true);
    }
    
    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param message message
     */

    public Object processMessage (Object message) {

    	// Reset exceptions
    	
    	this.setObjException(null);
    	if (message == null) {
    		handleError ("invalid message (null)");
    		return null;
    	}
    	
        if (!(message instanceof JtMessage)) {
        	handleError ("Invalid message format:" + message.getClass().getName());
        	return (null);
        }

        if (!initialized) {
        	initialized = initialize ();        }

    	return (new Boolean (authenticate ((JtMessage) message)));

    }

    /**
     * Demonstrates the messages processed by JtMessageAuthenticator.   
     */

   public static void main(String[] args) {
 	 //JtMessage msg = new JtMessage (JtJAASAdapter.JtLOGIN);
     JtFactory factory = new JtFactory ();
     JtMessageAuthenticator messageAuthenticator;
     Boolean Bool;
     


     // Create an instance of JtMessageAuthenticator
    
     messageAuthenticator = (JtMessageAuthenticator) factory.createObject(JtMessageAuthenticator.JtCLASS_NAME);
     
     
     // Create the message to be authenticated
     
     JtMessage message = new JtMessage ();
     JtContext context = new JtContext ();

     message.setMsgContext(context);
     
     // Set username & password
     
     context.setUserName("jt");
     context.setPassword("messaging");
    
     // The JAAS configuration file for this
     // example looks like the following:
     
     //Jt {
     //	  Jt.JAAS.JtLoginModule required
     //	  loginVerificationClassname="Jt.examples.LoginStrategy";    	    
     //};
     
     // Try to authenticate the message
     
     Bool = (Boolean) factory.sendMessage(messageAuthenticator, message);
     
     if (Bool == null || !Bool.booleanValue())
     	System.out.println("Authentication: fail");
     else
     	System.out.println("Authentication: pass");    	
     

     
   }   
}
