
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 */



package Jt.security;
import java.io.FileInputStream;
import java.security.cert.Certificate;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import Jt.JtObject;



/**
 * Handles identity certificates
 */


public final class JtCertificate extends JtObject {
	

    private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtCertificate.class.getName(); 
    private PublicKey publicKey = null;
    private String path = null;
    private String type = "X.509";
    private Certificate certificate;
    
    private boolean initialized = false;

      
	/**
	  * Returns the certificate path.
	  */
    
    public String getPath() {
		return path;
	}
    
	/**
	  * Specifies the certificate path.
	  */

	public void setPath(String path) {
		this.path = path;
	}

	/**
	  * Returns the public key.
	  */
	
	public PublicKey getPublicKey() {
		
		if (!initialized) {
			initialized = initialize ();
			
			if (!initialized)
				return (null);
		}
		
		if (certificate == null)
			return (null);
		
		publicKey = certificate.getPublicKey();
		
		return publicKey;
	}

	// void operation
	
	public void setPublicKey(PublicKey publicKey) {
		//this.publicKey = publicKey;
	}

	/**
	  * Returns the certificate type.
	  */
	
	public String getType() {
		return type;
	}

	/**
	  * Returns the certificate type. The default is X.509.
	  */
	
	public void setType(String type) {
		this.type = type;
	}

	/**
	  * Returns the certificate.
	  */

	public Certificate getCertificate() {
		return certificate;
	}

	// void operation
	
	public void setCertificate(Certificate certificate) {
		//this.certificate = certificate;
	}

	
	
	
	private boolean initialize () {
    	
    	if (path == null) {
    		handleError ("Path attribute needs to be set.");
    		return (false);
    	}
		
    	if (type == null) {
    		handleError ("Type attribute needs to be set.");
    		return (false);
    	}		
    	
    	try {
    		FileInputStream fis = new FileInputStream (path);
    		CertificateFactory cf = CertificateFactory.getInstance(type);
    		
    		certificate = cf.generateCertificate(fis);
    		fis.close();
    		
    		if (certificate == null)
    			return (false);
    		
    		return (true);
    		
    	} catch (Exception ex) {
    		handleException (ex);
    		return (false);
    	}
    	
    }

    
}
