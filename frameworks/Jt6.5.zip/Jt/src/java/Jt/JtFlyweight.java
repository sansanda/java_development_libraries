/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;


/**
 * Jt Implementation of the Flyweight pattern.
 */

public class JtFlyweight extends JtComponent {

  public static final String JtCLASS_NAME = JtFlyweight.class.getName();
  private static final long serialVersionUID = 1L;
  private Object factory = null;
  
  // Messages
  
  public static final String JtGET_FLYWEIGHT = "JtGET_FLYWEIGHT"; 
  public static final String JtCREATE_FLYWEIGHT = "JtCREATE_FLYWEIGHT";   

  public JtFlyweight () {
  }



/**
  * Specifies the factory.
  *
  * @param factory factory
  */

  public void setFactory (Object factory) {
     this.factory = factory; 

  }

/**
  * Returns the factory.
  */

  public Object getFactory () {
     return (factory);
  }




  /**
    * Process object messages.
    * <ul>
    * <li> JtGET_FLYWEIGHT- Returns the flyweight specified by msgContent if it exists.
    * If it doesn't exist, create it (by sending JtCREATE_FLYWEIGHT to the factory) and return it. 
    * </ul>
    * @param message Jt Message
    */


  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage e = (JtMessage) message;
      //Object content;
      //Object data;
      JtMessage tmp;
      JtInterface aux, aux1;
      JtFactory fact = new JtFactory ();



      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;

      //content = e.getMsgContent();
      //data = e.getMsgData ();

      // Remove this object
      if (msgid.equals (JtObject.JtREMOVE)) {
          return (null);     
      }


      if (msgid.equals (JtFlyweight.JtGET_FLYWEIGHT)) {
          tmp = new JtMessage (JtComposite.JtGET_CHILD);
          tmp.setMsgContent (e.getMsgContent ());
          aux = (JtInterface) super.processMessage (tmp);

          if (aux != null)
              return (aux); 


          if (factory == null) { 
              handleError ("processMessage: factory attribute needs to be set");
              return (null);
          }

          handleTrace ("Jt.Flyweight: processMessage creating a new flyweight");

          tmp = new JtMessage (JtFlyweight.JtCREATE_FLYWEIGHT);
          tmp.setMsgContent (e.getMsgContent ());

          aux1 = (JtInterface) fact.sendMessage (factory, tmp);

          tmp = new JtMessage (JtComposite.JtADD_CHILD);
          tmp.setMsgContent (aux1);
          super.processMessage (tmp);
          return (aux1);


      }


      return (super.processMessage (message));


  }

 
  /**
   * Demonstrates the messages processed by JtFlyweight.
   */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();

    JtFlyweight flyweightp;

    // Create an instance of JtFlyweight

    flyweightp = (JtFlyweight) main.createObject (JtFlyweight.JtCLASS_NAME);



  }

}


