

package Jt;
import java.util.*;

import Jt.examples.Test;


/**
 * Jt implementation of the Composite design pattern. 
 */

public class JtComposite extends JtPrototype {

  public static final String JtCLASS_NAME = JtComposite.class.getName(); 
  private static final long serialVersionUID = 1L;
  public static final String JtREMOVE_CHILD = "JtREMOVE_CHILD";
  public static final String JtADD_CHILD = "JtADD_CHILD";
  public static final String JtGET_CHILD = "JtGET_CHILD";
  public static final String JtGET_CHILDREN = "JtGET_CHILDREN";
  //private transient Iterator iterator;
  private  Hashtable hashtable = new Hashtable (); 
  //private List list = new ArrayList (); // Stores the components using a list.
  private List list = null;
  private boolean useToString = true;
  private boolean initialized = false;
  

  public JtComposite () {
  }


  
  /**
   * Returns and iterator over the composite.
   */ 
  
  /*
  public synchronized Iterator getIterator () {
      
      if (list == null)
    	  return (null);
      
      return (list.iterator());

  }
  */
  /**
   * Void operation.
   */
  
  public void setIterator () {
 

  }
  /**
   * Returns the internal list. For internal use only.
   */ 

  public synchronized List getList() {
      return list;
  }

  /**
   * Void operation.
   */
  
  public void setList(List list) {
	  this.list = list;
  
  }

  /**
   * Returns the value of useToString. Determines whether or not
   * the String representation of the object should be used as the
   * key. The default is true.
   */ 
  
  public boolean isUseToString() {
	  return useToString;
  }

  /**
   * Sets the value of useToString.
   */ 

  public void setUseToString(boolean useToString) {
	  this.useToString = useToString;
  }



  private synchronized boolean create (Object id) {
	  if (id == null) {
		  handleError ("Invalid parameters");
		  return (false);
	  }

	  if (read (id) != null) {
		  return (false);
	  }

	  if (useToString)
		  hashtable.put (id.toString(), id);


	  return (list.add(id));
  }
  
  private synchronized boolean remove (Object id) {
	  //int index;
	  Object obj;

	  if (id == null) {
		  handleError ("Invalid parameters");
		  return (false);
	  }
	  /*
	  index = list.indexOf(id);

	  if (index < 0) {
		  handleError ("component not found:" + id);
		  return;
	  }
	  if (useToString) {
		  hashtable.remove (id.toString());
	  }
	  */
	  obj = read (id);
	  if (obj != null)  {	  
		  if (useToString) {
			  hashtable.remove (id.toString());
		  }

		  return (list.remove (obj));
	  }	  
	  return (false);

  }
  
  private synchronized Object read (Object id) {
	  int index;
	  
	  if (id == null) {
		  handleError ("Invalid parameters");
		  return null;
	  }

	  if (useToString) {
		  return (hashtable.get (id.toString()));
	  }
	  
      index = list.indexOf(id);
      
      if (index >= 0)
      	return (list.get(index));
      
      return (null);

  }

  // Broadcast a message

  private synchronized void broadcastMessage (Object msg)
  {
      Object obj;
      JtMessage msg1;
      JtFactory factory = new JtFactory ();
      Iterator iterator;
      
      if (msg == null || list == null)
          return;


      iterator = list.iterator();
      
      while (iterator.hasNext()) {
    	  
          obj = iterator.next ();  
          if (!(obj instanceof JtInterface)) {
        	  handleWarning ("JtComposite.broadcast: unable to broadcast message to " + obj);
              continue;
          }    
          if (obj instanceof JtComposite) {
        	  handleTrace ("JtComposite.broadcast: broadcasting to composite:" + obj);
              msg1 = new JtMessage (JtObject.JtBROADCAST);
              msg1.setMsgContent(msg);
              factory.sendMessage (obj, msg1);
              continue;
          }  
          factory.sendMessage (obj, msg);
      }


  }

  private synchronized boolean initialize () {
	  list = new ArrayList ();
	  
	  return (true);
  }

  /**
    * Process object messages.
    * <ul>
    * <li> JtADD_CHILD - Adds the component (msgContent) to this composite. 
    * If useToString is true the String representation  of the object (toString) is used as the key.
    * <li> JtREMOVE_CHILD - Removes a component (msgContent) from this composite. 
    * If useToString is true, the String representation of the object 
    * is used as the key. 
    * <li> JtGET_CHILD - Returns the component specified by msgContent or null if it
    * doesn't exist. If useToString is true, the String representation of the object 
    * is used as the key.
    * <li> JtBROADCAST - Broadcasts a message (msgContent) to all the components
    * in this composition.
    * <li>JtREMOVE - Broadcasts JtREMOVE to all the component in this composition.
    * </ul>
    */

  public Object processMessage (Object message) {

   String msgid = null;
   JtMessage e = (JtMessage) message;
   Object content;


     if (e == null)
	return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	return null;

     content = e.getMsgContent();
     //data = e.getMsgData ();

     if (!initialized) {
    	 initialized = true;
    	 initialize ();
     }
     // Remove the composite
     if (msgid.equals (JtObject.JtREMOVE)) {
       // send JtREMOVE to all the members of the composite  
       broadcastMessage (new JtMessage (JtObject.JtREMOVE));  
       list.clear();
       return (null);     
     }

     if (msgid.equals (JtComposite.JtADD_CHILD)) {
        
        return (new Boolean (create (content)));
     }     


     if (msgid.equals (JtComposite.JtREMOVE_CHILD))

        return new Boolean (remove (content));
  

     if (msgid.equals (JtComposite.JtGET_CHILD)) {


        return (read (content));

     }  
     
     if (msgid.equals (JtComposite.JtGET_CHILDREN))
         return (list);
 

     // Broadcast a message to all the components

     
     if (msgid.equals (JtObject.JtBROADCAST)) {
     
       broadcastMessage (content);

       return (null);
     }

  
     return (super.processMessage (message));
     

  }

   /**
   * Demonstrates the messages processed by JtComposite. 
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtComposite composite, composite1;
    Double leaf1 = new Double (1.0);
    Double leaf2 = new Double (2.0);
    Double leaf3 = new Double (3.0);  
    Test leaf4 = new Test ();
    leaf4.setComponentId("myleaf");
    
    Test leaf = new Test ();
    leaf.setComponentId("myleaf");
    
    Test oLeaf;
    
    JtMessage msg;
    JtPrinter printer = new JtPrinter ();
  
    leaf4.setComments("comments");
    
    // Create an instance of JtComposite

    composite = (JtComposite) factory.createObject (JtComposite.JtCLASS_NAME);
    
    
    // Add objects to the composite
        
    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(leaf1);     
    factory.sendMessage(composite, msg);   
    
    msg.setMsgContent(leaf2);
    factory.sendMessage(composite, msg);
    
    msg.setMsgContent(leaf4);
    factory.sendMessage(composite, msg);
        
    composite1 = (JtComposite) factory.createObject (JtComposite.JtCLASS_NAME);    
    
    msg.setMsgContent(leaf3);
    factory.sendMessage(composite1, msg);
    
    msg = new JtMessage (JtComposite.JtADD_CHILD);
    msg.setMsgContent(composite1);
    factory.sendMessage(composite, msg);
    
    // Print the composite (XML format)
    
    //factory.sendMessage(composite, new JtMessage (JtObject.JtPRINT));
    factory.sendMessage(printer, composite);
    
    // Manipulate the composite
    
    msg = new JtMessage (JtComposite.JtGET_CHILD);
    msg.setMsgContent(leaf);
    oLeaf = (Test) factory.sendMessage(composite, msg);
    System.out.println ("leaf1 = " + factory.sendMessage(composite, msg));
    factory.sendMessage(printer, oLeaf);
    
    msg = new JtMessage (JtComposite.JtREMOVE_CHILD);
    msg.setMsgContent(leaf2);
    factory.sendMessage(composite, msg); 
    
    // Print the composite (XML format)
    
    //factory.sendMessage(composite, new JtMessage (JtObject.JtPRINT));
    
    
    factory.sendMessage(printer, composite);
    
    msg = new JtMessage (JtObject.JtBROADCAST);
    msg.setMsgContent (new JtMessage (JtObject.JtPRINT));

    System.out.println 
    ("JtComposite(JtBROADCAST): broadcast a message to the composite ...");

    factory.sendMessage (composite, msg);
    
    // Clone the composite. This functionality is inherited from JtPrototype
    
    System.out.println 
    ("JtComposite(JtBROADCAST): clone the composite ...");
    
    JtComposite composite3 = (JtComposite) factory.sendMessage (composite, new JtMessage (JtObject.JtCLONE));
    
    factory.sendMessage (composite, new JtMessage (JtObject.JtPRINT));
    
    factory.sendMessage(composite, new JtMessage (JtObject.JtREMOVE));
  
    
    //factory.sendMessage (composite, new JtMessage (JtObject.JtTEST));
    //factory.removeObject ("composite");


  }

}


