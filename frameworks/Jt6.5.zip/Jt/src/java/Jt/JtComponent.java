/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;


/**
 * Jt component. This class inherits functionality from several design patterns (JtPrototype and JtComposite).
 * It also inherits from JtThread. This component can execute using a separate/independent thread and 
 * process messages (requests) asynchronously via a message queue.
 */

public class JtComponent extends JtThread {

  public static final String JtCLASS_NAME = JtComponent.class.getName(); 
  private static final long serialVersionUID = 1L;
  private boolean synchronous = true;


  public JtComponent () {
  }

  /**
   * Verifies if this component should process messages synchronously or asynchronously
   * via a message queue and a separate thread. The default is true (synchronously).
   * This attribute is being deprecated. It is being moved to JtFactory (messenger).
   */

   public boolean getSynchronous () {
     return (synchronous);
   }

 /**
   * Specifies synchronous/asynchronous mode of processing messages.
   * This attribute is being deprecated.
   */

   public void setSynchronous (boolean synchronous) {
     this.synchronous = synchronous;
   }

   /**
    * Enqueues a message for asynchronous processing.
    */

    synchronized public Object enqueueMessage (Object msg)
    {

      //if (synchronous)
      // return (processMessage (msg));
      //else
       return (super.enqueueMessage (msg)); 

    }
   
  /**
    * Process object messages.
    */

  public Object processMessage (Object message) {


      // Let the superclass handle the messages

      if (message instanceof JtMessage) 
      	return (super.processMessage (message));         
      else {
      	handleError ("Invalid message:" + message);
      	return (null);
      }	

  }

 


}


