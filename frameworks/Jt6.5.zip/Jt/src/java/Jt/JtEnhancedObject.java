package Jt;


/**
 * Enhanced JtObject. It inherits from several design pattern classes.
 * This class is being deprecated. Use JtComponent instead.
 */

public class JtEnhancedObject extends JtCommand {

  public static final String JtCLASS_NAME = JtEnhancedObject.class.getName(); 
  private static final long serialVersionUID = 1L;


  public JtEnhancedObject () {
  }


  /**
    * Process object messages.
    * <ul>

    * </ul>
    */

  public Object processMessage (Object event) {

      String msgid = null;
      JtMessage e = (JtMessage) event;



      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;


      return (super.processMessage (event)); 


  }

 


}


