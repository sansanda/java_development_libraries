/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;
import java.net.*;
import java.io.*;


/**
 * Class used to handle URLs.
 */

public class JtURL extends JtObject {

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtURL.class.getName(); 
    public static final String JtDOWNLOAD = "JtDOWNLOAD";
    public static final String POST = "POST";
    //public final static int MAX_LENGTH = 1024 * 30;
    private long maxLength;

    private String url;
    InputStream stream;
    BufferedInputStream bstream;
    transient private URL someurl;

    public JtURL() {
    }

    /**
     * Specifies the URL.
     * @param newUrl url
     */

    public void setUrl(String newUrl) {
        url = newUrl;
    }


    /**
     * Returns the URL.
     */
    public String getUrl() {
        return url;
    }

    /**
     * Return maxLength. Trying to read a resource which size is bigger than
     * maxLength will fail. An error will be produced via handleError ().
     * The default is 0 (no limitation). maxLength only applies to JtDOWNLOAD/JtREAD  
     */
    
    public long getMaxLength() {
		return maxLength;
	}

    /**
     * Sets the max length. 
     * @param maxLength Max length
     */
    
	public void setMaxLength(long maxLength) {
		this.maxLength = maxLength;
	}

	String download () {
        //int available;
        String line;
        BufferedReader d = null;  
        URLConnection connection;
        StringBuffer result = new StringBuffer();
        long cnt = 0L;

        if (url == null)
            return (null);

        try {
            someurl = new URL (url);
            connection = someurl.openConnection ();
            //connection.setConnectTimeout(5000);
            connection.connect ();

            //stream = someurl.openStream ();
            stream = connection.getInputStream ();

            d = new BufferedReader (new InputStreamReader (stream));

            while ((line  = d.readLine ()) != null) {           
                //System.out.println (line);
            	if (maxLength > 0) {
            		cnt += line.length();
            		if (cnt > maxLength) {
                        handleError ("maxLenth exceeded:" + maxLength);
                        return (null);
            		}
            	}
                result.append (line + "\n"); 
            }

            // close streams
            if (stream != null)
                stream.close ();
            if (d != null)
                d.close ();
            return (result.toString ());
        } catch (Exception ex) {
            handleException (ex);
            return (null);
        } 
    } 
    
    // Post request
    
    private String doPost (String request) {
    	URLConnection urlConn;
    	URL destURL;
    	DataOutputStream outStream;
    	DataInputStream inStream;
    	int c;
    	StringBuffer sBuffer = new StringBuffer ();
    	
    	if (request == null)
    		return null;
    	
    	if (url == null)
    		return null;
    	
    	handleTrace ("request:" + request);
    	
    	try {
    	 
    		destURL = new URL (url);
    		
    		urlConn = destURL.openConnection();
    		urlConn.setDoOutput(true);    		
    		urlConn.setDoInput(true);
    		
    		
    		//urlConn.setRequestProperty("Content-type", 
    		//		"application/octet-stream");
    		urlConn.setRequestProperty("Content-length", 
    				"" + request.length());
    		
    		outStream = new DataOutputStream (urlConn.getOutputStream());
    		
    		outStream.writeBytes(request);
    		
    		outStream.close ();
    		
    		inStream = new DataInputStream (urlConn.getInputStream());  		
    		
    		while ((c = inStream.read()) >= 0) {
    			sBuffer.append((char) c);
    		}
    	} catch (Exception ex) {
    		handleException (ex);
    	}
    	
    	return ((String) sBuffer.toString());
    	
    }

    /**
     * Process object messages. 
     * <ul>
     * <li> JtDOWNLOAD/JtREAD - Download the URL and returns its content.
     * </ul>
     * @param message Jt Message    
     */

    public Object processMessage (Object message) {

        String msgid = null;

        JtMessage e = (JtMessage) message;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtURL.JtDOWNLOAD) || msgid.equals (JtObject.JtREAD)) {
            return (download ());
        }
        
        if (msgid.equals (JtURL.POST)) {
            return (doPost ((String)e.getMsgContent()));
        }

        return (super.processMessage(message));

    }


    /**
     * Demonstrates the messages processed by JtURL. Usage: java Jt.JtURL url    
     */

    public static void main (String args[]) {
        JtFactory main = new JtFactory ();
        JtMessage msg;

        if (args.length < 1) {
            System.err.println ("Usage: java Jt.JtURL url");
            System.exit (1);
        }

        main.createObject (JtURL.JtCLASS_NAME, "url");
        main.setValue ("url", "url", args[0]);

        System.err.println ("downloading "+ args[0] + " .....");
        msg = new JtMessage (JtURL.JtDOWNLOAD);

        System.err.println (main.sendMessage ("url", msg));
        
        System.err.println ("downloading "+ args[0] + " .....");
        msg = new JtMessage (JtURL.POST);
        msg.setMsgContent("");
        
        System.err.println (main.sendMessage ("url", msg));
        

    }
}