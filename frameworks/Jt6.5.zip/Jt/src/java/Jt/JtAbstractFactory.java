
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;



/**
 * Jt Implementation of the Abstract Factory pattern.
 */


public abstract class JtAbstractFactory extends JtObject {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtAbstractFactory.class.getName(); 
    //private Object family;
    private Object concreteFactory = null;
    

    public JtAbstractFactory() {
    }


    /**
     * Specifies the object family.
     *
     * @param family family
     */

    /*
    public void setFamily (Object family) {
        this.family = family; 

    }
    */
    
    /**
     * Returns the object family.
     */

    /*
    public Object getFamily () {
        return (family);
    }

    */
    
    /**
     * Returns the concrete factory.
     */
    
    public Object getConcreteFactory() {
        return concreteFactory;
    }

    /**
     * Specifies the concrete factory.
     */
    
    public void setConcreteFactory(Object concreteFactory) {
        this.concreteFactory = concreteFactory;
    }

    /**
     * Process object messages. 
     * @param message Message    
     */

    public Object processMessage (Object message) {

        //String msgid = null;
        JtFactory factory = new JtFactory ();
        
        /*
        JtMessage e = (JtMessage) event;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }
        */

        if (concreteFactory == null) {
            handleError 
            ("processMessage: concreteFactory attribute needs to be set");
            return (null);
        }

        return (factory.sendMessage (concreteFactory, message));
        //return ((JtInterface) concreteFactory).processMessage (event);


    }




}

