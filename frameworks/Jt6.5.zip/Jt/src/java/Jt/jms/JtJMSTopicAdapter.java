

package Jt.jms;

import java.io.Serializable;

import Jt.*;
import Jt.examples.Test;
import Jt.jndi.*;

import javax.jms.*;

/**
 * Jt Adapter for the JMS publish/subscribe API. 
 */

public class JtJMSTopicAdapter extends JtJMSAdapter implements MessageListener {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtJMSTopicAdapter.class.getName(); 

    private String topic;
    private String connectionFactory;
    private long timeout = 1L; // Receives the next message within the timeout interval
    private Object subject = null;  
    private int deliveryMode = Message.DEFAULT_DELIVERY_MODE;
    private int priority = Message.DEFAULT_PRIORITY;
    private long timeToLive = Message.DEFAULT_TIME_TO_LIVE; // message never expires
    private String messageSelector;
    private String JMSType;
    private boolean transacted = false;

    private transient JtJNDIAdapter jndiAdapter = null;
    private transient boolean initialized = false; 

    private transient Topic jmsTopic;
    private transient TopicConnectionFactory tcFactory;
    private transient TopicConnection topicConnection;
    private transient TopicSession topicSession;
    private transient TopicPublisher topicPublisher;
    private transient TopicSubscriber topicSubscriber;
    private transient JtFactory factory = new JtFactory ();

    // Initialize the JMS Adapter

    private boolean initial () {
        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP);


        jndiAdapter = new JtJNDIAdapter ();

        if (connectionFactory == null) {
            handleError ("Attribute value needs to be set (connectionFactory)");
            return false;    
        }

        //msg.setMsgContent ("TestJMSConnectionFactory");
        msg.setMsgContent (connectionFactory);

        tcFactory = (TopicConnectionFactory) factory.sendMessage (jndiAdapter, msg);

        if (tcFactory == null)
            return false;

        if (topic == null) {
            handleError ("Attribute value needs to be set (topic)");
            return false;    
        }
        msg.setMsgContent (topic); 

        jmsTopic = (Topic) factory.sendMessage (jndiAdapter, msg);


        if (jmsTopic == null)
            return false;

        try {
            topicConnection = tcFactory.createTopicConnection ();
            topicSession = topicConnection.createTopicSession (transacted, 
                    Session.AUTO_ACKNOWLEDGE);

        } catch (Exception e) {
            handleException (e);
            return false;
        }
        
        return true;

    }


    /**
     * Method used by this adapter to consume JMS messages
     * asynchronously.
     * @param message JMS message
     */

    public void onMessage (Message message) {
        //JtMessage msg; 
        Serializable msg; 
        ObjectMessage omessage;     

        if (message == null)
            return;

        try {

            omessage = (ObjectMessage) message;
            msg =   omessage.getObject ();

            if (subject == null) {
                handleWarning ("JtJMSAdapter.onMessage: the subject attribute needs to be set");
                return;
            }

            factory.sendMessage (subject, msg);

        } catch (Exception ex) {
            handleException (ex);
        }
    }

    private boolean commit () {
    	
    	if (topicSession == null)
    		return (false);
    	
    	try {
			topicSession.commit();
		} catch (JMSException ex) {
			handleException (ex);
			return (false);
		}
		
		return (true);
    	
    }
    
    private boolean rollback() {
    	
    	if (topicSession == null)
    		return (false);
    	
    	try {
			topicSession.rollback();
		} catch (JMSException ex) {
			handleException (ex);
			return (false);
		}
		
		return (true);
    	
    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtPUBLISH - Publish a message (msgContent).  
     * <li> JtRECEIVE  - Receive a message from the JMS queue and return it.
     * <li> The message is consumed synchronously.  
     * <li> JtSTART_LISTENING - Start listening and consume messages asynchronously.  
     * </ul>
     */

    public Object processMessage (Object message) {
        JtMessage e;
        Object reply;
        Serializable msg;

        if (message == null)
        	return (null);
        
        if (!initialized) {
            initialized = initial ();
            if (!initialized)
            	return null;
        }

        if (message instanceof JtMessage) {
        	e = (JtMessage) message;
        	
            if (e.getMsgId() == null)
                return (null);
        	
        	if (e.getMsgId().equals (JtObject.JtREMOVE)) {
        		return (null);
        	}

        	if (e.getMsgId().equals(JtJMSAdapter.JtPUBLISH)) {
        		msg = (Serializable) e.getMsgContent ();        
        		if (publishJMSMessage (msg))
        			return (new Boolean (true));
        		else
        			return (new Boolean (false));

        	}

        	
        	if (e.getMsgId().equals(JtJMSAdapter.JtCOMMIT))
        		return (new Boolean (commit ()));

        	if (e.getMsgId().equals(JtJMSAdapter.JtROLLBACK))
        		return (new Boolean (rollback ()));

        	if (e.getMsgId().equals(JtJMSAdapter.JtSTART_LISTENING)) {
        		startListening ();
        		return (null);
        	}

        	if (e.getMsgId().equals(JtJMSAdapter.JtRECEIVE)) {     
        		reply = receiveJMSMessage ();
        		return (reply);
        	}
/*
        	// Test the Publisher functionality

        	if (e.getMsgId().equals(JtJMSAdapter.JtTEST_PUBLISHER)) {
        		reply = testPublisher ();
        		return (reply);
        	}

        	// Test the Subscriber functionality

        	if (e.getMsgId().equals(JtJMSAdapter.JtTEST_SUBSCRIBER)) {
        		reply = testSubscriber ();
        		return (reply);
        	}
*/
        }

        publishJMSMessage ((Serializable) message);
        //handleError 
        //("processMessage: invalid message id:"+
        //        e.getMsgId());
        return (null);
    }



    /**
     * Specifies the JNDI name of the JMS topic.
     * @param topic topic
     */

    public void setTopic (String topic) {
        this.topic = topic;
    }


    /**
     * Returns the JNDI name of the JMS topic.
     */

    public String getTopic () {
        return (topic);
    }

    /**
     * Specifies the timeout interval (refer to javax.jms.MessageConsumer)
     * @param timeout timeout
     */

    public void setTimeout (long timeout) {
        this.timeout = timeout;
    }


    /**
     * Returns timeout (refer to javax.jms.MessageConsumer)
     */

    public long getTimeout () {
        return (timeout);
    }


    /**
     * Sets the delivery mode (persistent or non-persistent).
     * Messages will be published using this delivery mode. 
     * @param deliveryMode delivery mode
     */

    public void setDeliveryMode (int deliveryMode) {
        this.deliveryMode = deliveryMode;
    }


    /**
     * Returns the delivery mode (persistent or non-persistent)
     */

    public long getDeliveryMode () {
        return (deliveryMode);
    }




    /**
     * Sets the message priority. Messages will be published 
     * using this priority. 
     * @param priority message priority
     */

    public void setPriority (int priority) {
        this.priority = priority;
    }


    /**
     * Returns the message priority.
     */

    public long getPriority () {
        return (priority);
    }


    /**
     * Sets the message time to live (in milliseconds). Messages will be published 
     * using this value. 
     * @param timeToLive message time to live
     */

    public void setTimeToLive (long timeToLive) {
        this.timeToLive = timeToLive;
    }


    /**
     * Returns the message time to live (in milliseconds).
     */

    public long getTimeToLive () {
        return (timeToLive);
    }

    /**
     * Specifies the subject (JtObject). Messages received asynchronously are forwarded to
     * this Jt object for processing. 
     * @param subject subject
     */


    public void setSubject (Object subject) {
        this.subject = subject;
    }


    /**
     * Returns the subject. Messages received asynchronously are forwarded to
     * this Jt object for processing. 
     */

    public Object getSubject () {
        return (subject);
    }


    /**
     * Specifies the JNDI name of the connection factory.
     * @param connectionFactory connection factory
     */

    public void setConnectionFactory (String connectionFactory) {
        this.connectionFactory = connectionFactory;
    }


    /**
     * Returns the JNDI name of the connection factory.
     */

    public String getConnectionFactory () {
        return (connectionFactory);
    }


    /**
     * Returns the JMS message selector.
     */

    public String getMessageSelector() {
		return messageSelector;
	}

    /**
     * Specifies the JMS message selector.
     */
    
	public void setMessageSelector(String messageSelector) {
		topicSubscriber = null;
		this.messageSelector = messageSelector;
	}

    /**
     * Returns the JMS message type.
     */
	
	public String getJMSType() {
		return JMSType;
	}


    /**
     * Sets the JMS message type.
     */
	
	public void setJMSType(String jMSType) {
		JMSType = jMSType;
	}

    /**
     * Returns the value the boolean transacted.
     * If this flag is true, transactions are used.
     * The default is false.
     */
	
	public boolean isTransacted() {
		return transacted;
	}

    /**
     * Sets the value of the boolean transacted.
     */
	
	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}
/*
    private Object testSubscriber () {
        String reply = "PASS";
        //TextMessage message;
        //ObjectMessage message;
        JtMessage msg;



        for (;;) {

            msg = (JtMessage) factory.sendMessage (this, new JtMessage (JtJMSAdapter.JtRECEIVE));

            if (msg == null) {
                System.out.println ("no more messages");
                break;
            } 

            System.out.println ("msgId:" + msg.getMsgId ());

        }

        return (reply);
    }
*/

    // Publish a message

    private boolean publishJMSMessage (Serializable msg) {

        ObjectMessage omsg;
        //String reply = "PASS";
        boolean reply = true;


        if (msg == null) {
            //reply = "FAIL";
            return (false);
        }

        try {

            if (topicPublisher == null)
                topicPublisher = topicSession.createPublisher (jmsTopic);

            omsg = topicSession.createObjectMessage (); 
            omsg.setObject (msg); 

            omsg.setJMSType(JMSType);
            
            topicPublisher.publish (omsg, deliveryMode, priority, timeToLive);
        } catch (Exception e) {
            handleException (e);
            //reply = "FAIL";
            return (false);
        }
        return (reply);
    }

    private void startListening () {


        try {
            if (topicSubscriber == null)
                topicSubscriber = topicSession.createSubscriber (jmsTopic, messageSelector, false);


            if (topicConnection == null) {
                handleError ("receiveJMSMessage:topicConnection is null");
                return; 
            }

            // Use the adapter as the message listener

            topicSubscriber.setMessageListener (this);

            topicConnection.start ();
        } catch (Exception ex) {

            handleException (ex);
        }

    }

    private Object receiveJMSMessage () {

        //JtMessage msg = null;
        ObjectMessage message;
        Serializable reply = null;

        try {

            if (topicSubscriber == null)
                topicSubscriber = topicSession.createSubscriber (jmsTopic, messageSelector, false);


            if (topicConnection == null) {
                handleError ("receiveJMSMessage:topicConnection is null");
                return (null); 
            }
            topicConnection.start ();

            message = (ObjectMessage) topicSubscriber.receive (timeout);
            if (message != null) {
                reply = message.getObject ();
            } 

        } catch (Exception e) {
            handleException (e);
        }

        return (reply);

    }


/*
    private Object testPublisher () {
        //String reply = "PASS";
        //TextMessage message;
        //ObjectMessage omsg;
        JtMessage msg = new JtMessage ("JtHELLO");
        JtMessage wrapper = new JtMessage (JtJMSAdapter.JtPUBLISH);

        wrapper.setMsgContent (msg);


        return (factory.sendMessage (this, wrapper));
    }
*/
    
    /**
     * Demonstrates the messages processed by JtJMSTopicAdapter. 
     */

    public static void main (String[] args) {
        JtFactory main;
        JtJMSTopicAdapter jmsAdapter;
        Test test = new Test ();
        Test reply;
        JtPrinter printer = new JtPrinter ();
        JtKeyboard keyboard = new JtKeyboard ();

        main = new JtFactory ();


        jmsAdapter = (JtJMSTopicAdapter) main.createObject (JtJMSTopicAdapter.JtCLASS_NAME);

        if (args.length < 1) {
            System.err.println ("Usage: java Jt.jms.JtJMSTopicAdapter -p or java Jt.jms.JtJMSTopicAdapter -s");
            System.exit (1);
        }

        if (args[0].equals ("-p")) {
            //main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtTEST_PUBLISHER));
        	test.setEmail("test@test.com");
        	jmsAdapter.setJMSType("Test");
        	main.sendMessage (jmsAdapter, test); 

            System.exit (0);
        } else if (args[0].equals ("-s")) {
            //main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtTEST_SUBSCRIBER));
        	jmsAdapter.setMessageSelector ("JMSType IN ('Test')");
            reply = (Test) main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtRECEIVE));

            printer.processMessage(reply);
            System.exit (0);
        } else if (args[0].equals ("-a")) {
        	//main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtTEST_RECEIVER));
        	jmsAdapter.setSubject(new JtEcho ());
        	main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtSTART_LISTENING));
        	keyboard.setPrompt("Press any enter to continue ...");
        	main.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));
        	System.exit (0);
        } else
        	System.err.println ("Usage: java Jt.jms.JtJMSTopicAdapter -p or java Jt.jms.JtJMSTopicAdapter -s");

        //main.removeObject (jmsAdapter);

    }
}