
/*
 *
 * Copyright 2005, Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.jms;

import java.io.Serializable;

import Jt.*;
import Jt.examples.Test;
import Jt.jndi.*;
import javax.jms.*;

/**
 * Jt Adapter for the JMS point-to-point API. 
 */

public class JtJMSQueueAdapter extends JtJMSAdapter implements MessageListener {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtJMSQueueAdapter.class.getName(); 
    private String queue;
    private String connectionFactory;
    private long timeout = 1L; // Receives the next message within the timeout interval
    private Object subject = null;  
    private int deliveryMode = Message.DEFAULT_DELIVERY_MODE;
    private int priority = Message.DEFAULT_PRIORITY;
    private long timeToLive = Message.DEFAULT_TIME_TO_LIVE; // message never expires
    private String messageSelector;
    private String JMSType;

    private transient JtJNDIAdapter jndiAdapter = null;
    private transient boolean initialized = false; 
    private boolean transacted = false;

    private transient Queue jmsQueue;
    private transient QueueConnectionFactory qcFactory;
    private transient QueueConnection queueConnection;
    private transient QueueSession queueSession;
    private transient QueueSender queueSender;
    private transient QueueReceiver queueReceiver;
    private transient JtFactory factory = new JtFactory ();


    // Initialize the JMS Adapter

    private boolean initial () {
        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP);


        jndiAdapter = new JtJNDIAdapter ();

        if (connectionFactory == null) {
            handleError ("Attribute connectionFactory needs to be set.");
            return false;    
        }

        msg.setMsgContent (connectionFactory);

        qcFactory = (QueueConnectionFactory) factory.sendMessage (jndiAdapter, msg);

        if (qcFactory == null)
            return false;

        if (queue == null) {
            handleError ("Attribute queue needs to be set.");
            return false;    
        }
        msg.setMsgContent (queue); 

        jmsQueue = (Queue) factory.sendMessage (jndiAdapter, msg);


        if (jmsQueue == null)
            return false;

        try {
            queueConnection = qcFactory.createQueueConnection ();
            queueSession = queueConnection.createQueueSession (transacted, 
                    Session.AUTO_ACKNOWLEDGE);

        } catch (Exception e) {
            handleException (e);
            return (false);
        }
        
        return true;

    }

    /**
     * Method used by this adapter to consume JMS messages
     * asynchronously.
     * @param message JMS message
     */

    public void onMessage (Message message) {
        Serializable msg; 
        ObjectMessage omessage;     

        if (message == null)
            return;


        try {

            omessage = (ObjectMessage) message;
            msg = omessage.getObject ();

            if (subject == null) {
                handleWarning ("JtJMSQueueAdapter.onMessage: attribute 'subject' needs to be set.");
                return;
            }

            // Forward messages to the subject component

            factory.sendMessage (subject, msg);

        } catch (Exception ex) {
            handleException (ex);
        }
    }

    
    private boolean commit () {
    	
    	if (queueSession == null)
    		return (false);
    	
    	try {
			queueSession.commit();
		} catch (JMSException ex) {
			handleException (ex);
			return (false);
		}
		
		return (true);
    	
    }
    
    private boolean rollback() {
    	
    	if (queueSession == null)
    		return (false);
    	
    	try {
			queueSession.rollback();
		} catch (JMSException ex) {
			handleException (ex);
			return (false);
		}
		
		return (true);
    	
    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtSEND  - Send a message (msgContent) to the JMS queue.  
     * <li> JtRECEIVE  - Receive a message from the JMS queue and return it. 
     * <li> The message is consumed synchronously.
     * <li> JtSTART_LISTENING - Start listening and consume messages asynchronously. The JMS messages are
     * <li> processed by the specified component (subject attribute). 
     * </ul>
     */

    public Object processMessage (Object message) {
        //String content;
        //String query;
        JtMessage e;
        Object reply;
        Serializable msg;

        if (message == null)
        	return (null);

        if (!initialized) {
            initialized = initial ();
            if (!initialized)
            	return null;
        }

		// Reset exceptions
		this.setObjException(null);
		  
        if (message instanceof JtMessage) {

        	e = (JtMessage) message;
        	
            if (e == null ||  (e.getMsgId() == null))
                return (null);
            
        	
        	if (e.getMsgId().equals (JtObject.JtREMOVE)) {
        		return (null);
        	}

        	if (e.getMsgId().equals (JtComponent.JtINITIALIZE)) {
        		return (new Boolean (true));
        	}

        	if (e.getMsgId().equals(JtJMSAdapter.JtSEND)) {
        		msg = (Serializable) e.getMsgContent ();        
        		if (sendJMSMessage (msg))
        			return (new Boolean (true));
        		else
        			return (new Boolean (false));       			
        	}

        	if (e.getMsgId().equals(JtJMSAdapter.JtCOMMIT))
        		return (new Boolean (commit ()));

        	if (e.getMsgId().equals(JtJMSAdapter.JtROLLBACK))
        		return (new Boolean (rollback ()));

        	if (e.getMsgId().equals(JtJMSAdapter.JtSTART_LISTENING)) {

        		return (new Boolean (startListening ()));
        	}

        	if (e.getMsgId().equals(JtJMSAdapter.JtRECEIVE)) {     
        		reply = receiveJMSMessage ();
        		return (reply);
        	}
/*
        	// Test the Sender functionality

        	if (e.getMsgId().equals(JtJMSAdapter.JtTEST_SENDER)) {
        		reply = testSender ();
        		return (reply);
        	}

        	// Test the Receiver functionality

        	if (e.getMsgId().equals(JtJMSAdapter.JtTEST_RECEIVER)) {
        		reply = testReceiver ();
        		return (reply);
        	}
*/
        }

        //handleError 
        //("processMessage: invalid message id:"+
        //        e.getMsgId());
        return (new Boolean (sendJMSMessage ((Serializable) message)));
    }



    /**
     * Specifies the JNDI name of the JMS queue.
     * @param queue queue
     */

    public void setQueue (String queue) {
        this.queue = queue;
    }


    /**
     * Returns the JNDI name of the JMS queue.
     */

    public String getQueue () {
        return (queue);
    }

    /**
     * Specifies the timeout interval (refer to javax.jms.MessageConsumer).
     * @param timeout timeout
     */

    public void setTimeout (long timeout) {
        this.timeout = timeout;
    }


    /**
     * Returns timeout (refer to javax.jms.MessageConsumer).
     */

    public long getTimeout () {
        return (timeout);
    }


    /**
     * Sets the delivery mode (persistent or non-persistent).
     * Messages will be sent to the JMS queue using this delivery mode. 
     * @param deliveryMode delivery mode
     */

    public void setDeliveryMode (int deliveryMode) {
        this.deliveryMode = deliveryMode;
    }


    /**
     * Returns the delivery mode (persistent or non-persistent)
     */

    public long getDeliveryMode () {
        return (deliveryMode);
    }




    /**
     * Sets the message priority. Messages will be sent to the JMS queue 
     * using this priority. 
     * @param priority message priority
     */

    public void setPriority (int priority) {
        this.priority = priority;
    }


    /**
     * Returns the message priority.
     */

    public long getPriority () {
        return (priority);
    }


    /**
     * Sets the message time to live (in milliseconds). Messages will be sent to the JMS queue 
     * using this value. 
     * @param timeToLive message time to live
     */

    public void setTimeToLive (long timeToLive) {
        this.timeToLive = timeToLive;
    }


    /**
     * Returns the message time to live (in milliseconds).
     */

    public long getTimeToLive () {
        return (timeToLive);
    }



    /**
     * Specifies the subject. Messages received asynchronously are forwarded to
     * this component for processing. 
     * @param subject subject
     */

    public void setSubject (Object subject) {
        this.subject = subject;
    }


    /**
     * Returns the subject. Messages received asynchronously are forwarded to
     * this component for processing. 
     */

    public Object getSubject () {
        return (subject);
    }


    /**
     * Specifies the JNDI name of the connection factory.
     * @param connectionFactory connection factory
     */

    public void setConnectionFactory (String connectionFactory) {
        this.connectionFactory = connectionFactory;
    }


    /**
     * Returns the JNDI name of the connection factory.
     */

    public String getConnectionFactory () {
        return (connectionFactory);
    }



/*
    private Object testReceiver () {
        Object reply;
        //ObjectMessage message;



        //for (;;) {

        reply =  factory.sendMessage (this, new JtMessage (JtJMSAdapter.JtRECEIVE));

        if (reply == null) {
            System.out.println ("no more messages");
            return (reply);
        } 

        System.out.println ("msgId:" + reply );

        //}

        return (reply);
    }
*/

    /**
     * Returns the JMS message selector.
     */

    public String getMessageSelector() {
		return messageSelector;
	}

    /**
     * Specifies the JMS message selector.
     */
    
	public void setMessageSelector(String messageSelector) {
		queueReceiver = null;
		this.messageSelector = messageSelector;
	}

    /**
     * Returns the JMS message type.
     */
	
	public String getJMSType() {
		return JMSType;
	}


    /**
     * Sets the JMS message type.
     */
	
	public void setJMSType(String jMSType) {
		JMSType = jMSType;
	}

    /**
     * Returns the value the boolean transacted.
     * If this flag is true, transactions are used.
     * The default is false.
     */
	
	public boolean isTransacted() {
		return transacted;
	}

    /**
     * Sets the value of the boolean transacted.
     */
	
	public void setTransacted(boolean transacted) {
		this.transacted = transacted;
	}

	private boolean sendJMSMessage (Serializable msg) {

        ObjectMessage omsg;
        //String reply = "PASS";
        boolean reply = true;


        if (msg == null) {
            //reply = "FAIL";
            //return (reply);
        	return (false);
        }

        try {

            if (queueSender == null)
                queueSender = queueSession.createSender (jmsQueue);

            omsg = queueSession.createObjectMessage (); 
            omsg.setObject (msg); 
            
            //if (messageType != null && !messageType.equals(""))
            //	omsg.setStringProperty("messageType", messageType);
            
            omsg.setJMSType(JMSType);

            // send the message. Use the appropriate parameters (priority, 
            // deliveryMode, etc).
            queueSender.send (omsg, deliveryMode, priority, timeToLive);

        } catch (Exception e) {
            handleException (e);
            reply = false;
        }
        return (reply);
    }

    private boolean startListening () {


        try {
            if (queueReceiver == null)
                queueReceiver = queueSession.createReceiver (jmsQueue, messageSelector);


            if (queueConnection == null) {
                handleError ("receiveJMSMessage:queueConnection is null");
                return false; 
            }
            
            if (queueReceiver == null) {
                handleError ("receiveJMSMessage:queueReceiver is null");
                return false; 
            }           

            // Use the adapter as the message listener

            queueReceiver.setMessageListener (this);

            queueConnection.start ();
        } catch (Exception ex) {

            handleException (ex);
            return false;
        }
        
        return true;

    }

    private Object receiveJMSMessage () {

        //JtMessage msg = null;
        ObjectMessage message;
        Serializable reply = null;


        try {

            if (queueReceiver == null)
                queueReceiver = queueSession.createReceiver (jmsQueue, messageSelector);


            if (queueConnection == null) {
                handleError ("receiveJMSMessage:queueConnection is null");
                return (null); 
            }
            
            if (queueReceiver == null) {
                handleError ("receiveJMSMessage:queueReceiver is null");
                return (null); 
            }    
            
            queueConnection.start ();

            message = (ObjectMessage) queueReceiver.receive (timeout);
            if (message != null) {
                reply =  message.getObject ();
            } 

        } catch (Exception e) {
            handleException (e);
        }

        return (reply);

    }


/*
    private Object testSender () {
        //String reply = "PASS";
        //TextMessage message;
        //ObjectMessage omsg;
        JtMessage msg = new JtMessage ("JtHELLO");
        JtMessage wrapper = new JtMessage (JtJMSAdapter.JtSEND);

        wrapper.setMsgContent (msg); // wrapper message ("JtSEND") that contains
                                     // the real message ("JtHELLO")


        // send the message to the JMS adapter (JMS queue)
        return (factory.sendMessage (this, wrapper));
    }
*/
    /**
     * Demonstrates the messages processed by JtJMSQueueAdapter. 
     */

    public static void main (String[] args) {
        JtFactory main;
        JtJMSQueueAdapter jmsAdapter;
        Test test = new Test ();
        JtPrinter printer = new JtPrinter ();
        Object reply;
        JtKeyboard keyboard = new JtKeyboard ();

        main = new JtFactory ();


        jmsAdapter = (JtJMSQueueAdapter) main.createObject (JtJMSQueueAdapter.JtCLASS_NAME);

        if (args.length < 1) {
            System.err.println ("Usage: java Jt.jms.JtJMSQueueAdapter -s or java Jt.jms.JtJMSQueueAdapter -r");
            System.exit (1);
        }

        if (args[0].equals ("-s")) {
        	
        	test.setEmail("test@test.com");
            //main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtTEST_SENDER));
        	jmsAdapter.setJMSType("Test");
        	main.sendMessage (jmsAdapter, test);         
            System.exit (0);
        }

        if (args[0].equals ("-r")) {
            //main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtTEST_RECEIVER));
        	//jmsAdapter.setMessageSelector ("messageType IN ('Test')");
        	jmsAdapter.setMessageSelector ("JMSType IN ('Test')");
            reply = main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtRECEIVE));
            printer.processMessage(reply);
        	System.exit (0);
        }

        if (args[0].equals ("-a")) {
        	jmsAdapter.setSubject(new JtEcho ());
        	//jmsAdapter.setMessageSelector ("JMSType IN ('Test')");
        	//jmsAdapter.setMessageSelector ("JMSType IN ('1')");
	    	//jmsAdapter.setMessageSelector ("JMSType IN ('JtEND_OF_FILE')");
            main.sendMessage (jmsAdapter, new JtMessage (JtJMSAdapter.JtSTART_LISTENING));
            keyboard.setPrompt("Press any enter to continue ...");
            main.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));
        	System.exit (0);
        }
        
        System.err.println ("Usage: java Jt.jms.JtJMSQueueAdapter -s or java Jt.jms.JtJMSQueueAdapter -r");

        //main.removeObject ("jtAdapter");

    }
}