package Jt.jms;

import Jt.JtAdapter;


/**
 * Jt Adapter for the JMS API. 
 */


abstract public class JtJMSAdapter extends JtAdapter {
    
    public static final String JtSTART_LISTENING = "JtSTART_LISTENING";
    public static final String JtPUBLISH = "JtPUBLISH";
    public static final String JtSEND = "JtSEND";
    public static final String JtRECEIVE = "JtRECEIVE";
    public static final String JtTEST_PUBLISHER = "JtTEST_PUBLISHER";
    public static final String JtTEST_SUBSCRIBER= "JtTEST_SUBSCRIBER";
    public static final String JtTEST_SENDER = "JtTEST_SENDER";
    public static final String JtTEST_RECEIVER= "JtTEST_RECEIVER";
    public static final String JtCOMMIT= "JtCOMMIT";
    public static final String JtROLLBACK= "JtROLLBACK";    
 
}
