package Jt;

import Jt.examples.HelloWorld;




/**
 * Jt Implementation of the Chain of Responsibility pattern.
 */


public class JtChainOfResponsibility extends JtObject {

  public static final String JtCLASS_NAME = JtChainOfResponsibility.class.getName(); 
  private static final long serialVersionUID = 1L;
  private Object successor;

  public JtChainOfResponsibility() {
  }

/**
  * Specifies the successor in the chain.
  *
  * @param successor successor
  */

  public void setSuccessor (Object successor) {
     this.successor = successor; 

  }

/**
  * Returns the successor in the chain.
  */

  public Object getSuccessor () {
     return (successor);
  }




  /**
    * Process object messages. If unable to process a particular message, forward it to the successor.     
    */

  public Object processMessage (Object message) {

      JtFactory factory = new JtFactory ();


      if (message == null)
          return null;


      // Unable to handle the request, let the successor process the request

      if (successor == null) {
          handleError 
          ("JtChainOfResposibility.processMessage: last in the chain was unable to process message:" + message);
          return (null);
      }

      return (factory.sendMessage (successor, message));


  }

  /**
    * Demonstrates the messages processed by JtChainOfResposibilty.   
    */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtMessage msg;
    HelloWorld helloWorld;
    JtChainOfResponsibility chain;



    // Create an instance of JtChainOfResponsibilty

    chain = (JtChainOfResponsibility)
      main.createObject (JtChainOfResponsibility.JtCLASS_NAME);


    helloWorld = (HelloWorld) main.createObject (HelloWorld.JtCLASS_NAME);

    main.setValue (chain, "successor", helloWorld);


    msg = new JtMessage(HelloWorld.JtHELLO);

    // Send a message ("JtHello") to the chain

    System.out.println (main.sendMessage (chain, msg));

         

  }

}
