/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.JtRegistry;
import Jt.JtRemoteException;
import Jt.JtRemoteFacade;
//import Jt.security.JtAccessManager;
//import Jt.security.JtComponentAccessEntry;
//import Jt.security.JtEncryptedMessage;
//import Jt.security.JtMessageCipher;
import Jt.xml.JtXMLHelper;


/**
 * Jt Universal Servlet. This class implements MDP via the servlet API.
 */

public class JtServlet extends HttpServlet {


    private static final long serialVersionUID = 1L;
    //private JtRemoteFacade messenger = null;

      

    public JtServlet() {
     }

    
    
    // Convert object to XML format (use JtXMLHelper to do the conversion)
    
    private String convertToXML (JtFactory main, Object obj) {
        JtMessage msg = new JtMessage (JtXMLHelper.JtXML_ENCODE);
        JtXMLHelper xmlHelper = new JtXMLHelper ();
        
        //if (obj == null)
        //    return (null);
        
        msg.setMsgContent(obj);
        return ((String) main.sendMessage(xmlHelper, msg));
    }
    
    
    // Process the HTTP Get Request
    
    public void doGet (HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {
        doPost (req, res);
        
    }
    
    private String stackTrace (Exception ex ) {
        ByteArrayOutputStream bstream;


        if (ex == null)
            return (null);

        bstream = new ByteArrayOutputStream ();
        
        //ex = (Exception) getValue (this, "objException");

        ex.printStackTrace (new PrintWriter (bstream, true));


        return (bstream.toString ());


    }
    
	private Object convertXMLToObject (String xmlString) {
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtFactory factory = new JtFactory ();

		if (xmlString == null)
			return (null);

		msg.setMsgContent(xmlString);
		return (factory.sendMessage(xmlHelper, msg));
	}
	

	
	private Object forwardMessage (Object jMsg) {
		JtFactory factory = new JtFactory ();
		JtRemoteFacade messenger = null;

		Object reply;
		
		if (jMsg == null) {
			factory.handleError ("Invalid message (null).");
			return (null); 
		}
		

		//if (messenger == null) {
		//	factory.setCreateSingleton(true);
			messenger = (JtRemoteFacade) factory.createObject(JtRemoteFacade.JtCLASS_NAME);
		//	factory.setCreateSingleton(false);
		//}
/*		
		if (jMsg.getMsgTo () != null)
			messenger.setCreateClassInstance(false);
		else
			messenger.setCreateClassInstance(true);
		
*/		
		reply = messenger.processMessage(jMsg);
		
		return (reply);
		
	}
	
    // Process the HTTP Get Request
    
    public void doPost (HttpServletRequest req, HttpServletResponse res) 
    throws ServletException, IOException {
       String jtMsgContent = req.getParameter("jtMsgContent");
       String jtClassname = req.getParameter("jtClassname");
       String jtMsgId = req.getParameter("jtMsgId");
       String jtMessage = req.getParameter("jtMessage");
       String jtComponentId = req.getParameter("jtComponentId");
       
       JtMessage msg = new JtMessage ();
       JtMessage jMsg = new JtMessage (JtFactory.JtSEND_MESSAGE);
       Object jtReply = null;
       Exception ex;
       JtContext context;
       JtRemoteException jre;
       //Object delegate = null;
       //JtRegistry registry;
       Object message;


       JtFactory main = new JtFactory ();     
       res.setContentType("text/html");
       res.setHeader("Cache-Control", "no-cache");
       
       
       if (jtMessage == null) {

    	   if (jtMsgContent == null)
    		   jtMsgContent = req.getParameter("msgContent"); 

    	   if (jtClassname == null)
    		   jtClassname = req.getParameter("classname"); 

    	   if (jtMsgId == null)
    		   jtMsgId = req.getParameter("msgId");

    	   msg.setMsgData(req.getParameter("msgData"));
    	   msg.setMsgAttachment(req.getParameter("msgAttachment"));

    	   if (jtClassname == null && jtComponentId == null) {
    		   ex = errorDetected (main, "JtServlet: request parameter classname (or componentId) needs to be set.");
    		   jre = new JtRemoteException (ex.getMessage());
    		   jre.setTrace (stackTrace (ex));
    		   //if (convertToXML) {
    		   res.getWriter().write (convertToXML (main, jre));
    		   return;

    	   }    

    	   if (jtMsgId == null)
    		   jtMsgId = JtObject.JtACTIVATE;



    	   //JtInterface delegate = (JtInterface) createDelegate (main, jtClassName, jtComponentId);

    	   if (jtComponentId != null) {

    		   jMsg.setMsgTo(jtComponentId);

    	   } else
    		   jMsg.setMsgRecipientClassname(jtClassname);
    	   //delegate = (Object) createDelegate (main, jtClassname, jtComponentId);


    	   // Pass context information. 

    	   context = new JtContext ();

    	   context.setServletContext(this.getServletContext());    
    	   context.setRequest(req);
    	   context.setResponse(res);   
    	   context.setUserName(retrieveUserName (req));
    	   msg.setMsgContext(context);


    	   msg.setMsgId(jtMsgId);
    	   msg.setMsgContent(jtMsgContent);    

    	   // If jtMessage is present, it contains the message (XML format)


    	   jMsg.setMsgContent(msg);

    	   message = jMsg;

       } else {
    	   message = convertXMLToObject (jtMessage);
    	   
    	   main.handleTrace(jtMessage, JtLogger.JtMIN_LOG_LEVEL);
    	   
    	   if (message == null) {
    		   ex = errorDetected (main, "JtServlet: unable to convert message from XML.");
    		   jre = new JtRemoteException (ex.getMessage());
    		   jre.setTrace (stackTrace (ex));

    		   res.getWriter().write (convertToXML (main, jre));
    		   return;
    	   }

       }
    	   
	   //jtReply = forwardMessage ((JtMessage) message);
       jtReply = forwardMessage (message);


       
       if (jtReply instanceof String) {
           res.getWriter().write ((String) jtReply);
           return;
       }
       
       

       // Convert reply to XML format
       
       res.getWriter().write (convertToXML (main, jtReply));
           
    }

   // error detected
    
    private Exception errorDetected (JtFactory main, String error) {        
              
        main.handleError(error); // forces an exception to be generated
        return ((Exception) main.getObjException());          
        
    }
    

    private String retrieveUserName (HttpServletRequest request) {
        HttpSession session;
        JtContext ctx;
        JtFactory factory = new JtFactory ();
        
        
        if (request == null)
            return null;
        
        session = request.getSession();
        
        factory.handleTrace ("retrieveUserName(session):" + session);
        if (session == null)
            return null;
        
        ctx = (JtContext) session.getAttribute("jtContext");
        
        factory.handleTrace ("retrieveUserName(ctx):" + ctx);
        if (ctx == null)
            return null;
        
        factory.handleTrace ("retrieveUserName:" + ctx.getUserName());
        return (ctx.getUserName());
    }
    


}
