

package Jt;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import Jt.examples.HelloWorld;

/**
 * Prints a component using XML.
 */

public class JtPrinter extends JtObject {

  public static final String JtCLASS_NAME = JtPrinter.class.getName(); 
  private static final long serialVersionUID = 1L;
  //private JtFactory factory = new JtFactory ();  

  private String encodeObject (Object obj) {

      ByteArrayOutputStream stream = new ByteArrayOutputStream ();
      XMLEncoder e; 
      String result = null;


      if (obj == null)
          return (null);

      try {

          e = new XMLEncoder(
                  new BufferedOutputStream(stream));
          e.writeObject(obj);
          e.close();
          result = stream.toString ();

      } catch (Exception ex) {
          handleException (ex);
          return (null);
      }    
      return (result); 

  }


  public JtPrinter () {
  }





  /**
    * Prints a component using XML.
    * @param message component to be printed.
    */

  public Object processMessage (Object message) {

	 System.out.println(encodeObject (message));
     return (null);

  }

 
  /**
   * Demonstrates the messages processed by JtPrinter.
   */


  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtPrinter printer;
    HelloWorld hello = new HelloWorld ();

    hello.setGreetingMessage("Hello World");

    // Create an instance of JtPrinter

    printer = (JtPrinter) factory.createObject (JtPrinter.JtCLASS_NAME);
    
  
    factory.sendMessage (printer, hello);   
    
     


  }


}


