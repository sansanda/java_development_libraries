package Jt;



/**
 * Jt Implementation of the Visitor design pattern. 
 */


public class JtVisitor extends JtObject {

  public static final String JtCLASS_NAME = JtVisitor.class.getName(); 
  private static final long serialVersionUID = 1L;

  
  public JtVisitor() {
  }



  /**
    * Process object messages. 
    * <ul>
    * <li>JtVISIT - visit the object specified by msgContent. Subclasses need to
    * override this method and provide a complete implementation for this message.
    * </ul>
    * @param event Jt Message    
    */

  public Object processMessage (Object event) {

   String msgid = null;
   JtMessage e = (JtMessage) event;

     if (e == null)
	return null;

     msgid = (String) e.getMsgId ();

     if (msgid == null)
	   return null;

     //content = e.getMsgContent();

     if (msgid.equals (JtObject.JtREMOVE)) {
       return (null);     
     }

     if (msgid.equals (JtObject.JtVISIT)) {
       return (null);     
     }

     return (super.processMessage(event));


  }

  /**
    * Demonstrates the messages processed by JtVisitor.   
    */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtVisitor visitor;


    // Create an instance of JtVisitor

    visitor = (JtVisitor)
      main.createObject (JtVisitor.JtCLASS_NAME);

         
  }

}
