/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.rest;


import java.util.Date;

import Jt.JtComponent;
import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtMessenger;
import Jt.examples.DateService;
import Jt.http.JtHttpProxy;



/**
 * Jt Restful Service.
 */

public class JtRestService extends JtHttpProxy {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtRestService.class.getName();

	public JtRestService() {
	}

	/*
	 * Propagate an exception. Some exceptions need
	 * to be propagated to the sender.
	 */
	




	/**
	 * Process object messages. Invoke a Restful service.
	 * <ul>
	 * </ul>
	 */

	public Object processMessage (Object message) {

		if (message == null)
			return null;
		
		// Reset exceptions
		this.setObjException(null);
		this.setRestful(true); // Restful mode
		
		return (super.processMessage(message));
		//return (invokeService (message));



	}

	/**
	 * Demonstrates the messages processed by JtRestService (Restful service)
	 */

	public static void main(String[] args) {

		JtFactory factory = new JtFactory ();
		JtMessage msg; 
		//Object reply;
		String sReply;
		JtRestService service;
		Date date;
		//String url = "http://localhost:7001/JtBlankApp/JtRestService";
		String url = "http://localhost:8080/JtPortal/JtRestService";
		JtContext context;
		Object reply;
		JtMessenger messenger;

		// Create an instance of JtRestService

		service = (JtRestService) factory.createObject (JtRestService.JtCLASS_NAME);
		//service.setEncrypted(true);
		
		// Assign the URL for the REST service/resource

		service.setUrl(url);
		service.setClassname ("Jt.examples.HelloWorldMessage");

        // Invoke the remote service (Make the REST request to access the remote resource/service).
		
		sReply = (String) factory.sendMessage (service, "hi");
		
		
        // Check for exceptions. Remote exceptions are automatically
		// propagated by the framework.

		if (service.getObjException() == null)
			System.out.println ("Reply:" + sReply);
		


		
		service.setUrl(url);
		service.setClassname ("Jt.examples.DateService");
		//service.setEncrypted(false);
		msg = new JtMessage (DateService.GET_DATE);
		
		// The reply message is automatically converted to
		// the appropriate Java type by the framework
		
		date = (Date) factory.sendMessage (service, msg);
		
		if (service.getObjException() == null)
			System.out.println ("Reply date:" + date);
		
		
		//service.setUrl(url);
		//service.setClassname ("Jt.examples.JtHelloWorld");
		
		// Message Id is an integer (1)
		//msg = new JtMessage (JtHelloWorld.JtHELLO);
		
		//sReply = (String) factory.sendMessage (service, msg);
		
		//if (service.getObjException() == null)
		//	System.out.println ("Reply:" + sReply);
				
		
		//service.setClassname ("Jt.examples.HelloWorld");

		//msg = new JtMessage (HelloWorld.JtHELLO);
		
		//sReply = (String) factory.sendMessage (service, msg);
		
		//if (service.getObjException() == null)
		//	System.out.println ("lReply:" + sReply);

		// Authenticated service

		messenger = new JtMessenger ();
		
	    // Specify that secure/encrypted messaging should be used
		
		messenger.setEncrypted(true);
		
		service.setUrl(url);
		service.setClassname ("Jt.service.Logging");
		
		// Encrypt the message (including username & password)
		//service.setEncrypted(true);
		
		// Authentication information 
		context = new JtContext ();
		context.setUserName("jt");
		context.setPassword("messaging");

		msg = new JtMessage (JtLogger.JtENABLE_LOGGING);
		//msg.setMsgContext(context); This has been deprecated. Use the messenger context.
		messenger.setContext(context); 
		reply = messenger.sendMessage (service, msg);
		messenger.setContext(null);  // get rid of the authentication info
		context.setPassword(null);
		
		System.out.println("Reply (authenticated):" + reply);
		
		service = (JtRestService) factory.createObject (JtRestService.JtCLASS_NAME);	
		service.setUrl(url);
		service.setClassname ("Jt.examples.EchoService");
			

		//service.setEncrypted(true);
				
	    // Send the message to the remote component/service.
		
		reply = messenger.sendMessage (service, new JtMessage (JtComponent.JtACTIVATE));


		System.out.println ("Reply:" + reply);
		
	}

}
