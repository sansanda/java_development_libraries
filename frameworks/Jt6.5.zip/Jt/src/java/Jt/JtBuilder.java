/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;




/**
 * Jt Implementation of the Builder design 
 * pattern. Subclasses need to override the 
 * inherited processMessage method and implement 
 * the build message.
 */

public abstract class JtBuilder extends JtObject {


    private static final long serialVersionUID = 1L;
    public static final String JtBUILD = "JtBUILD";  
    public static final String JtCLASS_NAME = JtBuilder.class.getName(); 
    protected Object concreteBuilder;
    


	public JtBuilder () {
    }

    /**
     * Returns the concrete builder.
     */
	
    public Object getConcreteBuilder() {
		return concreteBuilder;
	}

    /**
     * Specifies the concrete builder.
     */
    
	public void setConcreteBuilder(Object concreteBuilder) {
		this.concreteBuilder = concreteBuilder;
	}

	
    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        JtFactory factory = new JtFactory ();


        if (concreteBuilder == null) {
            handleError ("concreteBuilder attribute needs to be set");
            return (null);
        }

        // Let the concreteBuilder process the message

        return (factory.sendMessage (concreteBuilder, message));

    }
	
    /**
     * Demonstrates the messages processed by JtBuilder.
     */


    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtBuilder builder;


        // Create an instance of JtBuilder

        builder = (JtBuilder) factory.createObject (JtBuilder.JtCLASS_NAME);



    }


}


