

package Jt;
import java.util.*;
import java.io.*;

/**
 * Handles directories.
 */

public class JtDirectory extends JtFile {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtDirectory.class.getName(); 
    public static final String JtLS = "JtLS";
    public static final String JtDIR = "JtDIR";
    public static final String JtCREATE_DIRECTORY = "JtCREATE_DIRECTORY";
    public static final String JtCLEANUP = "JtCLEANUP";
    public static final String JtFIND = "JtFIND";
    public static final String JtCOPY_DIRECTORY = "JtCOPY_DIRECTORY";
    public static final String JtCREATE_PARENT_DIRECTORY = "JtCREATE_PARENT_DIRECTORY";
    public static final String JtFIND_PREFIX = "JtFIND_PREFIX";
    public static final String JtFIND_EXTENSION= "JtFIND_EXTENSION";
    private JtFactory factory = new JtFactory ();


    public JtDirectory() {
    }


    private void createDir (String path) {
        File file;
        //String parentpath; 

        if (path == null) {
            handleError ("attribute path needs to be set.");
            return;
        }    

        file = new File (path);
        if (file == null) {
            handleError ("Unable to create File object:" + path);
            return;
        }

        if (!file.exists ())
            if (!file.mkdirs ())
                handleError ("Unable to create directories:" +
                        path);
    }

    // create operation

    private void createDirectory () {

        createDir (path);

    }
 

    
    // Copy a director

    private void copyDirectory (String targetDirectory) {
        File source, target;
        //JtDirectory targetDir = new JtDirectory ();
        JtMessage msg = new JtMessage (JtDirectory.JtLS);
        JtMessage msg1 = new JtMessage (JtFile.JtCOPY);
        List files;
        String tmp;
        int i;
        JtFile jfile = new JtFile ();

        if (path == null) {
            handleError ("Attribute path needs to be set.");
            return;
        }
        
        if (targetDirectory == null) {
            handleError ("Invalid target directory (null).");            
            return;
        }    

        source = new File (path);

        if (!source.isDirectory()) {
            handleError (path + " is not a directory");
            return;
        }

        target = new File  (targetDirectory);

        if (!target.exists ())
            if (createdir) {
                if (!target.mkdirs ()) {
                    handleError ("Unable to create directories:" +
                            targetDirectory);
                    return;
                }
            } else {
                handleError ("Target directory does not exist:" +
                        targetDirectory);
                return;
            }    

        if (!target.isDirectory()) {
            handleError ("Invalid directory:" +
                    targetDirectory);
            return;
        }


        files = (List) factory.sendMessage (this, msg);

        if (files != null) {
            for (i = 0; i < files.size(); i++) {
                tmp = (String) files.get(i);
                jfile.setName(tmp);
                msg1.setMsgContent(targetDirectory);
                factory.sendMessage (jfile, msg1);
            }    

            return;
        }


    }

    // cleanup: cleanup a directory

    private void cleanup (String dname) {
        File dir, file;
        int i;
        String files[];
        String tmp;

        if (dname == null)
            return;

        dir = new File (dname);

        if (!dir.isDirectory ()) {
            handleWarning ("cleanup: invalid directory:" +
                    dname);
            return;
        }

        files = dir.list ();

        i = 0;
        while (i < files.length) {
            tmp = dname + "/" + files[i++]; // check
            file = new File (tmp);
            if (file.isDirectory ())
                if (!recursive)
                    continue;
                else {
                    handleTrace ("cleanup (recursive): cleaning " + tmp);
                    cleanup (tmp);
                }
            handleTrace ("cleanup: deleting " + tmp);
            file.delete ();
        }
    }


    // dir: create a list with the content of this directory

    private List dir () {
        int i;
        File Dir;
        String files[];
        String ext = filter; // file extension
        LinkedList fileList = new LinkedList ();

        if (path == null) {
            handleError ("Attribute path needs to be set.");
            return null;
        }  

        // define a list of files

        /*
        if (filelist == null)
            filelist = new Vector ();

        if (filelist == null)
            return;
        else
            filelist.removeAllElements ();
        */
        
        Dir = new File (path);

        if (!Dir.isDirectory ()) {
            handleError ("JtDirectory.dir: invalid directory:" +
                    path);
            return (null);
        }

        files = Dir.list ();

        i = 0;
        while (i < files.length) {

            if (ext == null || (ext != null && files[i].endsWith (ext))) {
                handleTrace ("JtFile.dir:" + files[i]);
                fileList.add (files[i]);
            }
            i++;
        }
        
        return (fileList);
    }


    // find_extension: find a file under this directory. The file uses 
    // the specified extension

    private void find_extension (String dir, String extension) {


        File Dir, file;
        String tmp;
        String files[];
        int i;


        if (dir == null || extension == null) // check find
            return;

        // define a list of files
        if (filelist == null)
            filelist = new Vector ();

        if (filelist == null)
            return;

        Dir = new File (dir);

        if (!Dir.isDirectory ()) {
            handleError ("File.find_extension: invalid directory:" +
                    dir);
            return;
        }

        files = Dir.list ();

        i = 0;
        while (i < files.length) {

            tmp = dir + "/" + files[i];
            //handleTrace ("JtFile.find_prefix:checking ..." + tmp);
            if (files[i].endsWith (extension)) {
                handleTrace ("JtFile.find_extension:" + tmp);
                //add it
                filelist.addElement (tmp);
            }

            i++;
            file = new File (tmp);
            if (file.isDirectory ())
                find_extension (tmp, extension);  // check


        }


    }

    // find_prefix: find a file under this directory. The file starts with
    // the specified prefix

    private void find_prefix (String dir, String prefix) {


        File Dir, file;
        String tmp;
        String files[];
        int i;


        if (dir == null || prefix == null) // check find
            return;

        // define a list of files
        if (filelist == null)
            filelist = new Vector ();

        if (filelist == null)
            return;

        Dir = new File (dir);

        if (!Dir.isDirectory ()) {
            handleError ("File.find_prefix: invalid directory:" +
                    dir);
            return;
        }

        files = Dir.list ();

        i = 0;
        while (i < files.length) {

            tmp = dir + "/" + files[i];
            //handleTrace ("JtFile.find_prefix:checking ..." + tmp);
            if (files[i].startsWith (prefix)) {
                handleTrace ("JtFile.find_prefix:" + tmp);
                //add it
                filelist.addElement (tmp);
            }

            i++;
            file = new File (tmp);
            if (file.isDirectory ())
                find_prefix (tmp, prefix);  // check


        }


    }

    // find: look for a file under a directory

    private String  find (String dir, String fname) {


        File Dir, file;
        String tmp;
        String files[];
        int i;
        //LinkedList fileList = new LinkedList ();
        String result;


        if (dir == null) {
            handleError ("Invalid parameter (directory name): null.");
            return null;
        } 

        if (fname == null) { 
            handleError ("Invalid parameter (file name): null.");
            return null;
        }    

        // define a list of files
        /*
        if (filelist == null)
            filelist = new Vector ();

        if (filelist == null)
            return;
         */

        Dir = new File (dir);

        if (!Dir.isDirectory ()) {
            handleError ("Invalid directory:" +
                    dir);
            return (null);
        }

        files = Dir.list ();

        i = 0;
        while (i < files.length) {

            tmp = Dir.getAbsolutePath() + File.separatorChar + files[i];
            if (fname.equals (files[i])) {
                handleTrace ("JtDirectory.find:" + tmp);
                return (tmp);
            }

            i++;
            file = new File (tmp);
            if (file.isDirectory ()) {
                result = find (tmp, fname);
                if (result != null)
                    return (result);
            }    

        }
        
        return (null);

    }

    // ls: create a list with the content of this directory. The directory
    // name is added to the path.

    private List ls () {
        int i;
        LinkedList fileList = new LinkedList ();
        File Dir;
        String files[];
        String ext = filter; // file extension
        String tmp;

        if (path == null) {
            handleError ("Attribute path needs to be set.");
            return null;
        }    


        Dir = new File (path);

        if (!Dir.isDirectory ()) {
            handleError ("Invalid directory:" +
                    path);
            return null;
        }

        files = Dir.list ();

        i = 0;

        while (i < files.length) {

            tmp = Dir.getAbsolutePath() + File.separatorChar + files[i];
            if (ext == null || (ext != null && files[i].endsWith (ext))) {
                handleTrace ("JtDirectory:" + tmp);
                fileList.add (tmp);
            }
            i++;
        }
        
        return (fileList);
    }


    /**
     * Process object messages.
     * <ul> JtDIR - List the content of a directory.
     * <li> JtLS - List the content of a directory. The complete path is used.
     * <li> JtCREATE_DIRECTORY - Creates a directory.
     * <li> JtCLEANUP - Removes all the files under a directory
     * <li> JtFIND - Looks for the file specified by msgContent.
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        //byte buffer[];
        //JtBuffer buf;
        //File file;
        JtMessage e = (JtMessage) message;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        if (msgid.equals (JtDirectory.JtCREATE_DIRECTORY)) {
            createDirectory ();
            return null;
        }
        
        if (msgid.equals (JtDirectory.JtCOPY_DIRECTORY)) {
            copyDirectory ((String) e.getMsgContent());
            return null;
        }

        // List the directory

        if (msgid.equals (JtDirectory.JtLS)) {
            //ls ();
            return (ls ());
        }

        if (msgid.equals (JtDirectory.JtDIR)) {
            return (dir ());
        }

        if (msgid.equals (JtDirectory.JtCREATE_PARENT_DIRECTORY)) {

            if (path == null)
                return null;

            createParentDir (path);
            return null;
        }

        if (msgid.equals (JtDirectory.JtCLEANUP)) {
            if (path == null)
                return (null);

            cleanup (path);
            return (null);
        }

        if (msgid.equals (JtDirectory.JtFIND)) {

            //if (filelist != null)
            //    filelist.removeAllElements ();

            return (find (path, (String) e.getMsgContent ()));
        }

        if (msgid.equals (JtDirectory.JtFIND_PREFIX)) {

            if (filelist != null)
                filelist.removeAllElements ();

            find_prefix (path, (String) e.getMsgContent ());
            return (null);
        }

        if (msgid.equals (JtDirectory.JtFIND_EXTENSION)) {

            if (filelist != null)
                filelist.removeAllElements ();

            find_extension (path, (String) e.getMsgContent ());
            return (null);
        }

        return (super.processMessage (message));

    }





    /**
     * Demonstrates the messages processed by JtDirectory.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg = new JtMessage (JtDirectory.JtLS);
        File tmp;
        JtDirectory dir;
        
        
        tmp = new File ("c:/tmp/directory/");
        
        //System.out.println ("name:" + tmp.getName());
        //System.out.println ("path:" + tmp.getPath());     
        //System.out.println ("path:" + tmp.getAbsolutePath()); 


        // Create an instance of  JtDirectory       
        dir = (JtDirectory) main.createObject (JtDirectory.JtCLASS_NAME);
        main.setValue (dir, "name", "/tmp");


        main.sendMessage(dir, msg);

        main.setValue (dir, "name", "/tmp/tmpdirectory");
        msg.setMsgId(JtDirectory.JtCREATE_DIRECTORY);
        main.sendMessage (dir, msg);

        // Create directory

        tmp = new File ("/tmp/tmpdirectory");
        if (!tmp.exists ()) 
            main.handleError ("JtFile(JtCREATE_DIRECTORY): FAILED");
        else
            System.err.println ("JtFile(JtCREATE_DIRECTORY): GO");

        // Find (JtFIND)

        main.setValue (dir, "name", "/tmp");
        msg.setMsgId(JtDirectory.JtFIND);
        msg.setMsgContent("tmpdirectory");
        main.sendMessage (dir, msg);
        
        main.setValue (dir, "name", "/tmp/tmpdirectory");
        msg.setMsgContent("/tmp/tmpdirectory1");
        msg.setMsgId(JtDirectory.JtCOPY_DIRECTORY);
        main.sendMessage (dir, msg);

        //main.setValue ("file", "name", "/tmp");
        //main.setValue ("file", "filter", ".txt");
        //main.setValue ("message", "msgId", "JtDIR");
        //main.sendMessage ("file", "message");


        // List (JtLS)

        //main.setValue ("message", "msgId", "JtLS");
        //main.sendMessage ("file", "message");

        //main.removeObject ("file");



    }

}


