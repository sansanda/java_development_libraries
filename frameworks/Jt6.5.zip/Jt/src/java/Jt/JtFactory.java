package Jt;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.Key;
import java.text.DateFormat;
import java.util.Enumeration;
import java.util.Hashtable;

import Jt.security.JtEncryptedMessage;
import Jt.security.JtMessageCipher;



/**
 * Jt Factory
 */

public class JtFactory extends JtFactoryMethod {


  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtFactory.class.getName();
  
  public static final String RESOURCE_FILE = "Jt.properties";  // properties file
  public static final String JtGET_ATTRIBUTES = "JtGET_ATTRIBUTES";
  public static final String JtGET_ATTRIBUTE_TABLE = "JtGET_ATTRIBUTE_TABLE";
  public static final String JtGENERATE_ID = "JtGENERATE_ID";  
  public static final String JtLOAD_PROPERTIES = "JtLOAD_PROPERTIES";  
  
  // Internal Jt messages

  public static String JtCREATE_OBJECT = "JtCREATE_OBJECT";  
  public static String JtSEND_MESSAGE = "JtSEND_MESSAGE";  
  public static String JtSET_VALUE = "JtSET_VALUE";
  public static String JtGET_VALUE = "JtGET_VALUE";
  public static String JtREMOVE_OBJECT = "JtREMOVE_OBJECT";
  public static String JtSET_VALUES = "JtSET_VALUES";

  
  private Class stopClass = null;
  
  private static Hashtable resTable = null;            // Attribute values
  private static Hashtable resObjTable = null;         // Attribute values
  private static Hashtable singletonTable = new Hashtable ();      // Singleton table
  private static JtRegistry registry = new JtRegistry (); // Component registry
  //private static JtLogger logger; 

  // Context attributes


  private static boolean initialized = false;            // The framework has been initialized?
  //private static boolean firstFactory = true;          // first instance of JtFactory?    
  private static String resourceFile = RESOURCE_FILE;    // Jt properties file
  private static InputStream resourceStream = null;
  private static boolean logging = false;                // is logging enabled?
  private static String logFile = null;                  // Log file  
  private static int logLevel = JtLogger.JtDEFAULT_LOG_LEVEL;  // Log level

  private boolean useRegistry = true;                    // use the component registry ?
  
  private boolean synchronous = true;                    // Synchronous messaging ?
  protected boolean encrypted = false;                   // Encrypted messaging
  private boolean local = false;                         // Local property
  private JtMessageCipher messageCipher = null;
  private JtMessenger messenger = null;
  private boolean createSingleton = false;                  // Factory should create the component
                                                         // as a singleton (even if it is not a
                                                         // subclass of JtSinglenton or JtSingletonComponent)
  private JtContext context;
  
  public JtFactory () {
	  
      if (!initialized) {
          initialized = true;
          initialize ();
          loadObjectResources (this);

      }
      
      //if (firstFactory ) {     	
      //    loadObjectResources (this);
      //    firstFactory = false;
      //}
  }
  
  /**
   * Returns the stop class.
   */
  
  public Class getStopClass() {
      return stopClass;
  }

  /**
   * Specifies the stop class (the baseclass at which to stop the analysis).
   * 
   */
  public void setStopClass(Class stopClass) {
      this.stopClass = stopClass;
  }




/** 
   * Gets the name of the Jt properties file. The default value for this attribute is Jt.properties.
   * Attribute values are loaded from this properties file just after the component is created.
   */

  public String getResourceFile() {
      return resourceFile;
  }


  /** 
   * Specifies the file to be used as the Jt properties file. The default value for this attribute is Jt.properties.
   * Attribute values are loaded from this properties file after the component is created.
   * @param newResourceFile Jt resource file
   */

  public void setResourceFile(String newResourceFile) {
      resourceFile = newResourceFile;

      if (resourceFile != null)
          loadResourceFile ();  // check

  }
  
  /** 
   * Returns the resource input stream
   */
  public InputStream getResourceStream() {
      return resourceStream;
  }

  /** 
   * Specifies the resource input stream (internal use only)
   */

  public void setResourceStream(InputStream resourceStream) {
      JtFactory.resourceStream = resourceStream;
      //if (resTable != null) {
      //    handleTrace ("Jt Resources have been loaded already. ");
      //    return;
      //}
      loadResourcesFromStream (resourceStream);
  }

  /** 
   * Returns the logging flag.
   */

  public boolean getLogging() {
      return logging;
  }

  /** 
   * Specifies whether or not logging is enabled.
   * Updates the logger component.
   * @param logging
   */

  public void setLogging(boolean logging) {
      JtFactory.logging = logging;
      
		if (logger == null)
			return;
			
		logger.setLogging(logging);
  }
  
    /**
     * Returns the file to be used for logging purposes.
     */
	public String getLogFile() {
		return logFile;
	}


	/** 
	 * Specifies the file to be used for logging purposes.
	 * Updates the logger component.
	 * @param newLogFile name of the log file
	 */

	public void setLogFile(String newLogFile) {

		// CARE
		//if (newLogFile != null && logFile != null)
		//	if (newLogFile.equals(logFile))
		//		return;

		logFile = newLogFile;
		
		if (logger == null)
			return;
			
		logger.setLogFile(logFile);	

		/*
		logging = true;

		if (logFile != null)
			openLogFile ();
        */
	}
	
    /** 
     * Returns the logging level.
     */

    public int getLogLevel() {
        return logLevel;
    }

    /** 
     * Specifies the logging level.
     * Updates the logger component.
     * @param logLevel
     */

    public void setLogLevel(int logLevel) {
        JtFactory.logLevel = logLevel;
        
		if (logger == null)
			return;
			
		logger.setLogLevel(logLevel);	
    }

    /**
     * Returns the value of useRegistry.
     */
    
    public boolean isUseRegistry() {
    	return useRegistry;
    }

    /**
     * Specifies whether or not the component should be added
     * to the component registry while it is being created. The default
     * is true.
     */
    
    public void setUseRegistry(boolean useRegistry) {
    	this.useRegistry = useRegistry;
    }

    
    /**
     * Returns the registry component. For internal use only.
     */   
    public static JtRegistry getRegistry() {
    	return registry;
    }
    
    
   /**
    * Returns the value of synchronous.
    */

    public boolean isSynchronous() {
		return synchronous;
	}

    /**
     * Specifies whether or not this message should be processed asynchronously (independent thread).
     */
    
	public void setSynchronous(boolean synchronous) {
		this.synchronous = synchronous;
	}

	/**
	 * Returns the value of encrypted.
	 */


	public boolean isEncrypted() {
		return encrypted;
	}
	

	/**
	 * Specifies whether or not this message should be encrypted.
	 */

	public void setEncrypted(boolean encrypted) {
		this.encrypted = encrypted;
	}

	public boolean isCreateSingleton() {
		return createSingleton;
	}

	public void setCreateSingleton(boolean createSingleton) {
		this.createSingleton = createSingleton;
	}
	
	/*
	 * Returns the message context. It contains authentication information (username, password, etc).
	 */

	public JtContext getContext() {
		return context;
	}

	/*
	 * Specifies the message context.  
	 */

	public void setContext(JtContext context) {
		this.context = context;
	}

	/**
     * Specifies the registry component. For internal use only.
     */
    public static void setRegistry(JtRegistry registry) {
    	JtFactory.registry = registry;
    }
    
/**
   * Creates a component of the specified class. The object is added to the
   * component registry using he ID passed as parameter (if useRegistry is true). 
   * If another component with the same ID already exists, an error is produced.
   * After creating the component, it retrieves its attributes using the Jt properties file. 
   * @param class_name class name
   * @param id  object id
   * @return object created or  null
   */

  public Object createObject (Object class_name, Object id) {
      Object obj = null;
      Class jtclass;
      //String objId;
      Object tmp;

      if (id == null) {
          //objId = null;
          handleTrace ("createObject:" + class_name);
      } else {
          handleTrace ("createObject:" + class_name + "," + id);
          //objId = (String) id;
      }
      if (class_name == null) {
          handleError ("createObject: invalid paramenters");
          return (null);
      }

      // Entries should be added to the component registry ?
      
      if (useRegistry) {
    	  obj = lookupObject (id);

    	  // check for duplicates in the component registry
    	  if (obj != null) {
    		  if (!logging)
    			  handleWarning 
    			  ("createObject: unable to create a duplicate entry in the component registry:" + id);
    		  else
    			  handleError 
    			  ("createObject: unable to create a duplicate entry in the component registry:" + id);
    		  return (null);
    	  }
      }

      try {
          jtclass = Class.forName ((String) class_name);
      } catch (Exception e) {
          handleException (e);
          return (null);
      }

      // Create a new instance of the object

      try {
          
          if (createSingleton || JtSingleton.class.isAssignableFrom (jtclass) ||
        		  JtSingletonComponent.class.isAssignableFrom (jtclass)) {
              
              
              synchronized (singletonTable) {
              
                  obj = singletonTable.get(class_name);
                  
                  if (obj != null) {
                      handleTrace 
                      ("createObject: attempt to create another instance of a Singleton (" +
                              class_name + ")", JtLogger.JtMIN_LOG_LEVEL); 
                      return (obj);
                      
                  }
                  
                  obj = jtclass.newInstance();
                  singletonTable.put(class_name, obj);

              }
/*               
              if (obj == null)
                  handleTrace 
                  ("JtObject.createObject: attempt to create another instance of a Singleton (" +
                          class_name + ")", 0); 
*/
          }  else   	  		  
        	  obj = jtclass.newInstance ();

/*
          if (JtSingleton.class.isAssignableFrom (jtclass)) {
              
              tmp1 = jtclass.newInstance(); // ugly
              
              obj = ((JtSingleton) tmp1).getInstance();
              
              if (obj == null) {
                  obj = jtclass.newInstance ();

                  ((JtSingleton) tmp1).setInstance (obj);
                  tmp = ((JtSingleton) tmp1).getInstance ();        
                  // Although unlikely, another thread may create the Singleton instance
                  // first. In this case, a message should be produced. 
                  if (tmp != obj) {
                      handleTrace 
                      ("JtObject.createObject: attempt to create another instance of a Singleton (" +
                              class_name + ")", 0); 
                      return (tmp); 
                  }
                    

              } else {
                  handleTrace 
                  ("JtObject.createObject: attempt to create another instance of a Singleton (" +
                          class_name + ")", 0); 
                  return (obj); 
              }
          } else
              obj = jtclass.newInstance ();
*/
          
          if (obj instanceof JtObject) {
              if  (id != null)
                  //((JtObject)obj).setObjName (absoluteName ((String) objId));
                  ((JtObject)obj).setComponentId (id);

          }

          // add the new component to the component registry
          if (obj != null) {
              if (id != null && useRegistry) {
                  tmp = add (id, obj);
                  if (tmp == null)
                  	return (null); // duplicate component
              }    
              //else
              //    add (obj, obj);
          }
          loadObjectResources (obj);
      } catch (Exception e) {
          handleException (e);
      }


      return (obj);
  }

  /** Creates a component of the specified class. 
   * @param className class name
   * @return object created or  null
   */
  public Object createObject (Object className) {

      return (createObject (className, null));

  }

  /** 
   * Component lookup.
   */
  
  Object lookupObject (Object id) {
  	JtMessage msg = new JtMessage (JtRegistry.JtREAD);

      if (id == null)
      	return null;
      
      //if (!(id instanceof String))
      if (!validComponentId (id))
          return (id); 

      msg.setMsgData(id);
      return (registry.processMessage(msg));
  }    


  private boolean checkModifiers (Class cl, String prop) {

      //Class cl;
      Field field;
      int mod;


      if (cl == null || prop == null)
          return (false);


      field = null;
      try {
          field = cl.getDeclaredField (prop); // property dup property names
          //System.out.println ("class:" + cl.getName ());

      } catch (Exception e) {

          //handleException (e);

          if (cl.getSuperclass () == null) {
              handleException (e);
              return (false);
          }
      }

      if (field == null) {
          cl = cl.getSuperclass ();
          return (checkModifiers (cl, prop));
      }

      mod = field.getModifiers ();

      if (Modifier.isTransient (mod)) {
          return (false);
      }
      if (Modifier.isStatic (mod)) {
          return (false);
      } 
      return (true);       
  }

  private boolean copyObject (Object obj, Object target) {
      //Object args[];
      PropertyDescriptor[] prop;
      //Class p;
      //Method m;
      BeanInfo info = null;
      Object value, svalue = null;
      int i;


      if (obj == null || target == null)
          return (false);

      if (obj.getClass () != target.getClass ()) {
          handleError 
          ("copyObject: object classes should be the same (source and target)");
          return (false);
      }

      try {
          info = Introspector.getBeanInfo(
                  obj.getClass (), java.lang.Object.class);
      } catch(Exception e) {
          handleException (e);
          return (false); //check
      }

      prop = info.getPropertyDescriptors();


      for(i = 0; i < prop.length; i++) {

          if (!checkModifiers (obj.getClass (),prop[i].getName())) {
              continue;
          }

          value = getValue (obj, prop[i].getName()); // check

          svalue = null;
          if (value instanceof Integer ||
                  value instanceof Long || 
                  value instanceof Float ||
                  value instanceof Byte ||
                  value instanceof Boolean ||
                  value instanceof Short ||
                  value instanceof Double ||
                  value instanceof Character) {
              svalue =  value.toString (); 
          } else
              svalue = value;


          setValue (target, prop[i].getName(), svalue);

      }

      return (true);
  } 

  
	private Object decryptMessage (JtEncryptedMessage encryptedMessage, Key key) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		Object message;

		
		if (encryptedMessage == null)
			return (null);		
		
		if (messageCipher == null)
			messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        //messageCipher.setSessionKey(key);

		message = (Object) messageCipher.processMessage(encryptedMessage);
		
		if (message == null) {
			handleError ("Unable to decrypt message");
			return (null);
		}
		return (message);
		
	}
	
	private boolean validComponentId (Object id) {
		if (id == null)
			return (false);
		if (id instanceof String || id instanceof Integer || id instanceof Long)
			return (true);
		
		return (false);
	}
   
	private JtEncryptedMessage encryptMessage (Object message, Key key) {
		JtFactory factory = new JtFactory ();
		//JtMessageCipher messageCipher;
		JtEncryptedMessage encryptedMessage;
		//JtMessageCipher messageCipher = null;
		
		if (message == null)
			return (null);		
		
		if (messageCipher == null)
			messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        //messageCipher.setSessionKey(key);
		
		encryptedMessage = (JtEncryptedMessage) messageCipher.processMessage(message);
		
		if (encryptedMessage == null) {
			handleError ("Unable to encrypt message");
			return (null);
		}
		return (encryptedMessage);
		
	}
	
	
	private boolean initializeProxy (JtProxy proxy) {
		JtMessage msg = new JtMessage (JtProxy.JtINITIALIZE_PROXY);
		Boolean Bool;

		if (proxy == null)
			return (false);
		
		if (proxy.getSubject() != null)
			return (true);

		msg.setEncrypt(encrypted);
		Bool = (Boolean) ((JtProxy) proxy).processMessage(msg);

		return (Bool.booleanValue());

	}
  
  // Sets the value of an attribute via a proxy

  private boolean setProxyValue (JtProxy id, Object att, Object value) {
      JtMessage msg = new JtMessage (JtFactory.JtSET_VALUE);
      Object reply;
      JtEnvelope envelope;
      //JtMessenger messenger;
      JtEncryptedMessage encMessage;
      Object message;

	  
      if (id == null || att == null)
          return (false);
      
      if ((id instanceof JtRemoteProxy) && !initializeProxy (id))
    	  return (false);
      
      msg.setMsgTo(((JtProxy) id).getSubject());
      msg.setMsgContent(att);
      msg.setMsgData (value); 
      msg.setEncrypt(encrypted);

      if (id instanceof JtRemoteProxy) {
    	  envelope = new JtEnvelope ();
    	  envelope.setMessage(msg);
    	  message = envelope;
      } else
    	  message = msg;
      
      //messenger = new JtMessenger ();
      //messenger.setEncrypted(true);
      //reply = messenger.sendMessage(id, msg);
      if (encrypted) {
    	  encMessage = encryptMessage (message, null);

    	  if (encMessage == null)
    		  return (false);

    	  reply = ((JtProxy) id).processMessage(encMessage); //check

    	  if (reply instanceof JtEncryptedMessage) {
    		  reply = decryptMessage ((JtEncryptedMessage) reply, null);
    	  }
      } else
    	  reply = ((JtProxy) id).processMessage(message); 
    	  
      
      if (reply == null || !(reply instanceof Boolean))
    	  return (false);
      
      return (((Boolean)reply).booleanValue()); // check
  }

  /** 
   * Sets the value of an attribute. 
   * This method is able to convert the value from String to the correct type.
   * Automatic conversion from String is done for the following types:
   * byte, short, int, long, float, double, char, boolean and java.util.Date.
   * @param id object id
   * @param att attribute name
   * @param value attribute value
   */

  public boolean setValue (Object id, Object att, Object value) {

      Object obj;
      Object args[];
      PropertyDescriptor[] prop;
      int i;
      Class p;
      Method m;
      BeanInfo info = null;


      if ("password".equals(att))
      	handleTrace ("setValue:" + id + "," + att + "...");
      else	
      	handleTrace ("setValue:" + id + "," + att + "," + value);

      if (id == null | att == null) {
          handleError ("setValue: invalid parameters");
          return false;
      }
      
      
      // Use a Proxy
      if (id instanceof JtProxy && !local) {
          return (setProxyValue ((JtProxy) id, att, value));
      }

      obj = lookupObject (id);

      if (obj == null) {
          handleError ("setValue: unable to find object: " + id);
          return (false);
      }

      try {

          info = Introspector.getBeanInfo(
                  obj.getClass (), java.lang.Object.class);
      } catch(Exception e) {
          handleException (e);
          return (false);
      }

      prop = info.getPropertyDescriptors();
      for(i = 0; i < prop.length; i++) {

          if (prop[i].getName().equals ((String) att)) {

              p = prop[i].getPropertyType();
              args = new Object[1];
              //System.out.println ("setValue:type" + p);

              try {
                  if (p.getName().equals ("java.lang.String") ){
                      args[0] = value;
                  } else if (p.getName().equals ("byte") ){
                      args[0] = (value instanceof String)?Byte.valueOf ((String) value):value;
                  } else if (p.getName().equals ("short") ){
                      args[0] = (value instanceof String)?Short.valueOf ((String) value):value;
                  } else if (p.getName().equals ("int") ){
                      args[0] = (value instanceof String)?Integer.valueOf ((String) value):value;
                      //} else if (p.getName().equals ("java.lang.Long") ){
                  } else if (p.getName().equals ("long") ){
                      args[0] = (value instanceof String)?Long.valueOf ((String) value):value;
                  } else if (p.getName().equals ("float") ){
                      args[0] = (value instanceof String)?Float.valueOf ((String) value):value;
                  } else if (p.getName().equals ("double") ){
                      args[0] = (value instanceof String)?Double.valueOf ((String) value):value;
                  } else if (p.getName().equals ("boolean") ){
                	  if (value instanceof String) {
                		  if (!((String) value).equalsIgnoreCase("true") &&
                				  !((String) value).equalsIgnoreCase("false")) {
                			  handleError ("Invalid boolean:" + value);
                			  return false;
                		  }
                				  
                	  }
                      args[0] = (value instanceof String)?Boolean.valueOf ((String) value):value;
                  } else if (p.getName().equals ("char") ){
                      args[0] = (value instanceof String)?new Character (((String) value).charAt(0)):value;
                  } else if (p.getName().equals ("java.util.Date") ){
                      DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
                      //SimpleDateFormat df;
                      if (value instanceof String)
                          try {
                              //df = new SimpleDateFormat ((String) value);
                              if (value != null && value.equals("")) {
                                  handleWarning ("setValue(date): empty string");
                                  return (true);
                              }    
                              args[0] = df.parse ((String) value);
                              //args[0] = new SimpleDateFormat ((String) value);
                          } catch (Exception e) {
                              handleException (e);
                              return (false);
                          }
                          else
                              args[0] = value;
                  } else
                      args[0] = value;
              } catch (Exception e) {
                  handleException (e);
                  return (false);
              }

              try {
                  m = prop[i].getWriteMethod ();
                  if (m == null) {
                      handleError 
                      ("setValue failed:missing setter for attribute " + att);  
                      return (false);
                  }
                  m.invoke (obj, args);
              } catch (Exception e) {
                  handleException (e);
              }
              return (true);

          }
      }

      handleError ("setValue: invalid attribute:"+  att);
      return (false);

  }
  
  
  private boolean removeProxy (JtProxy id) {
      JtMessage msg = new JtMessage (JtFactory.JtREMOVE_OBJECT);
	  //JtEncryptedMessage encryptedMessage;
	  Object reply;
	  JtEnvelope envelope;
	  JtEncryptedMessage encMessage;
	  Object message;

      if (id == null)
          return (false);
      
      if ((id instanceof JtRemoteProxy) && !initializeProxy (id))
    	  return (false);
      
      msg.setEncrypt(encrypted);
      msg.setMsgTo(((JtProxy)id).getSubject());
      
      
      if (id instanceof JtRemoteProxy) {
    	  envelope = new JtEnvelope ();
    	  envelope.setMessage(msg);
    	  message = envelope;
    	  
    	  if (context != null)
    		  envelope.setContext(context);
      } else
    	  message = msg;
      
      
      if (encrypted) {
    	  encMessage = encryptMessage (message, null);

    	  if (encMessage == null)
    		  return (false);

    	  reply = ((JtProxy) id).processMessage(encMessage);

    	  if (reply instanceof JtEncryptedMessage) {
    		  reply = decryptMessage ((JtEncryptedMessage) reply, null);
    	  }
      } else
    	  reply = ((JtProxy) id).processMessage(message); 

      
	  if (reply == null || !(reply instanceof Boolean))
		  return (false);

	  return (((Boolean) reply).booleanValue());     
      

  }

  // Gets the value of an attribute via a proxy

  private Object getProxyValue (JtProxy id, Object att) {
      JtMessage msg = new JtMessage (JtFactory.JtGET_VALUE);
	  JtEncryptedMessage encMessage;
	  Object reply;
      JtEnvelope envelope;
      Object message;
      

      if (id == null)
          return (null);
      
      if ((id instanceof JtRemoteProxy) && !initializeProxy (id))
    	  return (null);
      
      
      msg.setMsgTo(((JtProxy)id).getSubject());
      msg.setMsgContent(att);
      msg.setEncrypt(encrypted);
      
      if (id instanceof JtRemoteProxy) {
    	  envelope = new JtEnvelope ();
    	  envelope.setMessage(msg);
    	  message = envelope;
      } else
    	  message = msg;
      
      if (encrypted) {
    	  encMessage = encryptMessage (message, null);

    	  if (encMessage == null)
    		  return (null);

    	  reply = ((JtProxy) id).processMessage(encMessage);

    	  if (reply instanceof JtEncryptedMessage) {
    		  reply = decryptMessage ((JtEncryptedMessage) reply, null);
    	  }
      } else
    	  reply = ((JtProxy) id).processMessage(message); 

      return (reply);

      
  }
  
 /* 
  private Object sendMessageToProxy (Object id, Object message) {
      JtMessage msg = new JtMessage (JtFactory.JtSEND_MESSAGE);
      //Object subject = ((JtProxy)id).getSubject();
	  //JtEncryptedMessage encryptedMessage;
	  //Object reply;
	  //JtMessage msg1 = new JtMessage (JtProxy.JtINITIALIZE_PROXY);
	  
	  
      if (id == null)
          return (null);
      
      msg.setMsgTo(((JtProxy)id).getSubject());
      msg.setMsgContent(message);
      msg.setEncrypt(encrypted);
      
      if (!this.isSynchronous())  {
    	  msg.setAsynchronous(true);
      }

      return (((JtProxy)id).processMessage(msg));

  }
*/  

  /** 
   * Gets the value of an attribute. An object is always returned.  
   * For primitive types, the corresponding object type is returned.
   * For instance, Integer is returned if
   * the attribute is of type int. 
   *
   * @param id component id
   * @param att attribute name
   * @return attribute value
   */

  public Object getValue (Object id, Object att) {
      Object obj;
      Method m;
      //Class p;
      BeanInfo info = null;
      PropertyDescriptor[] prop;
      int i;

      handleTrace ("getValue: " + id + "," + att);



      if (id == null || att == null) {
          handleError ("getValue: invalid paramenters");
          return (null);
      }

      if (id instanceof JtProxy) {
          return (getProxyValue ((JtProxy) id, att));
      }

      obj = lookupObject (id);

      if (obj == null) {
          handleError ("getValue: unable to find object " + id);
          return (null);
      }


      try {

          info = Introspector.getBeanInfo(obj.getClass (),
                  java.lang.Object.class);

      } catch(Exception e) {
          handleException (e);
          return (null);
      }

      prop = info.getPropertyDescriptors();

      for(i = 0; i < prop.length; i++) {


          if (prop[i].getName().equals ((String) att))    {

              try {
                  m = prop[i].getReadMethod ();
                  if (m == null) {
                      handleError 
                      ("getValue: getReadMethod returned null");
                      return (null);
                  }
                  return (m.invoke (obj, null));
              } catch (Exception e) {
                  handleException(e);
                  return (null);
              }
          }
      }
      handleError ("getValue:invalid attribute:" + att);
      return (null);

  }

  /**
   * Removes an object. A JtREMOVE message is sent to the object. All components
   * should process JtREMOVE and release any resources that were allocated 
   * (sockets, Database connections, etc.).  
   * @param id  object id
   */

  public boolean removeObject (Object id) {
      Object obj;
      Object singleton;

      handleTrace ("JtObject.removeObject: " + id);

      if (id == null) {
          handleError 
          ("removeObject: invalid paramenter (null)");
          return (false);
      }

      obj = lookupObject (id);

      if (obj == null) {
          handleError ("removeObject: object not found: "+
                  id);
          return (false);
      }
      
      // Jt Proxies
      
      if (obj instanceof JtProxy) {
          if (!removeProxy ((JtProxy) obj))
        	  return (false);
          
          if (validComponentId (id))
        	  return (remove (id) != null);
          else
        	  return (true);

      }

      
      sendMessage (obj, new JtMessage (JtObject.JtREMOVE));
      
      
      synchronized (singletonTable) {
    	  singleton = singletonTable.get (obj.getClass().getName());
    	  
    	  if ((obj == singleton) && singleton != null)
    		  singletonTable.remove(singleton);
      }

      if (validComponentId (id))
    	  return (remove (id) != null);
      else
    	  return (true);


  }

  
  // handleMessageTrace 
/*
  private void handleMessageTrace (Object message) {

      //String nl = System.getProperty("line.separator");
      String tmp;
      String xmlMessage;
      JtMessage msg;
            

      
      if (logger.getLogLevel() == JtLogger.JtMIN_LOG_LEVEL) {
    	  xmlMessage = (String) encodeObject (message);
    	  handleTrace ("Message ...\n" + xmlMessage, JtLogger.JtMIN_LOG_LEVEL);
    	  return;
      }
      if (message instanceof JtMessage) {
    	  msg = (JtMessage) message;
    	  tmp = "JtMessage.msgId:" + msg.getMsgId ();
    	  
    	  
    	  //if (msg.getMsgSubject () != null)
    	  //	  tmp +=nl+ "JtMessage.MsgSubject:"+ msg.getMsgSubject();
    	  	  
    	  if (msg.getMsgContent () != null)
    		  tmp += "\nJtMessage.msgContent:"+ msg.getMsgContent();
  
          handleTrace (tmp);
      }
      
  }  
*/

/*
  private Object componentName (Object obj) {
      String name;

      if (obj == null)
      	return null;
      
      if (!(obj instanceof JtObject))
          return (obj);

      name = ((JtObject) obj).getObjName (); 
      if (name == null)
          return (obj);

      return (name);
  }
*/

  /**
   * Sends a message to a component (Jt messaging design pattern). 
   *
   * @param id    component id
   * @param msgid message
   */

  public Object sendMessage (Object id, Object msgid) {
      
      if (messenger == null) {
    	  messenger = (JtMessenger) createObject (JtMessenger.JtCLASS_NAME);
      }
            
      if (id == null) {
          handleError ("sendMessage: invalid component Id");
          return (null);
      } 
      
      messenger.setContext(context);
      messenger.setSynchronous(synchronous);
      messenger.setEncrypted(encrypted);
      return (messenger.sendMessage(id, msgid));


  }


  private Object encodeObject (Object obj) {

      ByteArrayOutputStream stream = new ByteArrayOutputStream ();
      XMLEncoder e; 
      Object result = null;


      if (obj == null)
          return (null);

      try {

          e = new XMLEncoder(
                  new BufferedOutputStream(stream));
          e.writeObject(obj);
          e.close();
          result = stream.toString ();

      } catch (Exception ex) {
          handleException (ex);
          return (null);
      }    
      return (result); 

  }

  private Object decodeObject (Object obj) {

      ByteArrayInputStream stream;
      Object result = null;
      XMLDecoder d;


      if (obj == null)
          return (null);

      stream = new ByteArrayInputStream (((String) obj).getBytes ());

      try {

          d = new XMLDecoder(
                  new BufferedInputStream(stream));
          result = d.readObject();
          d.close();

      } catch (Exception ex) {
          handleException (ex);
      } 
      return (result);    

  }

  // Clone the object
/*
  private Object cloneObject () {


      JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
      JtObject tmp = new JtObject();
      Object aux;

      msg.setMsgContent (this);
      aux = tmp.processMessage  (msg);

      if (aux == null) {
          handleError ("cloneObject: Unable to encode the object (XML format"); 
          return (null);
      }

      msg = new JtMessage (JtObject.JtXML_DECODE);

      msg.setMsgContent (aux);
      return (tmp.processMessage (msg));    
  }

  private void resetFramework () {
      InputStream resStream = this.getClass().getClassLoader().getResourceAsStream (JtFactory.RESOURCE_FILE);
      if (resStream != null) {
          setResourceStream (resStream);
          return;
      }
  }
*/
  private void setValues (JtValueObject values) {
      JtIterator iterator;
      Object obj, value;
      JtMessage msg = new JtMessage (JtValueObject.JtGET);

      if (values == null)
          return;

      iterator = (JtIterator) values.processMessage(new JtMessage (JtValueObject.JtGET_KEYS));

      if (iterator == null)
          return;

      for (;;) {
          obj = iterator.processMessage(new JtMessage (JtIterator.JtNEXT));
          if (obj == null)
              break;
          msg.setMsgData(obj);
          value = values.processMessage(msg);
          setValue (this, obj, value);
      }
  }

  
  private Object generateObjectId () {
      JtIdGenerator generator;    

      generator = (JtIdGenerator) this.createObject(JtIdGenerator.JtCLASS_NAME);

      if (generator == null)
          return (null);

      return (this.sendMessage(generator, new JtMessage (JtObject.JtACTIVATE)));
  }

  /*
  private boolean checkModifiers (Class cl, String prop) {

      Field field;
      int mod;


      if (cl == null || prop == null)
          return (false);


      field = null;
      try {
          field = cl.getDeclaredField (prop); // property dup property names

      } catch (Exception e) {

          //handleException (e);

          if (cl.getSuperclass () == null) {
              handleWarning ("JtFactory.checkModifiers:" + e.getMessage());
              return (false);
          }
      }

      if (field == null) {
          cl = cl.getSuperclass ();
          return (checkModifiers (cl, prop));
      }

      mod = field.getModifiers ();

      if (Modifier.isTransient (mod)) {
          return (false);
      }
      if (Modifier.isStatic (mod)) {
          return (false);
      } 
      return (true);       
  }
  */


  private JtHashTable getAttributes (Object obj) {

      PropertyDescriptor[] prop;
      int i;
      BeanInfo info = null;
      //Hashtable attr;
      JtMessage msg = new JtMessage (JtHashTable.JtPUT);
      JtHashTable table = new JtHashTable ();

      //attr = new Hashtable ();


      try {
          //info = Introspector.getBeanInfo(
          //        obj.getClass (), java.lang.Object.class);
          if (stopClass != null && stopClass.isAssignableFrom(obj.getClass ()))
              info = Introspector.getBeanInfo(
                      obj.getClass (), stopClass);
          else    
              info = Introspector.getBeanInfo(
                      obj.getClass (), java.lang.Object.class);
      } catch(Exception e) {
          handleException (e);
          return (null);
      }

      prop = info.getPropertyDescriptors();
      for(i = 0; i < prop.length; i++) {
          
          // Skip static and transient attributes

          if (!checkModifiers (obj.getClass (),prop[i].getName())) {
              continue;
          }

          msg.setMsgContent(prop[i]);
          msg.setMsgData (prop[i].getName()); 
          table.processMessage(msg);
          //attr.put (prop[i].getName(), null); 

      }

      return (table);
  }
  

  private Hashtable getAttributeTable (Object obj) {

      PropertyDescriptor[] prop;
      int i;
      BeanInfo info = null;
      Class cl;
      Hashtable table = new Hashtable ();
      Method m;
      Object value;


      stopClass = null;

      try {
          //info = Introspector.getBeanInfo(
          //        obj.getClass (), java.lang.Object.class);
          if (stopClass != null && stopClass.isAssignableFrom(obj.getClass ()))
              info = Introspector.getBeanInfo(
                      obj.getClass (), stopClass);
          else    
              info = Introspector.getBeanInfo(
                      obj.getClass (), java.lang.Object.class);
      } catch(Exception e) {
          handleException (e);
          return (null);
      }

      prop = info.getPropertyDescriptors();
      for(i = 0; i < prop.length; i++) {
          

          cl = prop[i].getPropertyType();
          // Skip static and transient attributes

          //if (!checkModifiers (obj.getClass (),prop[i].getName())) {
          //    continue;
          //}
          
          m = prop[i].getReadMethod ();
          if (m == null) {
              handleError 
              ("getAttributes: getReadMethod returned null for " +
            		  prop[i].getName());
              continue;
          }
          try {
        	  value = m.invoke (obj, null);
          } catch (Exception ex){
        	  handleException (ex);
        	  continue;
          }

          //if (!(cl.isPrimitive() || value instanceof String)) {

          //    continue;

          //}
          handleTrace ("JtFactory.getAttributeTable:" + prop[i].getName(),
        		  JtLogger.JtMIN_LOG_LEVEL);	  
          table.put(prop[i].getName(), prop[i]);

      }

      return (table);
  }




// Create an object of a specific class
 /* 
  private Object create (String className) {
    Class jtclass;
    
    if (className == null)
        return (null);      
    try {
        jtclass = Class.forName ((String) className);
        return (jtclass.newInstance ());
    } catch (Exception e) {
        handleException (e);
        return (null);
    }  

  }
*/
  /**
    * Process object messages.
    * <ul>
    * </ul>
    */

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage msg = (JtMessage) message;
      Object content;
      JtEnvelope envelope;
      boolean bool;


      if (msg == null) {
    	  handleError ("Invalid message: null");
          return null;
      }
      
      msgid = (String) msg.getMsgId ();

      if (msgid == null)
          return null;
      
      if (msgid.equals (JtFactory.JtSET_VALUE)) {
          bool = setValue (msg.getMsgTo(),
                  msg.getMsgContent (),
                  msg.getMsgData());
          return (new Boolean(bool));
      }

      if (msgid.equals (JtFactory.JtSET_VALUES)) {
          setValues ((JtValueObject) msg.getMsgContent ());
          return (null);
      }

      if (msgid.equals (JtFactory.JtGET_VALUE)) {
          return (getValue (msg.getMsgTo(), msg.getMsgContent ()));
    	  /*
          if (msg.getMsgSubject () == null)
              return (getValue (this,
                      msg.getMsgContent ()));
          else
              return (getValue (msg.getMsgSubject (),
                      msg.getMsgContent ()));
          */
      }

      //check
      //if (msgid.equals (JtObject.JtCREATE_OBJECT)) {
      //    createObject (msg.getMsgContent (),
      //            msg.getMsgData());
      //    return (null);
      //}

      if (msgid.equals (JtFactory.JtREMOVE_OBJECT)) {
          bool = removeObject (msg.getMsgTo ());
          return (new Boolean (bool));
      }

      if (msgid.equals (JtFactory.JtSEND_MESSAGE)) {
    	     	  
    	  if (msg != null && msg.isAsynchronous()) {
    		  
        	  envelope = new JtEnvelope ();
        	  envelope.setMessage(msg.getMsgContent());
        	  envelope.setAsynchronous(true);
        	  
        	  return (sendMessage (msg.getMsgTo (), envelope));
    		  
    	  }
    	  
          return (sendMessage (msg.getMsgTo (),
                  msg.getMsgContent ()));

      }

      if (msgid.equals (JtObject.JtCOPY)) {
          return (new Boolean (copyObject (msg.getMsgContent (),
                  msg.getMsgData ())));

      }

      // Encode Object (XML format)

      if (msgid.equals (JtObject.JtXML_ENCODE)) {
          return (encodeObject (msg.getMsgContent ()));
      }

      // Decode Object

      if (msgid.equals (JtObject.JtXML_DECODE)) {
          return (decodeObject (msg.getMsgContent ()));
      }

      // This message is being deprecated
      // Use JtPrinter
      //if (msgid.equals (JtObject.JtPRINT)) {
      //    System.out.println (encodeObject (this));
      //    return (null);
      //}

      // This message is being moved to the subclasses
      // Check the documentation
      
      if (msgid.equals (JtObject.JtVALUE_OBJECT)) {
          return (this);
      }

      // Internal message. It will cause the framework
      // to be initialized. Use it with care

      //if (msgid.equals (JtObject.JtRESET_FRAMEWORK)) {
      //    resetFramework ();
      //    return (null);
      //}

      
      if (msgid.equals (JtFactory.JtCREATE_OBJECT)) {
          content = (String) msg.getMsgContent ();
          if (content == null) {
              handleError ("JtCREATE_OBJECT: invalid message. Class name is null.");
              return (null);
          }    
          return (createObject ((String) msg.getMsgContent (),
        		  msg.getMsgTo()));
      }
      
      if (msgid.equals (JtFactory.JtLOOKUP)) {
          //content = (String) msg.getMsgContent ();
          if (msg.getMsgContent() == null) {
              handleError ("JtFactory.JtLOOKUP: component Id is null.");
              return (null);
          }    
          return (lookupObject (msg.getMsgContent()));

      }
      
      if (msgid.equals (JtFactory.JtGET_ATTRIBUTES)) {
          content = msg.getMsgContent ();
          if (content == null) {
              handleError ("JtGET_ATTRIBUTES: invalid message (msgContent). Object is null.");
              return (null);
          }    
          return (getAttributes (msg.getMsgContent ()));
      }
      
      if (msgid.equals (JtFactory.JtGET_ATTRIBUTE_TABLE)) {
          content = msg.getMsgContent ();
          if (content == null) {
              handleError ("JtGET_ATTRIBUTES: invalid message (msgContent). Object is null.");
              return (null);
          }    
          return (getAttributeTable (msg.getMsgContent ()));
      }
      
      if (msgid.equals (JtFactory.JtGENERATE_ID)) {

          return (generateObjectId ());
      }
      
      if (msgid.equals (JtFactory.JtLOAD_PROPERTIES)) {
    	  // loadObjectResources needs to be be moved to JtFactory
    	  loadObjectResources (msg.getMsgContent ());
    	  return (null);
      }
      
      return (super.processMessage (message)); 


  }

  // add: add an component to the registry
  
  private Object add (Object id, Object obj) {
  	JtMessage msg = new JtMessage (JtObject.JtCREATE);
      if (id == null || obj == null)
          return null;
      
      msg.setMsgData(id);
      msg.setMsgContent(obj);        
      
      return (registry.processMessage(msg));
  }
  
  // remove: remove a component from the registry
  
  private Object remove (Object id) {
  	JtMessage msg = new JtMessage (JtObject.JtDELETE);
      if (id == null)
          return null;
      
      msg.setMsgData(id);      
      
      return (registry.processMessage(msg));
  }

   
  
  private void loadClassResources (Object obj, Class cl) {
      String className;
      Hashtable ht;
      Enumeration rnames;
      Object resource;
      boolean tmp;

      //handleTrace ("Jt: Loading Class ..." + cl);
      if (obj == null || cl == null)
          return;
      
      className = cl.getName();

      ht = (Hashtable) resTable.get (className);

      if (ht == null) {
          loadClassResources (obj, cl.getSuperclass()); // check
          return;
      }
      
      rnames = ht.keys ();
      if (rnames == null)
          return;


      while (rnames.hasMoreElements ()) {
          resource = rnames.nextElement ();
          tmp = local;
          local = true; // use local attributes
          setValue (obj, resource, ht.get (resource));
          local = tmp;
      } 
      
      loadClassResources (obj, cl.getSuperclass());
      
  }
  

  
  private void loadObjectResources (Object obj) {

      Hashtable ht;
      Enumeration rnames;
      Object resource;
      Object objId;
      //String className;
      boolean tmp;

      handleTrace ("Loading properties:" +
      		obj + "..");
      if (resTable != null) {


          // Load class resources

          if (obj == null)
              return;



          loadClassResources (obj, obj.getClass());

      }
      
      // Load object resources
      

      if (resObjTable == null)
          return; 
      
      if (!(obj instanceof JtObject))
          return;
                         
      objId = ((JtObject) obj).getComponentId();

      if (objId == null)
          return;
      
      
      ht = (Hashtable) resObjTable.get (objId);
      
      if (ht == null)
          return; 

      rnames = ht.keys ();
      if (rnames == null)
          return;

      while (rnames.hasMoreElements ()) {
          tmp = local;
          local = true; // use local attributes
          resource = rnames.nextElement ();
          setValue (obj, resource, ht.get (resource));
          local = tmp;
      }        
      
      //handleTrace ("Jt: Loaded Jt resources");
  }


  private void updateObjResources (JtResource res) {
      Hashtable ht;

      if (res == null)
          return;

      if (res.robj == null)
          return;

      if (resObjTable == null)
          resObjTable = new Hashtable ();

      if (resObjTable.get (res.robj) == null) {
          resObjTable.put (res.robj, new Hashtable ());
      }

      ht = (Hashtable) resObjTable.get (res.robj);

      if (ht == null)
          return; // check

      ht.put (res.name, res.value);
  }
  
  
  private void updateResources (JtResource res) {
      Hashtable ht;

      if (res == null)
          return;

      if (res.rclass == null)
          return;

      if (resTable == null)
          resTable = new Hashtable ();

      if (resTable.get (res.rclass) == null) {
          resTable.put (res.rclass, new Hashtable ());
      }

      ht = (Hashtable) resTable.get (res.rclass);

      if (ht == null)
          return; // check

      ht.put (res.name, res.value);
  }

  // Load resources from a stream

  private void loadResourcesFromStream (InputStream resourceStream) {
      String line;
      JtResource res;

      if (resourceStream == null)
          return;


      handleTrace ("Jt: reading resources from stream" + " ...");

      try {
          BufferedReader d = new BufferedReader 
          (new InputStreamReader (resourceStream));

          while ((line  = d.readLine ()) != null) {

              if (line.startsWith ("!") || 
                      line.startsWith ("//"))
                  continue;
              
              if (line.startsWith ("#")) {
                  res = parseObjResource (line);
                  
                  if (res != null)
                      updateObjResources (res);
                  
                  continue;
              }
              
              res = parseResource (line);

              if (res != null)
                  updateResources (res);
          }

      } catch (Exception ex) {
          handleException (ex);
      }
  } 

  // Load resources from a file

  private void loadResourceFile ( ) {
      String line;
      JtResource res;
      File file;

      if (resourceFile == null)
          return;

      file = new File (resourceFile);

      if (!file.exists ()) {
          handleTrace ("Resource file not found:" + resourceFile);
          return;
      }

      handleTrace ("Jt: reading resources from " +
              resourceFile + " ...");
      try {
          BufferedReader d = new BufferedReader 
          (new FileReader (resourceFile));

          while ((line  = d.readLine ()) != null) {
              //System.out.println ("JtFile.read_lines:" + line);
              if (line.startsWith ("!") || 
                      line.startsWith ("//"))
                  continue;
              
              if (line.startsWith ("#")) {
                  res = parseObjResource (line);
                  
                  if (res != null)
                      updateObjResources (res);
                  
                  continue;
              }
              
              res = parseResource (line);

              if (res != null)
                  updateResources (res);
          }

      } catch (Exception ex) {
          handleException (ex);
      }
  }
  

  private JtResource parseResource (String line) {

      //String resource_class 
      String tmp;
      int index;
      int length;
      JtResource res;

      if (line == null)
          return (null);

      length = line.length ();

      if (length == 0)
          return (null);

      index = line.indexOf (":");

      if (index < 0)
          return (null);

      if (index == length - 1)
          return (null);

      res = new JtResource ();

      res.value = line.substring (index+1, length);

      tmp = line.substring (0, index);

      index = tmp.lastIndexOf (".");

      if (index == -1)
          return (null);

      if (index == tmp.length () - 1)
          return (null);  // ends with a dot ?

      res.rclass = tmp.substring (0, index);
      res.name = tmp.substring (index + 1);  

      if ("password".equals(res.name))
      	handleTrace ("Jt Resource: " + "(" +
      			res.rclass + "," + res.name + ", ...)");
      else
      	handleTrace ("Jt Resource: " + "(" +
      			res.rclass + "," + res.name + "," + res.value
      			+ ")");

      return (res);

  }

  
  private JtResource parseObjResource (String line) {

      //String resource_class 
      String tmp;
      int index;
      int length;
      JtResource res;

      if (line == null)
          return (null);

      length = line.length ();

      if (length == 0)
          return (null);

      index = line.indexOf (":");

      if (index < 0)
          return (null);

      if (index == length - 1)
          return (null);

      res = new JtResource ();

      res.value = line.substring (index+1, length);

      tmp = line.substring (0, index);

      index = tmp.lastIndexOf (".");

      if (index == -1)
          return (null);

      if (index == tmp.length () - 1)
          return (null);  // ends with a dot ?

      res.robj = tmp.substring (1, index);
      res.name = tmp.substring (index + 1);  

      handleTrace ("Jt Resource: " + "(" +
              res.robj + "," + res.name + "," + res.value
              + ")");

      return (res);

  }


  // Initialize: initialize Jt

  private boolean initialize () {


      //String separator = System.getProperty ("file.separator");
      InputStream resStream;
      String logFile;

      //String tmp;

      logFile = System.getProperty ("Log");


      logger = new JtLogger ();
      exceptionHandler = new JtExceptionHandler ();

      if (logFile != null) {
          //logging = true; // show debugging messages
          //openLogFile (); 
          logger.setLogFile(logFile);
      }


      handleTrace ("Initializing Jt " + version + "...");



      //resStream = this.getClass().getClassLoader().getResourceAsStream (JtObject.RESOURCE_FILE);
      resStream = Thread.currentThread().getContextClassLoader().getResourceAsStream (JtFactory.RESOURCE_FILE);
      if (resStream != null) {
          setResourceStream (resStream);
          //return;
      }


      return (true);
      //loadResourceFile ();

  }
 
  /**
   * Demonstrates the messages processed by JtFactory
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtObject obj, obj1;
    JtHashTable attributes;
    JtMessage msg = new JtMessage (JtFactory.JtGET_ATTRIBUTES);
    JtPrinter printer = new JtPrinter ();


    // Create JtFactory

    obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "object");
    System.out.println (obj);

    msg.setMsgContent (obj);
    attributes =  (JtHashTable) factory.processMessage(msg);
    
    //factory.sendMessage (attributes, new JtMessage (JtObject.JtPRINT));
    //printer.processMessage(attributes);
    

    System.out.println (factory.processMessage (new JtMessage (JtFactory.JtGENERATE_ID)));

    // Demontrate the handling of singletons
    
    factory.setCreateSingleton (true);
    
    // Create the singlenton
    
    obj = (JtObject) factory.createObject(JtObject.JtCLASS_NAME);
    
    // The singleton instance is returned. No new instance is created
    
    obj1 = (JtObject) factory.createObject(JtObject.JtCLASS_NAME);
    
    if (obj == obj1) 
    	System.out.println("create singleton: GO");
    else
    	System.out.println("create singleton: FAIL"); 
    
    
  }

}


