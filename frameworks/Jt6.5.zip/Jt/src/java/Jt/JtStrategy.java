/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;


/**
 * Jt implementation of the Strategy pattern.
 */

public class JtStrategy extends JtObject {


  public static final String JtCLASS_NAME = JtStrategy.class.getName(); 
  private static final long serialVersionUID = 1L;
  protected Object concreteStrategy = null; // Concrete Strategy component
  public static final String JtEXECUTE_STRATEGY = "JtEXECUTE_STRATEGY"; 


  public JtStrategy () {
  }



/**
  * Specifies the reference to the concrete strategy.
  */


  public void setConcreteStrategy (Object concreteStrategy) {
     this.concreteStrategy = concreteStrategy;
  }


/**
  * Returns the reference to the concrete strategy.
  */

  public Object getConcreteStrategy () {
     return (concreteStrategy);
  }






  /**
   * Process object messages.
   * <ul>
   * </ul>
   */

  public Object processMessage (Object message) {
	  JtFactory factory = new JtFactory ();



      // Let the concrete strategy component handle the message

      if (concreteStrategy == null) {
          handleError ("processMessage: concreteStrategy attribute must be set");
          return (null);
      }

      return (factory.sendMessage (concreteStrategy, message));
      //return (((JtInterface) concreteStrategy).processMessage (message));


  }

 
  /**
   * Demonstrates the messages processed by JtStrategy.
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtStrategy strategy;
    JtEcho concreteStrategy;

    // Create an instance of JtStrategy

    strategy = (JtStrategy) factory.createObject (JtStrategy.JtCLASS_NAME);

    // Specify the concrete strategy to be executed

    concreteStrategy = (JtEcho) factory.createObject (JtEcho.JtCLASS_NAME);
    strategy.setConcreteStrategy (concreteStrategy);

    //factory.setSynchronous(false);    
    factory.sendMessage (strategy, new JtMessage (JtStrategy.JtEXECUTE_STRATEGY));


  }

}


