
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;

import java.io.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *  Jt Context
 */

public class JtContext implements Serializable {

    public static final String JtCLASS_NAME = JtContext.class.getName(); 
    private static final long serialVersionUID = 1L;

    private Object servletContext;
    private Object actionForm;
    private HttpServletRequest request;
    private HttpServletResponse response;  
    private String userName;
    private String password;
    
    /**
     * Returns the Struts ActionForm. 
     */
    
    public Object getActionForm() {
        return actionForm;
    }

    /**
     * Set the Struts ActionForm (set by JtStrutsAction). 
     * @param actionForm Struts ActionForm
     */
    
    public void setActionForm(Object actionForm) {
        this.actionForm = actionForm;
    }

    /**
     * Returns the servlet Context. 
     */
    
    public Object getServletContext() {
        return servletContext;
    }

    /**
     * Sets the servlet context. 
     * @param servletContext servlet context
     */
    
    public void setServletContext(Object servletContext) {
        this.servletContext = servletContext;
    }

    

    /**
     * Returns the servlet Request. 
     */
    
    public HttpServletRequest getRequest() {
        return request;
    }

    /**
     * Set the servlet Request. 
     * @param request servlet Request
     */
    
    
    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }
    
    
    /**
     * Returns the servlet Response. 
     */
    
    public HttpServletResponse getResponse() {
        return response;
    }

    /**
     * Set the servlet Response. 
     * @param response servlet Response
     */   
    
    public void setResponse(HttpServletResponse response) {
        this.response = response;
    }


    /**
     * Returns the username. 
     */
    
    
    public String getUserName() {
        return userName;
    }

    
    /**
     * Set the username. 
     */      
    
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Returns the password. 
     */
    
	public String getPassword() {
		return password;
	}

    /**
     * Set the password. This is used for message authentication. 
     */  
	
	public void setPassword(String password) {
		this.password = password;
	}




}
