package Jt;


/**
 * Jt Implementation of the Factory Method pattern.
 */

public class JtFactoryMethod extends JtObject {

  public static final String JtCLASS_NAME = JtFactoryMethod.class.getName();
  private static final long serialVersionUID = 1L;


  public JtFactoryMethod () {
  }

 
  /**
   * Demonstrates the messages processed by JtFactory
   */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtObject obj;


    // Create JtFactory

    obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "object");
    System.out.println (obj);



  }

}


