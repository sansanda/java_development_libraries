/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;


import java.security.Key;

import javax.crypto.KeyGenerator;

import Jt.axis.JtAxisAdapter;
import Jt.security.JtEncryptedMessage;
import Jt.security.JtMessageCipher;
import Jt.xml.*;



/**
 * Adapter to communicate with remote APIs. It performs message encryption
 * if required. The adaptee attribute specifies the component/mechanism to be used 
 * for communicating with remote components. Any mechanism/protocol may be used
 * (Axis, REST, RMI, sockets, HTTP, etc). This is possible
 * thanks to the Jt messaging design pattern. This class is being deprecated.
 * Use the remote proxies instead (JtRemoteProxy).
 */ 

public class JtRemoteAdapter extends JtAdapter  {

	public static final String JtCLASS_NAME = JtRemoteAdapter.class.getName(); 
	private static final long serialVersionUID = 1L; 
	JtAxisAdapter axisAdapter = null;
	private boolean encrypted = false;
	private Key sessionKey = null;
	private String encryptionAlgorithm = "Blowfish";
	private int keySize = 128;
	


	public JtRemoteAdapter () {
	}



	/**
	 * Returns the value of the encrypted attribute.
	 */

	public boolean isEncrypted() {
		return encrypted;
	}

	
	/**
	 * Specifies whether or not the interchange of messages between the adapter
	 * and remote components is encrypted (false is the default). Strong security/encryption
	 * is supported by the framework.
	 */

	public void setEncrypted(boolean encrypted) {
		this.encrypted = encrypted;
	}
	
 
	/**
	 * Returns the session key.
	 */
	
	public Key getSessionKey() {
		return sessionKey;
	}

	/**
	 * Specifies the session key that is to be used for message
	 * encryption. This key session  will be encrypted using the
	 * public key of the recipient. If no key is specified (null value)
	 * a session key is generated using the specified encryption algorithm
	 * and key size.
	 */

	public void setSessionKey(Key sessionKey) {
		this.sessionKey = sessionKey;
	}

	/**
	 * Returns the encryption algorithm.
	 */

	public String getEncryptionAlgorithm() {
		return encryptionAlgorithm;
	}

	/**
	 * Specifies the encryption algorithm to be
	 * used for message encryption (Blowfish
	 * is the default).
	 */
	
	public void setEncryptionAlgorithm(String encryptionAlgorithm) {
		this.encryptionAlgorithm = encryptionAlgorithm;
	}

	/**
	 * Returns the key size.
	 */
	
	public int getKeySize() {
		return keySize;
	}

	/**
	 * Specifies the key size to be
	 * used by the encryption mechanism
	 * (128 is the default).
	 */
	
	public void setKeySize(int keySize) {
		this.keySize = keySize;
	}


	/*
	 *  Propagate Exceptions
	 */
	
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}


	
	Object XmlToMessage (String xmlMessage) {
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		Object message;
		JtFactory factory = new JtFactory ();

		if (xmlMessage == null)
			return (null);

		msg.setMsgContent(xmlMessage);
		message = factory.sendMessage(xmlHelper, msg);

		if (propagateException (xmlHelper) != null)
			return (null);
		
		//if (message == null)
		//	handleError ("unable to convert XML into object.");
		
		return (message);

	}

	  private Key generateSessionKey () {
		  Key sessionKey;
		  
		  try {
			  KeyGenerator generator = KeyGenerator.getInstance (encryptionAlgorithm);
			  generator.init(keySize);
			  sessionKey = generator.generateKey();
			  
			  return (sessionKey);
		  } catch (Exception ex) {
			  handleException (ex);
			  return (null);
		  }
	  }
	
	private JtEncryptedMessage encryptMessage (Object message, Key key) {
		JtFactory factory = new JtFactory ();
		JtMessageCipher messageCipher;
		JtEncryptedMessage encryptedMessage;
		
		if (message == null || key == null)
			return (null);		
		
		messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        messageCipher.setSessionKey(key);
		
		encryptedMessage = (JtEncryptedMessage) messageCipher.processMessage(message);
		
		if (encryptedMessage == null) {
			handleError ("Unable to encrypt message");
			return (null);
		}
		return (encryptedMessage);
		
	}
 	
	private Object decryptMessage (JtEncryptedMessage encryptedMessage, Key key) {
		JtFactory factory = new JtFactory ();
		JtMessageCipher messageCipher;
		JtMessage message;
		
		if (encryptedMessage == null)
			return (null);		
		
		messageCipher = (JtMessageCipher) factory.createObject(JtMessageCipher.JtCLASS_NAME);
        messageCipher.setSessionKey(key);

		message = (JtEncryptedMessage) messageCipher.processMessage(encryptedMessage);
		
		if (message == null) {
			handleError ("Unable to decrypt message");
			return (null);
		}
		return (message);
		
	}
	
	
	public Object processMessage (Object message) {
		JtEncryptedMessage encryptedMessage;
		Object reply;
		//Key key;
		JtFactory factory = new JtFactory ();
		
		if (message == null) {
			handleError ("Invalid message (null)");
			return (null);
		}	
		
		if (this.getAdaptee() == null) {
			handleError ("Adaptee attribute needs to be set.");
			return (null);
		}
		
		if (encrypted) {
			
			

			
			//key = generateSessionKey ();
			
			if (sessionKey == null) {
				
				// Generate the session key to be
				// used for message encryption.
				
				handleTrace ("Generating a session key ....");
				
				sessionKey = generateSessionKey ();
				if (sessionKey == null)
					return (null);
			}
			

			
			encryptedMessage = encryptMessage (message, sessionKey);
			
			if (encryptedMessage == null)
				return (null);
		
			reply = factory.sendMessage(this.getAdaptee(), encryptedMessage);
			//reply = super.processMessage(encryptedMessage);
			
			if (propagateException (this.getAdaptee()) != null)
				return (null);
			
			if (reply instanceof JtEncryptedMessage) {
				
				return (decryptMessage  ((JtEncryptedMessage) reply, sessionKey));
			}
			
			return (reply);
		}
		
		reply = factory.sendMessage(this.getAdaptee(), message);
		
		if (propagateException (this.getAdaptee()) != null)
			return (null);
			
		return (reply);
	}
	
	

}


