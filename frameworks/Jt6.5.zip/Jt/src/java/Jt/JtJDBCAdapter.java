

package Jt;
import java.sql.*;
import javax.sql.*;
import java.text.*;
import Jt.jndi.*;

/**
 * Jt Adapter for the JDBC API. This implementation supports Data Sources.
 */

public class JtJDBCAdapter extends JtAdapter  {

    private static final long serialVersionUID = 1L;

    public static final String JtCLASS_NAME = JtJDBCAdapter.class.getName(); 
    public static final String JtCONNECT = "JtCONNECT"; 
    public static final String JtPREPARE_STATEMENT = "JtPREPARE_STATEMENT"; 
    public static final String JtEXECUTE_PREPARED_UPDATE = "JtEXECUTE_PREPARED_UPDATE"; 
    public static final String JtEXECUTE_PREPARED_QUERY = "JtEXECUTE_PREPARED_QUERY"; 
    public static final String JtEXECUTE_QUERY = "JtEXECUTE_QUERY"; 
    public static final String JtQUERY = "JtQUERY"; 
    public static final String JtEXECUTE_UPDATE = "JtEXECUTE_UPDATE"; 
    public static final String JtUPDATE = "JtUPDATE"; 
    public static final String JtCLOSE = "JtCLOSE"; 
    public static final String JtBEGIN_TRANSACTION = "JtBEGIN_TRANSACTION"; 
    public static final String JtCOMMIT = "JtCOMMIT"; 
    public static final String JtROLLBACK = "JtROLLBACK"; 
    public static final String JtMAP = "JtMAP"; // This message is being deprecated 
    
    private String user;
    private String password;
    private String url;  
    private String driver;
    private int maxRows = 0; // Check. Hibernate DAOAdapter needs to support this.
    private int fetchSize = 0; // check
    private transient Connection connection = null;
    private String base;
    private boolean retry = true;
    int n = 0;
    private transient Statement myStatement;
    private String datasource = null;
    private transient JtJNDIAdapter jndiAdapter = null;
    private transient DataSource dataSource = null;
    private transient boolean initted = false; 

    private DataSource locateDataSource (String datasource) {
        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP);


        if (datasource == null)
            return (null);

        msg.setMsgContent (datasource);
        jndiAdapter = new JtJNDIAdapter ();

        return ((DataSource) jndiAdapter.processMessage (msg));

    }


    private void initial () {



        if (datasource != null) {
            dataSource = locateDataSource (datasource);

            if (dataSource == null) {
                handleError ("JtJDBAdapter.connect: unable to locate datasource:" + 
                        datasource);
                connection = null;
                return;

            }

            try {
                connection = dataSource.getConnection ();
            } catch (Exception ex) {
                handleException (ex);
            }
        }

    }
    /*
    public boolean getAutoCommit () {
        boolean bool = false;

        if (connection == null) {
            handleWarning ("getAutoCommit: connection is null");
            return (false);
        }    
        try {
            bool = connection.getAutoCommit();
        } catch (Exception ex) {
            handleException (ex);            
        }
        return (bool);
    }

    public void setAutoCommit (boolean autocommit) {

        if (connection == null) {
            handleWarning ("setAutoCommit: connection is null");
            return;
        }

        try {
            connection.setAutoCommit(autocommit);
        } catch (Exception ex) {
            handleException (ex);            
        }
    }  
     */

    void connect ()
    {



        if (datasource != null) {

            if (dataSource == null) {
                handleWarning ("JtJDBAdapter.connect: unable to connect to Datasource: " + 
                        datasource);
                connection = null;
                return;

            }

            try {
                connection = dataSource.getConnection ();
                handleTrace ("JtJDBCAdapter.connect: using data source ....");

            } catch (Exception ex) {
                handleException (ex);
            }
            return;
        }

        if (connection != null) {
            return;
        }

        if (driver == null) {
            handleError ("connect: null attribute (driver)");
            return;
        }

        if (url == null) {
            handleError ("connect: null attribute (url)");
            return;
        }

        handleTrace ("JtJDBCAdapter.connect ....");
        try
        {
            Class.forName(driver);
            if (user == null)
                connection = DriverManager.getConnection(url);
            else
                connection = DriverManager.getConnection(url,
                        user, password);
            //System.out.println (connection.getAutoCommit ());
        }
        /*
        catch(ClassNotFoundException cnfe)
        {
            handleException (cnfe);
        }
        */
        catch(Exception sqle)
        {
            if (!retry) {
                handleException (sqle);
                return;
            }
 
            handleWarning ("JtJDBCAdapter.connect: retry connection." );
            try {

                if (user == null)
                    connection = DriverManager.getConnection(url);
                else
                    connection = DriverManager.getConnection(url,
                            user, password);
             } catch (Exception ex) {
                 handleException (ex);
             }
        }
    }

    // close: close connection

    void close () {

        if (connection == null)
            return;

        try {
            connection.close ();	
        } 
        catch (SQLException sqle) {
            handleException (sqle);
        } 
        finally {
            connection = null; 
        }
    }

    // Executes a query

    ResultSet execute_query (String query) {

        if (query == null)
            return (null);

        if (connection == null) {
            handleError ("execute_query: no database connection");
            return (null);
        }

        try {
            myStatement = connection.createStatement ();
            ResultSet results = myStatement.executeQuery (query);
            
            if (maxRows > 0) {
                myStatement.setMaxRows(maxRows);
            }
            
            if (fetchSize > 0) {
                myStatement.setFetchSize(fetchSize);
            }

            if (results == null) // check
                myStatement.close ();

            return (results); // check - close later

            //results.close ();
        }
        catch(SQLException sqle)
        {
            handleTrace ("Message: " + sqle.getMessage ());
            handleTrace ("SQL State: " + sqle.getSQLState ());
            handleTrace ("Vendor code: " + sqle.getErrorCode ());
            handleException (sqle);
            return (null);
        } 
        /*
      finally {
        if (myStatement != null) {
          try {
            myStatement.close ();
          } catch (SQLException sqle) {
          }
        }
      }
         */

    }

    Object execute_update (String query) {
        int cnt = 0;
        Statement myStatement = null;

        if (query == null)
            return (null);

        if (connection == null) {
            handleError ("execute_query: no database connection");
            return (null);
        }

        try {
            myStatement = connection.createStatement ();
            cnt = myStatement.executeUpdate (query);
            myStatement.close ();
            return new Integer (cnt);
        }
        catch(SQLException sqle)
        {
            handleTrace ("Message: " + sqle.getMessage ());
            handleTrace ("SQL State: " + sqle.getSQLState ());
            handleTrace ("Vendor code: " + sqle.getErrorCode ());
            handleException (sqle);
            return (null);
        } 

    }

    // show_output: show output of the query 

    int show_output (ResultSet res) {

        int ncol, n;
        ResultSetMetaData meta;

        if (res == null)
            return (0);

        try {        
            meta = res.getMetaData ();
        }
        catch (SQLException e) {
            handleException (e);
            return (0);
        }



        try {
            while (res.next ()) {
                ncol = meta.getColumnCount ();
                handleTrace ("output:ncol:"+ ncol);
                for (n = 1; n <= ncol; n++) {
                    handleTrace ("output:" + 
                            meta.getColumnName (n) + ":" +
                            res.getString (n));
                }
            }
            return (1);
        }
        catch (SQLException e) {
            handleException (e);
            return (0);
        }
    }

    // map: map database row onto object

    int map (ResultSetMetaData meta, 
            ResultSet res, Object obj) {
    	JtFactory factory = new JtFactory ();

        int ncol, n;
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);

        if ((meta == null) || (res == null) ||
                (obj == null))
            return (0);

        try {
            ncol = meta.getColumnCount ();
            for (n = 1; n <= ncol; n++) {
                //handleTrace ("JtJDBCAdapter.map:" + meta.getColumnTypeName(n));
                if (meta.getColumnTypeName(n).equals ("DATE") ||
                        meta.getColumnTypeName(n).equals ("DATETIME")) {
                    Date date = res.getDate (n);
                    if (date == null || date.equals (""))
                        continue; // check
                    String sdate = df.format (date);
                    factory.setValue (obj, 
                            meta.getColumnName (n),
                            sdate);
                    continue;
                }
                factory.setValue (obj, 
                        meta.getColumnName (n),
                        res.getString (n));
                /*
	  handleTrace ("JtJDBCAdapter.map:" + 
                 meta.getColumnName (n) + ":" +
                 res.getString (n));
                 */
            }

            return (1);
        }
        catch (SQLException e) {
            handleException (e);
            return (0);
        }
    }

    // map: map query onto object list. This method is being deprecated (see JtDAO)

    void map_query (String query, JtMessage me) {
        ResultSetMetaData mdata;
        ResultSet res;
        //int n = 0; - check memory leak
        String name;
        JtMessage event;
        JtObject tmp;
        JtFactory factory = new JtFactory ();

        //if (table == null)
        //return;

        handleTrace ("JtJDBCAdapter.map_query ....");

        if (query == null)
            return;

        if (base == null)
            return;

        //query = "select * from " + table; 

        res = execute_query (query);

        if (res == null) {
            handleTrace ("map_query:res:null");
            //myStatement.close ();
            return;
        }

        try {        
            mdata = res.getMetaData ();
        }
        catch (SQLException e) {
            handleException (e);
            return;
        }

        try {
            if (mdata == null) {
                myStatement.close ();
                //res.close (); // check
                return;
            }
        } catch (SQLException e) {
            handleException (e);
            return;
        }

        try {
            while (res.next ()) {
                n++;
                name = "" + n;
                //handleTrace ("creating object ..." + name);
                //tmp = (JtObject) factory.createObject (base, name);
                tmp = (JtObject) factory.createObject (base);
                handleTrace ("creating object ..." + tmp);
                if (map (mdata, res, tmp) == 0)
                    continue;
                event = new JtMessage ();
                //event.setMsgContent (this.getObjName()+"."+name);
                event.setMsgContent (tmp);
                event.setMsgId ("JtOBJECT");
                event.setMsgSubject (me.getMsgSubject ());
                //event.setMsgSubject("JtMAP");


                // send a reply
                if (me.getMsgReplyTo () != null) {
                    // fireMessageEvent(event);
                    //      else { 
                    //event.setMsgIsReply (true);
                    factory.sendMessage (me.getMsgReplyTo (), event);
                }

            }
            //	res.close (); // check
            myStatement.close ();
        }
        catch (SQLException e) {
            handleException (e);
        }
    }  

    
    private PreparedStatement prepareStatement (String query)
    {
        PreparedStatement pst = null;

        if (connection == null) {
            handleError ("JtJDBCAdapter.prepareStatement: invalid connection (null)");
            return (null);
        }

        if (query == null)
            return (null);

        try {
            pst = connection.prepareStatement (query);
        } 
        catch (Exception ex) {
            handleException (ex);
        }
        return (pst);    
    }


    private Object executePreparedUpdate (PreparedStatement pst )
    {
        int cnt = 0;

        if (pst == null) {
            return (null);
        }

        if (connection == null) {
            handleError ("JtJDBCAdapter.prepareStatement: invalid connection (null)");
            return (null);
        }
        try {
            cnt = pst.executeUpdate ();
            return (new Integer (cnt));
        } catch (Exception ex) {
            handleException (ex);
            return (ex); // check todo
        }

    }
    

    
    
    private Object executePreparedQuery (PreparedStatement pst )
    {
        //int cnt = 0;
        ResultSet res;

        if (pst == null) {
            return (null);
        }

        if (connection == null) {
            handleError ("JtJDBCAdapter.prepareStatement: invalid connection (null)");
            return (null);
        }       
        
        try {
            res = pst.executeQuery ();
            return (res);
        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }

    }

    /**
     * Begin transaction
     */
    private void beginTransaction () {

        if (connection == null) {
            handleWarning ("beginTransaction: connection is null");
            return;
        }

        try {
            connection.setAutoCommit(false);
        } catch (Exception ex) {
            handleException (ex);            
        }


    }

    /**
     *  Commit transaction
     */

    private void commitTransaction () {

        try {
            connection.commit();
            connection.setAutoCommit(true);
        } catch (Exception ex) {
            handleException (ex);
        }
    }

    /**
     *  Rollback transaction
     */

    private void rollbackTransaction () {

        try {
            connection.rollback();
            connection.setAutoCommit(true);
        } catch (Exception ex) {
            handleException (ex);
        }
    }


    /**
     * Process object messages.
     * <ul>
     * <li> JtCONNECT - Establishes a database connection using the appropriate object attributes 
     * (datasource or database driver, url and user/password if any).
     * <li> JtEXECUTE_QUERY - Executes an SQL statement. Typically this is an SQL SELECT statement.
     * Returns a ResultSet object. The message contains the query to be executed (msgContent).
     * <li> JtEXECUTE_UPDATE - Executes an SQL statement.The SQL statement must be an INSERT, UPDATE, DELETE; or an SQL statement that returns
     * no value as a DDL statemet. Returns the row count (Integer) for INSERT, UPDATE  or DELETE statements, or 0 for SQL statements 
     * that return nothing. The message contains the query to be executed (msgContent).
     * <li> JtPREPARE_STATEMENT - Returns a prepared statement. The message contains the query (msgContent).
     * <li> JtEXECUTE_PREPARED_QUERY - Executes a prepared statement a returns the ResultSet. The message 
     * (msgContent) contains the prepared statement to be executed. 
     * <li> JtEXECUTE_PREPARED_UPDATE - Executes a prepared statement. The message contains the prepared SQL statement
     * to be executed. The SQL statement must be an INSERT, UPDATE, DELETE; or an SQL statement that returns
     * no value as a DDL statemet. Returns the row count (Integer) for INSERT, UPDATE  or DELETE statements, or 0 for SQL statements 
     * that return nothing.
     * <li> JtBEGIN_TRANSACTION - Starts a transaction. Sets the autoCommit attribute of the connection (false value).
     * <li> JtCOMMIT - Commits the transaction. Resets the autocommit attribute (true value).
     * <li> JtROLLBACK - Rollbacks the transaction. Resets the autocommit attribute (false value).   
     * <li> JtCLOSE - Closes the database connection.
     * </ul>
     */

    public Object processMessage (Object message) {
        //String content;
        String query;
        JtMessage e = (JtMessage) message;
        Object reply;

        if (e == null ||  (e.getMsgId() == null))
            return (null);

        if (!initted) {
            initial ();
            initted = true;        
        }

        // establish connection
        if (e.getMsgId().equals(JtJDBCAdapter.JtCONNECT)) {
            connect ();
            return (connection);
        }

        // execute a query
        if (e.getMsgId().equals(JtJDBCAdapter.JtQUERY)) {
            connect ();
            query = (String) e.getMsgContent();
            show_output (execute_query (query));
            //if (dataSource != null)
            //  close ();

            return (null);
        }

        if (e.getMsgId().equals(JtJDBCAdapter.JtEXECUTE_QUERY)) {
            query = (String) e.getMsgContent();
            connect ();
            reply = execute_query (query);
            // When dealing with DataSources Close the connection after each operation
            //if (dataSource != null)
            //  close ();
            return (reply);

        }


        if (e.getMsgId().equals(JtJDBCAdapter.JtPREPARE_STATEMENT)) {
            query = (String) e.getMsgContent();
            connect ();
            reply = prepareStatement (query);
            //if (dataSource != null)
            //  close ();
            return (reply);
        }


        if (e.getMsgId().equals(JtJDBCAdapter.JtEXECUTE_PREPARED_UPDATE)) {
            //query = (String) e.getMsgContent();
            connect ();
            reply = executePreparedUpdate 
            ((PreparedStatement) e.getMsgContent());
            //if (dataSource != null)
            //  close ();
            return (reply);
        }
        
        if (e.getMsgId().equals(JtJDBCAdapter.JtEXECUTE_PREPARED_QUERY)) {
            //query = (String) e.getMsgContent();
            connect ();
            reply = executePreparedQuery 
            ((PreparedStatement) e.getMsgContent());
            //if (dataSource != null)
            //  close ();
            return (reply);
        }

        // execute an Update
        if (e.getMsgId().equals(JtJDBCAdapter.JtUPDATE) || e.getMsgId().equals(JtJDBCAdapter.JtEXECUTE_UPDATE)) {
            query = (String) e.getMsgContent();
            connect ();
            reply = execute_update (query);
            //if (dataSource != null)
            //  close ();
            return (reply);
        }

        // map query onto object list. This message is being deprecated

        if (e.getMsgId().equals(JtJDBCAdapter.JtMAP)) {
            query = (String) e.getMsgContent();
            if (query == null)
                return (null);
            connect ();
            map_query (query, e);
            //if (dataSource != null)
            //  close ();
            return (null);
        }

        
        // close a connection
        if (e.getMsgId().equals(JtJDBCAdapter.JtCLOSE) || e.getMsgId().equals (JtObject.JtREMOVE)) {
            close ();
            return (null);
        }

        if (e.getMsgId().equals (JtJDBCAdapter.JtBEGIN_TRANSACTION)) {
            connect ();
            beginTransaction ();
            return (this);
        }

        if (e.getMsgId().equals (JtJDBCAdapter.JtCOMMIT)) {
            commitTransaction ();
            return (this);
        }

        if (e.getMsgId().equals (JtJDBCAdapter.JtROLLBACK)) {
            rollbackTransaction ();
            return (this);
        }

        return (super.processMessage(message));

    }

    /**
     * Specifies the database user.
     * @param newUser user
     */

    public void setUser (String newUser) {
        user = newUser;
    }


    /**
     * Returns the database user.
     */

    public String getUser () {
        return (user);
    }


    /**
     * Specifies the database password.
     * @param newPassword password
     */

    public void setPassword (String newPassword) {
        password = newPassword;
    }


    /**
     * Returns the database password.
     */

    public String getPassword () {
        return (password);
    }


    /**
     * Specifies the URL of the database.
     * @param newUrl url
     */

    public void setUrl (String newUrl) {
        url = newUrl;
    }

    /**
     * Returns the URL of the database.
     */

    public String getUrl () {
        return (url);
    }


    /**
     * Specifies the Datasource logical name (if any).
     * @param datasource Datasource logical name
     */

    public void setDatasource (String datasource) {
        this.datasource = datasource;
    }

    /**
     * Returns the Datasource logical name (JNDI).
     */

    public String getDatasource () {
        return (datasource);
    }


    /**
     * Specifies the database driver.
     * @param newDriver driver
     */

    public void setDriver (String newDriver) {
        driver = newDriver;
    }

    /**
     * Returns the database driver.
     */
    public String getDriver () {
        return (driver);
    }

    /**
     * Method being deprecated.
     */

    public void setBase (String newBase) {
        base = newBase;
    }

    /**
     * Method being deprecated.
     */

    public String getBase () {
        return (base);
    }


    /**
     * Specifies the database Connection.
     */

    public void setConnection (Connection newConnection) {
        connection = newConnection;
    }

    /**
     * Returns the database Connection.
     */

    public Connection getConnection () {
        return (connection);
    }
    
    
    /*
     * Returns the value of maxRows.
     */

    public int getMaxRows() {
        return maxRows;
    }


    
    
    /*
     * Specifies the maximun number of rows returned
     * by the JtJDBCAdapter.JtEXECUTE_QUERY message.
     * The default value is 0 (no maximun number).
     * This limit is needed when a huge number 
     * of rows is expected.
     */
    public void setMaxRows(int maxRows) {
        this.maxRows = maxRows;
    }

    
    /**
     * Returns fetch size hint.
     */    
    
    public int getFetchSize() {
        return fetchSize;
    }

    /**
     * Fetch size hint.
     */   
    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }
    
    /**
     * Returns the attribute retry.
     */   
    
    public boolean isRetry() {
        return retry;
    }

    /**
     * Specifies whether or not the adapter should 
     * retry to establish a database connection. The default is true.
     */  
    public void setRetry(boolean retry) {
        this.retry = retry;
    }


    /**
     * Demonstrates the use of the JtJDBCAdapter.
     */

    private static void test () {
        JtFactory factory = new JtFactory ();  // JtFactory
        JtMessage msg = new JtMessage (JtJDBCAdapter.JtQUERY);
        JtJDBCAdapter adapter;

        // Create an instance of JtJDBCAdapter

        adapter = (JtJDBCAdapter) factory.createObject (JtJDBCAdapter.JtCLASS_NAME, "adapter");

        // Execute a query

        msg.setMsgContent ("select email from roster where email='member@hotmail.com';");        
        factory.sendMessage (adapter, msg);        

        // Illustrates the use of transactions. Begin a transaction

        factory.sendMessage ("adapter", new JtMessage (JtJDBCAdapter.JtBEGIN_TRANSACTION));

        // Execute the query

        msg = new JtMessage (JtJDBCAdapter.JtEXECUTE_UPDATE);    
        msg.setMsgContent("update roster set email_flag=1;");
        factory.sendMessage (adapter, msg);

        // Commit the transaction

        factory.sendMessage (adapter, new JtMessage (JtJDBCAdapter.JtCOMMIT));


        factory.removeObject (adapter);

    }

    /**
     * Unit tests the messages processed by JtJDBCAdapter. The following attributes should be
     * included in the Jt resource file:
     * <ul>
     * <li>Jt.JtJDBCAdapter.user
     * <li>Jt.JtJDBCAdapter.password
     * <li>Jt.JtJDBCAdapter.driver
     * <li>Jt.JtJDBCAdapter.url
     * <li>Jt.JtJDBCAdapter.datasource (if this attribute is present, the previous
     * attributes are not needed)
     * </ul>
     */

    public static void main (String[] args) {
        test ();
    }



}