

package Jt;

import java.util.Date;

import Jt.examples.Test;


/**
 * Echo the message received using XML format.
 */

public class JtEcho extends JtComponent {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtEcho.class.getName(); 
    public transient JtPrinter printer = new JtPrinter ();

    public JtEcho() {
    }


    /**
     * Process object messages (echoes the message using XML format).
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

         printer.processMessage(message);


        return (message);

    }


    /**
     * Demonstrates the messages processed by JtEcho.
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtEcho echo;
        JtMessage msg = new JtMessage (JtObject.JtTEST);
        Test test = new Test ();



        // Create an instance of JtEcho

        echo = (JtEcho) main.createObject (JtEcho.JtCLASS_NAME);

        msg.setMsgContent(new Date ());
        msg.setMsgData(new Integer (10));
        main.sendMessage (echo, msg);
        
        // Message is an instance of Date
        
        main.sendMessage (echo, new Date ());

        // Message is an instance of Integer
        
        main.sendMessage (echo, new Integer (10));
        
        // Message is an instance of Test
        
	    test.setComments("<comments>");
	    test.setStatus(1);
	    test.setLongField (1L);
	    test.setShortField ((short) 1);
	    test.setC ('<');
	    //test.setDate(date);
	    test.setDoubleField(1.0);
	    test.setFlag(true);
	    test.setFloatField((float) 1.0);
	    test.setByteField((byte) 1);
	    
        main.sendMessage (echo, test);

    }

}


