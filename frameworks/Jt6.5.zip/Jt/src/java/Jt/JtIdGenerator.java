

package Jt;

import java.util.Date;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtSingleton;



/**
 * Singleton use to generate unique framework Ids. It relies on the system date.
 * The system date must be correct for this to work properly.
 */

public class JtIdGenerator extends JtSingleton {
    
  public static final String JtCLASS_NAME = JtIdGenerator.class.getName(); 
  //public static final String JtGENERATE_ID = "JtGENERATE_ID"; 
  private static final long serialVersionUID = 1L;
  private long Id = 0L;


  public JtIdGenerator () {
  }

  public long getId() {
      return Id;
  }

  public void setId(long id) {
      Id = id;
  }

  private synchronized Long generateId () {
      Date date = new Date ();
      long tmp;

      tmp = date.getTime ();

      if (tmp != Id) {
          Id = tmp;
          return (new Long (Id));
      }

      tmp++;
      Id = tmp;

      return (new Long (Id));

  }

  /**
   * Process object messages.
   * <ul>
   * </ul>
   * @param message Jt Message
   */

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage e = (JtMessage) message;
      Object content;


      if (e == null)
          return null;

      msgid = (String) e.getMsgId ();

      if (msgid == null)
          return null;


      content = e.getMsgContent();
      

      if (msgid.equals (JtObject.JtACTIVATE)) {

          return (generateId ());
          
      }    
      
      
      handleError ("Invalid msg Id:" + msgid); // check
      return (null);

  }
 
  /**
   * Demonstrates the messages processed by JtIdGenerator.
   */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtIdGenerator singleton, singleton1;

    System.out.println ("Creating an instance of JtIdGenerator ...");

    // Create a JtSingleton instance

    singleton = (JtIdGenerator) main.createObject (JtIdGenerator.JtCLASS_NAME);


    System.out.println ("Attempting to create a second instance of JtIdGenerator ...");

    singleton1 = (JtIdGenerator) main.createObject (JtIdGenerator.JtCLASS_NAME);
    
    System.out.println (main.sendMessage(singleton, new JtMessage (JtObject.JtACTIVATE)));
    System.out.println (main.sendMessage(singleton, new JtMessage (JtObject.JtACTIVATE)));
    //main.removeObject (singleton);


  }

}


