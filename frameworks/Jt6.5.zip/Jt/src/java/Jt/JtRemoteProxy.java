/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */


package Jt;



/**
 * MDP Proxy to a remote component.
 */



public class JtRemoteProxy extends JtProxy {

	public static final String JtCLASS_NAME = JtRemoteProxy.class.getName(); 
	public static final String  JtINITIALIZE_PROXY = "JtINITIALIZE_PROXY"; 
	private static final long serialVersionUID = 1L;
	protected String url;
	protected String classname;
	protected Object remoteComponentId;
	protected JtAdapter adapter;
	JtFactory factory = new JtFactory ();
	protected boolean initialized = false;
	

	public JtRemoteProxy() {
	}


	/**
	  * Returns the url associated with the remote component
	  */
	
	
	public String getUrl() {
		return url;
	}

	/**
	  * Specifies the url
	  */	

	public void setUrl(String url) {
		this.url = url;
	}

	/**
	  * Returns the classname of the remote component
	  */	
	
	public String getClassname() {
		return classname;
	}

	/**
	  * Specifies the classname
	  */	
	
	public void setClassname(String classname) {
		this.classname = classname;
	}

	/**
	  * Returns the component Id of the remote component
	  */	
	
	public Object getRemoteComponentId() {
		return remoteComponentId;
	}

	
	/**
	  * Specifies the component Id of the remote component
	  */
	
	public void setRemoteComponentId(Object remoteComponentId) {
		this.remoteComponentId = remoteComponentId;
	}	
	
	/**
	  * Returns the remote Adapter For internal use only.
	  */
	
	public JtAdapter getAdapter() {
		return adapter;
	}

	/**
	  * Specifies the remote Adapter. For internal use only.
	  */
	
	public void setAdapter(JtAdapter adapter) {
		this.adapter = adapter;
	}



	
}

