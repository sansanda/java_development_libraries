package Jt.axis;


import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

import Jt.*;
import Jt.xml.JtXMLHelper;


/**
 * Universal Axis Web Service used to interface with the Jt Framework.
 * A single Axis service is required to implement the Jt messaging design pattern.
 */

public class JtAxisService extends JtObject {


  public static final String JtCLASS_NAME = JtAxisService.class.getName(); 
  private static final long serialVersionUID = 1L;
  private transient JtFactory factory = new JtFactory ();
  //private JtRemoteFacade messenger;

  public JtAxisService() {
  }

  
	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}
  
  
	Object XmlToMessage (String xmlMessage) {
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		Object message;
		JtFactory factory = new JtFactory ();

		if (xmlMessage == null)
			return (null);

		msg.setMsgContent(xmlMessage);
		message = factory.sendMessage(xmlHelper, msg);

		if (propagateException (xmlHelper) != null)
			return (null);
		
		//if (message == null)
		//	handleError ("unable to convert XML into object.");
		
		return (message);

	}
	
	private String MessageToXML (Object message) {
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_ENCODE);
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtFactory factory = new JtFactory ();
		String xmlMessage;

		if (message == null)
			return (null);

		msg.setMsgContent(message);
		xmlMessage = (String) factory.sendMessage(xmlHelper, msg);
		
		if (propagateException (xmlHelper) != null)
			return (null);

		if (xmlMessage == null) 
			handleError ("unable to convert message into XML");
		
		
		return (xmlMessage);
	}
	
	private String stackTrace (Exception ex ) {
	      ByteArrayOutputStream bstream;


	      if (ex == null)
	          return (null);

	      bstream = new ByteArrayOutputStream ();
	      

	      ex.printStackTrace (new PrintWriter (bstream, true));


	      return (bstream.toString ());


	  }
	
	JtRemoteException generateRemoteException (Exception ex) {
		JtRemoteException jre;
		
		if (ex == null)
			return (null);
		
		jre = new JtRemoteException (ex.getMessage());
		jre.setTrace (stackTrace (ex));
		
		return (jre);
	}

   /**
     * Process Jt framework messages (XML format).
     * 
     * @param xmlMessage input message (XML format)
     * @return reply message (XML format)
     */


  public String processMessage (String xmlMessage) {
  //JtMessage msg;
  //Object scriptOutput = null;
      Object message;
      String xmlReply;
      Object reply;
      JtRemoteFacade messenger = null;
  
      //MessageContext mc = MessageContext.
      //getCurrentContext();
      //Session session = mc.getSession();
      //String name = (String)session.get("name");

    if (xmlMessage == null) {
      handleError ("invalid message");
      return (MessageToXML (generateRemoteException ((Exception) getObjException ()))); 

    }

    handleTrace ("JtAxisService.processMessage (input) ...\n"  + xmlMessage,
            JtLogger.JtMIN_LOG_LEVEL);
    
    //if (messenger == null) {   
    	// Create an instance of JtRemoteMessenger. This component sends messages to the
    	// other remote components. It handles security, encryption, etc. 
    	// messenger should remain in the session
    	//factory.setCreateSingleton(true);
    	messenger = (JtRemoteFacade) factory.createObject (JtRemoteFacade.JtCLASS_NAME);
    	//factory.setCreateSingleton(false);    	

    //}
    
	
	message = XmlToMessage (xmlMessage);

	if (message == null) {
		// Error has been detected
		return (MessageToXML (generateRemoteException ((Exception) getObjException ()))); 
	}

	reply = messenger.processMessage(message);
	
	/*
	if (propagateException (messenger) == null)
		xmlReply = MessageToXML (reply);
	else
		xmlReply 
		   = MessageToXML (generateRemoteException ((Exception) this.getObjException ()));
	*/
	
	xmlReply = MessageToXML (reply);
	
    handleTrace ("JtAxisService.processMessage (output) ...\n"  + xmlReply,
            JtLogger.JtMIN_LOG_LEVEL);
	
	if (getObjException () != null)
		xmlReply 
		   = MessageToXML (generateRemoteException ((Exception) getObjException ()));
		
	return (xmlReply);

	
  }


 /**
   * Demonstrates all the messages processed by JtAxisService. 
   */


  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtAxisService adapter;
    String str;
    JtFile jFile;
    JtMessage msg;


    if (args.length < 1) {
      System.err.println ("Usage: java JtAxisService filename");
      System.exit (1);
    }

    jFile = (JtFile) main.createObject (JtFile.JtCLASS_NAME);
    jFile.setPath(args[0]);    
    msg = new JtMessage (JtFile.JtREAD);

    str = (String) main.sendMessage (jFile, msg);

    // Create adapter 

    adapter = (JtAxisService) main.createObject (JtAxisService.JtCLASS_NAME);

    adapter.processMessage (str);      

  }

}


