
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */
package Jt.axis;
import Jt.*;       
import Jt.xml.JtXMLHelper;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import javax.xml.rpc.ParameterMode;


/**
  * Jt Adapter for the Axis API. It transfers MDP messages using 
  * the Axis service.
  */  

public class JtAxisAdapter extends JtAdapter {

  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtAxisAdapter.class.getName(); 
  private String url = null;
  private Service  service = null;
  private Call     call    = null;



  public JtAxisAdapter() {
  }


 /**
  * Specifies the service URL.
  * @param url service url
  */

  public void setUrl (String url) {
     this.url = url;
  }

 /**
   * Returns the service URL. 
   */

  public String getUrl () {
     return (url);
  }



	// Propagate Exceptions 

	private Exception propagateException (Object obj)
	{
		Exception ex;
		JtFactory factory = new JtFactory ();

		if (obj == null)
			return null;

		ex = (Exception) factory.getValue (obj, "objException");


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}
  
	private String MessageToXML (Object message) {
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_ENCODE);
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtFactory factory = new JtFactory ();
		String xmlMessage;

		if (message == null)
			return (null);

		msg.setMsgContent(message);
		xmlMessage = (String) factory.sendMessage(xmlHelper, msg);
		
		if (propagateException (xmlHelper) != null)
			return (null);

		if (xmlMessage == null) 
			handleError ("unable to convert message into XML");
		
		
		return (xmlMessage);
	}
	
	Object XmlToMessage (String xmlMessage) {
		JtXMLHelper xmlHelper = new JtXMLHelper ();
		JtMessage msg = new JtMessage (JtXMLHelper.JtXML_DECODE);
		Object message;
		JtFactory factory = new JtFactory ();

		if (xmlMessage == null)
			return (null);

		msg.setMsgContent(xmlMessage);
		message = factory.sendMessage(xmlHelper, msg);

		if (propagateException (xmlHelper) != null)
			return (null);
		
		//if (message == null)
		//	handleError ("unable to convert XML into object.");
		
		return (message);

	}
	
	// Process object messages

	public Object processMessage (Object message) {

		//JtFactory factory = new JtFactory ();
		String xmlMessage;
		Object reply;
		String xmlReply;

		if (message == null) {
			handleError ("Invalid message (null).");
			return null;
		}

		this.setObjException(null);

			
		// Convert message into XML
		
		xmlMessage = MessageToXML (message);
		
		if (xmlMessage == null)
			return (null);
		
		// Send the XML message to the Remote host
		
		//xmlReply = (String) factory.sendMessage (remoteStrategy, xmlMessage);
		xmlReply = sendRemoteMessage ((String) xmlMessage);
		
		//if (propagateException (remoteStrategy) != null)
		//	return (null);
		
		if (xmlReply == null)
			return (null);
		
		// Convert XML reply into object
		
		reply = XmlToMessage (xmlReply);
		
		if (reply == null)
			return (null);

		// An remote exception was detected
		
		if (reply instanceof Exception) {
			handleError ("Remote exception detected");

			if (reply instanceof JtRemoteException)
				handleWarning ("<Remote Exception>\n" + 
						((JtRemoteException) reply).getTrace () + "</Remote Exception>\n"); 
			
			return (null);

		}

		return (reply);

	}
  

  // send the message using the Axis API/service
  
  private String sendRemoteMessage (String xmlMsg)
  {

    String ret = null;

 
      if (xmlMsg == null)
        return (null);

      try { 

          
          if (service == null) {
                     
            service = new Service();
            //service.setMaintainSession (true);

            call    = (Call) service.createCall();
          
          if (url == null) {
            handleError ("processxmlMessage: invalid attribute value: url (null)");
            return (null);
          }
                

          call.setTargetEndpointAddress( new java.net.URL(url) );
          call.setMaintainSession (true);

          // check 
          //call.setOperationName( new QName("http://example3.userguide.samples", "processMessage") );
          call.setOperationName("processMessage");

          call.addParameter( "arg1", XMLType.XSD_STRING, ParameterMode.IN);
          call.setReturnType( org.apache.axis.encoding.XMLType.XSD_STRING );
          }
          ret = (String) call.invoke( new Object[] { xmlMsg } );
          
      } catch (Exception e) {
          handleException (e);
          return (null);
      }

    
      return (ret);
      
 
  }



 /**
   * Demonstrates the messages processed by JtAxisAdapter
   */


  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    //JtMessage msg;
    JtAxisAdapter adapter;


    // Create an instance of the MDP Adapter

    adapter = (JtAxisAdapter) main.createObject (JtAxisAdapter.JtCLASS_NAME);
    main.setValue (adapter, "url",
      "http://localhost:8080/axis/services/MyService");       

    main.sendMessage (adapter, "hi there");


  }

}


