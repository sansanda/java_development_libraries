
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.axis;


import java.security.Key;

import javax.crypto.KeyGenerator;

import Jt.JtContext;
import Jt.JtEnvelope;
import Jt.JtFactory;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtMessenger;
import Jt.JtObject;
import Jt.JtProxy;
import Jt.JtRemoteProxy;
import Jt.security.JtEncryptedMessage;



/**
 * Axis Proxy to a remote component.
 */


public class JtAxisProxy extends JtRemoteProxy {
	public static final String JtCLASS_NAME = JtAxisProxy.class.getName(); 
	JtFactory factory = new JtFactory ();	




	private static final long serialVersionUID = 1L;

	public JtAxisProxy() {


	}
	

	private boolean initializeProxy (boolean encrypted) {
		JtMessage msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		Object output;
		JtAxisAdapter axisAdapter;
		JtMessenger messenger = new JtMessenger ();
		

		if (classname == null && remoteComponentId == null) {
			handleError ("Classname (or remoteComponentId) needs to be set.");
			return false;
		}

		if (url == null) {
			handleError ("Attribute url needs to be set.");
			return false;
		}
		
		if (remoteComponentId != null) {
			msg = new JtMessage (JtFactory.JtLOOKUP);
		    msg.setMsgContent(remoteComponentId);
		} else {
			msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		    msg.setMsgContent(classname);
		}
		
		
		// Initialize the adapter
		
		axisAdapter = new JtAxisAdapter ();
		axisAdapter.setUrl(url);
		
		//adapter.setConcreteStrategy(axisAdapter);
		
		// Specify the communication mechanism (Axis Web services)
		//adapter.setAdaptee(axisAdapter);

		adapter = axisAdapter;
		
		
		//output =  factory.sendMessage(adapter, msg);
		messenger.setEncrypted(encrypted);
		messenger.setUseEnvelope(true);
		output =  messenger.sendMessage(adapter, msg);
				
		if (output == null) {
			if (remoteComponentId  != null)
				handleTrace ("unable to create a proxy to remote component: " + 
						remoteComponentId);				
			else
				handleTrace ("unable to create remote component: " + 
						classname);
			
			propagateException (adapter);
			return (false);
		}    
	      

		this.setSubject(output);

		return (true);
	}
	
	



	/**
	 * Process object messages by forwarding them to the proxy's subject.  
	 */

	public Object processMessage (Object message) {
		//JtMessage msg;
		Object output;

		String msgid = null;
		JtMessage e;
		boolean bool;
		//JtMessenger messenger = new JtMessenger ();

		if (message == null) {
			handleError ("Invalid message (null)");
			return null;
		}
		
		this.setObjException(null);
		
		if (message instanceof JtEncryptedMessage) {
			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output);			
		}
		
		
		if (message instanceof JtMessage) {
			e = (JtMessage) message;

			msgid = (String) e.getMsgId ();

			if (msgid == null) {
				handleError ("Invalid message Id (null)");
				return null;
			}
			
			if (msgid.equals (JtProxy.JtINITIALIZE_PROXY)) {
				bool = initializeProxy (e.isEncrypt());
				initialized = bool;
				return (new Boolean (bool));
			}
			
			handleError ("Invalid message:" + msgid);
			return (null);
 
		}
		
		if (message instanceof JtEnvelope) {
			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output); 
			
		}
		
		handleError ("Invalid message type:" + message.getClass().getName()); 
		return (null);
		//return (super.processMessage(message));

	}
	
	

	// Propagate Exceptions 

	private Exception propagateException (JtObject obj)
	{
		Exception ex;

		if (obj == null)
			return null;

		ex = (Exception) obj.getObjException();


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}
	
	 /**
	   * Demonstrates all the messages processed by JtAxisProxy. 
	   */

	  public static void main(String[] args) {

	    JtFactory factory = new JtFactory ();

	    String reply = null;
	    JtAxisProxy proxy;
	    Boolean Bool;
	    JtMessenger messenger;
	    JtMessage msg;
	    JtContext context = new JtContext ();


	    //factory.setLogging(true);
	   	    
	    // Create a local proxy that references a remote component
	    
	    proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
	    
	    // Set the service url property (if it is not present in the resource file)
	    if (proxy.getUrl() == null)
	    	proxy.setUrl("http://localhost:8080/axis/services/JtAxisService");

	    proxy.setClassname("Jt.examples.Echo");
	    
    

	    // Send a message to the remote component via its proxy

	    //factory.setSynchronous(false);
	    reply = (String) factory.sendMessage (proxy, "Welcome to Jt messaging ...");

	    // Display the reply unless an exception is detected.
	    // The remote exception gets propagated from the
	    // remote object to the local proxy
	    
	    //ex = (Exception) proxy.getObjException();

   
	    System.out.println ("reply:" + reply);
    	
	    

	    
	    // Framework support for encryption and secure web services.
	    // Specifies that the messaging interchange between proxy and
	    // remote component/service should be encrypted.
	    //proxy.setEncrypted(true);
	    
	    // The following section supplies a session key
	    // for message encryption. This key will be encrypted
	    // with the public key of the recipient. If no session
	    // key is supplied, the framework will generate a session key.
	    
	    Key sessionKey = null;

	    try {
	    	KeyGenerator generator = KeyGenerator.getInstance ("Blowfish");
	    	generator.init(128);
	    	sessionKey = generator.generateKey();

	    } catch (Exception ex1) {
	    	ex1.printStackTrace();
	    }
	    
	    messenger = new JtMessenger ();
	    //messenger.setSynchronous(false);
	    messenger.setSessionKey(sessionKey);
	    
	    reply = (String) messenger.sendMessage (proxy, "Welcome to Jt messaging ...");
	    
	    System.out.println ("reply:" + reply);
	    
	    
	    // Remove the remote proxy
	    
	    factory.removeObject (proxy);
	    
	    proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);

	    if (proxy.getUrl() == null)
	    	proxy.setUrl("http://localhost:8080/axis/services/JtAxisService");

		proxy.setClassname ("Jt.service.Logging");
	    	    
		// Authentication information 
		context = new JtContext ();
		context.setUserName("jt");
		context.setPassword("messaging");

		messenger.setEncrypted(true);
		msg = new JtMessage (JtLogger.JtENABLE_LOGGING);
		//msg.setMsgContext(context); This has been deprecated. Use the messenger context.
		messenger.setContext(context); 
		Bool = (Boolean) messenger.sendMessage (proxy, msg);
		
		System.out.println("Reply (authenticated):" + Bool);

		factory.setContext(context); 
		factory.setEncrypted(true);
	    factory.removeObject (proxy);
	    
		messenger.setContext(null);  // get rid of the authentication info
		context.setPassword(null);

	  }


}
