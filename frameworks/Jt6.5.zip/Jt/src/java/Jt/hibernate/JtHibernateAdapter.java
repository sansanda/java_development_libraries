package Jt.hibernate;


import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import Jt.JtMessage;
import Jt.JtObject;
//import Jt.hibernate.events.Event;
import Jt.DAO.JtDAOAdapter;
import Jt.hibernate.util.HibernateUtil;

/**
 * Jt Adapter for the DAO Hibernate API. This implementation supports
 * transactions and BPM integration.
 */


public class JtHibernateAdapter extends JtDAOAdapter {
    

    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtHibernateAdapter.class.getName(); 
    private boolean autocommit = true;
    //private String configFile = null;

    /**
     * Returns the value of the autocommit attribute.
     */
    
    public boolean getAutocommit() {
        return autocommit;
    }

    
    /**
     * Specifies if the transaction should be automatically commited
     * after each operation.
     * @param autocommit boolean property
     */
    
    public void setAutocommit(boolean autocommit) {
        this.autocommit = autocommit;
    }

    /**
     * Insert DAO
     */
    
    private Object insert (Object obj) {
        Session session;


        if (obj == null) {
            handleError ("insert: invalid parameter obj (null)");
            return (null);
        }
        
        handleTrace ("JtHibernateAdapter.insert: " + obj, 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            session.save(obj);

        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }

        return null;   

    }
    
    /**
     * Update DAO
     */
    
    private Object update (Object obj) {//check
        Session session;

        if (obj == null) {
            handleError ("update: invalid parameter obj (null)");
            return (null);
        }    
        
        handleTrace ("JtHibernateAdapter.update: " + obj, 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            session.update(obj);
            //session.flush();

        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }

        return null;   

    }  
    
    /**
     * Find DAO
     */
    
    private Object find (Object obj, Object key) {
        Session session;
        Object output = null;

        if (obj == null) {
            handleError ("find: invalid parameter obj (null)");
            return (null);
        }    
        
        if (key == null) {
            handleError ("find: invalid parameter key (null)");           
            return (null);
        }    

        handleTrace ("JtHibernateAdapter.find: " + key, 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            output = session.get(obj.getClass(), (Serializable) key);
        } catch (Exception ex) {
            handleException (ex);
        }

        return (output);
    }
 
    
    /**
     * Delete DAO
     */
    
    private Object delete (Object obj) {
        Session session;


        if (obj == null) {
            handleError ("delete: invalid parameter obj (null)");
            return (null);
        }
        
        handleTrace ("JtHibernateAdapter.delete: " + obj, 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            /*
            tmp = session.get(obj.getClass(), (Serializable) key);

            if (tmp == null) {
                handleError ("not found");
                return (null);
            } 
            */   
            session.delete(obj);
        } catch (Exception ex) {
            handleException (ex);
        }

        return (null);
    }

    /**
     * Begin transaction
     */
    private void beginTransaction () {
        Session session = null;

        this.setObjException(null);  // reset the exception
        //autocommit = false;
        handleTrace ("JtHibernateAdapter.beginTransaction", 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.beginTransaction();
        } catch (Exception ex) {
            handleException (ex);
        }
    }
 
    /**
     *  Commit transaction
     */
    
    private void commitTransaction () {
        Session session = null;
        
        //autocommit = true;

        handleTrace ("JtHibernateAdapter.commitTransaction", 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.getTransaction().commit();
        } catch (Exception ex) {
            handleException (ex);
        }
    }
 
    /**
     *  Close a session
     */
    
    private void closeSession () {
        Session session = null;

        handleTrace ("JtHibernateAdapter.closeSession", 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.close ();
        } catch (Exception ex) {
            handleException (ex);
        }
    }
    
    
    /**
     *  Rollback transaction
     */
    
    private void rollbackTransaction () {
        Session session = null;

        handleTrace ("JtHibernateAdapter.rollbackTransaction", 0);
        try {
            session = HibernateUtil.getSessionFactory().getCurrentSession();

            if (session != null)
                session.getTransaction().rollback();
        } catch (Exception ex) {
            handleException (ex);
        }
        //autocommit = true;
    }
 
    /*
     * Execute a Query
     */
    
    
    private Object executeQuery (String query, Object obj) {
        List result = null;

        if (query == null || obj == null)
            return (null);

        handleTrace ("JtHibernateAdapter.executeQuery: " + query, 0);
        try {
            
            Session session = HibernateUtil.getSessionFactory().getCurrentSession();
            result = session.createSQLQuery(query).addEntity(obj.getClass()).list();

        } catch (Exception ex) {
            handleException (ex);
            return (null);
        }


        return result;

    }
    
    /**
     * Process object messages.
     * <ul>
     * <li> JtCREATE - Inserts an object. msgContent specifies the object
     * to be inserted.
     * <li> JtREAD - Finds an object. Returns the object or null. msgData 
     * specifies the identifier (key). msgContent specifies an instance of the 
     * persistent class. This instance is only used to determine the persistent class.
     * msgContent can be any instance of the class.
     * <li> JtUPDATE - Updates an object. msgContent specifies the object
     * to be updated.
     * <li> JtDELETE - Deletes an object. msgContent specifies the object
     * to be deleted.
     * <li> JtREMOVE - Releases resources and closes the session.
     * <li> JtEXECUTE_QUERY - Execute an SQL query. msgContent specifies
     * the query to be executed.
     * <li> JtBEGIN_TRANSACTION - Starts a transaction. 
     * <li> JtCOMMIT - Commits the transaction. 
     * <li> JtROLLBACK - Rollbacks the transaction. 
     * </ul>
     */
    
    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        Object obj;
        Object key;
        String query;
        Object reply;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        obj = e.getMsgContent();


        if (msgid.equals (JtDAOAdapter.JtINSERT) ||
                msgid.equals (JtObject.JtCREATE)) {
            
            if (autocommit)
               beginTransaction ();
            
            reply = insert (obj);

            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction ();
            
            return (null);
        }

        if (msgid.equals (JtDAOAdapter.JtFIND) ||
                msgid.equals (JtObject.JtREAD)) {
            if (autocommit)
                beginTransaction ();
            
            key = e.getMsgData ();
            
            reply = find (obj, key);
            
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            
            return (reply);
        }

        if (msgid.equals (JtDAOAdapter.JtUPDATE)) {
            if (autocommit)
                beginTransaction ();
            
            reply = update (obj);

            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            
            return (null);
        }
        
        
        if (msgid.equals (JtDAOAdapter.JtDELETE)) {
            
            if (autocommit)
                beginTransaction ();           
            
            //key = e.getMsgData ();
            reply = delete (obj);
 
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            return (null);
        }
 
        if (msgid.equals (JtDAOAdapter.JtBEGIN_TRANSACTION)) {
            autocommit = false;
            beginTransaction ();
            return (null);
        }
        
        if (msgid.equals (JtDAOAdapter.JtCOMMIT)) {
            commitTransaction ();
            return (null);
        }
 
        if (msgid.equals (JtDAOAdapter.JtROLLBACK)) {
            rollbackTransaction ();
            return (null);
        }
 
        if (msgid.equals (JtDAOAdapter.JtEXECUTE_QUERY)) {
            
            if (autocommit)
                beginTransaction ();
            
            query = (String) e.getMsgContent();
            obj = e.getMsgData();
            
            reply = executeQuery (query, obj);
            
            if (autocommit)
                if (this.getObjException() != null)
                    rollbackTransaction ();
                else
                    commitTransaction (); 
            
            return (reply);
        }
        
        if (msgid.equals (JtObject.JtREMOVE)) {
            closeSession ();
            return (null);
        }
        
        return (super.processMessage(event));

        //handleError ("JtHibernateAdapter.processMessage: invalid message id:" + msgid);
        //return (null);

    }
/*    
    public static void main(String[] args) {

        JtObject main = new JtObject ();
        JtMessage msg;
        JtHibernateAdapter adapter;
        Event event;
        List events;
        int i;


        msg = new JtMessage ();

        
        Event theEvent = new Event();
        theEvent.setTitle("hello1");
        theEvent.setDate(new Date ());
        
        
        // Create the Hibernate object

        adapter = (JtHibernateAdapter) main.createObject ("Jt.hibernate.JtHibernateAdapter", "adapter");
      
        main.sendMessage (adapter, new JtMessage ("JtBEGIN_TRANSACTION"));
        
        msg.setMsgId ("JtINSERT");
        msg.setMsgContent(theEvent);
        event = (Event) main.sendMessage (adapter, msg);
        if (event != null) {
            System.out.println("JtINSERT: GO");
            System.out.println(event.getId());
        }        
        
        //event = new Event ();
        msg.setMsgId ("JtFIND");
        msg.setMsgContent(event);
        //id = event.getId();
        msg.setMsgData (event.getId());
        event = (Event) main.sendMessage (adapter, msg);
        
        if (event != null) {
            System.out.println("JtFIND: GO");
            System.out.println(event.getId());
            System.out.println(event.getTitle());
        } else
            System.out.println("JtFIND: FAIL");           
        
       
        msg.setMsgId ("JtUPDATE");
        if (event != null)
            event.setTitle("hello2");
        //msg.setMsgContent(event);
        event = (Event) main.sendMessage (adapter, msg);
        
        main.sendMessage (adapter, new JtMessage ("JtCOMMIT"));      
        main.sendMessage (adapter, new JtMessage ("JtBEGIN_TRANSACTION"));
      
        msg.setMsgId ("JtEXECUTE_QUERY");
        msg.setMsgContent("select * from events");
        msg.setMsgData(new Event ());
        events = (List) main.sendMessage (adapter, msg);
        main.sendMessage (adapter, new JtMessage ("JtCOMMIT"));
        
        if (events != null) {
            for (i = 0; i < events.size(); i++) {
                System.out.println("count:" + events.size());
                Event theEvent1 = (Event) events.get(i);
                System.out.println("Event: " + theEvent1.getTitle() +
                                   " Time: " + theEvent1.getDate());
                theEvent1.setTitle("new");
            }
        }

        
      }
*/      
}
