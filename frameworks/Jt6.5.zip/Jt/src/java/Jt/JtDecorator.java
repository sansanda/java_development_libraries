/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;


/**
 * Jt Implementation of the Decorator design pattern.
 */

public class JtDecorator extends JtObject {

    public static final String JtCLASS_NAME = JtDecorator.class.getName(); 
    private static final long serialVersionUID = 1L;
    protected Object component = null;


    /**
     * Specifies the object that is being decorated.
     * @param component component
     */

    public void setComponent (Object component) {
        this.component = component;
    }


    /**
     * Returns the object that is being decorated.
     */

    public Object getComponent () {
        return (component);
    }

    public JtDecorator () {
    }




    /**
     * Process object messages. The subclass should override this method and implement the
     * additional functionality.
     */

    public Object processMessage (Object msg) {

    	JtFactory factory = new JtFactory ();

        if (component == null) {
            handleError ("processMessage: component attribute need to be set.");
            return (null);
        }

        // Let the component handle the original functionality
        return (factory.sendMessage (component, msg));        
        //return (((JtInterface) component).processMessage(msg));
    }


    /**
     * Demonstrates the messages processed by JtDecorator.
     */

    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();

        JtDecorator decorator;

        // Create JtDecorator

        decorator = (JtDecorator) factory.createObject (JtDecorator.JtCLASS_NAME);




    }

}


