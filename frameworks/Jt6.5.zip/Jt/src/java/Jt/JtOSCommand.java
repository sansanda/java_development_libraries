package Jt;

import java.io.*;


/** 
 *  Class used to invoke OS commands.
 */


public class JtOSCommand extends JtComponent {

    public static final String JtCLASS_NAME = JtOSCommand.class.getName(); 
    public static final String JtEXECUTE = "JtEXECUTE";
    
    private static final long serialVersionUID = 1L;
    private String command;
    private Process process = null;
    private int status = 0;
    private String stdout;


    /**
     * Specifies the OS command to be executed.
     * @param newCommand OS command
     */

    public void setCommand (String newCommand) {
        command = newCommand;
    }

    /**
     * Returns the OS command to be executed. 
     */

    public String getCommand () {
        return (command);
    }


    /**
     * Returns the output of the command. 
     */

    public String getStdout () {
        BufferedReader d;
        StringBuffer output = null;
        String line;
        InputStream stream;

        if (process == null)
            return (null);

        stream = process.getInputStream ();

        if (stream == null)
            return (null);

        d = new BufferedReader (new InputStreamReader (stream));
        try { 	
            while ((line  = d.readLine ()) != null) {
                handleTrace (line);
                if (output == null) { 
                    output = new StringBuffer ();
                    output.append (line);
                } else 
                    output.append ("\n" + line); // check

            }
        } catch (Exception e) {
            handleException (e);
        }
        if (output != null)
            stdout = output.toString ();
        return (stdout);
    }

    /**
     * Returns the exit status of the command. 
     */
    public int getStatus () {
        if (process == null) {
            handleWarning ("JtCommand: invalid process: null");
            return (-1);
        }

        try {
            process.waitFor ();
        } catch (Exception e) {
            handleException (e);
        }

        return (process.exitValue ());
    } 


    /**
     * Void operation. 
     */

    public void setStatus (int status) {

    } 

    // Executes the OS command

    void execute () {

        if (command == null) {
            process = null;		// just in case
            return;
        }

        try {
            process = Runtime.getRuntime().exec (command);
        } catch (Exception e) {
            handleException (e);
        }
    }


    /**
     * Process object messages. 
     * <ul>
     * <li> JtEXECUTE/JtACTIVATE - Executes the OS command specified by the command attribute.
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;

        JtMessage e = (JtMessage) message;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;


        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtOSCommand.JtEXECUTE) ||
        		msgid.equals(JtObject.JtACTIVATE)) {
            execute ();
            return null;
        }

        return (super.processMessage(message));
    }

    /**
     * Demonstrates all the message processed by JtCommand. Usage: java Jt.JtCommand command  
     */

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtMessage msg;
        int status;
        String output;
        JtOSCommand command = new JtOSCommand ();


        if (args.length < 1) {
            System.err.println ("Usage: java Jt.JtOSCommand command");
            return;
        }
        
        command.setCommand(args[0]);

        main.sendMessage (command, new JtMessage (JtObject.JtACTIVATE));

        status = command.getStatus();
        System.err.println ("Exit status:" +  status);
        output = command.getStdout();
        System.err.println ("Command output:" +  output);


    }
}


