package Jt;



/**
 * Jt Implementation of the Interpreter design pattern.
 */


public class JtInterpreter extends JtObject {


  private static final long serialVersionUID = 1L;
  private Object context = null;
  public static final String JtINTERPRET = "JtINTERPRET";
  public static final String JtCLASS_NAME = JtInterpreter.class.getName(); 

  public JtInterpreter() {
  }

/**
  * Specifies the interpreter context.
  *
  * @param context context
  */

  public void setContext (Object context) {
     this.context = context; 

  }

/**
  * Returns the interpreter context.
  */

  public Object getContext () {
     return (context);
  }


  /**
    * Process object messages. Subclasses need to override this method and implement
    * the JtINTERPRET message.
    */

  public Object processMessage (Object message) {

      String msgid = null;
      JtMessage e;


      if (message == null)
          return null;

      if (message instanceof JtMessage) {
    	  e = (JtMessage) message;
    	  msgid = (String) e.getMsgId ();

    	  if (msgid == null)
    		  return null;

    	  // Remove this object
    	  if (msgid.equals (JtObject.JtREMOVE)) {
    		  return (null);     
    	  }

    	  if (msgid.equals (JtInterpreter.JtINTERPRET)) {
    		  // subclass needs to implement/process this message
    		  return (null);     
    	  }
      }
      return (super.processMessage(message));
  }

  /**
    * Demonstrates the messages processed by JtInterpreter.   
    */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtInterpreter interpreter;

    // Create an instance of JtInterpreter

    interpreter = (JtInterpreter)
      main.createObject (JtInterpreter.JtCLASS_NAME, 
      "interpreter");


    main.sendMessage (interpreter, new JtMessage (JtInterpreter.JtINTERPRET));

    //main.removeObject ("interpreter");
         

  }

}