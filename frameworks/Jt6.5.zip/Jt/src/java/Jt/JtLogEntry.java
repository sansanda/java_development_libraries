

package Jt;


/**
 *  Represents a log entry
 */

public class JtLogEntry {

    String msg;
	int level; 

    public JtLogEntry (String msg, int level) {
    	this.msg = msg;
    	this.level = level;
    }
    
    /** 
     * Returns the message to be logged.
     */

    public String getMsg() {
		return msg;
	}

	/** 
	 * Specifies the message to be logged.
	 */
    
	public void setMsg(String msg) {
		this.msg = msg;
	}

	/** 
	 * Returns the logging level associated with this message.
	 */
	
	public int getLevel() {
		return level;
	}

	/** 
	 * Specifies the logging level associated with this message.
	 * @param level
	 */
	
	public void setLevel(int level) {
		this.level = level;
	} 


}
