/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt.http;


import Jt.JtComponent;
import Jt.JtEnvelope;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtMessenger;
import Jt.JtObject;
import Jt.JtProxy;
import Jt.JtRemoteProxy;
import Jt.http.JtHttpAdapter;
import Jt.security.JtEncryptedMessage;



/**
 * HTTP Proxy.
 */

public class JtHttpProxy extends JtRemoteProxy {

	private static final long serialVersionUID = 1L;
	public static final String JtCLASS_NAME = JtHttpProxy.class.getName();


	private boolean restful = false;
	



	/**
	 * Returns the value of restful.
	 */


	public boolean isRestful() {
		return restful;
	}
	
	/**
	  * Specifies whether or not restful mode should be used.
	  */
	
	public void setRestful(boolean restful) {
		this.restful = restful;
	}
	
	/*
	 * Propagate an exception. Some exceptions need
	 * to be propagated to the sender.
	 */
	
	private Exception propagateException (JtObject obj) {
		Exception ex;

		if (obj == null)
			return (null);

		ex = (Exception) obj.getObjException();

		if (ex != null) {
			this.setObjException(ex);
		}  
		return (ex);
	}


	

	private boolean initializeProxy (boolean encrypted) {
		JtMessage msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		Object output;
		//JtAxisAdapter axisAdapter;
		JtMessenger messenger = new JtMessenger ();
		

		if (classname == null && remoteComponentId == null) {
			handleError ("Classname (or remoteComponentId) needs to be set.");
			return false;
		}

		if (url == null) {
			handleError ("Attribute url needs to be set.");
			return false;
		}
				
		
		// Initialize the adapter
		
		adapter = new JtHttpAdapter ();
		((JtHttpAdapter) adapter).setUrl(url);
		
		if (restful)
			return (true);
		
		
		if (remoteComponentId != null) {
			msg = new JtMessage (JtFactory.JtLOOKUP);
		    msg.setMsgContent(remoteComponentId);
		} else {
			msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		    msg.setMsgContent(classname);
		}
		

		
		//adapter.setConcreteStrategy(axisAdapter);
		
		// Specify the communication mechanism (Axis Web services)
		//adapter.setAdaptee(axisAdapter);

		//adapter = axisAdapter;
		
		
		//output =  factory.sendMessage(adapter, msg);
		messenger.setEncrypted(encrypted);  //
		messenger.setUseEnvelope(true);
		output =  messenger.sendMessage(adapter, msg);
				
		if (output == null) {
			if (remoteComponentId  != null)
				handleTrace ("unable to create a proxy to remote component: " + 
						remoteComponentId);				
			else
				handleTrace ("unable to create remote component: " + 
						classname);
			
			propagateException (adapter);
			return (false);
		}    
	      
        handleTrace ("handle:" + output);
		this.setSubject(output);

		return (true);
	}
	
	
	
	/**
	 * Process object messages by forwarding them to the proxy's subject.  
	 */

	public Object processMessage (Object message) {
		//JtMessage msg;
		Object output;

		String msgid = null;
		JtMessage e;
		boolean bool;
		JtMessenger messenger = new JtMessenger ();

		if (message == null) {
			handleError ("Invalid message (null)");
			return null;
		}
		
		this.setObjException(null);
		
		if (message instanceof JtEncryptedMessage) {
			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output);			
		}
		
		if (message instanceof JtMessage) {
			e = (JtMessage) message;

			msgid = (String) e.getMsgId ();

			if (msgid == null) {
				handleError ("Invalid message Id (null)");
				return null;
			}
			
			if (msgid.equals (JtProxy.JtINITIALIZE_PROXY)) {
				bool = initializeProxy (e.isEncrypt());
				initialized = bool;
				return (new Boolean (bool));
			}
			
			/*
			if (!initialized) {
				initialized = initializeProxy (e.isEncrypt());
				if (!initialized)
					return null;
			}


			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output);
			*/
			
			handleError ("Invalid message:" + msgid);
			return (null);
		}
		
		
		if (message instanceof JtEnvelope) {
			output = adapter.processMessage (message); 
			

			propagateException (adapter);
			return (output); 
			
		}
		
		handleError ("Invalid message type:" + message.getClass().getName()); 
		return (null);
		//return (super.processMessage(message));

	}

	/**
	 * Send a message to a remote component/Restful service using
	 * a remote proxy. Secure/Encrypted messaging may be used.
	 * The messaging design pattern provides transparent access
	 * to remote components.
	 */

	public static void main(String[] args) {

		JtFactory factory = new JtFactory ();
		String sReply;
		Object reply;
		JtHttpProxy proxy;
		String url = "http://localhost:8080/JtPortal/JtRestService";
		JtMessenger messenger;
		boolean bool;

		// Create an instance of the remote Proxy

		proxy = (JtHttpProxy) factory.createObject (JtHttpProxy.JtCLASS_NAME);
		
		proxy.setUrl(url);
		proxy.setClassname ("Jt.examples.Echo");
		
        // Specify that secure/encrypted messaging should be used
		
		//proxy.setEncrypted(true);

        // Send the message to the remote component/service.
		
		sReply = (String) factory.sendMessage (proxy, "Welcome to Jt messaging ...");
		

		System.out.println ("Reply:" + sReply);
		
		
		proxy = (JtHttpProxy) factory.createObject (JtHttpProxy.JtCLASS_NAME);	
		proxy.setUrl(url);
		proxy.setClassname ("Jt.examples.EchoService");
		proxy.setRestful(false);
		
		
		messenger = new JtMessenger ();
	    // Specify that secure/encrypted messaging should be used
		messenger.setEncrypted(true);
		//messenger.setSynchronous(false);
		
	    // Send the message to the remote component/service.
		
		reply = messenger.sendMessage (proxy, new JtMessage (JtComponent.JtACTIVATE));


		System.out.println ("Reply:" + reply);
		
		factory.setEncrypted(true);
		bool = factory.setValue(proxy, "greeting", "new message");
		System.out.println ("boolean:" + bool);		
		
		reply = factory.getValue(proxy, "greeting");
		System.out.println ("greeting attribute:" + reply);	
			
		bool = factory.removeObject(proxy);		
		System.out.println ("removeObject:" + bool);		
		
		
	}

}
