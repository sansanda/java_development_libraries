

package Jt;


/**
 * Jt Implementation of the Bridge pattern.
 */

public class JtBridge extends JtObject {

    public static final String JtCLASS_NAME = JtBridge.class.getName(); 
    private static final long serialVersionUID = 1L;
    protected Object implementor;

    public JtBridge () {
    }

    /**
     * Specifies the implementor.
     *
     * @param implementor implementor
     */

    public void setImplementor (Object implementor) {
        this.implementor = implementor; 

    }

    /**
     * Returns the implementor.
     */

    public Object getImplementor () {
        return (implementor);
    }



    /**
     * Process object messages.
     * <ul>
     * </ul>
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtFactory factory = new JtFactory ();


        if (implementor == null) {
            handleError ("JtBridge.process: the implementor attribute needs to be set");
            return (null);
        }

        // Let the implementor process the request

        return (factory.sendMessage (implementor, message));

    }


    /**
     * Demonstrates the messages processed by JtBridge.
     */


    public static void main(String[] args) {

        JtFactory factory = new JtFactory ();
        JtBridge bridge;


        // Create an instance of JtBridge

        bridge = (JtBridge) factory.createObject (JtBridge.JtCLASS_NAME);



    }


}


