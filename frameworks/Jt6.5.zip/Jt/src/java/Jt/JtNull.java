

package Jt;


/**
 * Implementation of the Null design pattern
 */

public class JtNull extends JtObject {

    public static final String JtCLASS_NAME = JtNull.class.getName(); 
    private static final long serialVersionUID = 1L;


    public JtNull() {
    }


    /**
     * Process object messages. JtNull does nothing.
     */

    public Object processMessage (Object event) {


        return (null);

    }



}


