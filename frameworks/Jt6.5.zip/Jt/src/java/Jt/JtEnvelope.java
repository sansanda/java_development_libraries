
/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;



/**
 *  Message envelope
 */

public class JtEnvelope extends JtObject  {

   public static final String JtCLASS_NAME = JtEnvelope.class.getName(); 
   private static final long serialVersionUID = 1L;
   private Object message;
   private boolean asynchronous = false;
   private JtContext context;



   public JtEnvelope () {

   }


   /**
    * Returns the message.
    */
   
   public Object getMessage() {
	   return message;
   }

   /**
    * Specifies the message.
    *
    */

   public void setMessage(Object message) {
	   this.message = message;
   }


   /**
    * Returns the value of asynchronous.
    */
   
   public boolean isAsynchronous() {
	   return asynchronous;
   }


   /**
    * Specifies whether or not this message should be processed asynchronously.
    */
   
   public void setAsynchronous(boolean asynchronous) {
	   this.asynchronous = asynchronous;
   }

   /*
    * Return the message context.
    */

   public JtContext getContext() {
	   return context;
   }

   

   /**
    * Specifies the message context.
    */

   public void setContext(JtContext context) {
	   this.context = context;
   }


}
