/*
 *
 * Copyright Jt Design Pattern Framework. All Rights Reserved.
 * 
 * - Redistributions of source code must retain this copyright
 *   notice and disclaimer.

 * This software is provided "AS IS," without a warranty of any
 * kind. ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND
 * WARRANTIES, INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY
 * EXCLUDED. THE AUTHORS SHALL NOT BE LIABLE FOR ANY
 * DAMAGES OR LIABILITIES SUFFERED BY LICENSEE AS A RESULT OF OR
 * RELATING TO USE, MODIFICATION OR DISTRIBUTION OF THIS SOFTWARE OR
 * ITS DERIVATIVES. IN NO EVENT WILL THE AUTHORS OR ITS LICENSORS BE LIABLE
 * FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT,
 * SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER
 * CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF
 * THE USE OF OR INABILITY TO USE THIS SOFTWARE.
 * 
 * 
 */

package Jt;

import java.util.Iterator;
import java.util.List;

/**
 * Jt implementation of the Observer design pattern.
 */

public class JtObservable extends JtComponent {

  public static final String JtCLASS_NAME = JtObservable.class.getName(); 
  private static final long serialVersionUID = 1L;
  public static final String JtADD_OBSERVER = "JtADD_OBSERVER";
  public static final String JtREMOVE_OBSERVER = "JtREMOVE_OBSERVER";
  public static final String JtNOTIFY_OBSERVERS = "JtNOTIFY_OBSERVERS";
  //public static final String JtNOTIFY = "JtNOTIFY";
  
  private boolean synchronousObserver = true;

  public JtObservable () {
  }


  public boolean isSynchronousObserver() {
	  return synchronousObserver;
  }

  public void setSynchronousObserver(boolean synchronousObserver) {
	  this.synchronousObserver = synchronousObserver;
  }

 
  private void notifyObservers (Object msg)
  {
      Object obj;
      JtFactory factory = new JtFactory ();
      Iterator iterator;
      List list;
      
      
      list = this.getList();
      
      if (msg == null || list == null)
          return;


      iterator = list.iterator();
      
      while (iterator.hasNext()) {
    	  
          obj = iterator.next ();  

          if (!synchronousObserver)
        	  factory.setSynchronous(false);
          
          factory.sendMessage (obj, msg);
      }


  }
  /**
    * Process object messages.
    * <ul>
    * <li>JtADD_OBSERVER - Adds the observer contained in the message (msgContent)
    * <li>JtREMOVE_OBSERVER - Removes the observer contained in the message (msgContent)
    * <li>JtNOTIFY_OBSERVERS - Notifies its observers when the object changes
    * state. msgContent contains the message to be sent to the observers.
    * </ul>
    */

  public Object processMessage (Object event) {

	  String msgid = null;
	  JtMessage e = (JtMessage) event;
	  Object content;
	  //Object data;
	  JtMessage tmp;

	  if (e == null)
		  return null;

	  msgid = (String) e.getMsgId ();

	  if (msgid == null)
		  return null;

	  content = e.getMsgContent();
	  //data = e.getMsgData ();


	  if (msgid.equals (JtObservable.JtADD_OBSERVER)) {
		  tmp = new JtMessage (JtComposite.JtADD_CHILD);
		  tmp.setMsgContent (content);
		  return (super.processMessage (tmp));     
	  }

	  if (msgid.equals (JtObservable.JtREMOVE_OBSERVER)) {
		  tmp = new JtMessage (JtComposite.JtREMOVE_CHILD);
		  tmp.setMsgContent (content);
		  return (super.processMessage (tmp));     
	  }


	  if (msgid.equals (JtObservable.JtNOTIFY_OBSERVERS)) {
		  if (content == null) {
			  handleError ("Invalid message (JtNOTIFY_OBSERVERS): content needs to set");
			  return (null);
		  }

		  notifyObservers (content);
		  return (null);
		  /*	 
       tmp = new JtMessage (JtObject.JtBROADCAST);
       if (content == null) {
           tmp1 = new JtMessage (JtObservable.JtNOTIFY);
           tmp1.setMsgContent (this);
           tmp.setMsgContent (tmp1);
       } else
           tmp.setMsgContent (content);

       return (super.processMessage (tmp));   
		   */  
	  }


	  //if (msgid.equals ("JtREMOVE")) {
	  //  return (null);     
	  //}

	  return (super.processMessage(event));
  }

 
  /**
   * Demonstrates the messages processed by JtObserver
   */

  public static void main(String[] args) {

    JtFactory main = new JtFactory ();
    JtObservable observable;
    JtMessage msg;
    JtEcho echo1, echo2;
    

    // Create JtObservable instance

    observable = (JtObservable) main.createObject (JtObservable.JtCLASS_NAME, "observable");
    echo1 = (JtEcho) main.createObject (JtEcho.JtCLASS_NAME);
    echo2 = (JtEcho) main.createObject (JtEcho.JtCLASS_NAME);

    System.out.println ("JtObservable(JtADD_OBSERVER): adding an observer ...");

    msg = new JtMessage (JtObservable.JtADD_OBSERVER);
    msg.setMsgContent (echo1);

    main.sendMessage (observable, msg);


    System.out.println ("JtObservable(JtADD_OBSERVER): adding an observer ...");

    msg = new JtMessage (JtObservable.JtADD_OBSERVER);
    msg.setMsgContent (echo2);

    main.sendMessage (observable, msg);

    System.out.println ("JtObservable(JtNOTIFY_OBSERVERS): notifying observers ...");

    msg = new JtMessage (JtObservable.JtNOTIFY_OBSERVERS);
    msg.setMsgContent("Notification message");

    
    main.sendMessage (observable, msg);
    

    //main.removeObject (observable);


  }

}


