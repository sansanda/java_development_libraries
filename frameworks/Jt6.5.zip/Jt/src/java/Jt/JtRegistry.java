package Jt;


import java.util.Hashtable;

import Jt.examples.Test;


/**
 * Maintains a registry of framework components
 */

public class JtRegistry extends JtObject {


  private static final long serialVersionUID = 1L;
  public static final String JtCLASS_NAME = JtRegistry.class.getName(); 

  private Hashtable componentTable = new Hashtable ();                 
  
  public JtRegistry () {
  }
  
  private synchronized Object add (Object id, Object obj) {


	  if (id == null || obj == null) {
		  handleError ("Invalid parameters");
		  return null;
	  }
	  
	  if (componentTable.get (id) != null) {
		  handleWarning ("JtRegistry.add: unable to create a duplicate entry " + id);  
		  return (null);
	  }
	  
	  componentTable.put (id, obj);

	  return (id);

  }
  
  private synchronized Object update (Object id, Object obj) {


	  if (id == null || obj == null) {
		  handleError ("Invalid parameters");
		  return null;
	  }
	  if (componentTable.get (id) == null) {
		  handleWarning ("JtRegistry.update: entry not found " + id);  
		  return (null);
	  }
	  
	  componentTable.put (id, obj);

	  return (id);

  }
  
  
  private synchronized Object lookup (Object id) {


      if (id == null) {
		  handleError ("Invalid parameters");
          return (null);
      }

      return (componentTable.get (id));


  }
  
  private synchronized Object remove (Object id) {


      if (id == null) {
		  handleError ("Invalid parameters");
          return (null);
      }

      return (componentTable.remove (id));


  }
  
  /**
    * Process object messages.
     * <ul>
     * <li> JtCREATE - Creates a registry entry for the component (msgContent)
     * using the specified key (msgData).
     * <li> JtREAD - Returns the component associated with the key (msgData).
     * <li> JtUPDATE - Updates the registry entry associated with the key (msgData) using the new
     * component (msgContent).
     * <li> JtDELETE - Removes the entry associated with the key (msgData) from the component registry.
     * </ul>

    */

  public Object processMessage (Object message) {

	  String msgid;
	  JtMessage e = (JtMessage) message;
	  //Object content;


	  if (e == null)
		  return null;

	  msgid = (String) e.getMsgId ();

	  if (msgid == null)
		  return null;

	  if (msgid.equals (JtObject.JtCREATE)) {
		  //content = e.getMsgContent ();
 
 
		  return (add (e.getMsgData(), e.getMsgContent ()));
	  }
	  
	  if (msgid.equals (JtObject.JtUPDATE)) {

		  return (update (e.getMsgData(), e.getMsgContent ()));
	  }

	  if (msgid.equals (JtObject.JtREAD)) {
  
		  return (lookup (e.getMsgData ()));
	  }
	  
	  if (msgid.equals (JtObject.JtDELETE)) {
		  
		  return (remove (e.getMsgData ()));
	  }
      
      handleError ("invalid message Id:" + msgid);
	  //return (super.processMessage (event)); 
	  return null;


  }

 
  /**
   * Demonstrates the messages processed by JtRegistry
   */

  public static void main(String[] args) {

	JtFactory factory = new JtFactory ();	  
    JtRegistry registry = new JtRegistry ();
    JtMessage msg = new JtMessage (JtObject.JtCREATE);
    Test test = new Test ();
    Test test1 = new Test ();
    Test tmp;


    // Create an instance of JtRegistry

    registry = (JtRegistry) factory.createObject (JtRegistry.JtCLASS_NAME);

    msg.setMsgData("testComponent");
    msg.setMsgContent(test);
    

    factory.sendMessage(registry, msg);

    msg = new JtMessage (JtObject.JtREAD);
    msg.setMsgData("testComponent");
    

    
    tmp = (Test) factory.sendMessage(registry, msg);

    if (test == tmp)
    	System.out.println("JtCREATE/JtREAD: OK");
    
    msg = new JtMessage (JtObject.JtUPDATE);   
    msg.setMsgData("testComponent");
    msg.setMsgContent(test1);
    
    factory.sendMessage(registry, msg);
    
    msg = new JtMessage (JtObject.JtREAD);
    msg.setMsgData("testComponent");
    
    test = (Test) factory.sendMessage(registry, msg);

    if (test == test1)
    	System.out.println("JtUPDATE: OK");

    msg = new JtMessage (JtObject.JtDELETE);
    msg.setMsgData("testComponent");
    
    factory.sendMessage(registry, msg);
    
    msg = new JtMessage (JtObject.JtREAD);
    msg.setMsgData("testComponent");
    
    test = (Test) factory.sendMessage(registry, msg);

    if (test == null)
    	System.out.println("JtDELETE: OK");
    
    
    msg.setMsgData("testComponent");
    msg.setMsgContent(test1);
  }

}


