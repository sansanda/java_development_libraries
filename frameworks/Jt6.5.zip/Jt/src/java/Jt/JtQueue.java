

package Jt;


/**
 * Implements a queue of objects.
 */

public class JtQueue extends JtList {


    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = JtQueue.class.getName(); 
    public static final String JtENQUEUE = "JtENQUEUE";
    public static final String JtDEQUEUE = "JtDEQUEUE";

    public JtQueue() {
    }


    private Object test () {

        JtMessage msg;
        Integer obj;
        JtFactory factory = new JtFactory ();


        // Enqueue couple of objects

        msg = new JtMessage (JtQueue.JtENQUEUE);
        msg.setMsgContent (new Integer (1));
        System.out.println ("Enqueue object ... " + new Integer (1));
        factory.sendMessage (this, msg);


        msg = new JtMessage (JtQueue.JtENQUEUE);
        msg.setMsgContent (new Integer (2));
        System.out.println ("Enqueue object ... " + new Integer (2));
        factory.sendMessage (this, msg);


        // Dequeue all the elements in the queue

        for (;;) {
            obj = (Integer) factory.sendMessage (this, new JtMessage (JtQueue.JtDEQUEUE));
            if (obj == null)
                break;
            System.out.println ("Dequeue object ... " + obj);
        }
        return (this);

    }

    /**
     * Process object messages.
     * <ul>
     * <li> JtENQUEUE - Enqueues the object specified by msgContent
     * <li> JtDEQUEUE - Dequeues and returns the object at the beginning of the queue.
     * </ul>
     * @param message Jt Message
     */

    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        Object content;
        //Object data;
        JtMessage tmp;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = e.getMsgContent();


        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {

            return (null);     
        }

        // Enqueue message
        if (msgid.equals (JtQueue.JtENQUEUE)) {
            // Add an object to the queue

            tmp = new JtMessage (JtList.JtADD);
            tmp.setMsgContent (content);    
            return (super.processMessage (tmp));
        }     


        // Dequeue message

        if (msgid.equals (JtQueue.JtDEQUEUE)) {

            return (super.processMessage (new JtMessage (JtList.JtREMOVE_FIRST)));
        }     


        // Test this object
        if (msgid.equals (JtObject.JtTEST)) {

            return (test ());     
        }


        return (super.processMessage(message));

    }


    /**
     * Demonstrates the messages processed by JtQueue.
     */ 

    public static void main(String[] args) {

        JtFactory main = new JtFactory ();
        JtQueue queue;


        // Create a Queue

        queue = (JtQueue) main.createObject (JtQueue.JtCLASS_NAME);

        main.sendMessage (queue, new JtMessage (JtObject.JtTEST));

    }

}


