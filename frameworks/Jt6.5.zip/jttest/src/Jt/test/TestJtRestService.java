package Jt.test;

import java.util.Date;

import Jt.JtContext;
import Jt.JtFactory;
import Jt.JtLogger;
import Jt.JtMessage;
import Jt.JtMessenger;
import Jt.JtObject;
import Jt.examples.DateService;
import Jt.examples.HelloWorld;
import Jt.examples.JtHelloWorld;
import Jt.rest.JtRestService;

import junit.framework.TestCase;

public class TestJtRestService extends TestCase {

    JtFactory factory = new JtFactory ();
    

	// Rest services should be configured before running this test
	
	public void testRestService() {
		JtFactory factory = new JtFactory ();
		JtMessage msg = new JtMessage (JtObject.JtACTIVATE);
		Object reply;
		JtRestService service;
		Date date;
		JtMessenger messenger;
		JtContext context;

		// Create an instance of JtRestService

		service = (JtRestService) factory.createObject (JtRestService.JtCLASS_NAME);
		
		// Assign the URL for the REST service/resource
		
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.examples.HelloWorld");

        // Invoke the remote service (Make the REST request to access the remote resource/service).
		
		msg = new JtMessage (HelloWorld.JtHELLO);
		reply = factory.sendMessage (service, msg);
		
        // Check for exceptions. Remote exceptions are automatically
		// propagated by the framework.

		//if (service.getObjException() == null)
		//	System.out.println ("Reply:" + reply);
		
        assertNull (service.getObjException());
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.examples.DateService");
		msg = new JtMessage (DateService.GET_DATE);
		
		// The reply message is automatically converted to
		// the appropriate Java type by the framework
		
		date = (Date) factory.sendMessage (service, msg);
		
		//if (service.getObjException() == null)
		//	System.out.println ("Reply date:" + date);
		
        assertNull (service.getObjException());
        
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.examples.JtHelloWorld");
		
		// Message Id is an integer (1)
		msg = new JtMessage (JtHelloWorld.JtHELLO);
		
		reply = factory.sendMessage (service, msg);
		
		//if (service.getObjException() == null)
		//	System.out.println ("Reply:" + reply);

		messenger = new JtMessenger ();
		messenger.setEncrypted(true);
		// The framework access manager is responsible
		// for granting/blocking access to remote components.
		
		context = new JtContext ();
		context.setUserName("jt");
		context.setPassword("messaging1");
		
		messenger.setContext(context);
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.service.Logging");
		msg = new JtMessage (JtLogger.JtENABLE_LOGGING);
		reply = messenger.sendMessage (service, msg);
		
        assertNotNull (service.getObjException());
        
		context.setUserName("jt");
		context.setPassword("messaging");
		
		messenger.setContext(context);   
		reply = messenger.sendMessage (service, msg);
		
        assertNull (service.getObjException());
        
        // Invoke the Echo service. JtEchoComponent is started.
        
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.examples.EchoService");
		//service.setEncrypted(true); deprecated. use the messenger
		messenger.setEncrypted(true);
		msg = new JtMessage (JtObject.JtACTIVATE);
		reply = messenger.sendMessage (service, msg);
		
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname (null);
		service.setRemoteComponentId ("jtEchoComponent");
		messenger.setEncrypted(true);
		//service.setEncrypted(true);
		//msg = new JtMessage (JtObject.JtACTIVATE);
		reply = messenger.sendMessage (service, "hello there.");
		
		System.out.println(reply);

		assertEquals (reply, "hello there.");
		
		service.setUrl("http://localhost:8080/JtPortal/JtRestService");
		service.setClassname ("Jt.examples.DateService");

		// Asynchronous messaging
		
		messenger.setSynchronous(false);
		
		reply = messenger.sendMessage (service, "hello there.");
		assertEquals (reply, null);
		
	}

}
