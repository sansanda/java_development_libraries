package Jt.test;


import Jt.JtFactory;
import Jt.JtMessage;
import Jt.ejb.JtBusinessDelegate;
import Jt.ejb.JtEJBProxy;
import Jt.examples.HelloWorld;


import junit.framework.TestCase;

public class TestJtBusinessDelegate extends TestCase {

    JtFactory factory = new JtFactory ();
    

	// EJBs should be configured before running this test
	
	  public void testJtBusinessDelegate () {
			JtFactory factory = new JtFactory ();
			JtBusinessDelegate businessDelegate;
			String tmp;
			String reply = null;
			JtMessage msg;
			Exception ex;
			Boolean Bool;


			// Create an instance JtBusinessDelegate

			businessDelegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME);

			businessDelegate.setClassname(HelloWorld.JtCLASS_NAME);
	        //factory.setValue (businessDelegate, "logLevel", "0");
	        //factory.setValue (businessDelegate, "logging", "true");

	        // Initialize the JtBusinessDelegate component
	        
	        //Bool = (Boolean) factory.sendMessage(businessDelegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
	        //assertTrue (Bool);
	        
	        //if (!Bool.booleanValue()) {
	        	// Failed to initialized the JtBusinessDelegate component
	        	//System.err.println("Unable to initialize the business delegate ... exiting.");
	        	//System.exit(1);
	        //}
	        
	        // The JtBusinessDelegate component is ready to be used.
	        // Set an attribute value (remote component) via the
	        // local JtBusinessDelegate component.
			
	        factory.setValue (businessDelegate, "greetingMessage", "Hello there...");

	        tmp = (String) factory.getValue (businessDelegate, "greetingMessage");
		    assertEquals (tmp, "Hello there...");


	        System.out.println ("greetingMessage:" + tmp);

	        msg = new JtMessage (HelloWorld.JtHELLO);

	        // Send a message to the remote component

	        reply = (String) factory.sendMessage (businessDelegate, msg);  
		    assertEquals (reply, "Hello there...");

			ex = (Exception) factory.getValue (businessDelegate, "objException");    

			// Display the reply unless an exception is detected
            assertNull (ex);
            
			if (ex != null)
				System.out.println (reply);


			// Remove the business delegate

			factory.removeObject (businessDelegate);

	  }
}
