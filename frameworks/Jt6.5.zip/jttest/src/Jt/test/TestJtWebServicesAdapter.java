package Jt.test;

import java.util.ArrayList;
import java.util.Date;

import Jt.JtComponent;
import Jt.JtFactory;
import Jt.JtHashTable;
import Jt.JtList;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.JtProxy;
import Jt.axis.JtAxisProxy;
import Jt.examples.DateService;
import Jt.examples.HelloWorld;
import Jt.examples.JtHelloWorld;
import Jt.examples.Test;
import Jt.rest.JtRestService;
import Jt.util.JtComparator;

import junit.framework.TestCase;

public class TestJtWebServicesAdapter extends TestCase {

    JtFactory factory = new JtFactory ();
    

	// Rest services should be configured before running this test
	
	public void testAxisService() {
	    JtFactory factory = new JtFactory ();

	    //JtWebServicesAdapter adapter;
	    String reply = null;
	    Exception ex;
	    JtMessage msg;
	    JtAxisProxy proxy;
	    Integer I;
	    Test test = new Test ();
	    Test test1;
	    JtPrinter printer = new JtPrinter ();
	    ArrayList list = new ArrayList ();
	    JtComparator comparator = new JtComparator ();
	    Boolean Bool;
	    boolean bool;
	    String url = "http://localhost:8080/axis/services/JtAxisService";

	    
	    // Create a local proxy that references a remote component
	    
	    proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
	    
	    // Set the service url property (if it is not present in the resource file)
	    if (proxy.getUrl() == null)
	    	proxy.setUrl("http://localhost:8080/axis/services/JtAxisService");
	    proxy.setClassname(HelloWorld.JtCLASS_NAME);
	    

	    // Create a remote instance of the HelloWorld class. The Jt Web service adapter
	    // can be used to create remote objects. A local proxy is returned.
	    
	    //proxy = (JtProxy) factory.sendMessage (adapter, msg);
	    
	    
	    //Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));
	    
	    //assertTrue (Bool);
	    
	    //if (!Bool.booleanValue()) {
	    	// Failed to initialized the proxy
	    //	System.err.println("Unable to initialize the local proxy to the remote component.");
	    //	System.exit(1);
	    //}
	    

	    bool = factory.setValue (proxy, "greetingMessage", "Hello there...");
	    
	    assertEquals (bool, true);	    
	    
	    reply = (String) factory.getValue (proxy, "greetingMessage");
	    
	    assertEquals (reply, "Hello there...");
	    
	    
	    //factory.setValue (proxy, "logLevel", "0");
	    //factory.setValue (proxy, "logging", "true");

	    msg = new JtMessage (HelloWorld.JtHELLO);

	    // Send JtHello to the remote helloWorld object

	    reply = (String) factory.sendMessage (proxy, msg);

	    // Display the reply unless an exception is detected.
	    // The remote exception gets propagated from the
	    // remote object to the local proxy
	    

	    ex = (Exception) proxy.getObjException();

	    //if (ex == null)    
	    //  System.out.println (reply);

        assertNull (proxy.getObjException());
        //System.out.println("reply:" + reply);
        assertEquals (reply, "Hello there...");
        
        bool = factory.removeObject (proxy);
        
	    //assertEquals (bool, true);	 
	    
		proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
		
		proxy.setUrl(url);
		proxy.setClassname ("Jt.examples.EchoService");
			
		factory.setEncrypted(true);
		//messenger.setSynchronous(false);
		Bool = (Boolean) factory.sendMessage (proxy, new JtMessage (JtComponent.JtACTIVATE));

		System.out.println ("Reply:" + Bool);
		
		assertEquals (Bool, new Boolean (true));
				
		bool = factory.setValue(proxy, "greeting", "new message");
		//System.out.println ("boolean:" + bool);		
		
	    assertEquals (bool, true);	 
		
		reply = (String) factory.getValue(proxy, "greeting");
		//System.out.println ("greeting attribute:" + reply);	
		
		assertEquals (reply, "new message");
		
		bool = factory.removeObject(proxy);
		
	    //assertEquals (bool, true);	

		
		//System.out.println ("removeObject:" + bool);		
		//bool = factory.removeObject(proxy);
		
	    //assertEquals (bool, false);	
	    
	    //proxy = (JtAxisProxy) factory.createObject (JtAxisProxy.JtCLASS_NAME);
	    
	    //msg = new JtMessage (JtWebServicesAdapter.JtCREATE_PROXY);
	    //msg.setMsgContent(JtHashTable.JtCLASS_NAME);
	    //msg.setMsgData("helloWorld");
	    
	    // The following Test case requires remote access to Jt.JtHashtable
	    /*
	    proxy.setClassname(JtHashTable.JtCLASS_NAME);
	    
	    
	    Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));
	    
	    assertTrue (Bool);
	    
	    if (!Bool.booleanValue()) {
	    	// Failed to initialized the proxy
	    	System.err.println("Unable to initialize the local proxy to the remote component.");
	    	System.exit(1);
	    }
	    
	    //proxy = (JtAxisProxy) factory.sendMessage (adapter, msg);
	    
	    test.setComments("<comments>");
	    test.setStatus(1);
	    test.setLongField (1L);
	    test.setShortField ((short) 1);
	    test.setC ('<');
	    //test.setDate(date);
	    test.setDoubleField(1.0);
	    test.setFlag(true);
	    test.setFloatField((float) 1.0);
	    test.setByteField((byte) 1);
	    
        // Add an object to hashtable	    
        msg = new JtMessage (JtHashTable.JtPUT);
        msg.setMsgContent(test);
        msg.setMsgData(new Integer (1));                
        factory.sendMessage (proxy, msg); 
        
        // Add an object to hashtable	    
        msg = new JtMessage (JtHashTable.JtPUT);
        msg.setMsgContent(test);
        msg.setMsgData("one");                
        factory.sendMessage (proxy, msg); 
        
        msg = new JtMessage (JtHashTable.JtGET);
        msg.setMsgData(new Integer (1));
	    test1 = (Test) factory.sendMessage (proxy, msg);
	    
	    //System.out.println("Test:" + test1);
	    
	    //printer.processMessage(test1);
	    
	    
	    list.add (test);
	    list.add (test1);
	    
	    Bool = (Boolean) comparator.processMessage(list);
	    
	    //assertEquals (test, test1);
	    assertTrue (Bool);
	    */
	    //myService.removeObject ("helloWorld");
	    //factory.removeObject (proxy);
	    //factory.removeObject(adapter);


	}

}
