package Jt.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Jt.JtCollection;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtPrinter;
import Jt.JtRemoteException;
import Jt.examples.DateService;
import Jt.examples.HelloWorld;
import Jt.examples.JtHelloWorld;
import Jt.examples.Test;
import Jt.rest.JtRestService;
import Jt.util.JtComparator;
import Jt.xml.JtXMLHelper;

import junit.framework.TestCase;

public class TestJtXMLHelper extends TestCase {

    JtFactory factory = new JtFactory ();

    

	// Rest services should be configured before running this test
	
	public void testTest() {
		
		JtXMLHelper helper;
		Test test = new Test ();
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
		String xmlString;
		JtFactory factory = new JtFactory ();
		JtMessage msg1 = new JtMessage ();
		Test test1;
		JtComparator comparator = new JtComparator ();
		ArrayList list = new ArrayList ();
		Boolean Reply;
        String str = "Hello World ..";
        JtPrinter printer = new JtPrinter ();


	    helper = (JtXMLHelper) factory.createObject (JtXMLHelper.JtCLASS_NAME);

        test.setStatus(1);
        test.setComments("<my comments>");
        test.setByteField((byte) 1);
        //test.setDate(new Date ());
        test.setDoubleField(1.0);
        test.setFloatField( (float) 1.0);
        test.setShortField((short) 1);
        test.setLongField(1L);
        test.setFlag(true);
        test.setC('\t');
        //test.setByteArray(str.getBytes());
        
        msg.setMsgContent(test);
        xmlString = (String) factory.sendMessage(helper, msg);
        
        System.out.print (xmlString); 
        

        //msg.setMsgContent(test);
        //xmlString = (String) factory.sendMessage(helper, msg);
        

        //System.out.print (xmlString);

        msg1.setMsgId (JtObject.JtXML_DECODE);
        msg1.setMsgContent (xmlString);
        

        
        test1 = (Test) factory.sendMessage(helper, msg1);
        
   
        list.add(test);
        list.add(test1);
        
        Reply = (Boolean) factory.sendMessage(comparator, list);

        //System.out.println ("comparator:" + Reply);  
        
        //msg.setMsgContent(test1);       
        //xmlString = (String) factory.sendMessage(helper, msg);
        
        //System.out.print (xmlString);   
        
		//test1 = new Test ();
        //test1.setStatus(1);
        //test1.setComments("<&");
        //test1.setC('<');
        
        assertNotNull (Reply);
        assertTrue (Reply.booleanValue());
        //System.exit (1);
        //assertNotNull (test.getByteArray());
        //assertNotNull (test1.getByteArray());     
        
        //assertEquals (new String (test.getByteArray()), new String (test1.getByteArray()));
        
        System.out.println(xmlString);
        //assertSame (test, test1);
        //printer.processMessage(test);
	}
/*	
	public void testJtRemote() {
		
		JtXMLHelper helper;
		JtRemoteException jRemote = new JtRemoteException ("error");
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
		JtMessage msg1 = new JtMessage ();
        
		String xmlString;
		JtFactory factory = new JtFactory ();

		JtRemoteException jRemote1;
		JtComparator comparator = new JtComparator ();
		ArrayList list = new ArrayList ();
		Boolean Reply;


	    helper = (JtXMLHelper) factory.createObject (JtXMLHelper.JtCLASS_NAME);
        msg.setMsgContent(jRemote);
        
        xmlString = (String) factory.sendMessage(helper, msg);
        
        System.out.print (xmlString); 
        
        msg1.setMsgId (JtObject.JtXML_DECODE);
        msg1.setMsgContent (xmlString);
        
        jRemote1 = (JtRemoteException) factory.sendMessage(helper, msg1);
        
        
        assertNotNull (jRemote1);  
        
        list.add(jRemote);
        list.add(jRemote1);
        
        Reply = (Boolean) factory.sendMessage(comparator, list);
        
        assertNotNull (Reply);
        assertTrue (Reply.booleanValue());
        
	}
*/	
	
	public void testNull () {
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
        String xmlString;
        Object obj;
		
        msg.setMsgContent(null);
        xmlString = (String) factory.sendMessage(new JtXMLHelper () , msg);
        
        //System.out.print (xmlString); 
 
        msg = new JtMessage (JtObject.JtXML_DECODE);      
        msg.setMsgContent(xmlString);
        obj =  factory.sendMessage(new JtXMLHelper () , msg);

        assertNull (obj);
	}
	
	public void testString () {
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
        String xmlString;
        Object obj;
        String str1;
		
        msg.setMsgContent("<Welcome to Jt messaging ...>");
        xmlString = (String) factory.sendMessage(new JtXMLHelper () , msg);
        
        //System.out.print (xmlString); 
 
        msg = new JtMessage (JtObject.JtXML_DECODE);      
        msg.setMsgContent(xmlString);
        str1 =  (String) factory.sendMessage(new JtXMLHelper () , msg);

        assertEquals ("<Welcome to Jt messaging ...>", str1);
	}
	
	public void testDate () {
        JtMessage msg = new JtMessage (JtObject.JtXML_ENCODE);
        String xmlString;
        Date date1;
        Date date = new Date ();
		
        msg.setMsgContent(date);
        xmlString = (String) factory.sendMessage(new JtXMLHelper () , msg);
        
        //System.out.print (xmlString); 
 
        msg = new JtMessage (JtObject.JtXML_DECODE);      
        msg.setMsgContent(xmlString);
        date1 =  (Date) factory.sendMessage(new JtXMLHelper () , msg);

        assertEquals (date, date1);
	}
	
	public void testJtCollection() {
        JtMessage msg1 = new JtMessage (JtObject.JtXML_ENCODE);
        JtMessage msg;
        JtCollection collection, collection1;
        String xmlString;
        String xmlString1;
        
        collection = (JtCollection) factory.createObject (JtCollection.JtCLASS_NAME);

        msg = new JtMessage (JtCollection.JtADD);  

        // Add objects to the collection

        msg.setMsgContent (new Integer(1));
        factory.sendMessage (collection, msg);

        msg.setMsgContent (new Integer(2));       
        factory.sendMessage (collection, msg);
        
        msg1.setMsgContent(collection);
        xmlString = (String) factory.sendMessage(new JtXMLHelper () , msg1);
        
        //System.out.print (xmlString); 
        msg = new JtMessage (JtObject.JtXML_DECODE);
        msg.setMsgContent(xmlString);
        
        collection1 = (JtCollection) factory.sendMessage(new JtXMLHelper () , msg);

        msg = new JtMessage (JtObject.JtXML_ENCODE);
        msg.setMsgContent(collection1);   
        
        xmlString1 = (String) factory.sendMessage(new JtXMLHelper () , msg);
        
        assertEquals (xmlString, xmlString1);

	}

}
