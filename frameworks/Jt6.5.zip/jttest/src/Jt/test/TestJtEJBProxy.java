package Jt.test;


import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtProxy;
import Jt.ejb.JtEJBProxy;
import Jt.examples.HelloWorld;


import junit.framework.TestCase;

public class TestJtEJBProxy extends TestCase {

    JtFactory factory = new JtFactory ();
    

	// EJBs should be configured before running this test
	
	  public void testEJBProxy () {

	      JtFactory factory = new JtFactory ();
	      String reply, tmp;
	      Exception ex;
	      JtMessage msg;
	      JtEJBProxy proxy;
	      Boolean Bool;


	      // Create an EJB proxy. This local proxy
	      // will reference the remote component

	      proxy = (JtEJBProxy) factory.createObject (JtEJBProxy.JtCLASS_NAME);
	      
	      proxy.setClassname(HelloWorld.JtCLASS_NAME);
	      //factory.setValue (proxy, "logLevel", "0");
	      //factory.setValue (proxy, "logging", "true");
	      
	      // Initialize the Proxy
	      
	      //Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));
		  //assertTrue (Bool);
		    
	      //if (!Bool.booleanValue()) {
	      	// Failed to initialized the proxy
	      //	System.err.println("Unable to initialize the local proxy to the remote component.");
	      //	System.exit(1);
	      //}
	      
	      // The local proxy is ready to be used.
	      // Set an attribute value (remote component) via the
	      // local proxy.
	      
	      factory.setValue (proxy, "greetingMessage", "Hello there...");

	      tmp = (String) factory.getValue (proxy, "greetingMessage");

	      System.out.println ("greetingMessage:" + tmp);
	      
	      assertEquals (tmp, "Hello there...");

	      msg = new JtMessage (HelloWorld.JtHELLO);

	      // Send JtHello to the remote component

	      reply = (String) factory.sendMessage (proxy, msg);    
	      
	      assertEquals (tmp, "Hello there...");

	      // Retrieve any exceptions that might have occurred.
	      // Exceptions are propagated automatically by the framework.

	      ex = (Exception) proxy.getObjException();
	      
	      assertNull (ex);

	      // Display the reply unless an exception is detected

	      if (ex == null)    
	          System.out.println (reply);

	      // Remove the EJB proxy (cleanup)

	      factory.removeObject (proxy);

	  }
}
