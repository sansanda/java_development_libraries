package Jt.test;

import java.util.Date;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.examples.HelloWorld;
import Jt.examples.Test;
import junit.framework.TestCase;

public class TestJtObject extends TestCase {

    JtFactory factory = new JtFactory ();
	private float delta = (float) 0.001;
    
	public void testHelloWorld () {
		String reply;
		HelloWorld helloWorld = new HelloWorld ();
		
		helloWorld.setGreetingMessage("Hello World ...");
		reply = (String) factory.sendMessage(helloWorld, 
				new JtMessage (HelloWorld.JtHELLO));

		assertEquals (reply, "Hello World ...");
	}
	
	public void testCreateObject () {
		JtObject obj;
		boolean bool;
		
        obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "myname");

        assertNotNull (obj);
        
        if (obj == null)
        	return;
        
        assertEquals (obj.toString(), "myname");
        
        bool = factory.removeObject("myname");

        assertTrue (bool);
        
        bool = factory.removeObject("myname");
        
        assertFalse (bool);
	}
	
	public void testUseRegistry () {
		JtObject obj;
		JtFactory factory = new JtFactory ();
		
		factory.setUseRegistry(false); // Do not use the component registry
		
        obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "myname");

        assertNotNull (obj);                
        
        if (obj == null)
        	return;
        
        obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "myname");

        assertNotNull (obj);
        
        if (obj == null)
        	return;
        
        assertEquals (obj.toString(), "myname");
        
		factory.setUseRegistry(true);
		
        obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "myComponent");  
        
        assertNotNull (obj);
        
        obj = (JtObject) factory.createObject (JtObject.JtCLASS_NAME, "myComponent"); 
        
        assertNull (obj);
        //factory.removeObject("myname");

	}
	
	public void testSetValue () {
		HelloWorld helloWorld;
		Test testObject = new Test ();
		//float delta = (float) 0.001;
		Date date = new Date ();
		
		helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME);

        assertNotNull (helloWorld);
        
        if (helloWorld == null)
        	return;
        
        helloWorld.setGreetingMessage("");
        
        factory.setValue(helloWorld, "greetingMessage", "Welcome to Jt messaging!");
        assertEquals (helloWorld.getGreetingMessage(), "Welcome to Jt messaging!");

        helloWorld.setGreetingMessage("");
        factory.setValue(helloWorld, "greetingMessage", "Welcome to Jt messaging!");
        assertEquals (helloWorld.getGreetingMessage(), "Welcome to Jt messaging!");
	
        factory.setValue(testObject, "status", "1");
        assertEquals (testObject.getStatus(),1);
        
        factory.setValue(testObject, "longField", "1");
        assertEquals (testObject.getLongField(),1L);
        
        factory.setValue(testObject, "shortField", "1");
        assertEquals (testObject.getShortField(),1);
        
        factory.setValue(testObject, "byteField", "1");
        assertEquals (testObject.getByteField(),1);
        
        factory.setValue(testObject, "floatField", "1.0");
        //System.out.println(testObject.getFloatField());
        assertEquals (testObject.getFloatField(),1.0, delta);
        
        factory.setValue(testObject, "doubleField", "1.0");
        //System.out.println(testObject.getDoubleField());
        assertEquals (testObject.getDoubleField(),1.0, (double) delta);
        
        factory.setValue(testObject, "flag", "true");
        assertEquals (testObject.isFlag(),true); 
        
        factory.setValue(testObject, "flag", "false");
        assertEquals (testObject.isFlag(),false); 
        
        factory.setValue(testObject, "date", date);
        assertEquals (testObject.getDate(),date); 
        
        factory.setValue(testObject, "date", "01/01/09");
        //System.out.println(testObject.getDate());
        //assertEquals (testObject.getDate(),date); 
        
        factory.setValue(testObject, "c", "c");
        //System.out.println(testObject.getC ());
        assertEquals (testObject.getC(),'c'); 
	}
	
	public void testGetValue () {
		HelloWorld helloWorld;
		String greetings;
		Test testObject = new Test ();
		Integer I;
		Float Fl;
		Double Db;
		Boolean B;
		Character Char;
		
		helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME, "helloWorld");

        assertNotNull (helloWorld);
        
        if (helloWorld == null)
        	return;
        
        helloWorld.setGreetingMessage("Welcome to Jt messaging!");
        
        greetings = (String) factory.getValue(helloWorld, "greetingMessage");
        assertEquals (greetings, "Welcome to Jt messaging!");
		//assertTrue (false);
        
        helloWorld.setGreetingMessage("Welcome to Jt messaging!");
        
        greetings = (String) factory.getValue("helloWorld", "greetingMessage");
        assertEquals (greetings, "Welcome to Jt messaging!");
        
		testObject.setStatus(1);
		
        assertEquals (factory.getValue(testObject, "status"), new Integer (1));
		
        testObject.setLongField(1L);
        
        assertEquals (factory.getValue(testObject, "longField"), new Long (1));
       
        testObject.setShortField((short) 1);
        
        assertEquals (factory.getValue(testObject, "shortField"), new Short ((short) 1));
       
        testObject.setByteField((byte) 1);
        
        assertEquals (factory.getValue(testObject, "byteField"), new Byte ((byte) 1));
 
        testObject.setFloatField((float) 1.0);
        
        Fl = (Float) factory.getValue(testObject, "floatField");
        assertEquals (Fl.floatValue(), 1.0, delta);

        testObject.setDoubleField((double) 1.0);
        
        Db =  (Double) factory.getValue(testObject, "doubleField");

        assertEquals (Db.doubleValue(), (double) 1.0, (double) delta);       
        //        factory.setValue(testObject, "doubleField", "1.0");
             
        
        testObject.setFlag(true);
        
        B = (Boolean) factory.getValue(testObject, "flag");
                
        assertEquals (B.booleanValue(),true); 
	
        testObject.setC('c');
        
        Char = (Character) factory.getValue(testObject, "c");
        
        assertEquals (Char.charValue(),'c'); 
        
        factory.removeObject("helloWorld");
	}
	
	public void testSendMessage () {
		HelloWorld helloWorld;
		String greeting;
		JtMessage msg = new JtMessage (HelloWorld.JtHELLO);
		
		helloWorld = (HelloWorld) factory.createObject (HelloWorld.JtCLASS_NAME, "helloWorld");

        assertNotNull (helloWorld);
        
        if (helloWorld == null)
        	return;
        
        helloWorld.setGreetingMessage("Welcome to Jt messaging!");
        greeting = (String) factory.sendMessage(helloWorld, msg);
        
        assertEquals (greeting, "Welcome to Jt messaging!");
		//assertTrue (false);
        
        greeting = (String) factory.sendMessage("helloWorld", msg);
        
        assertEquals (greeting, "Welcome to Jt messaging!");
        
        
        greeting = (String) helloWorld.processMessage(msg);
        
        assertEquals (greeting, "Welcome to Jt messaging!");

        factory.removeObject("helloWorld");
	}
	
	


}
