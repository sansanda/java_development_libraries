package Jt.test;


import java.util.Date;

import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtObject;
import Jt.JtProxy;
import Jt.ejb.JtBusinessDelegate;
import Jt.ejb.JtEJBProxy;
//import Jt.examples.HelloWorld;
import Jt.examples.Member;


import junit.framework.TestCase;

public class TestValueObject extends TestCase {

    JtFactory factory = new JtFactory ();
    

	// EJBs should be configured before running this test
	
	  public void testValueObject () {

		  JtFactory factory = new JtFactory ();
		    JtBusinessDelegate delegate;
		    Member valueObject;
		    //JtMessage msg;
		    Boolean Bool;
		    Date date = new Date ();
		    
		    // Create an instance of JtBusinessDelegate (Jt implementation of
		    // the J2EE business delegate pattern)

		    delegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME, 
		     "businessDelegate");
		    delegate.setClassname (Member.JtCLASS_NAME);

		    // The JtBusinessDelegate component is ready to be used.
		    // Set an attribute value (remote component) via the
		    // local JtBusinessDelegate component.
		      
		    //Bool = (Boolean) factory.sendMessage(delegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
		    
		    //assertTrue (Bool);
		    
		    //if (!Bool.booleanValue()) {
		    	// Failed to initialized the JtBusinessDelegate component
		    //	System.err.println("Unable to initialize the business delegate ... exiting.");
		    //	System.exit(1);
		    //}
		    
		    // The JtBusinessDelegate component is ready to be used.
		    // Set an attribute value (remote component) via the
		    // local JtBusinessDelegate component.
		    
		    factory.setValue (delegate, "email", "test@hotmail.com");
		    factory.setValue (delegate, "tstamp", date);
		    factory.setValue (delegate, "status", "1");
		    factory.setValue (delegate, "firstname", "John");
		    factory.setValue (delegate, "lastname", "Doe");

		    // This single request returns the Value Object

		    valueObject = (Member) factory.sendMessage (delegate, new JtMessage (JtObject.JtVALUE_OBJECT));
		    
            assertNotNull (valueObject);
		    
		    // Print the attribute values using the local instance of the Value Object
		    // This is much faster and efficient.
		    
		    System.out.println ("Email =" + valueObject.getEmail());  
		    System.out.println ("Tstamp =" + valueObject.getTstamp());
		    System.out.println ("Status =" + valueObject.getStatus());   
		    System.out.println ("First Name =" + valueObject.getFirstname());     
		    System.out.println ("Last Name =" + valueObject.getLastname());    
		    
		    assertEquals (valueObject.getEmail(), "test@hotmail.com");
		    assertEquals (valueObject.getFirstname(), "John");
		    assertEquals (valueObject.getLastname(), "Doe");
		    assertEquals (valueObject.getTstamp(), date);
		    assertEquals (valueObject.getStatus(), 1);		    
		       
		    // Remove the business delegate. The remote instance is also removed.
		    
		    factory.removeObject(delegate);


	  }
}
