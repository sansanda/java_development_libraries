package Jt.test;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for Jt.test");
		//$JUnit-BEGIN$
		suite.addTestSuite(TestJtRestService.class);
		suite.addTestSuite(TestJtXMLHelper.class);
		suite.addTestSuite(TestJtObject.class);
		suite.addTestSuite(TestJtWebServicesAdapter.class);
		//$JUnit-END$
		return suite;
	}

}
