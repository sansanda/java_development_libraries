package Jt.ejb.examples.bmp;


import java.util.*;
import Jt.*;

/**
 * Local interface for Member.
 */
public interface MemberLocal
   extends javax.ejb.EJBLocalObject
{

   public JtValueObject getValueObject ();

   public void setValueObject (JtValueObject valueObject);

   public String getEmail();

   public void setEmail (String email);

   public void setEmail_flag (int newEmail_flag);

   public int getEmail_flag ();

   public int getStatus ();

   public void setStatus (int newStatus);

   public String getSubject();

   public void setSubject (String newSubject);

   public String getComments();

   public void setComments (String newComments);

   public void setFirstname (String newFirstname);

   public String getFirstname();

   public void setLastname (String newLastname);

   public String getLastname();

   public void setTstamp (Date tstamp);

   public Date getTstamp ();

   public void setMdate (Date mdate);

   public Date getMdate ();

   public String getLocation();

   public void setLocation (String location);
   
   public boolean getDirty();

   public void setDirty (boolean dirty);

}
