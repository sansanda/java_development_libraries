
package Jt.ejb.examples.bmp;

//import java.rmi.RemoteException;

/**
 * Local Home interface for Member.
 */
public interface MemberLocalHome
   extends javax.ejb.EJBLocalHome
{

   MemberLocal create(String email, String firstName, String lastName)
      throws javax.ejb.CreateException;

   MemberLocal findByPrimaryKey (String primaryKey) throws 
      javax.ejb.FinderException;

}
