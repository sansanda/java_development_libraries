package Jt.apps;

import Jt.*;
import Jt.jndi.*;
import Jt.ejb.examples.bmp.*;


//Example of a remote component that implements business logic.
//Interfaces with an Entity Bean via its Local Home
//interface.

public class RemoteBusinessObject extends JtObject {

    private static final long serialVersionUID = 1L;
    private transient JtJNDIAdapter jndiAdapter = null;
    private transient MemberLocalHome memberLocalHome = null;
    private boolean realized = false;
    private transient MemberLocal memberLocal = null; 
    private String firstname, lastname;
    public static final String FIND = "FIND"; 
    public static final String MODIFY = "MODIFY";   
    public static final String DELETE = "DELETE";
    public static final String DISABLE = "DISABLE";
    public static final String CREATE = "CREATE";

    public void setFirstname (String newFirstname) {
        firstname = newFirstname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setLastname (String newLastname) {
        lastname = newLastname;
    }

    public String getLastname() {
        return lastname;
    }

    /**
     * Process object messages.
     */

    public Object processMessage (Object event) {

        String msgid = null;
        JtMessage e = (JtMessage) event;
        String content;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        content = (String) e.getMsgContent(); // email (table key)

        // Reset the object exception after each
        // operation.
        
        this.setObjException(null);
        
        if (msgid.equals (RemoteBusinessObject.DISABLE)) {
            if (!realized) { 
                realized = true;
                realizeObject ();
            }
            disable (content);
            return (null);
        }


        if (msgid.equals (RemoteBusinessObject.DELETE)) {
            if (!realized) { 
                realized = true;
                realizeObject ();
            }

            return (delete (content));
        }

        if (msgid.equals (RemoteBusinessObject.CREATE)) {
            if (!realized) { 
                realized = true;
                realizeObject ();
            }

            return (create (content, firstname, lastname));
        }

        if (msgid.equals (RemoteBusinessObject.FIND)) {
            if (!realized) { 
                realized = true;
                realizeObject ();
            }         
            return (find (content));
        }

        if (msgid.equals (RemoteBusinessObject.MODIFY)) {
            if (!realized) { 
                realized = true;
                realizeObject ();
            }

            return (modify (e));
        }

        //return (super.processMessage (event));
        handleError ("processMessage: invalid message id:" + msgid);
        return (null);

    }


    private void realizeObject() {

        JtFactory factory = new JtFactory ();   
        JtMessage msg = new JtMessage (JtJNDIAdapter.JtLOOKUP); 

        jndiAdapter = (JtJNDIAdapter) factory.createObject (JtJNDIAdapter.JtCLASS_NAME);

        msg.setMsgContent ("LocalBMPEntityExample");

        memberLocalHome = (MemberLocalHome) factory.sendMessage (jndiAdapter, msg);
        //System.out.println ("memberLocalHome:" + memberLocalHome);

    }

    private void disable (String email) {


        if (find (email) == null) {
            return;
        }
        memberLocal.setStatus (-1);
        memberLocal.setDirty(true);

        return;

    }



    private String create (String email, String firstname, String lastname) {

        String reply = null;

        if (memberLocalHome == null) {
            handleError ("Local Home Interface is null");
            return (null);
        }

        memberLocal = null;  

        try {

            memberLocal = memberLocalHome.create (email, firstname, lastname);


            if (memberLocal == null)
                return (null);

            reply = "OK";
        } catch (Exception ex) {
            handleException (ex);      
        }
        return (reply);

    }


    private String delete (String email) {

        String reply = null;


        if (memberLocalHome == null) {
            handleError ("Local Home Interface is null");
            return (null);
        }

        memberLocal = null;  

        try {

            memberLocal = memberLocalHome.findByPrimaryKey (email);

            if (memberLocal != null)
                memberLocal.remove ();

            reply = "OK";
        } catch (Exception ex) {
            handleException (ex);      
        }
        return (reply);

    }

    public void modifyEJB (JtValueObject valueObject) {

        JtMessage msg;
        String tmp;
        //Object out;
        Integer I;

        //this.valueObject = valueObject;

        if (valueObject == null)
            return;


        msg = new JtMessage (JtValueObject.JtGET);
        msg.setMsgData ("firstname");

        tmp = (String) valueObject.processMessage (msg);

        if (tmp != null)
            memberLocal.setFirstname (tmp);

        msg.setMsgData ("lastname");
        tmp = (String) valueObject.processMessage (msg);

        if (tmp != null)
            setLastname (tmp);


        msg.setMsgData ("location");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            memberLocal.setLocation (tmp);


        msg.setMsgData ("comments");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            memberLocal.setComments (tmp);

        msg.setMsgData ("subject");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            memberLocal.setSubject (tmp);


        msg.setMsgData ("status");
        I = (Integer) valueObject.processMessage (msg);
        if (I != null)
            memberLocal.setStatus(I.intValue());


        msg.setMsgData ("email_flag");
        I = (Integer) valueObject.processMessage (msg);
        if (I != null)
            memberLocal.setEmail_flag(I.intValue());

        memberLocal.setDirty(true);
    }

    private String modify (JtMessage imsg) {

        String reply = null;
        String email;
        JtValueObject valueObject;

        if (imsg == null)
            return (null);

        email = (String) imsg.getMsgContent ();
        valueObject = (JtValueObject) imsg.getMsgData ();        

        if (email == null || valueObject == null)
            return (null);

        if (memberLocalHome == null) {
            handleError ("Local Home Interface is null");
            return (null);
        }

        memberLocal = null;  


        try {

            memberLocal = memberLocalHome.findByPrimaryKey (email);

            if (memberLocal == null)
                return (null);

            //memberLocal.setValueObject (valueObject);
            modifyEJB (valueObject);
            reply = "OK";
        } catch (Exception ex) {
            handleException (ex);      
        }
        return (reply);

    }

    private JtValueObject find (String email) {

        JtValueObject member = null;


        if (memberLocalHome == null) {
            handleError ("find: Local Home Interface is null");
            return (null);
        }

        memberLocal = null;  

        try {

            memberLocal = memberLocalHome.findByPrimaryKey (email);


            if (memberLocal == null) {
                handleError ("find: findByPrimaryKey failed");
                return (null);
            }

            member = (JtValueObject) memberLocal.getValueObject ();


        } catch (javax.ejb.FinderException fe) {

            // this exception is expected.
            //handleException (fe);  
            
        } catch (Exception ex) {
            handleException (ex);      
        } 
        return (member);

    }

}



