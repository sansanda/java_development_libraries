

package Jt.ejb;


/**
 * Remote interface for JtSessionFacade.
 */


public interface JtSessionFacade
   extends javax.ejb.EJBObject
{



   /**
    * Process a message
    */

   public java.lang.Object processMessage(java.lang.Object message )
      throws Jt.JtException, java.rmi.RemoteException;

   
 
}
