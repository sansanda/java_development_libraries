
package Jt.ejb;

import Jt.*;
import Jt.examples.HelloWorldMessage;


/**
 * Jt implementation of the J2EE Business Delegate pattern. 
 */ 

public class JtBusinessDelegate extends JtEJBProxy  {

	public static final String JtCLASS_NAME = JtBusinessDelegate.class.getName(); 
	private static final long serialVersionUID = 1L;
    //public static final String JtINITIALIZE_DELEGATE = "JtINITIALIZE_DELEGATE";   


	public JtBusinessDelegate () {
	}



	/**
	 * Process object messages.
	 * @param event message
	 */

	/*
	public Object processMessage (Object message) {

		String msgid = null;
		JtMessage e;

		if (message == null)
			return null;

		if (message instanceof JtMessage) {
			e = (JtMessage) message;
						
			msgid = (String) e.getMsgId ();

			if (msgid == null)
				return null;

			// Initialize the business delegate
			if (msgid.equals(JtBusinessDelegate.JtINITIALIZE_DELEGATE)) {
				return (super.processMessage (new JtMessage (JtProxy.JtINITIALIZE_PROXY)));			
			}
		}
		// Let the superclass (JtProxy) do most of the work

		return (super.processMessage (message));

	}
    */


	/**
	 * Demonstrates all the messages processed by JtBusinessDelegate. 
	 */

	public static void main(String[] args) {

		JtFactory factory = new JtFactory ();
		JtBusinessDelegate businessDelegate;
		String tmp;
		String reply = null;
		//JtMessage msg;
		Exception ex;
		//Boolean Bool;


		// Create an instance of JtBusinessDelegate

		businessDelegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME);

		businessDelegate.setClassname(HelloWorldMessage.JtCLASS_NAME);
        //factory.setValue (businessDelegate, "logLevel", "0");
        //factory.setValue (businessDelegate, "logging", "true");

        // Initialize the JtBusinessDelegate component
        
        //Bool = (Boolean) factory.sendMessage(businessDelegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
        
        //if (!Bool.booleanValue()) {
        	// Failed to initialized the JtBusinessDelegate component
        //	System.err.println("Unable to initialize the business delegate ... exiting.");
        //	System.exit(1);
        //}
        
        // The JtBusinessDelegate component is ready to be used.
        // Set an attribute value (remote component) via the
        // local JtBusinessDelegate component.
		
        factory.setValue (businessDelegate, "greetingMessage", "Hello there....");

        tmp = (String) factory.getValue (businessDelegate, "greetingMessage");

        System.out.println ("greetingMessage:" + tmp);

        //msg = new JtMessage (HelloWorld.JtHELLO);

        // Send a message to the remote component

        reply = (String) factory.sendMessage (businessDelegate, "hi");  

		ex = (Exception) factory.getValue (businessDelegate, "objException");    

		// Display the reply 
		
		//if (ex != null)
		System.out.println ("reply:" + reply);


		// Remove the business delegate

		factory.removeObject (businessDelegate);

	}

}


