
package Jt.ejb;


//import javax.ejb.*;
//import javax.naming.*;
//import java.rmi.*;
//import java.beans.*;
//import java.io.*;
//import java.util.*;
//import java.util.Hashtable;

import Jt.*;
import Jt.examples.HelloWorld;



/**
 * Jt EJB Adapter. 
 */ 

public class JtEJBAdapter extends JtAdapter  {

    public static final String JtCLASS_NAME = JtEJBAdapter.class.getName(); 
    public static final String JtCREATE_PROXY = "JtCREATE_PROXY";   
    private static final long serialVersionUID = 1L;
    private transient JtSessionFacadeHome dhome = null;
    private transient JtSessionFacade sejb = null;



    public JtEJBAdapter () {
    }



    private void getEJBHandle () {

        if (sejb == null) {

            dhome = locateJtService ();
            if (dhome == null)
                return;
            try {
                sejb = dhome.create();
            } catch (Exception ex) {
                handleException (ex);
            }
        } 
    }

    
     // Intialialize the Jt EJB

    private void initializeEJB () {


        if (sejb == null)
            getEJBHandle ();    

        if (sejb == null)
            return;

        return;


    }

   
    
    /**
     * Invokes the service locator
     */

    private JtSessionFacadeHome locateJtService () {
    	JtSessionFacadeHome jtservice;
        JtServiceLocator locator;
        JtFactory factory;

        factory = new JtFactory ();

        // Create ServiceLocator

        locator = (JtServiceLocator) factory.createObject (JtServiceLocator.JtCLASS_NAME);


        // Activate Service Locator

        jtservice = (JtSessionFacadeHome) factory.sendMessage (locator, new JtMessage (JtObject.JtACTIVATE));
        factory.removeObject (locator);
        return (jtservice);
    }

 

    private Object sendRemoteMessage (Object message) {

        Object output = null;


        if (message == null) {
            handleError ("JtEJBAdapter.sendRemoteMessage: invalid message (null)");
            return (null);
        }

        handleTrace ("JtEJBAdapter.sendRemoteMessage:" + message);


        // Reset the object exception
        setObjException (null);

        if (sejb == null)
            initializeEJB ();
        if (sejb == null)
            return (null);
        try { 
            //output = sejb.sendMessage (null, null, message); 
        	output = sejb.processMessage (message);

        } catch (Exception ex) {
        	
            //handleException (ex);
        	
        	handleError ("Remote exception detected");

        	if (ex instanceof JtRemoteException)
        		handleWarning ("<Remote Exception>\n" + 
        				((JtRemoteException) ex).getTrace () + "</Remote Exception>\n"); 

        	return (null);
            
        }    

        return (output);

    } 



    /**
     * Process object messages.
     * <ul>
     * </ul>
     * @param event message
     */

    public Object processMessage (Object event) {


    	if (event == null)
    		return (null);
    	this.setObjException(null);
        return (sendRemoteMessage (event));

    }


}


