
package Jt.ejb.examples.bmp;

/**
 * Home interface for Member.
 */
public interface MemberHome
   extends javax.ejb.EJBHome
{
   //public static final String COMP_NAME="java:comp/env/ejb/JtStateful";
   //public static final String JNDI_NAME="JtStateful";

   Member create(String email, String firstName, String lastName)
      throws javax.ejb.CreateException, java.rmi.RemoteException;

   public Member findByPrimaryKey (String primaryKey) throws 
      javax.ejb.FinderException, java.rmi.RemoteException;

}
