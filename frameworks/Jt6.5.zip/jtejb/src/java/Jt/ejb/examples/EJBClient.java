package Jt.ejb.examples;

import Jt.*;
import Jt.ejb.*;


//This class demonstrates the use of most J2EE design patterns.
//It also uses an Entity bean (cmp) and the Jt DAO pattern.
//A Jt remote business object is used to interface with the entity bean (local
//home interfaces). The application itself manipulates a set of customer records. 
//The usual operations are demonstrated: find, create, modify, delete, etc.

public class EJBClient extends JtObject {


    //private JtBusinessDelegate businessDelegate;
    private JtKeyboard keyboard;
    private static final long serialVersionUID = 1L;
    public static final String JtCLASS_NAME = EJBClient.class.getName(); 
    public static final String FIND = "FIND"; 
    public static final String MODIFY = "MODIFY";   
    public static final String DELETE = "DELETE";
    public static final String DISABLE = "DISABLE";
    public static final String CREATE = "CREATE";
    
    private JtEJBProxy proxy;
    private JtFactory factory = new JtFactory ();

    private Object findMember (String email) {

        JtMessage msg = new JtMessage (EJBClient.FIND);

        if (proxy == null) {
            handleError ("findMember: proxy is null");
            return (null);
        }

        //adapter = (JtEJBAdapter) factory.createObject (JtEJBAdapter.JtCLASS_NAME);

        msg.setMsgContent (email);  

        return (factory.sendMessage (proxy, msg));
        //return (businessDelegate.sendMessage ("remoteBusinessObject", msg));


    }


    public Object processMessage (Object message) {

        String msgid = null;
        JtMessage e = (JtMessage) message;
        //Object content;
        //Object data;


        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();
        //data = e.getMsgData ();

        // Remove this object
        if (msgid.equals (JtObject.JtREMOVE)) {
            return (null);     
        }

        if (msgid.equals (JtObject.JtACTIVATE)) {
            test ();
            return (null);     
        }

        return (super.processMessage(message));
        //handleError ("processMessage: invalid message id:" + msgid);
        //return (null);

    }



    private void modifyMember (String email, JtValueObject valueObject) {
        JtIterator jit;
        String str;
        JtValueObject outValueObject = null;
        Object value;
        String input;
        String svalue = null;
        JtMessage msg;
        int num;

        if (email == null || valueObject == null)
            return;

        jit = (JtIterator) factory.sendMessage (valueObject, new JtMessage (JtValueObject.JtGET_KEYS));

        if (jit == null)
            return;

        System.out.println  
        ("Please enter a new value or press <enter> to leave the current value ...");

        for (;;) {
            str = (String) jit.processMessage (new JtMessage (JtIterator.JtNEXT));
            if (str == null)
                break;

            msg = new JtMessage (JtHashTable.JtGET);
            msg.setMsgData (str);
            value = valueObject.processMessage (msg);       
            //value = getValue (valueObject, str);

            //if (value instanceof java.sql.Date)
            //  continue;

            if (str.equals ("email") || str.equals ("mdate") || str.equals ("tstamp")
                    || str.equals ("dirty"))
                continue;

            System.out.print (str + "(" + value + "):");

            input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

            if (input == null)
                continue;

            input = input.trim ();
            if (input.equals (""))
                continue;
            if (value == null)
                svalue = null;
            else
                svalue = value.toString ();


            if (input.equals (svalue))
                continue;

            if (outValueObject == null)
                outValueObject = new JtValueObject ();     

            msg = new JtMessage (JtHashTable.JtPUT); 
            msg.setMsgData (str);
                        
            
            if (str.equals ("status") || str.equals ("email_flag")) {
                try {
                    num = Integer.parseInt(input);
                } catch (Exception ex) {
                    System.err.print("Invalid number:" + input);
                    return;
                }
                msg.setMsgContent (new Integer (num));
            } else    
                msg.setMsgContent (input);    
            outValueObject.processMessage (msg);

        }   


        if (outValueObject == null)
            return;

        msg = new JtMessage (EJBClient.MODIFY);
        msg.setMsgContent (email);
        msg.setMsgData (outValueObject);


        factory.sendMessage (proxy, msg);

    }


    // Test program

    public static void main(String[] args) {
        JtFactory factory = new JtFactory ();  // Jt Factory

        EJBClient main;


        main = (EJBClient) factory.createObject (EJBClient.JtCLASS_NAME, 
        "EJBClient");

        factory.sendMessage (main, new JtMessage (JtObject.JtACTIVATE));   

    }


    private void test () {

        //JtFactory factory = new JtFactory ();  // Jt Factory
        String reply;
        JtMessage msg, msg1;
        JtValueObject member;
        String input, email, firstName = null, lastName = null;
        JtValueObject valueObject = new JtValueObject ();
        Boolean Bool;
        


        keyboard = (JtKeyboard) factory.createObject (JtKeyboard.JtCLASS_NAME);


        //factory.setValue (proxy, "logLevel", "0");
        //factory.setValue (proxy, "logging", "true");
        
        
        // Create an EJB proxy. This local proxy
        // will reference the remote component
        
        proxy = (JtEJBProxy) factory.createObject (JtEJBProxy.JtCLASS_NAME);
        
        proxy.setClassname("Jt.apps.RemoteBusinessObject");
        
        // Initialize the Proxy
        
        //Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));
        
        //if (!Bool.booleanValue()) {
        	// Failed to initialized the proxy
        //	System.err.println("Unable to initialize the local proxy to the remote component.");
        //	System.exit(1);
        //}
        
        // The local proxy is ready to be used.
        // Set an attribute value (remote component) via the
        // local proxy.        

        //factory.setValue (proxy, "logLevel", "0");
        //factory.setValue (proxy, "logging", "true");
               
        for (;;) {
            
            //System.out.println("logLevel:" + factory.getValue (proxy, "logLevel"));
            //System.out.println("logging:" + factory.getValue (proxy, "logging"));
            //System.out.println("logFile:" + factory.getValue (proxy, "logFile"));

            System.out.println  ("Please  select an operation ...");
            System.out.println  ("1. Find ...");
            System.out.println  ("2. Create ...");
            System.out.println  ("3. Modify ...");
            System.out.println  ("4. Delete ...");
            System.out.println  ("5. Disable ...");
            System.out.println  ("6. Exit ...");



            input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));


            if (input == null)
                continue;

            input = input.trim ();

            if (input.equals ("1")) {

                System.out.println  ("Please enter an email address ...");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));
                //msg = new JtMessage (EJBClient.FIND);

                if (input == null)
                    continue;

                input = input.trim ();

                if (input.equals (""))
                    continue;

                //msg.setMsgContent (input);
                member = (JtValueObject) findMember (input);
                //member = (JtValueObject) businessDelegate.sendMessage ("remoteBusinessObject", msg);

                if (member == null) {
                    System.out.println ("Record not found:" + input);
                    continue;
                }


                //msg = new JtMessage ("JtENCODE_OBJECT");
                //msg.setMsgContent (member);

                // Print the content of the ValueObject

                System.out.println (member);

            }   

            if (input.equals ("2")) {

                System.out.println  ("Please enter an email address ...");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input == null)
                    continue;

                input = input.trim ();

                if (input.equals (""))
                    continue;

                msg = new JtMessage (EJBClient.CREATE);
                msg.setMsgContent (input);


                System.out.print  ("Name:");
                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input != null)
                    firstName = input.trim ();

                //factory.setValue (proxy, "firstname", input);

                System.out.print  ("Last Name:");
                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input != null)
                    lastName = input.trim ();

                valueObject = new JtValueObject ();
                msg1 = new JtMessage (JtValueObject.JtPUT);
                msg1.setMsgData("firstname");   
                msg1.setMsgContent(firstName);
                valueObject.processMessage(msg1);  
                msg1.setMsgData("lastname");   
                msg1.setMsgContent(lastName);
                valueObject.processMessage(msg1);  
                
                msg1 = new JtMessage (JtFactory.JtSET_VALUES);   
                msg1.setMsgContent(valueObject);
                factory.sendMessage (proxy, msg1);
                
                //factory.setValue (proxy, "lastname", input);
                reply = (String) factory.sendMessage (proxy, msg);

                if (reply == null)
                    System.out.println ("Error: unable to create record.");

            }     

            if (input.equals ("4")) {

                System.out.println  ("Please enter an email address ...");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input == null)
                    continue;

                input = input.trim ();

                if (input.equals (""))
                    continue;

                email = input;
                valueObject = (JtValueObject) findMember (input);

                if (valueObject == null) {
                    System.out.println ("Record doesn't exist:" + input);
                    continue;
                }

                System.out.print ("Do you want to delete this record(Y/N) ?");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input != null)
                    input = input.trim ();

                if (!("y".equals(input) || "Y".equals (input)))
                    continue;

                msg = new JtMessage (EJBClient.DELETE);

                msg.setMsgContent (email);
                reply = (String) factory.sendMessage (proxy, msg);

                if (reply == null)
                    System.out.println ("Unable to delete record.");        
            }  

            if (input.equals ("3")) {

                System.out.println  ("Please enter an email address ...");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input == null)
                    continue;

                input = input.trim ();

                if (input.equals (""))
                    continue;


                valueObject = (JtValueObject) findMember (input);

                if (valueObject == null) {
                    System.out.println ("Record doesn't exist:" + input);
                    continue;
                }

                modifyMember (input, valueObject);

                //if (reply == null)
                //System.out.println ("Unable to modify record.");

            }  

            if (input.equals ("5")) {

                System.out.println  ("Please enter an email address ...");

                input = (String) factory.sendMessage (keyboard, new JtMessage (JtObject.JtACTIVATE));

                if (input == null)
                    continue;

                input = input.trim ();

                if (input.equals (""))
                    continue;

                msg = new JtMessage (EJBClient.DISABLE);
                msg.setMsgContent (input);

                factory.sendMessage (proxy, msg);

            }  

            if (input.equals ("6")) {
                break;
            }  

        }

        // Remove the local proxy. 

        factory.removeObject (proxy);


    }

}



