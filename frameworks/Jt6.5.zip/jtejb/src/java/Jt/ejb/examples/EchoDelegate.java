package Jt.ejb.examples;

import Jt.*;
import Jt.ejb.*;
import Jt.examples.Echo;
import Jt.examples.HelloWorld;


// This class demonstrates the use of  
// the J2EE Business Delegate design pattern

public class EchoDelegate  {


	/**
	 * Demonstrates all the messages processed by JtBusinessDelegate. 
	 */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    String reply;
    JtBusinessDelegate delegate;
    //Boolean Bool;
    
    // Create an instance of JtBusinessDelegate (Jt implementation of
    // the J2EE business delegate pattern)

    delegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME);
    delegate.setClassname(Echo.JtCLASS_NAME);
   
    // Initialize the JtBusinessDelegate component
    
    //Bool = (Boolean) factory.sendMessage(delegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
    
    //if (!Bool.booleanValue()) {
    	// Failed to initialized the JtBusinessDelegate component
    //	System.err.println("Unable to initialize the business delegate ... exiting.");
    //	System.exit(1);
    //}
    
    // The JtBusinessDelegate component is ready to be used.
    // Send a message to the remote component

    reply = (String) factory.sendMessage (delegate, "Welcome to Jt messaging ...");    


    // Display the reply 
 
    System.out.println (reply);

	// Remove the business delegate
    
    factory.removeObject (delegate);

        
  }

}



