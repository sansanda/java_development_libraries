
package Jt.ejb.examples.bmp;

/**
 * Remote interface for Member (the local interface is being used).
 */
public interface Member
   extends javax.ejb.EJBObject
{
   //public static final String COMP_NAME="java:comp/env/ejb/JtStateful";
   //public static final String JNDI_NAME="JtStateful";



   public String getEmail() 
      throws java.rmi.RemoteException;

   public void setEmail (String email) 
      throws java.rmi.RemoteException;

/*
   public String getFirstname() 
      throws java.rmi.RemoteException;

   public void setFirstname (String firstName) 
      throws java.rmi.RemoteException;

   public String getLastname() 
      throws java.rmi.RemoteException;

   public void setLastname (String lastname) 
      throws java.rmi.RemoteException;
*/
}
