
package Jt.ejb.examples.bmp;

import javax.ejb.*;
import Jt.*;
import Jt.DAO.JtDAOAdapter;
import Jt.examples.*;
import java.util.*;


/**
 * Member EJB
 */

public class MemberEJB implements EntityBean
{
    private static final long serialVersionUID = 1L;
    EntityContext ctx;
    public String email;
    public String firstname;
    public String lastname;
    public int status;
    public String subject;
    public String comments;
    public Date tstamp;
    public int email_flag;
    public Date mdate;
    public String location;
    public boolean dirty = false;

    private transient DAOMember member = null;// check
    private transient JtFactory factory = new JtFactory ();
    private transient JtValueObject valueObject = null;
    //private transient boolean dirty = false;
    private transient boolean loaded = false;

    /**
     * A value object is returned containing the
     * attribute values. 
     */

    public Object calcValueObject () {

        JtValueObject valueObj;

        factory.handleTrace ("calcValueObject");

        valueObj = new JtValueObject ();
        factory.setValue (valueObj, "subject", this);


        factory.sendMessage (valueObj, new JtMessage (JtObject.JtACTIVATE));   
        return (valueObj);


    }

    public JtValueObject getValueObject () {
        valueObject = (JtValueObject) calcValueObject ();
        return (valueObject);

    }

    public void setValueObject (JtValueObject valueObject) {

        JtMessage msg;
        String tmp;
        JtFactory factory = new JtFactory ();
        Object out;

        this.valueObject = valueObject;

        if (valueObject == null)
            return;


        msg = new JtMessage (JtHashTable.JtGET);
        msg.setMsgData ("firstname");

        tmp = (String) valueObject.processMessage (msg);

        if (tmp != null)
            setFirstname (tmp);

        msg.setMsgData ("lastname");
        tmp = (String) valueObject.processMessage (msg);

        if (tmp != null)
            setLastname (tmp);


        msg.setMsgData ("location");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            setLocation (tmp);


        msg.setMsgData ("comments");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            setComments (tmp);

        msg.setMsgData ("subject");
        tmp = (String) valueObject.processMessage (msg);
        if (tmp != null)
            setSubject (tmp);

        msg.setMsgData ("status");
        out = (Object) valueObject.processMessage (msg);
        if (out != null)
            factory.setValue (this, "status", out);


        msg.setMsgData ("email_flag");
        out = (Object) valueObject.processMessage (msg);
        if (out != null)
            factory.setValue (this, "email_flag", out);

        dirty = true; //check
    }



    public String getEmail() {
        return (email);
    }

    public void setEmail (String email) {
        this.email = email;
    }

    public boolean getDirty() {
        return (dirty);
    }

    public void setDirty (boolean dirty) {
        this.dirty = dirty;
    }
    
    
    public void setEmail_flag (int newEmail_flag) {
        email_flag = newEmail_flag;
    }

    public int getEmail_flag () {
        return (email_flag);
    }

    public int getStatus () {
        return (status);
    }


    public void setStatus (int newStatus) {
        status = newStatus;
        //dirty = true;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject (String newSubject) {
        subject = newSubject;
    }

    public String getComments() {
        return comments;
    }

    public void setComments (String newComments) {
        comments = newComments;
    }

    public void setFirstname (String newFirstname) {
        firstname = newFirstname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setLastname (String newLastname) {
        lastname = newLastname;
    }

    public String getLastname() {
        return lastname;
    }


    public void setTstamp (Date tstamp) {
        this.tstamp = tstamp;
    }

    public Date getTstamp () {
        return tstamp;
    }

    public void setMdate (Date mdate) {
        this.mdate = mdate;
    }

    public Date getMdate () {
        return mdate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation (String location) {
        this.location = location;
    }


    private DAOMember createDAO () {
        DAOMember member;

        // Create DAO object

        member = (DAOMember) factory.createObject (DAOMember.JtCLASS_NAME);

        // Set database key and table

        factory.setValue (member, "key", "email");
        factory.setValue (member, "table", "member");

        factory.sendMessage (member, new JtMessage (JtDAO.JtREALIZE));
        // Attribute values should be in the resource file
        //member.setValue ("db", "driver", "com.mysql.jdbc.Driver");
        //member.setValue ("db", "url", "jdbc:mysql://localhost/test");
        //member.setValue ("db", "user", "root");
        //member.setValue ("db", "password", "123456");
        //member.setValue ("db", "datasource", "datasrc");

        return (member);

    }

    public String ejbCreate (String email, String firstname, String lastname) 
    throws CreateException {

        DAOMember tmp;
        Date date = new Date ();


        if (member == null)
            member = createDAO ();


        factory.setValue (member, "email", email);
        factory.setValue (member, "firstname", firstname);
        factory.setValue (member, "lastname", lastname);
        factory.setValue (member, "status", "1");
        factory.setValue (member, "tstamp", date);
        factory.setValue (member, "subject", null);
        factory.setValue (member, "comments", null);
        factory.setValue (member, "email_flag", "0");
        factory.setValue (member, "mdate", null);
        factory.setValue (member, "location", null);


        this.firstname = firstname;
        this.lastname = lastname;
        this.status = 1;
        this.tstamp = date;  
        this.subject = null;
        this.comments = null;
        this.email_flag = 0;
        this.mdate = null;
        this.location = null;



        tmp = (DAOMember) factory.sendMessage (member, new JtMessage (JtDAOAdapter.JtINSERT));

        if (tmp == null) { 
            throw new CreateException ("Unable to create member");
        } 

        return email;
    }


    public void setEntityContext (EntityContext ctx) {
        this.ctx = ctx;
    }

    public void unsetEntityContext () {
        ctx = null;
    }
    public void ejbLoad () {

        String primaryKey;
        DAOMember tmp;

        factory.handleTrace ("MemberEJB.ejbLoad .....");

        if (ctx == null)
            return; // check

        primaryKey = (String) ctx.getPrimaryKey ();


        if (loaded) {
            factory.handleTrace ("MemberEJB.ejbLoad: nothing to load .....");
            return;
        }


        if (member == null)
            member = createDAO ();


        factory.setValue (member, "email", primaryKey);
        tmp = (DAOMember) factory.sendMessage (member, new JtMessage (JtDAOAdapter.JtFIND));

        if (tmp == null)
            return;

        email = tmp.getEmail ();
        firstname = tmp.getFirstname ();
        lastname = tmp.getLastname ();
        status = tmp.getStatus ();
        subject = tmp.getSubject ();
        comments = tmp.getComments ();
        email_flag = tmp.getEmail_flag ();
        mdate = tmp.getMdate ();
        location = tmp.getLocation ();   
        tstamp = tmp.getTstamp ();


    }

    public void ejbStore () {


        factory.handleTrace ("MemberEJB.ejbStore .....");

        if (!dirty) {
            factory.handleTrace ("MemberEJB.ejbStore: nothing to update ....");
            return;
        }

        if (member == null)
            member = createDAO ();


        factory.setValue (member, "email", email);

        member.setEmail (email);
        member.setFirstname (firstname);
        member.setLastname (lastname);
        member.setStatus (status);
        member.setSubject (subject);
        member.setComments (comments);
        member.setEmail_flag (email_flag);
        member.setMdate (mdate);
        member.setLocation (location);   
        member.setTstamp (tstamp);


        factory.sendMessage (member, new JtMessage (JtDAOAdapter.JtUPDATE));
        dirty = false;


    }

    public void ejbRemove () {

        if (member == null)
            member = createDAO ();


        factory.setValue (member, "email", email);


        factory.sendMessage (member, new JtMessage (JtDAOAdapter.JtDELETE));

    }

    public void ejbPassivate () {

        //if (member != null)
        //    factory.removeObject ("member"); // check

        member = null;

    }
    public void ejbActivate () {

    }

    public String ejbFindByPrimaryKey (String primaryKey) throws FinderException {
        DAOMember tmp;


        if (member == null)
            member = createDAO ();

        factory.setValue (member, "email", primaryKey);

        factory.handleTrace ("MemberEJB.ejbFindByPrimaryKey:" + primaryKey);
        factory.handleTrace ("MemberEJB.ejbFindByPrimaryKey(this):" + this);

        tmp = (DAOMember) factory.sendMessage (member, new JtMessage (JtDAOAdapter.JtFIND));

        if (tmp == null) 
            throw new ObjectNotFoundException ();

        email = tmp.getEmail ();
        firstname = tmp.getFirstname ();
        lastname = tmp.getLastname ();
        status = tmp.getStatus ();
        subject = tmp.getSubject ();
        comments = tmp.getComments ();
        email_flag = tmp.getEmail_flag ();
        mdate = tmp.getMdate ();
        location = tmp.getLocation ();   
        tstamp = tmp.getTstamp ();
        loaded = true;
        dirty = false;

        return (primaryKey);
    }

    public void ejbPostCreate (String email, String firstname, String lastname) {
    }
}
