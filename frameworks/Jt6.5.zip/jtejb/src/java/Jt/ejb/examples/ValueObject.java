package Jt.ejb.examples;

import Jt.*;
import Jt.ejb.*;

import java.util.*;
import Jt.examples.*;

// This class demonstrates the Jt implementation of 
// the J2EE value object design pattern. A remote instance 
// of an object is created. A single request is used to return 
// its value object

public class ValueObject  {



  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    JtBusinessDelegate delegate;
    Member valueObject;
    //JtMessage msg;
    Boolean Bool;
    
    // Create an instance of JtBusinessDelegate (Jt implementation of
    // the J2EE business delegate pattern)

    delegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME, 
     "businessDelegate");
    delegate.setClassname (Member.JtCLASS_NAME);

      
    //Bool = (Boolean) factory.sendMessage(delegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
    
    //if (!Bool.booleanValue()) {
    	// Failed to initialized the JtBusinessDelegate component
    //	System.err.println("Unable to initialize the business delegate ... exiting.");
    //	System.exit(1);
    //}
    
    // The JtBusinessDelegate component is ready to be used.
    // Set an attribute value (remote component) via the
    // local JtBusinessDelegate component.
    
    factory.setValue (delegate, "email", "test@hotmail.com");
    factory.setValue (delegate, "tstamp", new Date ());
    factory.setValue (delegate, "status", "1");
    factory.setValue (delegate, "firstname", "John");
    factory.setValue (delegate, "lastname", "Doe");

    // This single request returns the Value Object

    valueObject = (Member) factory.sendMessage (delegate, new JtMessage (JtObject.JtVALUE_OBJECT));
    
    //factory.sendMessage (valueObject, new JtMessage (JtObject.JtPRINT));
    //valueObject = (Member) delegate.sendMessage ("member", new JtMessage (JtObject.JtVALUE_OBJECT));
    //factory.sendMessage (valueObject, new JtMessage (JtObject.JtPRINT));
    
    // Print the attribute values using the local instance of the Value Object
    // This is much faster and efficient.
    
    System.out.println ("Email =" + valueObject.getEmail());  
    System.out.println ("Tstamp =" + valueObject.getTstamp());
    System.out.println ("Status =" + valueObject.getStatus());   
    System.out.println ("First Name =" + valueObject.getFirstname());     
    System.out.println ("Last Name =" + valueObject.getLastname());     

       
    // Remove the business delegate. The remote instance is also removed.
    
    factory.removeObject(delegate);

        
  }

}



