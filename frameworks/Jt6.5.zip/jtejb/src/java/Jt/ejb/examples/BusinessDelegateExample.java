package Jt.ejb.examples;

import Jt.*;
import Jt.ejb.*;
import Jt.examples.HelloWorld;


// This class demonstrates the use of  
// the J2EE Business Delegate design pattern

public class BusinessDelegateExample  {


	/**
	 * Demonstrates all the messages processed by JtBusinessDelegate. 
	 */

  public static void main(String[] args) {

    JtFactory factory = new JtFactory ();
    String reply;
    JtBusinessDelegate delegate;
    JtMessage msg;
    String tmp;
    Exception ex;
    Boolean Bool;
    
    // Create an instance of JtBusinessDelegate (Jt implementation of
    // the J2EE business delegate pattern)

    delegate = (JtBusinessDelegate) factory.createObject (JtBusinessDelegate.JtCLASS_NAME);
    delegate.setClassname(HelloWorld.JtCLASS_NAME);
   
    // Initialize the JtBusinessDelegate component
    
    //Bool = (Boolean) factory.sendMessage(delegate, new JtMessage (JtBusinessDelegate.JtINITIALIZE_DELEGATE));
    
    //if (!Bool.booleanValue()) {
    	// Failed to initialized the JtBusinessDelegate component
    //	System.err.println("Unable to initialize the business delegate ... exiting.");
    //	System.exit(1);
    //}
    
    // The JtBusinessDelegate component is ready to be used.
    // Set an attribute value (remote component) via the
    // local JtBusinessDelegate component.
    
    //factory.setValue (delegate, "greetingMessage", "Hello there... welcome to Jt messaging.");

    tmp = (String) factory.getValue (delegate, "greetingMessage");

    System.out.println ("greetingMessage:" + tmp);

    msg = new JtMessage (HelloWorld.JtHELLO);

    // Send a message to the remote component

    reply = (String) factory.sendMessage (delegate, msg);    


    ex = (Exception) delegate.getObjException();


    // Display the reply unless an exception is detected

    if (ex == null)    
        System.out.println (reply);

	// Remove the business delegate
    
    factory.removeObject (delegate);

        
  }

}



