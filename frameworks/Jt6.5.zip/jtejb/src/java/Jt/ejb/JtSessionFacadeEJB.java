



package Jt.ejb;

import javax.ejb.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import Jt.*;


/**
 * Jt implementation of the J2EE Session Facade pattern.
 * Provides an EJB interface to the Jt API. This bean is invoked by 
 * JtEJBAdapter and JtBusinessDelegate. By using JtEJBAdapter, J2EE 
 * clients are able to transparently manipulate remote Jt components. 
 *
 * @ejb:bean type="Stateful"
 *     name="JtSessionFacade"
 *     jndi-name="JtSessionFacade"
 *     display-name="Jt Session Facade"
 */

public class JtSessionFacadeEJB implements SessionBean {

    private static final long serialVersionUID = 1L;
    private JtFactory factory = new JtFactory ();
	//private JtRemoteFacade messenger = null;


    // Implement the methods in the SessionBean interface


    public void ejbActivate()  {  
    }

    public void ejbRemove() {

    }

    public void ejbPassivate() {

    }

    /**
     * Sets the session context.
     *
     * @param ctx  session context
     */

    public void setSessionContext(SessionContext ctx) 
    throws javax.ejb.EJBException, java.rmi.RemoteException 
    {
    }



    public void ejbCreate () {

    }



  
    /*  
    public Object sendMessage (Object session, Object objId, Object msgId) 
    throws JtException  
    {
    	

        Object reply;
        Exception ex;
        
        if (messenger == null) {   
        	// Create an instance of JtRemoteMessenger. This component sends messages to the
        	// other remote components. It handles security, encryption, etc. 

        	factory.setSingleton(true);
        	messenger = (JtRemoteFacade) factory.createObject (JtRemoteFacade.JtCLASS_NAME);
        	factory.setSingleton(false);    	

        }
        
    	reply = messenger.processMessage(msgId);
    	
        ex = (Exception) messenger.getObjException ();

        if (ex != null) {
         
          throw new JtException (ex.getMessage ());
        }  
    	
    	return (reply);
    	
    }
    */
	private String stackTrace (Exception ex ) {
	      ByteArrayOutputStream bstream;


	      if (ex == null)
	          return (null);

	      bstream = new ByteArrayOutputStream ();
	      

	      ex.printStackTrace (new PrintWriter (bstream, true));


	      return (bstream.toString ());


	  }
    
	private JtRemoteException generateRemoteException (Exception ex) {
		JtRemoteException jre;
		
		if (ex == null)
			return (null);
		
		jre = new JtRemoteException (ex.getMessage());
		jre.setTrace (stackTrace (ex));
		
		return (jre);
	}
    
    
    public Object processMessage (Object message) 
    throws JtException  
    {
    	

        Object reply;
        Exception ex;
        JtRemoteFacade messenger = null;
        
        //if (messenger == null) {   
        	// Create an instance of JtRemoteMessenger. This component sends messages to the
        	// other remote components. It handles security, encryption, etc. 

        	//factory.setCreateSingleton(true);
        	messenger = (JtRemoteFacade) factory.createObject (JtRemoteFacade.JtCLASS_NAME);
        	//factory.setCreateSingleton(false);    	

        //}
        
    	reply = messenger.processMessage(message);
    	
        ex = (Exception) messenger.getObjException ();

        if (ex != null) {
         
          //throw new JtException (ex.getMessage ());
        	throw generateRemoteException (ex);
        }  
    	
    	return (reply);
    	
    }
    


}
