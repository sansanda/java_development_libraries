
package Jt.ejb;

/**
 * Home interface for JtSessionFacade.
 */
public interface JtSessionFacadeHome
   extends javax.ejb.EJBHome
{
   public static final String COMP_NAME="java:comp/env/ejb/JtStateful";
   public static final String JNDI_NAME="JtStateful";

   public JtSessionFacade create()
      throws javax.ejb.CreateException,java.rmi.RemoteException;

}
