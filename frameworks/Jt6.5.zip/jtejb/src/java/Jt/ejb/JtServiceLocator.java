package Jt.ejb;
import javax.naming.*;
import java.util.Properties;
import Jt.*;


/**
 * Jt Implementation of the J2EE service locator pattern.  
 */

public class JtServiceLocator extends JtObject {

    private String url = "t3://localhost:7001"; // Default value (Weblogic)
    private String user = null;
    private String password = null;
    private String factory = "weblogic.jndi.WLInitialContextFactory"; // Default value (Weblogic)
    public static final String JtCLASS_NAME = JtServiceLocator.class.getName(); 
    private String jndiName = "JtSessionFacade";  // Default value
    private Class sclass = JtSessionFacadeHome.class; // Default value
    private static final long serialVersionUID = 1L;

    //private String url;
    //private String user;
    //private String password;
    //private String factory;

    /**
     * Specifies the service class. EJBHome class in the case of EJBs
     * @param sclass service class
     */

    public void setSclass (Class sclass) {
        this.sclass = sclass; 

    }


    /**
     * Returns the service class. 
     */


    public Class getSclass () {
        return (sclass);
    }


    /**
     * Specifies the URL (initial context).
     * @param url url
     */

    public void setUrl (String url) {
        this.url = url; 

    }

    /**
     * Returns the url. 
     */

    public String getUrl () {
        return (url);
    }


    /**
     * Specifies the user (initial context).
     * @param user user
     */

    public void setUser (String user) {
        this.user = user; 
    }

    /**
     * Returns the user. 
     */

    public String getUser () {
        return (user);
    }


    /**
     * Specifies the password (initial context).
     * @param password password
     */

    public void setPassword (String password) {
        this.password = password; 
    }


    /**
     * Returns the password. 
     */

    public String getPassword () {
        return (password);
    }

    /**
     * Specifies the context factory (initial context).
     * @param factory factory
     */

    public void setFactory (String factory) {
        this.factory = factory; 
    }


    /**
     * Returns the context factory. 
     */


    public String getFactory () {
        return (factory);
    }

    /**
     * Specifies the JNDI name.
     * @param jndiName JNDI name
     */

    public void setJndiName (String jndiName) {
        this.jndiName = jndiName; 
    }


    /**
     * Returns the JNDI name. 
     */

    public String getJndiName () {
        return (jndiName);
    }


    // Locate the service 

    private Object activate () {

        Object dhome = null;


        try {

            Context ctx = getInitialContext();
            
            if (ctx == null) {
                handleError ("unable to get initial context");
                return (null);
            }
            //Context ctx  = new InitialContext();
            Object objref = ctx.lookup (jndiName);

            dhome = (Object) 
            javax.rmi.PortableRemoteObject.narrow (objref, sclass);


        } catch (Exception e) {
            handleException (e);
        }
        return (dhome);

    }

    
    /**
     * Process object messages.
     * <ul>
     * <li> JtACTIVATE - Activates this object to locate a service.
     * </ul>
     * @param event message
     */

    public Object processMessage (Object msg) {

        String msgid = null;
        JtMessage e = (JtMessage) msg;
        //Object content;

        if (e == null)
            return null;

        msgid = (String) e.getMsgId ();

        if (msgid == null)
            return null;

        //content = e.getMsgContent();

        // Locate the service (JtACTIVATE)

        if (msgid.equals (JtObject.JtACTIVATE)) {

            return (activate ());

        }


        if (msgid.equals (JtObject.JtREMOVE)) {

            return (null);

        }

        //return (super.processMessage(event));
        handleError ("JtServiceLocator.processMessage: invalid message id:" + msgid);
        return (null);

    }


    /**
     * Gets an initial context.
     *
     */

    private Context getInitialContext() throws Exception {

        Properties p = new Properties();
        
        if (factory == null || url == null) {
            handleWarning ("getInitialContext(): invalid factory and/or url");
            return (null);
        }    
        
        p.put(Context.INITIAL_CONTEXT_FACTORY,
                factory);
        
        p.put(Context.PROVIDER_URL, url);
        
            
        if (user != null) {
            //System.out.println ("user: " + user);
            p.put(Context.SECURITY_PRINCIPAL, user);
            if (password == null) 
                password = "";
            p.put(Context.SECURITY_CREDENTIALS, password);
        } 
        return new InitialContext(p);
    }


    /**
     * Demonstrates all the messages processed by JtServiceLocator. 
     */

    public static void main (String[] args) {
        JtFactory factory = new JtFactory ();
        JtServiceLocator locator;
        JtSessionFacadeHome jtservice;


        // Create an instance of JtServiceLocator

        locator = (JtServiceLocator) factory.createObject (JtServiceLocator.JtCLASS_NAME);

        // Set the service locator attributes

        locator.setJndiName("JtSessionFacade");
        locator.setSclass(JtSessionFacadeHome.class);

        // Activate the Service Locator (locate the Service)

        jtservice = (JtSessionFacadeHome) factory.sendMessage (locator, new JtMessage (JtObject.JtACTIVATE));


        if (jtservice != null)
            System.out.println  ("JtServiceLocator: GO");  
        else
            System.out.println  ("JtServiceLocator: FAIL");  



    }
}
