package Jt.ejb;

import java.util.Date;

import Jt.JtComponent;
import Jt.JtEnvelope;
import Jt.JtFactory;
import Jt.JtMessage;
import Jt.JtMessenger;
import Jt.JtObject;
import Jt.JtProxy;
import Jt.JtRemoteProxy;
import Jt.axis.JtAxisProxy;
import Jt.examples.DateService;
import Jt.examples.HelloWorldMessage;



/**
 * A Proxy to a remote component.
 */


public class JtEJBProxy extends JtRemoteProxy {
	public static final String JtCLASS_NAME = JtEJBProxy.class.getName(); 
	private boolean initialized = false;
	private transient JtFactory factory = new JtFactory ();	


	private static final long serialVersionUID = 1L;

	public JtEJBProxy() {
	}

	
	private boolean initializeProxy (boolean encrypted) {
		JtMessage msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		Object output;

		JtMessenger messenger = new JtMessenger ();
		
	
		if (classname == null && remoteComponentId == null) {
			handleError ("Classname (or remoteComponentId) needs to be set.");
			return false;
		}

		
		if (remoteComponentId != null) {
			msg = new JtMessage (JtFactory.JtLOOKUP);
		    msg.setMsgContent(remoteComponentId);
		} else {
			msg = new JtMessage (JtFactory.JtCREATE_OBJECT);
		    msg.setMsgContent(classname);
		}

		
		// Initialize the adapter
		// Create the EJB Adapter as a singleton
		// for better performance
		//factory.setSingleton(true);
		adapter = (JtEJBAdapter) factory.createObject(JtEJBAdapter.JtCLASS_NAME);
		//factory.setSingleton(false);
		
		//output =  factory.sendMessage(adapter, msg);
		messenger.setEncrypted(encrypted);
		messenger.setUseEnvelope(true);
		output =  messenger.sendMessage(adapter, msg);
				
		if (output == null) {
			if (remoteComponentId  != null)
				handleTrace ("unable to create a proxy to remote component: " + 
						remoteComponentId);				
			else
				handleTrace ("unable to create remote component: " + 
						classname);
			
			propagateException (adapter);
			return (false);
		}    
	      

		this.setSubject(output);

		return (true);
	}
	


	/**
	 * Process object messages by forwarding them to the proxy's subject.  
	 */

	public Object processMessage (Object message) {
		//JtMessage msg;
		Object output;

		String msgid = null;
		JtMessage e;
		boolean bool;

		if (message == null) {
			handleError ("Invalid message (null)");
			return null;
		}
		
		this.setObjException(null);
		
		if (message instanceof JtMessage) {
			e = (JtMessage) message;

			msgid = (String) e.getMsgId ();

			if (msgid == null) {
				handleError ("Invalid message Id (null)");
				return null;
			}
			
			if (msgid.equals (JtProxy.JtINITIALIZE_PROXY)) {
				bool = initializeProxy (e.isEncrypt());
				initialized = bool;
				return (new Boolean (bool));
			}
			
			if (!initialized) {
				initialized = initializeProxy (e.isEncrypt());
				if (!initialized)
					return null;
			}

		    //e.setMsgTo(this.getSubject());

			
			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output); 
		}
		
		if (message instanceof JtEnvelope) {
			output = adapter.processMessage (message); 
			
			
			propagateException (adapter);
			return (output); 
			
		}
		
		handleError ("Invalid message type:" + message.getClass().getName()); 
		return (null);

	}
	


	// Propagate Exceptions 

	private Exception propagateException (JtObject obj)
	{
		Exception ex;

		if (obj == null)
			return null;

		ex = (Exception) obj.getObjException();


		if (ex != null)
			this.setObjException(ex);

		return (ex);
	}

	/**
	 * Demonstrates all the messages processed by JtEJBProxy. 
	 */

	public static void main(String[] args) {

		JtFactory factory = new JtFactory ();
		String reply, tmp;
		Exception ex;
		JtMessage msg;
		JtEJBProxy proxy;
		Boolean Bool;
		Date date;


		// Create an EJB proxy. This local proxy
		// will reference the remote component

		proxy = (JtEJBProxy) factory.createObject (JtEJBProxy.JtCLASS_NAME);

		proxy.setClassname(HelloWorldMessage.JtCLASS_NAME);
		//proxy.setRemoteComponentId("jtEchoComponent");
		//factory.setValue (proxy, "logLevel", "0");
		//factory.setValue (proxy, "logging", "true");

		// Initialize the Proxy

		//Bool = (Boolean) factory.sendMessage(proxy, new JtMessage (JtProxy.JtINITIALIZE_PROXY));

		//if (!Bool.booleanValue()) {
			// Failed to initialized the proxy
		//	System.err.println("Unable to initialize the local proxy to the remote component.");
		//	System.exit(1);
		//}

		// The local proxy is ready to be used.
		// Set an attribute value (remote component) via the
		// local proxy.

		factory.setValue (proxy, "greetingMessage", "Hello there...");

		tmp = (String) factory.getValue (proxy, "greetingMessage");

		System.out.println ("greetingMessage:" + tmp);


		// Send a message to the remote component
		
		//factory.setEncrypted(true);

		reply = (String) factory.sendMessage (proxy, "hi");    

		// Retrieve any exception that might have occurred.
		// Exceptions are propagated automatically by the framework.

		ex = (Exception) proxy.getObjException(); 

		// Display the reply unless an exception is detected

		if (ex == null)    
			System.out.println (reply);


		
		proxy = (JtEJBProxy) factory.createObject (JtEJBProxy.JtCLASS_NAME);
		proxy.setClassname ("Jt.examples.DateService");
		//service.setEncrypted(false);
		msg = new JtMessage (DateService.GET_DATE);
		
		// The reply message is automatically converted to
		// the appropriate Java type by the framework
		
		date = (Date) factory.sendMessage (proxy, msg);
		
		if (proxy.getObjException() == null)
			System.out.println ("Reply date:" + date);

		// Remove the EJB proxy (cleanup)
		
		factory.removeObject (proxy);
		
		proxy = (JtEJBProxy) factory.createObject (JtEJBProxy.JtCLASS_NAME);
		proxy.setClassname ("Jt.examples.EchoService");
			
	    // Specify that secure/encrypted messaging should be used
		//messenger.setEncrypted(true);
		
	    // Send the message to the remote component/service.
		
		//Bool = (Boolean) factory.sendMessage (proxy, new JtMessage (JtComponent.JtACTIVATE));


	}
}
